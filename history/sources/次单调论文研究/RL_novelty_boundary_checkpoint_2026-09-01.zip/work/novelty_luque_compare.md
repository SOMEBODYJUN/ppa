# Luque 1981/1984 与冻结 RL 基线的逐定理重叠审稿

> project_id: `monotonicity-regularity-seesaw-2026-09`  
> paper_family: `T`  
> stage_id: `T2`  
> task_id: `RL-NOV-LUQUE-COMPARE-14`  
> reading_depth: `DEEP`  
> 核心裁决：**Luque 已经在 maximal-monotone/full-resolvent 框架内，以 full inverse power growth 推出了 exact PPA 的集合距离端点递推 \(d_{k+1}=O(d_k^s)\)，而且允许非孤立解集。冻结稿不得把这一核心链条作为新贡献。相对于 Luque 仍未被覆盖的是 restricted/nonmonotone named branch、\(\gamma<1\) reflector composition、two-anchor alignment/\(\theta q\)、branch-scope 逻辑以及相应 sharpness 边界；这些只是 Luque-bounded residue，不等于已完成全局新颖性证明。**

## 1. scope_and_inputs

### 1.1 来源深度与身份

- `[原文事实 / VERIFIED_SOURCE]` [Fernando Javier Luque, LIDS-P-1142, September 1981, full prepublication PDF](https://pdfs.semanticscholar.org/8733/1e54b6595ad42fdb76dbb13e347b0aa3128f.pdf)。这是完整扫描稿，题名为 *Asymptotic Convergence Analysis of the Proximal Point Algorithm*，题名页注明 “To appear in SIAM Journal on Control and Optimization”。本地下载副本 SHA-256 为 `af357dfe1e7036892523061496218d040817630104d25b03111b2d2a79004e78`。
- `[外部核验 / VERIFIED_SOURCE]` [SIAM 正式出版页](https://epubs.siam.org/doi/10.1137/0322019)确认作者为 **Fernando Javier Luque**，卷期为 *SIAM Journal on Control and Optimization* 22(2), March 1984, pp. 277--293，DOI `10.1137/0322019`，投稿日为 21 September 1981。作者不是 “R. Luque”。
- `[用户材料 / VERIFIED_USER_MATERIAL]` 冻结对照基线为 `research/RL_foundations.md`，复核 SHA-256：`0adf8ca1593148bebce576e9659f3da50e61a77880c0b311cbcc35d0dcbb4ebd`。本任务未修改该文件。
- `[原文事实 / VERIFIED_SOURCE]` 为回应反向一致性检查，仅定点核对了 [Ciyou Zhu 的 Argonne primary prepublication P457](https://ftp.mcs.anl.gov/pub/tech_reports/reports/P457.pdf)中作者对 Luque rate object 的说明及 Theorem 4.3；没有进行新的广泛文献检索。

本报告的逐式判断绑定于 1981 LIDS 全文。SIAM 页面只开放元数据与摘要，因此本报告不声称已经逐页证明 1981 prepublication 与 1984 最终排版逐字相同；但正式页的题名、作者、摘要、投稿时间与出版记录闭合了二者的书目对应。

### 1.2 记号与比较问题

Luque 记解集为 \(\bar Z=T^{-1}(0)\)，其记号

\[
|z-\bar Z|=\min_{z'\in\bar Z}\|z-z'\|=d(z,\bar Z)
\]

是**到解集的距离**。为避免扫描稿上横线造成混淆，以下写

\[
d_k:=d(z^k,\bar Z),\qquad
\widehat d_k:=d(P_kz^k,\bar Z),\qquad
P_k=(I+c_kT)^{-1}.
\]

冻结稿的解集写作 \(S=F^{-1}(0)\)，power error bound 为

\[
d(u,S)\le \rho r_F(u)^q,
\qquad r_F(u):=\inf\{\|u^*\|:u^*\in F(u)\}.
\]

审稿问题限定为：上述两个 full residual-to-set-distance 条件、PPA 速率对象、端点指数、步长、operator/branch scope，以及 reflector/alignment 结构是否真正重合。

## 2. specialist_findings

### 2.1 Luque 指定公式与定理的逐式读取

| 对象 | 原文定位 | `[原文事实 / VERIFIED_SOURCE]` 精确内容与边界 |
|---|---|---|
| (1.4) | PDF p. 10，印刷页 “-8-” | 存在 δ>0，使对每个 \(w\in B(0,\delta)\) 与每个 \(z\in T^{-1}w\)，\(d(z,\bar Z)\le f(\|w\|)\)，其中 \(f(0)=0\) 且在 0 上半连续（此处等价于在 0 连续）。Proposition 1.2 据此推出 \(d_k\to0\)。Luque 随即注明 (1.4) 是充分而非必要条件。 |
| Theorem 2.1 | PDF pp. 12--14，印刷页 “-10-”--“-12-” | 取线性 inverse growth \(d(z,\bar Z)\le a\|w\|\)。对满足 \((A_r)\)、\(r\ge1\) 的 approximate PPA，以及正且非减的 \(c_k\uparrow c_\infty\le+\infty\)，集合距离线性收敛；若 \(c_\infty<\infty\)，rate 上界为 \(a/(a^2+c_\infty^2)^{1/2}<1\)；若 \(c_\infty=+\infty\)，则 superlinear。解集不要求单点。 |
| Q-order 定义 | PDF p. 19，印刷页 “-17-” | 假设 \(d_k\ne0\) 对所有 k，Q-order 是所有满足 \(\tau\ge1\) 且 \(\limsup_k d_{k+1}/d_k^\tau<+\infty\) 的 τ 的上确界。该定义不自动表示上确界被达到，更不表示归一化比值趋于正有限常数。 |
| Theorem 3.1 | PDF pp. 19--21，印刷页 “-17-”--“-19-” | 扫描原文参数是 \(r\ge1\)、\(s\ge1\)。假设 \(d(z,\bar Z)\le a\|w\|^s\) 对所有小 w 及所有 \(z\in T^{-1}w\) 成立，且 \(c_k>0\) 非减；则 \(d_k\to0\)，其 Q-order \(t\ge\min\{r,s\}\)。superlinear 子情形当然要求 \(\min\{r,s\}>1\)。 |
| recurrence (3.7) | PDF p. 21，印刷页 “-19-” | 令 \(\varepsilon_k\) 为 \((A_r)\) 中 summable inexactness，原式为 \[ d_{k+1}\le \frac{a d_k^s}{(1-\varepsilon_k)\bigl(c_k^2+a^{2/s}\widehat d_k^{\,2(s-1)/s}\bigr)^{s/2}} +\frac{2\varepsilon_k}{(1-\varepsilon_k)^r}d_k^r. \tag{L-3.7}\] 因此正式的 “Q-order at least” 结论来自一个包含端点幂的逐步 upper recurrence。 |
| Theorem 3.2 | PDF pp. 23--25，印刷页 “-21-”--“-23-” | flat inverse 条件是 \(T^{-1}(B(0,\delta))\subset\bar Z\)，即所有足够小 output 的 preimage 已经是解。只要求 \(\liminf c_k>0\)。大 k 时 \[d_{k+1}\le \frac{\varepsilon_k}{(1-\varepsilon_k)^r}d_k^r.\tag{L-3.9}\] exact PPA（ε_k≡0）有限步终止；inexact 情形给相应 superlinear 结论。原文明确指出 \(\bar Z\) 不必单点，甚至不必紧。 |

Luque 的 approximate stopping criterion 是

\[
\|z^{k+1}-P_kz^k\|
\le\varepsilon_k\min\{1,\|z^{k+1}-z^k\|^r\},
\qquad \sum_k\varepsilon_k<\infty.
\]

因此 “Luque 只处理 exact/fixed-step PPA” 不是可接受的概括。

### 2.2 full inverse growth 是否等于本项目 full power EB

**裁决：数学核相同，原始量词不逐字相同。** 令 \(T=F\)、\(S=\bar Z\)、\(q=s\)、\(\rho=a\)。Luque 的 power condition 可写成

\[
\|w\|<\delta
\Longrightarrow
T^{-1}(w)\subset\{z:d(z,S)\le a\|w\|^s\}.
\tag{L-IG}
\]

冻结 PEB 是 base-local/residual-windowed 的

\[
z\in U,\quad r_T(z)<\delta
\Longrightarrow
d(z,S)\le a r_T(z)^s.
\tag{RL-PEB}
\]

`[AI分析 / AI_INFERENCE]` 两方向关系如下。

1. `(L-IG) ⇒ PEB`：若 (r_T(z)<\delta)，取 (w_n\in Tz) 使 \(\|w_n\|\downarrow r_T(z)\)。大 n 时 \(\|w_n\|<\delta\)，故
   \[
   d(z,S)\le a\|w_n\|^s\to a r_T(z)^s.
   \]
   Luque 的写法甚至不限制 z 落在某个 base neighborhood，因此它给出 output-local、global-in-z 的 PEB。
2. `(RL-PEB) ⇒ local inverse growth`：若 (z\in U\)、(w\in Tz\)、\(\|w\|<\delta\)，则
   \[
   r_T(z)\le\|w\|,
   \qquad
   d(z,S)\le a r_T(z)^s\le a\|w\|^s.
   \]
   这只得到 (T^{-1}(w)\cap U) 的 inclusion；除非 (U=H) 或另有排除 remote points 的条件，否则不能升级为 Luque 原式的 global-in-z 量词。

所以安全措辞是：**Luque (1.4) 的 power specialization 与冻结稿 full PEB 是同一个 full residual-to-set-distance mechanism，在共同 localization 中等价；Luque 原式对 base variable 的范围更强。** 不能说二者毫无关系，也不能忽略 localization 后宣称字面同一定义。

### 2.3 exact PPA：端点 (s) 还是只有 sup-order

**裁决：exact PPA 直接给端点 upper recurrence。** 在 exact 情形 ε_k=0 且 (z^{k+1}=P_kz^k)，所以 \(\widehat d_k=d_{k+1}\)。由 (L-3.7)，

\[
d_{k+1}
\le
\frac{a d_k^s}
{\bigl(c_k^2+a^{2/s}d_{k+1}^{,2(s-1)/s}\bigr)^{s/2}}
\le
\frac{a}{c_k^s}d_k^s.
\tag{L-endpoint}
\]

由于 Theorem 3.1 的 (c_k) 正且非减，(c_k\ge c_0>0)，故

\[
d_{k+1}=O(d_k^s).
\]

`[AI分析 / AI_INFERENCE]` 这意味着端点 τ=s 本身属于 Luque Q-order 定义的 admissible set，而不是只证明每个 τ<s。Theorem 3.1 仍只声称 **order at least s**；它没有证明：

- order 恰等于 s；
- two-sided exact exponent s；
- (d_{k+1}/d_k^s\to c\in(0,+\infty))；
- 非终止（Theorem 3.2 的 exact 情形反而有限终止）。

这正对应冻结稿注 5.4 的 “upper order ≠ two-sided exact exponent ≠ positive exact Q-factor” 边界。

### 2.4 Luque 与 Zhu 的反向区分：rate object 与 endpoint 不可串台

`[原文事实 / VERIFIED_SOURCE]` Zhu 的导论明确说，其几何分析给出 sequence (z^k) 本身的 rate，而 Luque 的结论 “mostly” 控制 (d(z^k,\bar Z))。Zhu Theorem 4.3 在 (r>1) 时对每个 (1<t<r) 给

\[
\limsup_k
\frac{\|z^{k+1}-z^\infty\|}{\|z^k-z^\infty\|^t}=0,
\]

即 **actual-iterate-to-limit / every strict subendpoint (t<r)**。与之相反，本次从 Luque (3.7) 独立核出的结论是 **set distance / endpoint (s)**：

| 来源 | rate object | 已明确的 exponent strength |
|---|---|---|
| Luque Theorem 3.1 + (3.7) | (d(z^k,\bar Z)) | exact PPA 直接有 endpoint upper (d_{k+1}=O(d_k^s))，但不证明 exact factor |
| Zhu Theorem 4.3 | ∥(z^k-z^\infty)∥ | 每个 (1<t<r) 的 actual-iterate superlinear 结论；正式定理未写 endpoint (O(e_k^r)) |

两者是交叉而非替代：不能用 Zhu 的 actual-iterate 结论否认 Luque 已有 set-distance endpoint，也不能把 Luque 的 endpoint 自动改写成非孤立情形的 actual-iterate endpoint。

### 2.5 actual iterate 与 set distance 的完整量词审计

| 结果 | 非孤立解集？ | 定量对象 | 可否直接称 actual-iterate endpoint？ |
|---|---:|---|---|
| Luque Thm 2.1 / 3.1 | 是 | (d(z^k,\bar Z)) | 否。Rockafellar 全局定理给 weak convergence 到某个解，但本次核读的 rate theorem 没有给 ∥(z^k-z^\infty)∥ 的同阶端点。 |
| Luque Thm 3.2 exact | 是 | 进入 ̅Z 后有限终止 | 是有限终止意义，不是正 Q-factor。 |
| RL Thm 4.2 | 是 | (r_k=d(x^k,S))，另有 finite length、strong (x^k\to x^\infty\in S) 与 tail bound (4.16) | 同时控制 actual iterate，但 power corollaries 的一阶递推首先是 set distance。 |
| RL Cor. 5.1--5.3 | 是 | (r_{k+1}) 对 (r_k) 的 upper recurrence | 单独不可改写为 exact actual-iterate Q-factor。 |
| RL Thm 7.4 | locally isolated | (r_k=\|x^k-p\|) | 是 actual error，因为 isolation 使 set distance 等于到 p 的距离；仍只是 upper order。 |
| RL Thm 8.2 / Prop. 9.1 | 是 | map-level (d(Jx,S)) 与 alignment envelopes | 否；它们没有把结论改成 ∥(x^k-x^\infty)∥ 的 endpoint。 |
| GX-071--073 | 依各例 | 冻结稿明示的 set-distance / one-step / orbit radius | 只能使用各例“判定”栏的强度，不能统一升级为 actual-iterate exact factor。 |

### 2.6 theorem-by-theorem overlap matrix

| 冻结 RL 对象 | Luque 对应对象 | 重叠裁决 | 不重叠的安全边界 |
|---|---|---|---|
| Thm 4.2 localized gauge--PPA | (1.4), Prop. 1.2, Thm 2.1/3.1 | **部分重叠、scope 不可比。** 都把 output residual growth 传到 set-distance convergence。Luque 已有 full maximal-monotone resolvent、nonisolated、approximate/variable-step；RL 4.2 有 fixed-step exact named branch、显式 local coverage/anchoring/invariance、finite length 与 strong convergence。 | 可说冻结定理在没有 maximal monotonicity 的 named branch 上闭合了 local validity；不可说它整体推广或包含 Luque，因为未覆盖 Luque 的 inexact/variable-step 结果。 |
| Cor. 5.1, (0<\gamma<1,L>0) | 无同型 Luque 参数 | **无直接公式重叠。** Luque 的 s 是 inverse-growth exponent，不是 reflector exponent γ。 | γq phase 是 Luque 未讨论的 restricted Hölder-reflector composition；仍只是 conditional upper order，不是普适 exact law。 |
| Cor. 5.2, γ=1 | Thm 2.1、Thm 3.1、(3.7) | **直接 special-case overlap。** maximal monotonicity 使 reflector 隐含为 nonexpansive，即冻结坐标中的 (L=1,\gamma=1)。q=s>1 时 exact fixed-step 的 coarse endpoint 常数与 Luque 完全吻合。q=1 时 Luque 的 rate 更强。 | 只有 (L\ne1)、nonmonotone/restricted named branch、local invariance 等 scope residue 未被 Luque 覆盖。不能把 γ=1 的 PEB→q-order 本身作为新结论。 |
| Cor. 5.3, (L=0) q-phase | Thm 3.2 的 flat inverse | **不是同一退化轴。** RL 的 (L=0) 表示 restricted reflector 为常值；Luque Thm 3.2 表示 inverse-growth gauge 在 output ball 上为 0，即 (T^{-1}(B(0,\delta))\subset S)。 | 可以说 RL 识别了 reflector-degenerate 仍由 q 控制的 phase；不可称其为 Luque (s=+\infty) 的重述或推广。 |
| Thm 7.4 isolated named PPA | Thm 3.1 exact，取 ̅Z 局部为 {p} | **order implication 直接重叠。** Luque 已在 maximal monotone/full resolvent 特例给 actual error (O(e_k^s))。RL 7.4 的常数 (\rho(2/\lambda)^q) 来自无 firm monotonicity 的三角估计，不能冒充对 Luque 常数的改进。 | named possibly-nonmonotone branch、output return/small-residual localization、reflection-defect (7.8) 是 Luque 未给的结构包装。 |
| Thm 8.2 nonisolated alignment θq | Luque Thm 3.1 的 nonisolated set distance | **主题邻近、机制不同。** Luque 依 firm inequality 直接有 residual-step control，相当于无需引入显式 two-anchor θ；他没有 (a_J,\delta_J,\mathcal A_J\) 或 θq law。 | 可强调在非 firm/nonmonotone named branch 中把 nearest-solution drift 单独参数化；不可声称“首次允许非孤立解集的高阶 PPA”。 |
| Prop. 9.1 joint saturation | 无 | **无直接定理重叠。** Luque 不分析 alignment×residual×endpoint 三个同序列 two-sided ratios。 | 只能声称该 factorization/sharpness criterion 不在 Luque 中；指数相乘本身是一行代数，不足以单独支撑重大新颖性。 |
| GX-071 | 无 maximal-monotone 对应 | **不被 Luque class 覆盖。** 其 γ<1 reflector、tangential drift 与 exact γq witness 属于 generated/restricted nonmonotone geometry。 | 安全 claim 是在声明 class 中 attainability 与 normalized limit 1；不是 universal optimality。 |
| GX-072 | 无 | **不被 Luque class 覆盖。** 它显示 all-pairs γ 可保守而 actual orbit set-distance order 为 q。 | 不可用它否定 Luque；也不可把 γq 称为 universal exact exponent。 |
| GX-073 | 无 | **不被 Luque full-domain resolvent class 覆盖。** restricted natural domain 上 one-step expansion 后逃逸。 | 只判决 one-step scale ≠ convergence order、invariance 不可省；不是 q>1 PEB theorem 的反例。 |

### 2.7 常数级特化：最直接的重复证据

`[AI分析 / AI_INFERENCE]` 对 maximal monotone T，full resolvent (J_{\lambda T}) 满域单值且 reflector (R=2J-I) 非扩张。因此冻结 RL 参数取

\[
\gamma=1,\qquad L=1,\qquad \rho=a,\qquad q=s,
\qquad c_k\equiv\lambda.
\]

冻结 Corollary 5.2 的 (5.6) 变成

\[
r_{k+1}
\le a\left(\frac{1+1}{2\lambda}\right)^s r_k^s
=\frac{a}{\lambda^s}r_k^s,
\]

与 Luque (L-endpoint) 的 fixed-step coarse bound **逐项相同**。这是判定 direct overlap 的最强证据。

线性端点 (s=q=1) 则相反地显示冻结 generic bound 较弱：

\[
\text{RL Cor. 5.2: }r_{k+1}\le(a/\lambda)r_k,
\quad\text{须 }a/\lambda<1;
\]

而 Luque Theorem 2.1 在 fixed λ 下给

\[
\limsup_k\frac{d_{k+1}}{d_k}
\le\frac{a}{\sqrt{a^2+\lambda^2}}<1
\quad\text{对每个 }a>0.
\]

原因是 Luque 使用 maximal monotonicity 的 Pythagorean/firm inequality；冻结 4--5 章的 generic anchored path 没有利用这项更强结构。故不能声称冻结 q=1 推论在 monotone case 改进了 Luque。

### 2.8 fixed/variable stepsize、full/named branch、reflector/alignment 总表

| 维度 | Luque 1981/1984 | 冻结 RL 基线 | 审稿结论 |
|---|---|---|---|
| stepsize | Thm 2.1/3.1：(c_k>0) 非减，可趋有限值或 +∞；Thm 3.2：仅 λinf (c_k>0) | 固定 λ | 不可声称 RL 算法定理 subsume Luque。固定步只是 Luque 的特例。 |
| operator | multivalued maximal monotone T | arbitrary relation F；可 nonmonotone/nonmaximal | RL 的 operator scope 更宽，但算法假设不同。 |
| resolvent | full-domain single-valued (P_k=(I+c_kT)^{-1}) | restricted natural domain 上的 named branch；无 EX 时 full resolvent 可多值或含 remote selections | named-branch residue 是真实差别；结论不得升级为任意 full selection。 |
| exact/inexact | 两者均处理；(3.7) 显式含 ε_k | 冻结核心迭代为 exact named step | Luque 在此维度更宽。 |
| solution geometry | ̅Z 可非孤立；Thm 3.2 明说可非单点、非紧 | isolated 与 nonisolated 分章 | “nonisolated 首次” 被 Luque 直接禁止。 |
| reflector | 不使用 (R=2P-I) 术语，但 firm inequality (1.2) 等价地隐含 nonexpansive reflector，即 γ=1,L=1 | 显式 restricted reflector，允许 (0<\gamma<1) 与 L=0 | 不可说 Luque 完全没有 reflector content；准确说法是它没有显式 Hölder reflector/γ<1 机制。 |
| alignment | 无 input-nearest/output-nearest drift exponent | (a_J,\delta_J,\theta) 与 θq | 这是 Luque-bounded residue；Luque 用 firm geometry 直接控制 set distance。 |
| rate strength | endpoint set-distance upper recurrence；不证明 exact factor | 显式分 upper/two-sided/factor，并给 GX 边界 | 术语精化与 sharpness 仍可保留；upper q-order 本身不新。 |

## 3. evidence_and_execution_status

### 3.1 证据标签

- `VERIFIED_SOURCE`：Luque full prepublication 的题名页、PPA 定义、(1.4)、Theorem 2.1、Q-order definition、Theorem 3.1、(3.7)、Theorem 3.2 及 remarks 已逐页读取；SIAM official page 已核元数据；Zhu primary source 仅核对 actual-iterate/strict-subendpoint 对照。
- `VERIFIED_USER_MATERIAL`：冻结 `research/RL_foundations.md` 的指定 SHA-256 与所有要求对照的 theorem/equation tags 已核。
- `EXECUTED_LOCAL`：下载 Luque PDF并计算 SHA-256；用 `pdftotext -layout` 抽取全文；用 `pdftocairo` 渲染关键页并逐式视觉复核，避免 OCR 把 ≥、上标、集合横线或分母错读。
- `AI_INFERENCE`：full inverse growth 与 PEB 的双向 localization 证明、(3.7) exact endpoint 化简、maximal-monotone (L=1,\gamma=1) 特化，以及 theorem-overlap 裁决。
- `PENDING_VERIFICATION`：1984 最终排版与 1981 prepublication 的逐字/逐式版本同一性；本报告不依赖该未核事项作更强 claim。
- `NOT_EXECUTED`：没有做全领域 priority search，没有声称 Luque 之外不存在同型 theorem。

### 3.2 结论边界与作者自述限制

Luque 自己明确说 (1.4) 不是必要条件；Theorem 3.1 只给 order at least，不给 equality 或 Q-factor；Theorem 3.2 的 finite termination 与正 finite Q-factor 不兼容。冻结稿自身也锁定 upper order、two-sided exact exponent、exact Q-factor 三层不可互换。两边没有证据冲突。

## 4. deliverables

### 4.1 claim-safe contribution residue（仅相对于 Luque）

以下措辞可以进入后续 contribution drafting，但每句都必须保留限定词：

1. **named/nonmonotone scope**：
   > In a fixed-step exact setting, we recover analogous local error-bound recurrences for a specified resolvent branch of a possibly nonmaximal or nonmonotone relation, under explicit coverage, anchoring, output-return, and invariance conditions. This does not subsume Luque's inexact variable-step maximal-monotone theory.
2. **Hölder reflector composition**：
   > Beyond the latent nonexpansive-reflector case γ=1 covered by maximal monotonicity, a restricted γ-Hölder reflector with (0<\gamma<1) composes with a q-power full error bound to give the conditional upper exponent γq, together with the critical and degenerate phase split.
3. **nonisolated two-anchor mechanism**：
   > For nonisolated solution sets, we isolate nearest-solution drift as a separate alignment profile and obtain a conditional map-level upper exponent θq. Luque already covers nonisolated set-distance superlinear convergence; the residue is the explicit two-anchor mechanism outside firm monotonicity, not the broad existence of such convergence.
4. **structural equivalence and scope ledger**：
   > The graph-germ equivalence among branchwise residual flatness, resolvent q-flatness, and reflected-resolvent asymptotic reflection, together with the coverage/exclusion/invariance ledger, is not present in the checked Luque theorem blocks.
5. **sharpness discipline**：
   > Joint saturation and GX-071--GX-073 distinguish attainable upper exponents, conservative all-pairs exponents, and domain escape. These examples support only their stated class-level verdicts, not universal optimality.

这些都是“Luque 未覆盖”的 bounded statements；没有 wider verified search 时，不得把 “not in Luque” 改写成 “first in the literature”。

### 4.2 forbidden claims

| 禁止表述 | 禁止理由 |
|---|---|
| “我们首次用 higher-order/full power error bound 得到 exact PPA 的 q-order。” | Luque Thm 3.1 + (3.7) 已直接给 exact set-distance endpoint (O(d_k^s))。 |
| “Luque 只证明 sup-order，端点 s 未覆盖。” | 错。(3.7) exact specialization 明确包含 τ=s 的 big-O。 |
| “Luque 的 theorem 只适用于 isolated/unique solution。” | 错。Thm 2.1/3.1 均允许一般非空解集；Thm 3.2 明说可非单点、非紧。 |
| “我们的 nonisolated high-order PPA convergence 是首次。” | 被 Luque 的 set-distance 结果直接否定；actual-iterate 维度还受 Zhu 先例约束。 |
| “Luque 已给 nonisolated actual-iterate endpoint s。” | 证据不足。其 checked rate object 是 set distance；不能自动升级。 |
| “Zhu 与 Luque 都只给每个 (t<s)。” | 错。strict-subendpoint 是 Zhu actual-iterate formal theorem 的边界；Luque (3.7) 已给 set-distance endpoint。 |
| “RL Cor. 5.2 的 γ=1,q>1 monotone specialization 是新公式。” | fixed-step (L=1) 时常数 (a/\lambda^s) 与 Luque 逐项相同。 |
| “RL q=1 bound 改进了 Luque。” | 错。Luque 给 (a/\sqrt{a^2+\lambda^2}<1)，冻结 generic bound (a/\lambda) 更弱且需阈值。 |
| “RL (L=0) 就是 Luque (s=+\infty)。” | 错。前者是 reflector modulus 退化，后者是 inverse-growth gauge 为零。 |
| “Luque 只用 fixed stepsize/exact PPA。” | 错。其主要定理显式允许 variable (c_k) 与 summable inexactness。 |
| “Luque 覆盖 restricted/nonmonotone named branch。” | 错。Luque 依 maximal monotonicity 与 full-domain single-valued resolvent。 |
| “冻结 named-branch theorem 自动适用于任意 full-resolvent selection。” | 错。无 EX 时冻结稿明确禁止该升级。 |
| “γq 或 θq 是 universal exact Q-order/factor。” | 错。它们是条件性 upper laws；GX-072 与注 5.4 阻止该升级。 |
| “Luque 已经提出 γ<1 reflector regularity 或 two-anchor alignment exponent。” | checked source 无此结构；其 firm inequality 只隐含 γ=1 nonexpansive reflector。 |
| “1981 与 1984 final text 已逐字验证相同。” | 未取得并逐页核对最终期刊全文；只能声称书目对应与 prepublication theorem-level 证据。 |

## 5. limitations_and_risks

1. 本报告是 Luque-centered bounded overlap referee，不是完整 priority search；因此 claim-safe residue 只能写成 “not covered by the checked Luque source”。
2. 1984 期刊最终全文未逐式访问；若最终版本删改了 theorem numbering 或常数，应以正式 PDF 再核。但 1981 原稿本身已经足以否定“端点未出现”等强 claim。
3. Luque 与冻结 RL 的 assumptions 交叉：前者 operator/algorithm geometry 更强且允许 inexact/variable step，后者 relation/branch scope 更宽但固定步 exact。任何 “strict generalization” 都会丢失至少一个维度。
4. 从 set-distance recurrence 推 actual-iterate rate 需要额外 finite-length/alignment/isolated geometry；不能仅凭 weak/strong convergence 字样补出 endpoint。
5. 没有提出新的“novel idea”：本任务是先例审计，超出证据的研究设想会模糊 claim boundary。

## 6. quality_checks

- [x] Luque 作者姓名以题名页和 SIAM official record 双重核对。
- [x] (1.4)、Thm 2.1、Q-order definition、Thm 3.1、(3.7)、Thm 3.2 均从 full scan 逐页读取。
- [x] 扫描中的 (r\ge1,s\ge1)、分母幂与 ε_k 项经渲染页视觉复核，不依赖 OCR 单独判读。
- [x] exact endpoint (d_{k+1}\le(a/c_k^s)d_k^s) 已从 (3.7) 显式推导。
- [x] full inverse growth ↔ local full PEB 的两方向量词与 infimum attainment 问题已处理。
- [x] nonisolated、actual iterate/set distance、fixed/variable step、full/named branch、maximal/nonmonotone、reflector/γ<1/alignment 均分栏核对。
- [x] 冻结 Thm 4.2、Cor. 5.1--5.3、Thm 7.4、Thm 8.2、Prop. 9.1/GX 全部进入 crosswalk。
- [x] Zhu actual-iterate/every (t<r) 与 Luque set-distance/endpoint s 已从 primary sources 反向区分。
- [x] 冻结基线在任务结束前再次验 hash；报告未修改冻结文件。
- [x] forbidden claims 与 Luque-bounded residue 均已输出。

## 7. SCI-Skills Expert Contract 1.0

```yaml
contract_version: "1.0"
expert_skill: sci-skills-paper-deep-reading
project_id: monotonicity-regularity-seesaw-2026-09
paper_family: T
stage_id: T2
task_id: RL-NOV-LUQUE-COMPARE-14
task_status: COMPLETE
inputs_reviewed:
  - "Luque LIDS-P-1142 full prepublication PDF, September 1981; local SHA-256 af357dfe1e7036892523061496218d040817630104d25b03111b2d2a79004e78"
  - "SIAM official publication record, DOI 10.1137/0322019"
  - "research/RL_foundations.md @ sha256 0adf8ca1593148bebce576e9659f3da50e61a77880c0b311cbcc35d0dcbb4ebd"
  - "Ciyou Zhu Argonne P457 primary prepublication, bounded reverse comparison only"
outputs:
  - "work/novelty_luque_compare.md"
  - "Equation-level reconstruction of Luque (1.4), Theorems 2.1/3.1/3.2, Q-order definition, and recurrence (3.7)"
  - "Theorem-by-theorem overlap matrix against frozen RL 4.2, 5.1--5.3, 7.4, 8.2, 9.1/GX"
  - "Claim-safe Luque-bounded contribution residue and forbidden-claims ledger"
evidence_status:
  - "VERIFIED_SOURCE: Luque full prepublication theorem blocks and official SIAM metadata"
  - "VERIFIED_SOURCE: Zhu actual-iterate/strict-subendpoint reverse distinction"
  - "VERIFIED_USER_MATERIAL: frozen RL baseline and supplied task identifiers"
  - "EXECUTED_LOCAL: PDF extraction, page rendering, SHA-256, and equation visual QA"
  - "AI_INFERENCE: localization equivalence, exact endpoint derivation, and overlap verdicts"
  - "PENDING_VERIFICATION: verbatim identity of the 1981 prepublication and final 1984 typeset article"
assumptions:
  - "All Luque theorem-level mathematical claims in this report are bound to LIDS-P-1142; no unverified final-typesetting difference is used affirmatively."
  - "The comparison sets T=F, solution sets equal, and q=s only in explicitly marked specializations."
author_input_needed: []
manual_actions: []
quality_checks:
  - "Frozen RL SHA-256 verified before and after the comparison"
  - "Every user-requested Luque and RL theorem/equation entered the crosswalk"
  - "Endpoint set-distance, actual-iterate strict subendpoint, exact exponent, and Q-factor were kept distinct"
  - "Exactly one primary next action is stated at the end"
conflicts: []
conflict_resolution_status: NOT_REQUIRED
merge_permission: orchestrator_only
recommended_next_action: "See the single action in section 8; no second action is authorized by this expert."
stage_acceptance_recommendation: PASS_CANDIDATE
```

## 8. one_next_action

由 SCI-Skills orchestrator 将本报告的 **direct-overlap 判决、Luque/Zhu rate-object 区分、claim-safe residue 与 forbidden claims** 作为一个整体纳入 T2 新颖性账本并执行 stage-acceptance 核验。
