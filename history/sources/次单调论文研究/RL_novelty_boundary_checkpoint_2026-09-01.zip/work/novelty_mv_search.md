# Moursi–Vanderwerff 2025 原始来源检索核验

## 0. 任务身份与冻结边界

| 字段 | 值 |
|---|---|
| project_id | `monotonicity-regularity-seesaw-2026-09` |
| paper_family | `T` |
| stage_id | `T2` |
| task_id | `RL-NOV-MV-SEARCH-11` |
| 检索日期 | 2026-09-01 |
| 任务类型 | 定向原始来源检索、书目核验与新颖性风险冻结；不是系统综述 |
| 目标论文 | Moursi–Vanderwerff, *On Further Notions of Strong Nonexpansiveness and Corresponding Notions of Monotonicity* |
| 冻结基线 | `research/RL_foundations.md` |
| 要求的基线 SHA-256 | `0adf8ca1593148bebce576e9659f3da50e61a77880c0b311cbcc35d0dcbb4ebd` |
| 本轮实测 SHA-256 | `0adf8ca1593148bebce576e9659f3da50e61a77880c0b311cbcc35d0dcbb4ebd` |
| 基线写入 | 未修改；仅作只读哈希与结构定位 |

### 证据问题

本轮要回答的不是“这篇论文是否相关”这一摘要级问题，而是：其原始全文是否已经覆盖冻结 RL 中的下列精确结构。

1. all-pairs、graph-local、global、solution-anchored 等量词层；
2. reflector/Cayley 表示及其 monotonicity 对应；
3. centered reflection remainder
   \[
   \widehat x-(2p-x)=2(y-p)
   \]
   及其高阶小量控制；
4. output-near、随 graph point 变化的 moving zero anchor；
5. locally isolated zero 上 fixed-anchor branchwise \(q\)-flatness；
6. \(0<\gamma<1\) 的 Hölder reflector/Cayley modulus。

### 允许与禁止的来源

- 允许：平台原生网页检索、出版社正式页面、作者页面、机构页面、机构知识库普通网页、arXiv 普通网页。
- 禁止：第三方 API、密钥/SDK、绕过订阅墙、抓取登录态、把摘要或搜索片段冒充全文。
- 搜索结果中的聚合站只作发现线索，未用于形成论文内容结论。

---

## 1. 概念块与检索设计

| 概念块 | 核心词 | 同义/变体 | 用途 |
|---|---|---|---|
| 书目身份 | exact title；DOI；Moursi；Vanderwerff | article 50；JOTA 205；02633-4 | DOI、作者、卷、文章号与版本日期核验 |
| 合法全文 | PDF；preprint；accepted manuscript | author manuscript；repository；self-archived | 找公开预印本或机构/作者稿 |
| 点态概念 | at each point | pointwise；locally at a point；on bounded sets | 定位 every at-each-point definition |
| 反射/Minty | reflection operator；reflector | reflected resolvent；Cayley；resolvent | 定位 operator correspondence 与公式 |
| 余项/模量 | modulus；remainder；defect | gauge；rate；order；little-o；big-O | 定位 centered remainder 或一般模量 |
| 量词 | local；global；all pairs | anchored；fixed point；bounded set | 区分全 pair、点态、局部与锚定条件 |
| 高阶/指数 | Hölder；gamma；power | exponent；q-flatness；superlinear | 检查 \(\gamma<1\) 或 \(q>1\) 结构 |
| 更新状态 | correction；erratum | update；retraction；publisher correction | 查勘误、撤稿或版本更新 |

**广发现式：** `"Moursi" "Vanderwerff" "02633-4" PDF OR preprint OR manuscript`

**窄确认式：** `"On Further Notions of Strong Nonexpansiveness and Corresponding Notions of Monotonicity"` 与 `"10.1007/s10957-025-02633-4"`，随后加官方域名与目标术语限制。

---

## 2. 已核书目元数据

主记录：[Springer Nature 正式文章页](https://link.springer.com/article/10.1007/s10957-025-02633-4)。

| 字段 | 核验值 | 证据与状态 |
|---|---|---|
| 标题 | *On Further Notions of Strong Nonexpansiveness and Corresponding Notions of Monotonicity* | 出版社文章页，`VERIFIED_SOURCE` |
| 出版作者字符串 | Walaa M. Moursi；Jon Vanderwerff | 出版社文章页，`VERIFIED_SOURCE` |
| 作者 1 最完整可核姓名 | **Walaa M. Moursi** | [作者主页](https://sites.google.com/view/walaa-moursi/home)与出版社一致；可访问官方/作者来源未展开中间名首字母 `M.`，不得自行补全，`VERIFIED_SOURCE` |
| 作者 1 ORCID | `0000-0002-0113-9309` | 出版社作者栏链接，`VERIFIED_SOURCE` |
| 作者 2 最完整可核姓名 | **Jon D. Vanderwerff** | [La Sierra University 教师页](https://lasierra.edu/mathematics/faculty-staff/jon-d-vanderwerff/)给出中间首字母 `D.`；出版社记录省略该首字母，二者相容，`VERIFIED_SOURCE` |
| 作者 1 机构 | University of Waterloo, Department of Combinatorics and Optimization；Mansoura University, Faculty of Science | 出版社文章页，`VERIFIED_SOURCE` |
| 作者 2 机构 | La Sierra University, Department of Mathematics | 出版社文章页及机构教师页，`VERIFIED_SOURCE` |
| 期刊 | *Journal of Optimization Theory and Applications* | 出版社文章页，`VERIFIED_SOURCE` |
| 卷与文章号 | volume 205, article 50 (2025) | 出版社文章页，`VERIFIED_SOURCE` |
| DOI | `10.1007/s10957-025-02633-4` | 出版社文章页，`VERIFIED_SOURCE` |
| 收稿 | 2024-02-26 | 出版社文章页，`VERIFIED_SOURCE` |
| 接收 | 2025-01-15 | 出版社文章页，`VERIFIED_SOURCE` |
| 在线发表/Version of Record | 2025-04-18 | 出版社文章页，`VERIFIED_SOURCE` |
| 文献类型 | journal article | 出版社记录，`VERIFIED_SOURCE` |
| 摘要级主题 | maximally monotone operators；uniform monotonicity on bounded sets / at each point；与 nonexpansive mappings 的联系；duality 与 fixed points | 仅出版社摘要，`VERIFIED_SOURCE`（abstract-only） |
| 关键词中的直接风险词 | `Reflection operator`、`Uniformly monotone operator`、`Nonexpansive mapping` | 出版社关键词，`VERIFIED_SOURCE`（metadata-only） |

### 作者名规范化说明

- 引用目标论文时应保留出版社形式 `Walaa M. Moursi and Jon Vanderwerff`。
- 建作者实体卡时可把第二作者规范化为 `Jon D. Vanderwerff`，同时记录“出版社省略 D.”。
- `Walaa M. Moursi` 已是本轮合法可访问来源给出的最完整形式；`M.` 的展开仍未知，不能猜测。

### 勘误、撤稿与更新状态

截至 2026-09-01：

- 正式文章页未显示 “This article has been updated”、Correction 或 Retraction 标记；页面内逐字查找亦无相应字段。
- 对正式 Springer 域名执行 exact-title/DOI + `correction | erratum | retraction | update` 查询，未出现指向该目标论文的官方更正记录。
- 因此可记录为：**在本轮已查官方界面中未发现勘误、撤稿或更新记录**，`VERIFIED_SOURCE`。
- 这不是对未来更新或未被搜索界面索引记录的永久不存在证明。

---

## 3. 合法全文与公开手稿检索结果

### 3.1 访问深度编码

| 代码 | 含义 |
|---|---|
| `S` | 搜索结果标题/片段 |
| `M` | 正式元数据与作者/机构信息 |
| `A` | 正式摘要 |
| `R` | 正式参考文献或页面附属信息 |
| `FT` | 可逐页核对的合法全文 |

本轮对目标论文达到的最高深度是 **`M+A+R`，未达到 `FT`**。

### 3.2 路径核验

| 路径 | 实际访问 | 结果 | 状态 |
|---|---|---|---|
| Springer 正式文章页 | `M+A+R` | 可见完整元数据、摘要、关键词、参考文献；正文标为 subscription preview | `VERIFIED_SOURCE` |
| [Springer PDF 入口](https://link.springer.com/content/pdf/10.1007/s10957-025-02633-4.pdf) | `M+A+R` | 回跳至订阅预览文章页；页面提供购买/机构登录，未取得 PDF 字节 | `NOT_EXECUTED`（full-text access） |
| Springer SharedIt | `M` | 正式页明确显示当前没有 shareable link | `VERIFIED_SOURCE` |
| [Walaa M. Moursi 作者主页](https://sites.google.com/view/walaa-moursi/home) | `M` | 核作者身份与机构 | `VERIFIED_SOURCE` |
| [作者 publications 页](https://sites.google.com/view/walaa-moursi/publications) | `M` | 页面显示的 29 条 accepted/published 列表中无目标标题/DOI；页面显然不是 2025 完整清单，不能据此断言无作者稿 | `PENDING_VERIFICATION` |
| [arXiv：W. Moursi 作者检索](https://arxiv.org/search/?abstracts=show&order=-announced_date_first&query=W.+Moursi&searchtype=author&size=50) | `M` | 页面显示 47 条结果；目标标题与 DOI 均为 0 次匹配 | `VERIFIED_SOURCE`（bounded-search outcome） |
| UWSpace 机构库/Waterloo 域名 | `S+M` | exact title、DOI 与作者组合查询均未浮现目标记录 | `VERIFIED_SOURCE`（search boundary；不是 absence proof） |
| La Sierra University 域名 | `S+M` | exact title 与 DOI 查询未浮现目标手稿；教师身份页可访问 | `VERIFIED_SOURCE`（search boundary；不是 absence proof） |

### 3.3 公开版本判定

**本轮未找到可合法公开读取的 preprint、accepted manuscript、机构存档全文或作者自存档全文。** 这只说明当前有界检索未取得全文，不说明这些版本从未存在。出版社 PDF 的订阅限制没有被绕过。

---

## 4. 精确查询日志

所有查询均于 2026-09-01 在平台原生网页检索中执行。平台搜索界面不暴露每条查询的稳定总命中数，且批量查询会合并返回候选；因此 hit count 栏如实记作“未暴露”，不伪造数字。能够从来源页面直接计数的地方另行记录。

| ID | 来源/过滤 | 完整查询 | 总命中数 | 目标命中与访问深度 |
|---|---|---|---|---|
| Q01 | 全网页，exact title | `"On Further Notions of Strong Nonexpansiveness and Corresponding Notions of Monotonicity"` | 未暴露 | Springer 正式记录 1；`M+A+R` |
| Q02 | 全网页，exact DOI | `"10.1007/s10957-025-02633-4"` | 未暴露 | Springer 正式记录 1；`M+A+R` |
| Q03 | 全网页，合法全文发现 | `"Moursi" "Vanderwerff" "02633-4" PDF OR preprint OR manuscript` | 未暴露 | 官方/作者/机构公开全文 0；`S` |
| Q04 | 全网页，公开版本 | `"On Further Notions of Strong Nonexpansiveness" manuscript OR preprint OR repository` | 未暴露 | 官方/作者/机构公开全文 0；`S` |
| Q05 | Waterloo 域 | `site:uwaterloo.ca "On Further Notions of Strong Nonexpansiveness"` | 未暴露 | 目标记录 0；`S` |
| Q06 | Waterloo 机构库域 | `site:uwspace.uwaterloo.ca "On Further Notions of Strong Nonexpansiveness"` | 未暴露 | 目标记录 0；`S` |
| Q07 | Waterloo 机构库域 | `site:uwspace.uwaterloo.ca "10.1007/s10957-025-02633-4"` | 未暴露 | 目标记录 0；`S` |
| Q08 | Waterloo 机构库域 | `site:uwspace.uwaterloo.ca "Walaa M. Moursi"` | 未暴露 | 返回其他含作者名记录；目标 0；`S` |
| Q09 | La Sierra 域 | `site:lasierra.edu "On Further Notions of Strong Nonexpansiveness"` | 未暴露 | 目标手稿 0；`S` |
| Q10 | La Sierra 域 | `site:lasierra.edu "10.1007/s10957-025-02633-4"` | 未暴露 | 目标记录 0；`S` |
| Q11 | arXiv 域 | `site:arxiv.org "On Further Notions of Strong Nonexpansiveness"` | 未暴露 | 目标记录 0；`S` |
| Q12 | arXiv 普通作者检索，author=`W. Moursi`, size=50 | `W. Moursi` | 47 | 目标标题 0、目标 DOI 0；`M` |
| Q13 | Springer 域，勘误 | `site:link.springer.com/article "Correction to: On Further Notions of Strong Nonexpansiveness"` | 未暴露 | 目标更正记录 0；`S` |
| Q14 | Springer 域，更新状态 | `site:link.springer.com/article "On Further Notions of Strong Nonexpansiveness" correction OR erratum OR retraction` | 未暴露 | 目标更正/撤稿记录 0；`S` |
| Q15 | Springer 域，DOI 更新状态 | `site:link.springer.com "10.1007/s10957-025-02633-4" correction OR erratum OR retraction` | 未暴露 | 目标更正/撤稿记录 0；`S` |
| Q16 | Springer 单页逐字查找 | `This article has been updated`；`Correction`；`Retraction` | 1 个目标页 | 三词均 0 匹配；`M+A+R` |
| Q17 | Springer 域，点态定义探针 | `site:link.springer.com/article/10.1007/s10957-025-02633-4 "at each point" definition` | 0 返回 | 无 theorem snippet；`S` |
| Q18 | Springer 域，reflection 命题探针 | `site:link.springer.com/article/10.1007/s10957-025-02633-4 "reflection operator" proposition` | 0 返回 | 无 theorem snippet；`S` |
| Q19 | Springer 域，模量/余项探针 | `site:link.springer.com/article/10.1007/s10957-025-02633-4 modulus remainder` | 0 返回 | 无 theorem snippet；`S` |
| Q20 | Springer 域，Cayley/Hölder 探针 | `site:link.springer.com/article/10.1007/s10957-025-02633-4 Cayley Hölder` | 0 返回 | 无 theorem snippet；`S` |
| Q21 | exact title 缩写，点态 | `"On Further Notions" "at each point" nonexpansive` | 未暴露 | 只复现摘要级主题；无定义；`S+A` |
| Q22 | exact title 缩写，reflection | `"On Further Notions" "reflection operator" Moursi` | 未暴露 | 只复现关键词；无命题；`S+M` |
| Q23 | exact title 缩写，modulus | `"On Further Notions" modulus monotonicity` | 未暴露 | 无可核目标公式；`S` |
| Q24 | exact title 缩写，Cayley/Hölder | `"On Further Notions" Cayley Hölder Moursi Vanderwerff` | 未暴露 | 无可核目标公式；`S` |
| Q25 | 作者 2 机构姓名 | `site:lasierra.edu "Jon D. Vanderwerff"` | 未暴露 | 机构教师页 1；`M` |

### 搜索限制

1. 搜索引擎总命中数不稳定且未暴露；本报告只记录目标记录数与实际访问深度。
2. `site:` 查询是有界发现工具，不等同于机构库的完整后台导出。
3. 搜索片段即使显示正文片段，也没有被升级为 `FT`。
4. 未使用任何第三方 API 或未授权下载路径。

---

## 5. 筛选、去重与来源账本

### 5.1 纳入/排除规则

**纳入：** DOI 精确一致，或规范化标题、作者、年份完全一致；且来源为出版社、作者、机构或 arXiv 普通网页。

**排除为内容证据：** 聚合索引、自动生成作者页、搜索缓存片段、仅给“full text available”标签而不能证明合法公开来源的页面。

### 5.2 去重

- DOI 去重：所有命中归并至 `10.1007/s10957-025-02633-4`，得到 **1 篇目标论文**。
- 规范化标题去重：大小写、连字符和省略号差异未生成第二篇记录。
- Springer article URL 与 Springer PDF URL 是同一版本记录/访问入口，不计为两篇论文。
- 本轮没有需要合并的 correction DOI。

### 5.3 核验来源表

| ID | 来源 | 身份/用途 | 访问深度 | 相关性 | 证据状态 |
|---|---|---|---|---|---|
| S1 | Springer Nature 目标文章页 | 正式版本记录、摘要、关键词、日期、机构、访问限制 | `M+A+R` | `精确同方向` | `VERIFIED_SOURCE` |
| S2 | Walaa M. Moursi 作者主页/出版页 | 作者名、机构、公开版本线索 | `M` | `精确同方向` | `VERIFIED_SOURCE` / 列表完整性 `PENDING_VERIFICATION` |
| S3 | arXiv W. Moursi 作者检索 | 公开预印本边界 | `M` | `精确同方向` | `VERIFIED_SOURCE`（bounded-search outcome） |
| S4 | UWSpace / Waterloo 机构域 | 机构存档线索 | `S+M` | `精确同方向` | `VERIFIED_SOURCE`（search boundary；不是 absence proof） |
| S5 | La Sierra University 教师页/机构域 | Jon D. Vanderwerff 全名与机构存档线索 | `M` | `精确同方向` | `VERIFIED_SOURCE` / 手稿存在性 `PENDING_VERIFICATION` |

---

## 6. Theorem-level 提取状态

出版社明确把正文标为订阅内容，故下列任何定义或命题都不能从摘要重构。本节逐项保留待核，不用“似乎没有”替代证据。

| 待提取项目 | 本轮能直接核实的最深事实 | theorem-level 状态 |
|---|---|---|
| every “at each point” definition | 摘要确认论文研究 uniformly monotone at each point 这一类；定义的对象、邻域、序列/点对量词、是否 uniform in base point 均不可见 | `PENDING_VERIFICATION` |
| on bounded sets definition | 摘要确认有此类；bounded set 放在哪个变量、模量是否依赖集合均不可见 | `PENDING_VERIFICATION` |
| strong nonexpansiveness variants | 标题确认存在 further notions；逐定义语句、序列条件与模量不可见 | `PENDING_VERIFICATION` |
| reflection-operator propositions | 关键词确认 reflection operator 是论文主题；命题编号、公式、假设与方向不可见 | `PENDING_VERIFICATION` |
| Cayley / reflected resolvent correspondence | 摘要/元数据未给公式；不能由关键词反推是 \(R_A=2J_A-I\)、\(-R_A\) 还是其他规范 | `PENDING_VERIFICATION` |
| monotonicity propositions | 摘要确认 operator classes 与 map classes 有连接；iff/单向、maximality、domain 与局部量词均不可见 | `PENDING_VERIFICATION` |
| modulus / defect / remainder | 无可访问原文公式或定义；搜索探针没有产生可核命题 | `PENDING_VERIFICATION` |
| local / global | 摘要不能区分 graph-local、input-local、bounded-set uniform 或全空间 global | `PENDING_VERIFICATION` |
| all-pairs | 未见原始量词；不能把 uniformly monotone on bounded sets 自动翻译成冻结 RL 的 graph all-pairs | `PENDING_VERIFICATION` |
| anchored / fixed-point anchored | 摘要提到 fixed points，但不支持 anchored inequality 或 fixed-anchor theorem | `PENDING_VERIFICATION` |
| moving anchor | 无可访问证据 | `PENDING_VERIFICATION` |

---

## 7. 与冻结 RL 的精确风险矩阵

冻结定位均来自只读的 `research/RL_foundations.md`：Definition 0.3、Theorem 1.1、Theorem 6.1、Corollary 6.2、Theorem 7.1、Propositions 7.2–7.3。

| 冻结 RL 结构 | 冻结公式/量词要点 | 目标论文当前可见证据 | 判定 |
|---|---|---|---|
| restricted/global all-pairs RL | 对 \(\Gamma\times\Gamma\) 的每一对 graph points；global 仅修饰 graph quantifier | 摘要级 bounded-set/at-each-point；无法看到 pair quantifier | **待全文核验** |
| graph-local all-pairs | 同一 graph window 中所有 pairs，区别于 input-local | 无原文定义 | **待全文核验** |
| solution-anchored RL | moving graph point 对所有 \(p\in S_0\)，不推出 Minty injectivity | 摘要提 fixed points 不能证明 anchored inequality | **待全文核验** |
| reflector/Cayley modulus | \(\|R x-R y\|\le \omega(\|x-y\|)\)，power 情形 \(Lt^\gamma\) | 关键词仅确认 reflection operator | **待全文核验** |
| centered reflection identity | \(\widehat x-(2p-x)=2(y-p)\) | 无可访问公式 | **待全文核验** |
| moving-anchor asymptotic reflection | \(p=p(y,w)\) 为 output-near zero，\(\widehat x-p=-(x-p)+o(\|x-p\|)\) | 无可访问 anchor 选择或 remainder | **待全文核验** |
| power moving-anchor remainder | \(\|\widehat x-(2p-x)\|\le C\|x-p\|^q\), \(q>1\) | 无可访问 power theorem | **待全文核验** |
| isolated-zero fixed-anchor \(q\)-flatness | graph germ 上 \((B_q)\Leftrightarrow(J_q)\Leftrightarrow(R_q)\)，固定 \(p\)，\(q>1\) | 无 zero/isolation/graph-germ 证据 | **待全文核验** |
| full error bound 与 branchwise bound | local isolation、residual completeness、infimum residual 的方向区分 | 摘要未提 error bound 或 isolated zero | **待全文核验** |
| Hölder \(\gamma<1\) | \(\omega(t)=Lt^\gamma\)，需区分 all-pairs、anchored 与 bounded-domain 降阶 | 无 exponent 或 power modulus 证据 | **待全文核验** |

### 五个重点问题的冻结答案

1. **是否出现 centered reflection remainder？** `PENDING_VERIFICATION`。关键词命中 reflection 不等于命中余项公式。
2. **是否出现 moving-anchor？** `PENDING_VERIFICATION`。摘要的 fixed-point 叙述不能支持随 graph point 变化的 output-near anchor。
3. **是否出现 isolated-zero \(q\)-flatness？** `PENDING_VERIFICATION`。公开摘要没有 zero、isolation、\(q\)-power 或 graph-germ 量词。
4. **是否出现 Hölder exponent \(\gamma<1\)？** `PENDING_VERIFICATION`。没有可访问 exponent/modulus 定义。
5. **是否覆盖 frozen RL 的 local/global/all-pairs/anchored 分层？** `PENDING_VERIFICATION`。目前只能确认存在“on bounded sets / at each point”主题，不能做量词同一化。

---

## 8. 证据矩阵与可安全的新颖性表述

| claim | 证据 | 标签 | 可否冻结 |
|---|---|---|---|
| 论文身份、DOI、卷、文章号、日期与作者机构 | Springer 正式记录 | `VERIFIED_SOURCE` | 是 |
| 第二作者完整机构姓名为 Jon D. Vanderwerff | La Sierra University 教师页 | `VERIFIED_SOURCE` | 是 |
| 论文研究 on-bounded-sets / at-each-point uniform monotonicity 与 nonexpansive-map connections | Springer 摘要 | `VERIFIED_SOURCE`（abstract-only） | 仅摘要级 |
| reflection operator 是论文直接主题 | Springer 关键词 | `VERIFIED_SOURCE`（metadata-only） | 仅风险提示 |
| 未找到公开合法全文 | 出版社访问限制 + 作者/arXiv/机构域有界检索 | `VERIFIED_SOURCE`（bounded-search outcome） | 可冻结为访问事实，不可冻结为版本不存在 |
| 目标论文不含 centered/moving reflection | 无全文 | `PENDING_VERIFICATION` | 否 |
| 目标论文不含 isolated-zero \(q\)-flatness | 无全文 | `PENDING_VERIFICATION` | 否 |
| 目标论文不含 Hölder \(\gamma<1\) | 无全文 | `PENDING_VERIFICATION` | 否 |
| 因本轮未命中，所以 frozen RL 新颖 | 阴性检索 | `AI_INFERENCE` 且不成立为 novelty proof | 否 |

### 可直接使用的 claim-safe 结论

> Moursi–Vanderwerff (2025) is a direct theorem-level novelty risk because its official record expressly concerns monotonicity at each point and corresponding nonexpansive-map notions, while its keywords include reflection operators. The accessible abstract does not resolve whether its definitions or propositions cover the centered, moving-anchor, isolated-zero, or Hölder-power structures used here; that comparison remains pending full-text review.

这段只陈述风险与访问边界，不作排他性优先权判断。

### 当前不得使用的表述

- “Moursi–Vanderwerff 2025 与 centered reflection 无关。”
- “该文只处理全局/all-pairs，不处理 anchored。”
- “该文没有 \(\gamma<1\) 或 \(q>1\) 指数。”
- “本轮没有搜索命中，因此 RL 是首次提出。”

---

## 9. 限制与风险

1. 目标正文为订阅内容；本轮没有合法 `FT`，所以任务的 theorem-level 部分不能完成。
2. 公开摘要只支持主题，不支持定义、命题编号、公式、证明、例子或量词边界。
3. 机构域与作者页的阴性命中会受索引和页面更新影响。
4. 即使日后逐字未找到 frozen RL 公式，也只能形成 negative boundary；新颖性仍需别名、等价变换与引用链复核。
5. 在全文到位前，T2 不应冻结任何 “first/novel/previously unknown” 表述。

---

## 10. 人工操作陪跑（仅用于合法取得全文）

### 操作目标与隐私边界

- 目标：通过作者本人已有的机构订阅，或向作者索取可合法分享的 accepted manuscript，取得目标论文 PDF。
- 所需材料：目标 DOI 与标题；无需向本对话提供账号、密码、验证码、cookies 或订阅凭据。
- 完成证据：PDF 文件本身，以及下载来源/作者回传方式的简短说明；若许可信息可见，一并截图或记录。
- 返回后：核验 PDF 书目页与页数，再逐定义/命题完成本报告第 6–7 节。

## **需要你操作网页或软件：复制下面这段 Prompt 到一个新对话窗口**

```text
你现在是“SCI-Skills 操作陪跑助手”。

请帮助我完成下面这项论文外部操作。每次只告诉我一个步骤，等待我确认或发送截图后再继续。不要假设我已经完成操作。如果页面、按钮或软件界面与预期不同，请让我截图，并根据截图重新指导。

不要索取或要求我粘贴密码、验证码、私钥、会话信息或完整访问凭据。如果需要登录，只指导我在网页中自行登录。不要把安装或配置软件作为主线前置条件；先给我无安装替代方案。只有我明确选择可选增强后，才说明软件来源、系统要求、磁盘空间、风险和卸载方法。

项目ID：monotonicity-regularity-seesaw-2026-09
论文类型：T
当前阶段：T2
任务ID：RL-NOV-MV-SEARCH-11
操作平台或软件：Springer Nature 普通网页、我本人可合法使用的机构图书馆入口，或作者联系渠道
本次目标：合法取得 Moursi–Vanderwerff (2025), DOI 10.1007/s10957-025-02633-4 的 version-of-record PDF 或可分享 accepted manuscript
已有文件：没有目标全文；已有 DOI、标题和出版社正式文章页
完成标准：下载得到可打开、书目信息匹配且页码完整的 PDF；记录取得渠道与可见许可/使用限制
安全与隐私限制：我自行登录；不得索取或回传密码、验证码、cookies、会话信息或机构凭据；不得绕过付费墙或访问控制
需要带回原对话的材料：PDF、来源或作者回传方式说明、许可/访问限制说明，以及完整 SCI-Skills 操作回传卡

完成后，请核验生成或下载的文件，并输出一张“SCI-Skills 操作回传卡”，保留项目ID、阶段和任务ID，列明实际步骤、参数、文件、标识符、限制和未解决问题。
```

### SCI-Skills 操作回传卡

```yaml
contract_version: "1.0"
project_id: "monotonicity-regularity-seesaw-2026-09"
paper_family: "T"
stage_id: "T2"
operation_task_id: "RL-NOV-MV-SEARCH-11"
platform_or_software:
operation_date:
completed_steps: []
queries_filters_or_parameters: []
generated_identifiers: []
returned_files: []
logs_or_screenshots: []
record_count_or_output_summary:
access_license_or_export_limits: []
problems_encountered: []
unresolved_items: []
user_confirmation:
credentials_or_secrets_included: false
```

---

## 11. Quality checks

- [x] 冻结基线 SHA-256 与任务给定值完全一致。
- [x] 未修改 `research/`。
- [x] 目标 DOI、标题、作者、期刊、卷、文章号与日期均由出版社正式页核对。
- [x] 作者全名差异由机构页核对；没有展开未知的 `M.`。
- [x] exact-title、DOI、作者、机构域、arXiv、勘误与 theorem-term 查询均逐字记录。
- [x] 记录了 hit-count 不可得性，没有伪造总命中数。
- [x] DOI 与规范化标题去重后只有一篇目标论文。
- [x] 摘要、关键词、搜索片段与全文证据严格分层。
- [x] every-at-each-point、reflection/Cayley、modulus/remainder 与量词问题均在无全文时保持 `PENDING_VERIFICATION`。
- [x] 阴性检索未被升级为 absence proof 或 novelty proof。
- [x] 未使用第三方 API，未绕过访问控制。

---

## 12. SCI-Skills Expert Contract 1.0

```yaml
contract_version: "1.0"
expert_skill: "sci-skills-literature-search"
project_id: "monotonicity-regularity-seesaw-2026-09"
paper_family: "T"
stage_id: "T2"
task_id: "RL-NOV-MV-SEARCH-11"
task_status: "PROVISIONAL"
inputs_reviewed:
  - "research/RL_foundations.md @ sha256:0adf8ca1593148bebce576e9659f3da50e61a77880c0b311cbcc35d0dcbb4ebd (read-only)"
  - "Springer Nature official article page for DOI 10.1007/s10957-025-02633-4"
  - "Springer Nature PDF endpoint and subscription-access response"
  - "Walaa M. Moursi author homepage and publications page"
  - "arXiv ordinary author-search page for W. Moursi (47 displayed records)"
  - "University of Waterloo/UWSpace domain-scoped search results"
  - "La Sierra University Jon D. Vanderwerff faculty page and domain-scoped search results"
  - "Exact-title, DOI, correction/status, manuscript, and theorem-term search logs dated 2026-09-01"
outputs:
  - "work/novelty_mv_search.md"
evidence_status:
  - "VERIFIED_SOURCE: title, DOI, journal, volume 205, article 50, received/accepted/published dates, author strings, affiliations, ORCID, abstract scope, keywords, and publisher access boundary"
  - "VERIFIED_SOURCE: Jon D. Vanderwerff is the fuller institutional form of the second author's name; the publisher omits D."
  - "VERIFIED_SOURCE: no public full text surfaced in the bounded author/arXiv/institutional search; this is a search boundary, not an absence proof"
  - "PENDING_VERIFICATION: every at-each-point definition; reflection/Cayley/monotonicity propositions; modulus/remainder; local/global/all-pairs/anchored quantifiers"
  - "PENDING_VERIFICATION: centered reflection remainder, moving anchor, isolated-zero q-flatness, and Hölder exponent gamma<1 overlap"
  - "AI_INFERENCE: the target is a direct novelty risk, but no positive or negative theorem-level overlap decision is justified without full text"
assumptions:
  - "The platform search interface does not expose stable per-query total hit counts; unavailable counts are reported as unavailable rather than estimated."
  - "No-hit results from site-scoped search are access/search boundaries, not proof that an author manuscript or a theorem does not exist."
  - "The frozen RL concepts are identified by their exact sections and formulas in the reviewed baseline hash."
author_input_needed:
  - "A lawfully obtained version-of-record PDF or author-shareable accepted manuscript for DOI 10.1007/s10957-025-02633-4."
manual_actions:
  - "Use the included one-step operation companion through the author's own institutional access or an author-manuscript request; return the PDF and operation return card without credentials."
quality_checks:
  - "Frozen baseline hash matched and research/ was not edited."
  - "Bibliographic identity was deduplicated by DOI and normalized title."
  - "Only publisher, author, institutional, and arXiv ordinary webpages support findings."
  - "Exact queries, filters, dates, hit-count availability, target hits, and access depth are recorded."
  - "Abstract/metadata/search snippets were not represented as full text."
  - "All requested theorem-level fields remain pending where full-text evidence is unavailable."
  - "No negative search result was upgraded to novelty proof."
conflicts: []
conflict_resolution_status: "NOT_REQUIRED"
merge_permission: "orchestrator_only"
stage_acceptance_recommendation: "REPAIR"
recommended_next_action: "请作者通过本人合法机构订阅取得该文 PDF，或向 Walaa M. Moursi / Jon D. Vanderwerff 索取可分享的 accepted manuscript，并把文件连同操作回传卡交回，以完成逐定义、逐命题的 T2 新颖性冻结。"
```
