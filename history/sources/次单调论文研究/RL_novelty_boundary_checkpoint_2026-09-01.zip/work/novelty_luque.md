# Luque 1984 原始来源与逐定理历史重叠核验

> 项目：`monotonicity-regularity-seesaw-2026-09`  
> family：`T`；stage：`T2`；task：`RL-NOV-LUQUE-13`  
> 核验日：2026-09-01  
> 冻结输入：`research/RL_foundations.md`，实测 SHA-256 `0adf8ca1593148bebce576e9659f3da50e61a77880c0b311cbcc35d0dcbb4ebd`；本任务未修改 `research/`。

## 0. 结论先行

1. **作者元数据需要纠正。** [SIAM 官方页面](https://epubs.siam.org/doi/10.1137/0322019)与 1981 年 LIDS 原稿封面均给出全名 **Fernando Javier Luque**，规范缩写是 **F. J. Luque**，不是现有任务引文中的 “R. Luque”。刊物元数据为 *SIAM Journal on Control and Optimization* 22(2), March 1984, 277–293，DOI [10.1137/0322019](https://doi.org/10.1137/0322019)。`[外部核验 / VERIFIED_SOURCE]`
2. **已取得并逐页读取 primary prepublication 全文。** [MIT DSpace 官方记录](https://dspace.mit.edu/entities/publication/8faf9133-3e45-4400-9a4f-40ad3afbab90)把同题报告列为 1981 年 MIT Laboratory for Information and Decision Systems 出版物；公开的 [LIDS-P-1142 PDF](https://pdfs.semanticscholar.org/8733/1e54b6595ad42fdb76dbb13e347b0aa3128f.pdf) 共 36 个 PDF 页，封面标明 September 1981、Fernando Javier Luque、MIT LIDS 与 Operations Research Center，并标 “To appear in SIAM Journal on Control and Optimization”。本地下载件 SHA-256 为 `af357dfe1e7036892523061496218d040817630104d25b03111b2d2a79004e78`。`[原文事实 / VERIFIED_SOURCE]`
3. **Luque 已在 maximal-monotone PPA 中得到非孤立解集的 endpoint set-distance 幂阶。** 预刊 Theorem 3.1 的 inverse growth 为
   \[
   \forall w\in B(0,\delta),\ \forall z\in T^{-1}w:
   d(z,\bar Z)\le a\|w\|^s,
   \]
   其陈述实际是 (r\ge1,s\ge1)；结论对象是 (d(z^k,\bar Z))，Q-order 至少 (min\{r,s\})。证明式 (3.7) 在 exact PPA 下直接化为 endpoint 上界
   \[
   d(z^{k+1},\bar Z)\le \frac{a}{c_k^s}d(z^k,\bar Z)^s.
   \]
   常步长 (c_k\equiv\lambda) 是其特例。故“inverse growth / higher-order error bound 首次给出非孤立 PPA 的 (q)-阶 set-distance”以及“孤立点下首次给出 actual-iterate endpoint (q)-阶”均不可作为新颖性主张。`[原文事实 + AI分析 / VERIFIED_SOURCE + AI_INFERENCE]`
4. **Luque 没有覆盖当前稿件仍可保留的结构。** LIDS 原稿没有 restricted/nonmonotone named branch、anchored RL 的独立指数 (gamma)、finite-length 强收敛、reflector remainder、input/output 两锚点 drift，或显式 (\theta q) composition。Frozen §4.2、§5、§7.4、§8.2 的可守价值须落在这些更窄的结构与量词上，而不能落在“PPA 高阶收敛存在性”上。`[AI分析 / AI_INFERENCE]`
5. **Luque 与 Zhu 的结论对象和 endpoint 强度相反。** Luque 在任意实 Hilbert 空间处理 exact/inexact PPA，给 (d(z^k,\bar Z)) 的 endpoint (s)-幂上界；Zhu 1995 在有限维 exact PPA 中给实际迭代点 (|z^k-\bar z|) 的结论，但正式证明是每个 (1<t<r) 的 ratio-to-zero，未声明 endpoint (t=r)。`[原文事实 / VERIFIED_SOURCE]`

## 1. 范围与输入（scope_and_inputs）

| 项 | 本任务口径 |
| --- | --- |
| 研究问题 | Luque 1984 的 inverse growth、PPA 范围、步长、解集、各 rate theorem、指数及 rate object，与 frozen §4.2、§5、§7.4、§8.2 和 Zhu 1995 到底重叠到哪一层？ |
| 证据目的 | 历史优先权与 theorem-level novelty 边界；不是系统综述，也不推进 T2 阶段 |
| 学科/对象 | maximal monotone operator、proximal point algorithm、Hölder/inverse growth、Q-rate |
| 文献范围 | Luque 刊物官方页、MIT 报告记录与公开原稿；Zhu 1995 primary prepublication；冻结稿指定章节 |
| 语言/文种 | 英文期刊论文、机构技术报告；中文审计输出 |
| 访问约束 | 仅平台原生检索、普通公开网页、官方/机构页面与公开 PDF；未用第三方 API、密钥、SDK，也未绕过 SIAM 访问控制 |
| 深读层级 | `DEEP`：公式、假设、逐定理 rate object、endpoint、维度和历史 crosswalk |

### 1.1 证据标签

- `原文事实 / VERIFIED_SOURCE`：直接由可访问的 primary prepublication 或官方页面支持，并附 theorem、equation 或页码定位。
- `外部核验 / VERIFIED_SOURCE`：由官方刊物页或机构记录核验的元数据。
- `AI分析 / AI_INFERENCE`：由已核公式与 frozen 定理作出的重叠判断，不冒充原文自述。
- `PENDING_VERIFICATION`：SIAM 最终排印全文与 LIDS 原稿的逐字一致性；本任务没有把二手文献当成最终刊版替代品。

## 2. 检索设计与日志（literature_search）

### 2.1 概念块与检索式

| 概念块 | 关键词/变体 | 用途 |
| --- | --- | --- |
| 书目身份 | `10.1137/0322019`; exact title; `Fernando Javier Luque`; `F. J. Luque` | 作者全名、刊物、DOI、版本去重 |
| 机构原稿 | `LIDS-P-1142`; title + `MIT`; `dspace.mit.edu` | 寻找合法 primary prepublication 与机构 provenance |
| 定理内容 | `inverse growth`; `T^{-1}`; `proximal point`; `Q-order`; `set distance`; `superlinear` | 定位假设、rate object、endpoint 与 phase |
| 历史比较 | `Ciyou Zhu`; `P457`; `forward-backward`; `Luque`; `actual iterate` | Luque–Zhu 边界与后续可验证引用 |
| 完整性状态 | DOI + `correction OR erratum OR retraction` | 有界核验更正/撤稿信号 |

Broad discovery query：`"Asymptotic Convergence Analysis of the Proximal Point Algorithm" Luque PDF`。  
Narrow confirmation queries：`"10.1137/0322019"`、`"LIDS-P-1142"`、`site:dspace.mit.edu "LIDS-P-1142"`。

### 2.2 可复现检索日志

平台没有暴露每条 query 的全量 hit count；下表只报告同批查询合并返回的**可见候选数**，不把它冒充数据库总命中数。

| 日期 | 路由 | 完整 query | 过滤 | 可见候选 | 结果/限制 |
| --- | --- | --- | --- | ---: | --- |
| 2026-09-01 | 平台原生 web search | `"10.1137/0322019"`; `"Asymptotic Convergence Analysis of the Proximal Point Algorithm" Luque PDF`; 同题 `author`; `site:siam.org "0322019" Luque` | 无日期限制 | 28（合并） | 命中 SIAM 官方页、重复元数据页和后续引用；SIAM final PDF 显示 Get Access |
| 2026-09-01 | 平台原生 web search | `"LIDS-P-1142"`; `site:dspace.mit.edu "LIDS-P-1142"`; `site:mit.edu` + exact title; `"Fernando Javier Luque" MIT proximal point` | 优先 MIT | 12（合并） | 命中 MIT DSpace 官方记录及公开 LIDS PDF；其余多为 “Lids” 商业噪声 |
| 2026-09-01 | 平台原生 web search | `site:dspace.mit.edu/bitstreams "LIDS-P-1142" pdf`; DSpace UUID + `Download`; `site:hdl.handle.net` + exact title; `"LIDS-P-1142" PDF MIT` | 机构域优先 | 2（合并） | 官方 bitstream URL 未被搜索结果暴露；公开 PDF 镜像可正常读取 |
| 2026-09-01 | 平台原生 web search | `"10.1137/0322019" correction OR erratum OR retraction`; `site:epubs.siam.org/doi "10.1137/0322019" correction`; DSpace UUID + `Luque 1981` | 官方域优先 | 3（合并） | 未命中针对该文的 correction/erratum/retraction 页面；这是有界检索结果，不是穷尽性证明 |
| 2026-09-01 | 直接打开 primary source | `https://ftp.mcs.anl.gov/pub/tech_reports/reports/P457.pdf` | Argonne 机构全文 | 1 | Zhu P457，22 个 PDF 页，全文可读 |

### 2.3 筛选、排除与去重

| 候选 | 处理 | 理由 |
| --- | --- | --- |
| SIAM DOI 页面 | 纳入 | 作者全名、摘要、卷期页、DOI、提交日期均为官方元数据 |
| MIT DSpace entity 记录 | 纳入 | 官方机构 provenance；页面被搜索索引确认，直接打开在当前检索器中报内部错误 |
| LIDS-P-1142 公开 PDF | 纳入为 primary prepublication full text | 封面身份、机构、日期和 “to appear” 完整；无登录、无绕过 |
| ACM/Semantic Scholar 题录页、普通引用页 | 书目去重后排除 | DOI/题名重复，不能替代原稿定理块 |
| ResearchGate、Amanote 等聚合页 | 排除 | 不需要且 provenance 弱于 MIT 记录 + LIDS 原稿 |
| 后续论文的一般引用 | 排除出 Luque 原文事实层 | 只可作历史线索；未用其替代 Luque 原稿 |
| Zhu Argonne P457 | 纳入比较层 | 机构 primary prepublication，明确逐字比较 Luque 的 set-distance 与 Zhu 的 actual iterate |

Deduplication：按 DOI `10.1137/0322019` 合并题录，再按规范化题名与作者-年份核验；最终识别为一个 1984 刊物作品及其 1981 LIDS prepublication 版本。没有执行 RIS/BibTeX 批量导出；本任务是单篇定理审计，export guidance 为 `NOT_APPLICABLE`。

## 3. 来源深度与书目身份（evidence_and_execution_status）

| ID | 来源 | 层级 | 已核内容 | 状态 |
| --- | --- | --- | --- | --- |
| L1 | [SIAM 期刊页](https://epubs.siam.org/doi/10.1137/0322019) | 官方 publisher page + abstract | Fernando Javier Luque；卷 22、期 2、March 1984、277–293；DOI；submitted 21 Sep 1981；Hilbert/maximal-monotone/set-distance phase 摘要 | `VERIFIED_SOURCE` |
| L2 | [MIT DSpace 记录](https://dspace.mit.edu/entities/publication/8faf9133-3e45-4400-9a4f-40ad3afbab90) | 官方机构记录 | 1981；MIT Laboratory for Information and Decision Systems 出版物；同题 | `VERIFIED_SOURCE` |
| L3 | [LIDS-P-1142 PDF](https://pdfs.semanticscholar.org/8733/1e54b6595ad42fdb76dbb13e347b0aa3128f.pdf) | primary prepublication full text | 36 PDF 页；封面、全文公式、Theorems 1.1/2.1/3.1/3.2/4.1/4.2；本地 hash 已记录 | `VERIFIED_SOURCE` |
| Z1 | [Zhu Argonne P457](https://ftp.mcs.anl.gov/pub/tech_reports/reports/P457.pdf)；[刊物 DOI](https://doi.org/10.1287/moor.20.2.449) | primary prepublication full text + official identifier | finite-dimensional exact PPA；Definition 2.3、Lemma 4.1、Theorem 4.3；Luque 比较段 | `VERIFIED_SOURCE` |
| F1 | `research/RL_foundations.md` frozen hash | 用户工作区冻结材料 | §4.2、§5、§7.4、§8.2 的精确陈述 | `VERIFIED_USER_MATERIAL` |

**访问边界。** SIAM 最终排印 PDF 在当前会话中要求订阅；没有尝试绕过。下文凡称“Luque 原文定理”均精确指 LIDS-P-1142 primary prepublication，并给预刊印刷页码；只把 SIAM 官方页用于刊物元数据和摘要对齐。LIDS 原稿与最终排印版是否逐字相同仍是 `PENDING_VERIFICATION`，本文不假装完成该项比对。

**本地执行。** 实际下载 LIDS PDF、计算 SHA-256、以 `pdftotext -layout` 提取 1,952 行文本，并把关键扫描页渲染为 PNG 逐式目检。特别核掉 OCR 容易把 `\ge` 误识成 `>` 的问题：Theorems 2.1 与 3.1 扫描页均明确写 (r\ge1)，Theorem 3.1 亦明确写 (s\ge1)。`[EXECUTED_LOCAL]`

## 4. 标准深读卡（specialist_findings）

| # | 项目 | 结论与证据层 |
| ---: | --- | --- |
| 1 | Bibliographic position | 1981 LIDS 报告、1984 SIAM 刊文；早于 Zhu 1995，是 inverse growth–PPA rate 的直接历史源。`原文事实/外部核验` |
| 2 | Research question | 对 (0\in Tz) 的 exact/inexact PPA，(T^{-1}) 离解集的增长怎样控制 set-distance 收敛速度？`原文事实` |
| 3 | Background route | 以 Rockafellar 1976 的 maximal-monotone PPA 全局弱收敛和 firm-type 不等式为起点。`原文事实`，预刊 pp. 4–6 |
| 4 | Unresolved pain point | 既有 rate 主要针对单解；Luque 要处理一般非空解集并统一 sublinear/linear/superlinear/finite phases。`原文事实`，pp. 6–8 |
| 5 | Core insight | 对所有小 (w) 和所有 (z\in T^{-1}w) 控制 (d(z,\bar Z))，再用 resolvent 的 Pythagorean inequality 消去 step residual。`原文事实` |
| 6 | Method overview | (P_k=(I+c_kT)^{-1})、(Q_k=I-P_k)；exact 或满足 ((A_r)) 的 inexact step；把 (c_k^{-1}Q_kz^k\in T(P_kz^k)) 代入 inverse growth。`原文事实`，(1.1)、(A_r) |
| 7 | Mechanism logic | inverse growth 控 output set-distance；firmness 给 (|Q_kz^k|^2\le d_k^2-d(P_kz^k,\bar Z)^2)；inexact tolerance 再引入 (r)-幂项。`原文事实`，(2.3)、(3.2)–(3.7) |
| 8 | Essential formula | (d(z,\bar Z)\le a\|w\|^s)；exact endpoint (d_{k+1}\le(a/c_k^s)d_k^s)。符号与失败边界见 §5。`原文事实` |
| 9 | Data/material | 无数据集；纯理论，空间为任意实 Hilbert 空间。`原文事实` |
| 10 | Design/baseline | 同时分析 exact/inexact、有限/无界步长；Theorem 2.1 后的二维旋转 maximal-monotone 例证明线性 factor bound 可达。`原文事实`，pp. 10–14 |
| 11 | Claim evidence | 逐定理链见 §6 matrix。`原文事实` |
| 12 | Conclusion boundary | 一般结论是 (d(z^k,\bar Z))，不是 (|z^k-z^\infty|)；Hilbert 空间中的迭代点只由基线定理保证弱收敛。`原文事实` |
| 13 | Author-stated limitation | Theorem 4.2 后的 remark 明说 (s\uparrow1) 时 (o(k^{-s/2})) 估计看来保守。`原文事实`，p. 32 |
| 14 | Critical assessment | Theorem 3.1 的 endpoint set-distance 比“只对每个 (t<s)”更强，但不能在非孤立集上自动升级为 actual-iterate endpoint。`AI分析` |
| 15 | Reusable connection | Luque 的 power growth 与 frozen (PEB) 同属 Hölder inverse/error-bound 路线；不同在于 Luque 使用 maximal monotonicity，frozen 使用 named coverage + anchored RL + output EB。`AI分析` |
| 16 | Falsifiable boundary | 在已读 LIDS 全文中未见 reflector remainder、two-anchor drift 或 (\theta q) theorem；若最终排印版存在新增同型定理，此边界需重开。`AI分析` |

## 5. 关键假设、算法与 rate object

### 5.1 inverse growth 的精确量词

Luque 的通用 growth condition（预刊 p. 6；Proposition 1.2 用式 (1.4)）是

\[
\exists\delta>0\quad
\forall w\in B(0,\delta)\quad
\forall z\in T^{-1}w:
\quad d(z,\bar Z)\le f(\|w\|),
\qquad f(0)=0.
\]

power specialization 是 (f(t)=at^s)。这是 **residual 邻域内、对整个 inverse image 的统一条件**；它没有 frozen (GEB)/(PEB) 的 base-point neighborhood，因此相对于某一固定零点附近的局部 error bound，Luque 的 (z)-量词更宽、更强。`[原文事实 + AI分析]`

### 5.2 operator、解集与维度

- (T:H\rightrightarrows H) 是 multivalued maximal monotone，(H) 为实 Hilbert 空间；不是只限有限维。`[原文事实]`
- (P_k=(I+c_kT)^{-1}) 因 maximal monotonicity 在全 (H) 单值有定义。`[原文事实]`
- (\bar Z=T^{-1}(0)\ne\varnothing)，由 maximal monotonicity 为闭凸集，故每个点有唯一最近点。主 rate theorem 不要求 singleton；Theorem 3.2 后还明确说 (\bar Z) 可非 singleton、甚至非 compact。`[原文事实]`
- frozen 稿不默认 (S) 闭、凸、proximinal，并允许 arbitrary set-valued (F) 的局部 named branch；这是适用域上的实质差别。`[AI分析]`

### 5.3 PPA 与步长

Luque 的 exact step 为

\[
z^{k+1}=P_kz^k,
\qquad P_k=(I+c_kT)^{-1},\quad c_k>0.
\]

inexact criterion 为

\[
\|z^{k+1}-P_kz^k\|
\le \varepsilon_k\min\{1,\|z^{k+1}-z^k\|^r\},
\quad r>0,\ \varepsilon_k\ge0,\ \sum_k\varepsilon_k<\infty.
\tag{A_r}
\]

- Rockafellar Theorem 1.1 的复述与 Proposition 1.2 只需 (liminf c_k>0)。
- Theorems 2.1、3.1 使用非减 (c_k\uparrow c_\infty\le+\infty)。
- Theorem 4.1 另要求 (c_\infty<+\infty)；Theorem 4.2 允许 (c_\infty\le+\infty)。
- frozen 稿固定 (lambda>0)；(c_k\equiv\lambda) 完全落在 Luque 的允许范围内。`[原文事实 + AI分析]`

### 5.4 set-distance、actual iterate 与强/弱收敛

Luque 在预刊 p. 5 明定“analysis will focus”于标量序列 (d(z^k,\bar Z))。Theorem 1.1 只给 (z^k\rightharpoonup z^\infty\in\bar Z)，Proposition 1.2 再给 (d(z^k,\bar Z)\to0)。所以：

- 一般非孤立 (\bar Z)：不能把 Luque rate 改写为 (|z^k-z^\infty|) rate；
- singleton 或轨道最终落入 locally isolated 零点邻域：(d(z^k,\bar Z)=\|z^k-p\|)，Luque endpoint set-distance 就成为 actual-iterate endpoint；
- frozen Theorem 4.2 由 finite length 证明强收敛，这是 Luque 的一般 Hilbert set-distance 分析没有给出的结论。`[原文事实 + AI分析]`

## 6. Luque theorem matrix（逐定理核验）

| 原稿 block（预刊印刷页） | 关键假设 | 原文结论与 rate object | endpoint/维度 | 对 frozen 的历史重叠判决 |
| --- | --- | --- | --- | --- |
| Theorem 1.1（Rockafellar 复述），pp. 5–6 | maximal monotone；(\bar Z\ne\varnothing)；((A_r))；(liminf c_k>0) | (z^k) 有界并弱收敛到 (\bar Z) 中一点；residual/step (\to0) | Hilbert；无 rate | §4.2 的强收敛与 finite length 不被覆盖；但全局 PPA 合法性来自更强 maximal monotonicity |
| Proposition 1.2，pp. 8–9，(1.4) | 通用 inverse gauge (f)，在 0 上半连续；其余同上 | (d(z^k,\bar Z)\to0) | Hilbert；set-distance | 已把 inverse growth 与 PPA set-distance convergence 连接；§4.2 的 gauge 路线不是历史首次，但其 named/nonmonotone/finite-length 组合仍不同 |
| Theorem 2.1，pp. 10–12，(2.1)–(2.8) | (s=1) growth；(r\ge1)；(c_k\uparrow c_\infty) | (d_k) Q-linear，factor (le a/(a^2+c_\infty^2)^{1/2}<1)；若 (c_\infty=\infty) 则 superlinear | Hilbert；set-distance；后附二维 tight example | 直接覆盖 frozen §5 的 maximal-monotone (q=1) 历史核心；frozen 系数来自 RL 路线，不能宣称更优或首次 |
| Theorem 3.1，pp. 17–19，(3.1)–(3.7) | (r\ge1,s\ge1)；power inverse growth；(c_k\uparrow c_\infty) | (d_k\to0)，Q-order (t\ge\min\{r,s\})；exact 时 endpoint (d_{k+1}\le(a/c_k^s)d_k^s) | Hilbert；非孤立允许；endpoint upper order，不是 two-sided exact factor | **直接覆盖** §5 的 (q)-phase、§7.4 在 maximal-monotone isolated 子类的 actual endpoint、§8.2 在 maximal-monotone set-distance/(\theta=1) 历史主题；不覆盖 (gamma q)、reflection、two-anchor/(\theta q)、restricted branch |
| Theorem 3.2，pp. 21–23，(3.8)–(3.12) | (T^{-1}(B(0,\delta))\subset\bar Z)（flat/(s=\infty) 极限）；exact 或 ((A_r))；(liminf c_k>0) | exact PPA 有限步终止；inexact 给 (d_{k+1}\le\varepsilon_k(1-\varepsilon_k)^{-r}d_k^r)，(r\ge1) 时 superlinear | Hilbert；(\bar Z) 可非 singleton/noncompact | finite-termination 历史边界已存在；frozen 不能以 flat inverse–PPA finite termination 为新颖点 |
| Lemmas 3.2–3.3 / Proposition 3.4，pp. 25–29 | maximal monotone、normal cone/interior geometry | 比较 (T^{-1}(B(0,\delta))\subset\bar Z) 与 (0\in\operatorname{int}T\bar Z)，并推出后者要求 (\bar Z) 有界等 | Hilbert；几何支持 | 无 RL/reflector 等价；主要限定 Theorem 3.2 的历史语境 |
| Theorem 4.1，pp. 29–31，(4.1) | 对每个 (a>0)，小 residual 时 (d(z,\bar Z)\ge a\|w\|)；(c_k\uparrow c_\infty<\infty) | 非有限终止时 (liminf d_{k+1}/d_k=1)，不能快于 sublinear | Hilbert；exact/inexact | 与 frozen §5 “(q<1) 的 upper bound 单独不推出收敛/发散”不冲突；Luque 另用了 converse lower growth + maximal monotone PPA |
| Theorem 4.2，pp. 31–32，(4.8) | exact；(0<s<1) power growth；(c_k\uparrow c_\infty\) | (d_k=o(k^{-s/2}))；无界 (c_k) 可更快 | Hilbert；set-distance | Luque 已给 sublinear phase rate；frozen §5 仅凭局部 one-step upper bound不作该结论是正确且更弱的逻辑边界 |

## 7. Theorem 3.1 的 endpoint 核验

令 (d_k=d(z^k,\bar Z))。LIDS 扫描页的正式定义把 (d_k) 的 Q-order 定义为：使

\[
\limsup_{k\to\infty}\frac{d_{k+1}}{d_k^\tau}<+\infty
\]

成立的 (\tau\ge1) 的 supremum。Theorem 3.1 声明该 order 至少为 (min\{r,s\})。更重要的是，证明中的 (3.7) 给出实际 endpoint recurrence

\[
d_{k+1}
\le
\frac{a d_k^s}
{(1-\varepsilon_k)
\left(c_k^2+a^{2/s}d(P_kz^k,\bar Z)^{2(s-1)/s}\right)^{s/2}}
+
\frac{2\varepsilon_k}{(1-\varepsilon_k)^r}d_k^r.
\tag{L-3.7}
\]

在 exact PPA 中 (\varepsilon_k=0)，故

\[
d_{k+1}
\le
\frac{a d_k^s}
{\left(c_k^2+a^{2/s}d(P_kz^k,\bar Z)^{2(s-1)/s}\right)^{s/2}}
\le \frac{a}{c_k^s}d_k^s.
\tag{L-endpoint}
\]

所以需严格区分：

- **已核原文事实：** Luque 有 endpoint (O(d_k^s))，但对象是 set-distance；
- **不能升级的结论：** 没有 two-sided exact exponent，也没有正的 exact Q-factor；
- **孤立子类：** 若 (d_k=\|z^k-p\|)，上式就是 actual-iterate endpoint；
- **非孤立一般情形：** 上式不能控制 (|z^k-z^\infty|)。

## 8. 与 Zhu 1995 的精确区分

Zhu 的 [Argonne P457](https://ftp.mcs.anl.gov/pub/tech_reports/reports/P457.pdf) 在开篇明确说，其 actual-sequence 分析补充 Luque “mostly” 关于 (d(z^k,\bar Z)) 的结果（PDF p. 3）；末尾再次明确比较两者（PDF p. 19）。

| 轴 | Luque LIDS-P-1142 / 1984 | Zhu P457 / 1995 |
| --- | --- | --- |
| 空间 | 任意实 Hilbert 空间 | (mathbb R^n)，有限维 |
| operator | multivalued maximal monotone (T) | maximal monotone；PPA 是 forward-backward 的 (h=0) 特例 |
| 算法 | exact + ((A_r)) inexact | Section 4 的 rate theorem 是 exact PPA |
| 步长 | rate theorem 多用非减 (c_k\uparrow c_\infty) | 可变 (c_k)，Theorem 4.3 只需 (liminf c_k>0) |
| growth | (\forall z\in T^{-1}w, d(z,\bar Z)\le a\|w\|^s) | Definition 2.3 同型 (r)-growth |
| 解集 | 非空闭凸，可非 singleton/noncompact | 非空，可非 singleton |
| rate object | (d(z^k,\bar Z)) | actual iterate (|z^k-\bar z|) |
| 高阶 endpoint | exact 时有 (d_{k+1}=O(d_k^s)) | Theorem 4.3 对每个 (1<t<r) 有 ratio (\to0)；未声明 (t=r) endpoint |
| alignment | 无 orbit tangent/normal lemma | Lemma 4.1：归一化误差相对 (T_{\bar Z}(\bar z)) 的距离系数 (\to1)，即渐近 normal alignment |
| 收敛拓扑 | 一般迭代点弱收敛；set-distance 有 rate | 有限维 actual iterate 收敛并有 rate |

因此，安全的历史叙述是：**Luque 先给一般 Hilbert/maximal-monotone PPA 的非孤立 set-distance endpoint 幂阶；Zhu 后给有限维 exact PPA 的非孤立 actual-iterate、orbit-alignment 与任意 (t<r) 的高阶结论。** 两者共同排除了“首次把 higher-order inverse growth 用于 PPA”以及“首次处理非孤立高阶 PPA”的主张。`[原文事实 + AI分析]`

## 9. Frozen §4.2、§5、§7.4、§8.2 crosswalk

| Frozen block | Luque 已覆盖的历史核心 | Zhu 补充的威胁 | 当前仍可守的精确区别 | 新颖性判决 |
| --- | --- | --- | --- | --- |
| Theorem 4.2 localized gauge–PPA | inverse gauge + PPA set-distance convergence；power/linear/superlinear phases；Hilbert、非孤立、inexact 亦可 | actual iterate + finite-dimensional orbit geometry | arbitrary set-valued (F) 的 named coverage；anchored RL；显式 local margin/invariance；finite length 与强收敛 | **宽主题 KNOWN；结构差异 POTENTIAL_DISTINCTION** |
| §5 power corollaries | (q=s) 的 endpoint set-distance；(q=1) factor；(q>1) superlinear；(q<1) sublinear phase | actual iterate 对每个 (t<q) | 独立 RL exponent (gamma) 导致 (gamma q)；(L=0) 时回到 (q)；这些 branchwise phase bookkeeping 不在 Luque | **(q)-phase KNOWN；(gamma q) packaging POTENTIAL_DISTINCTION** |
| Theorem 7.4 isolated named PPA | 一旦解在局部唯一，Luque 的 endpoint set-distance 即 actual endpoint (q)；常步长也是特例 | isolated endpoint 亦是 Zhu 同型 growth 的直接邻近推论，虽非其正式 endpoint statement | nonmonotone/restricted named branch；纯局部 base/residual windows；ball invariance；reflector 公式 (7.8) | **rate 本身 KNOWN/KNOWN_ADJACENT；branch/reflection 才可守** |
| Theorem 8.2 nonisolated (\theta q) | maximal-monotone exact PPA 已有非孤立 set-distance endpoint (q)，不需显式 two-anchor 语言 | actual iterate + asymptotic normal alignment，但仅 (t<q) 且无 quantitative (\theta) | map-level two-anchor envelope、显式 drift/alignment exponent (\theta)、一般 branch 下的 conditional endpoint (\theta q) | **非孤立高阶存在性 KNOWN；two-anchor/(\theta q) 结构 POTENTIAL_DISTINCTION** |

### 9.1 可直接采用的 claim-safe 文字

> Luque already established endpoint power-order convergence of the distance to a possibly non-singleton solution set for maximal-monotone proximal point iterations under an inverse growth condition, while Zhu later obtained actual-iterate high-order convergence in finite dimensions through an asymptotic normal-alignment argument. Our distinction is therefore not the existence of higher-order PPA convergence. It lies in a local named-branch mechanism that does not assume maximal monotonicity, separates anchored RL from the output error bound, and exposes reflection and two-anchor alignment as independent quantitative components.

### 9.2 必须避免的主张

- “首次把 higher-order metric subregularity/inverse growth 与 PPA rate 联系起来。”
- “首次在非孤立解集上得到 PPA 超线性 set-distance 收敛。”
- “首次在孤立零点下得到 fixed-step PPA endpoint (q)-阶。”
- “Luque 只给线性率，未给高阶 endpoint。”
- “Zhu 已给 endpoint (q)-阶 actual-iterate theorem。”——其正式证明是每个 (t<q)。

## 10. Claim-to-source evidence matrix（deliverables）

| Claim | 直接定位 | 标签 | 判定 |
| --- | --- | --- | --- |
| 作者是 Fernando Javier Luque | SIAM page author field；LIDS cover | `外部核验/原文事实` | `VERIFIED_SOURCE` |
| 刊物为 22(2), 277–293, DOI 10.1137/0322019 | SIAM Information | `外部核验` | `VERIFIED_SOURCE` |
| LIDS-P-1142 是 MIT 1981 primary prepublication | MIT DSpace record；LIDS cover | `外部核验/原文事实` | `VERIFIED_SOURCE` |
| scope 是 real Hilbert + multivalued maximal monotone | LIDS abstract、pp. 1–5；SIAM abstract | `原文事实` | `VERIFIED_SOURCE` |
| 解集可非 singleton/noncompact | p. 5；Theorem 3.2 后 remark, p. 23 | `原文事实` | `VERIFIED_SOURCE` |
| inverse growth 对全 (T^{-1}w) 量化 | p. 6；(1.4)、(2.1)、(3.1) | `原文事实` | `VERIFIED_SOURCE` |
| linear factor 与无界步长 superlinear | Theorem 2.1, pp. 10–12 | `原文事实` | `VERIFIED_SOURCE` |
| endpoint set-distance (s)-幂 | Theorem 3.1, (3.7), pp. 17–19 | `原文事实` | `VERIFIED_SOURCE` |
| exact finite termination / inexact (r)-order | Theorem 3.2, pp. 21–23 | `原文事实` | `VERIFIED_SOURCE` |
| (0<s<1) 时 (o(k^{-s/2})) | Theorem 4.2, pp. 31–32 | `原文事实` | `VERIFIED_SOURCE` |
| Luque rate object 主要为 set-distance | LIDS p. 5；Zhu P457 pp. 2, 18 | `原文事实` | `VERIFIED_SOURCE` |
| Zhu 是 finite-dimensional exact actual-iterate，正式 endpoint 未给 | Zhu abstract、Lemma 4.1、Theorem 4.3 proof | `原文事实` | `VERIFIED_SOURCE` |
| frozen 的安全差别是 branch/RL/finite-length/reflection/two-anchor | 上述原文与 frozen §4.2/§5/§7.4/§8.2 crosswalk | `AI分析` | `AI_INFERENCE` |

## 11. 限制与风险（limitations_and_risks）

1. 已深读的是 primary prepublication，不是被 SIAM 访问控制拦住的最终排印 PDF；不能声称两版逐字相同。
2. theorem 编号、假设与公式均以 LIDS 扫描页为准；自动 OCR 多处把 `\ge` 误成 `>`，关键页已经视觉复核。
3. “未见 reflector/two-anchor/(\theta q)”只对已读 LIDS 全文成立，不是全领域的绝对不存在声明。
4. correction/retraction 检索是有界普通网页检索；没有命中专门记录，但不把负命中升级为穷尽性证明。
5. 当前 crosswalk 不证明 frozen 定理新颖，只把 Luque/Zhu 已知覆盖与仍待更广文献核验的区别拆开。

## 12. 质量检查（quality_checks）

- [x] 冻结文件 hash 与任务指定值完全一致；未修改 `research/`。
- [x] 完整读取并遵循 `sci-skills-literature-search` 与 `sci-skills-paper-deep-reading` 的 SKILL、required core refs、playbook 与 schemas。
- [x] 区分 publisher metadata、official repository record、primary prepublication full text、二手索引与 AI crosswalk。
- [x] Theorems 2.1、3.1、3.2、4.1、4.2 的假设、rate object、步长和 exponent 均有页/式定位。
- [x] Theorem 3.1 的 (r\ge1,s\ge1) 与 endpoint (3.7) 已由扫描图目检，不依赖 OCR。
- [x] 已核 real Hilbert vs finite dimension、set-distance vs actual iterate、endpoint vs (t<q)、exact vs inexact。
- [x] 没有使用第三方 API、凭证或绕过访问控制。
- [x] 没有把 bounded search 称为 systematic search，也没有把未读 SIAM final PDF 称为全文已核。

## 13. SCI-Skills Expert Contract 1.0

```yaml
contract_version: "1.0"
expert_skill: "sci-skills-literature-search; sci-skills-paper-deep-reading"
project_id: "monotonicity-regularity-seesaw-2026-09"
paper_family: "T"
stage_id: "T2"
task_id: "RL-NOV-LUQUE-13"
task_status: COMPLETE
inputs_reviewed:
  - "research/RL_foundations.md @ sha256:0adf8ca1593148bebce576e9659f3da50e61a77880c0b311cbcc35d0dcbb4ebd"
  - "SIAM official article page and abstract for DOI 10.1137/0322019"
  - "MIT DSpace publication record 8faf9133-3e45-4400-9a4f-40ad3afbab90"
  - "Luque LIDS-P-1142 primary prepublication full text, 36 PDF pages, sha256:af357dfe1e7036892523061496218d040817630104d25b03111b2d2a79004e78"
  - "Zhu Argonne primary prepublication P457, especially Definition 2.3, Lemma 4.1, Theorem 4.3"
outputs:
  - "work/novelty_luque.md"
  - "reproducible search log, screening log, and deduplication summary"
  - "Luque theorem matrix and frozen-section crosswalk"
  - "Luque–Zhu endpoint/rate-object/dimension comparison"
  - "claim-safe and prohibited novelty language"
evidence_status:
  - "VERIFIED_USER_MATERIAL: frozen baseline hash and specified theorem text"
  - "VERIFIED_SOURCE: SIAM official author, abstract, DOI, issue, pages, and submission metadata"
  - "VERIFIED_SOURCE: MIT official report provenance"
  - "VERIFIED_SOURCE: LIDS-P-1142 primary prepublication full-text theorem audit"
  - "VERIFIED_SOURCE: Zhu P457 primary prepublication comparison"
  - "EXECUTED_LOCAL: PDF hashing, text extraction, page rendering, and visual formula checks"
  - "PENDING_VERIFICATION: word-for-word identity between LIDS-P-1142 and the paywalled final SIAM typeset article"
assumptions:
  - "Notation mapping for comparison: Luque T,Z,c_k,s correspond to frozen F,S,lambda,q when c_k is constant."
  - "No claim of textual identity between the prepublication and final typeset version is made."
author_input_needed: []
manual_actions: []
quality_checks:
  - "source-depth gate recorded"
  - "all requested Luque fields checked at theorem level"
  - "set-distance and actual-iterate conclusions kept separate"
  - "endpoint and t<q statements kept separate"
  - "finite- and infinite-dimensional scopes kept separate"
  - "zero-API and access-control boundaries respected"
conflicts: []
conflict_resolution_status: NOT_REQUIRED
merge_permission: orchestrator_only
recommended_next_action: "见文末“唯一下一步（one_next_action）”。"
stage_acceptance_recommendation: PASS_CANDIDATE
```

## 14. 唯一下一步（one_next_action）

由 SCI-Skills 编排器把本报告的 Theorem 3.1 判决并入 T2 新颖性矩阵：将“maximal-monotone PPA 的非孤立 set-distance endpoint (s)-阶”标为 Luque 已知，只保留 named/nonmonotone branch、finite-length 强收敛、reflection 与 two-anchor/(\theta q) 作为待更广文献核验的候选区别。
