# RL 新颖性冻结：独立终审与冲突消解

> **project_id**: `monotonicity-regularity-seesaw-2026-09`  
> **paper_family / stage_id / task_id**: `T / T2 / RL-NOV-FREEZE-REFEREE-15`  
> **role**: independent novelty referee / integrator  
> **review mode**: read-only synthesis；不作新文献检索；不修改 `research/`  
> **review date**: `2026-09-01`

## 0. 终审结论

1. 冻结数学基线保持不变。`research/RL_foundations.md` 的实测 SHA-256 为
   `0adf8ca1593148bebce576e9659f3da50e61a77880c0b311cbcc35d0dcbb4ebd`，与指定冻结值一致。
2. Luque 风险已经在 theorem level 闭合，并产生一项必须进入后续稿件的重大更正：**F. J. Luque 已在 maximal-monotone、可能非单点解集的 PPA 中，从 full inverse power growth 得到 exact PPA 的 set-distance endpoint upper recurrence**。因此，固定步长 maximal-monotone 特例中的纯 (q)-phase 不能作为 RL 的新贡献。
3. Luque 没有消掉全部 RL package。相对 Luque 可保留的候选区别是：restricted/nonmonotone named branch、显式 coverage/exclusion/invariance 账本、(\gamma<1) Hölder--Cayley 与 error bound 的条件式复合、finite-length strong convergence、fixed/moving-anchor reflection、two-anchor alignment 与 (\theta q) 分解，以及相应的边界例子。
4. 这些只能称为 **candidate residue**，不能称为已证明的 literature firstness。Wang--Li--Ng 2023 与 Moursi--Vanderwerff 2025 仍只有摘要/单页预览，二者的 definition/theorem/example blocks 未取得。
5. **T2 当前判定为 `REPAIR / PARTIAL`，不得通过。** Luque 单项已闭合；Wang 与 Moursi--Vanderwerff 两个 critical full-text gates 仍开放，且既有 alias audit 还保留 nonlinear-gauge/citation-chain 边界。

## 1. 六份 Expert Contract 身份与状态核验

| output | contract identity | declared status | referee validation | merge decision |
|---|---|---|---|---|
| `work/novelty_wang_search.md` | `RL-NOV-WANG-SEARCH-09`, `T/T2`, literature-search | `PROVISIONAL`; stage `REPAIR` | **PASS**。题名、DOI、作者与访问边界闭合；未把摘要升级成 theorem evidence。 | 作为 access/metadata ledger 合并；不得产生 theorem-overlap 结论。 |
| `work/novelty_wang_deepread.md` | `RL-NOV-WANG-DEEP-10`, `T/T2`, paper-deep-reading | `PROVISIONAL`; stage `REPAIR` | **PASS**。source-depth gate 正确失败；指定 frozen blocks 保持 `PENDING`。 | 合并全部 `PENDING` 与 claim-safe wording。 |
| `work/novelty_mv_search.md` | `RL-NOV-MV-SEARCH-11`, `T/T2`, literature-search | `PROVISIONAL`; stage `REPAIR` | **PASS**。publisher/author/institution identities 与 access boundary 区分正确。 | 作为 access/metadata ledger 合并；不得由 no-hit 推断 absence。 |
| `work/novelty_mv_deepread.md` | `RL-NOV-MV-DEEP-12`, `T/T2`, paper-deep-reading | `PROVISIONAL`; stage `REPAIR` | **PASS**。摘要、第一页 preview、Fig. 1 caption 与 full text 分层正确。 | 合并全部 theorem/example `PENDING`。 |
| `work/novelty_luque.md` | `RL-NOV-LUQUE-13`, `T/T2`, search + deep-reading | `COMPLETE`; stage `PASS_CANDIDATE` | **PASS WITH EDITORIAL REPAIR**。数学主判决可靠；作者、参数、rate object 与 endpoint 均由 primary prepublication 核验。文件含损坏的 TeX 宏，不得逐字合并。 | 合并数学结论，不合并损坏字符串；Luque 子任务视为 closed。 |
| `work/novelty_luque_compare.md` | `RL-NOV-LUQUE-COMPARE-14`, `T/T2`, paper-deep-reading | `COMPLETE`; stage `PASS_CANDIDATE` | **PASS**。与 Luque 主报告独立一致；明确分开 endpoint upper order、two-sided exponent 与 Q-factor。 | 作为 Luque overlap 的主 crosswalk 合并。 |

六个 `task_id`、project/family/stage identities 与各自输出文件均一致，没有 identity collision。四份 Wang/MV 结果的 `PROVISIONAL + REPAIR` 不是执行失败，而是合法全文缺失所触发的正确证据门控；两份 Luque 结果的 `COMPLETE + PASS_CANDIDATE` 只批准 **Luque 子问题**，不批准整个 T2。

## 2. Luque 冲突的独立裁决

### 2.1 作者身份

规范作者为 **Fernando Javier Luque**，引用缩写为 **F. J. Luque**。既有 `R. Luque` 记录应视为书目错误。当前 theorem-level 证据绑定于 1981 年 MIT LIDS-P-1142 primary prepublication；1984 SIAM 正式排印版与该原稿尚未作逐字逐式比对，不能声称两版 verbatim identical。

### 2.2 Theorem 3.1 的 (r,s) 端点

扫描页的定理陈述明确打印

\[
r\ge 1,\qquad s\ge 1,
\]

并令 (t) 为集合距离序列的 Q-order，结论为

\[
t\ge \min\{r,s\}.
\]

同页 Q-order 定义对 admissible exponent 使用 (\tau\ge1)。证明末句又写了
`≥ min{r,s} > 1`；最后一个严格不等号只有在
(min\{r,s\}>1) 时成立，与定理允许 equality 的打印假设不一致。终审采用如下不夸张解释：

- theorem statement 与 recurrence 对 (r\ge1,s\ge1) 有效；
- “superlinear” 子结论另需 (min\{r,s\}>1)；
- 当某一指数等于 (1) 时，不得复述证明末句的 `>1`。

这同时解决了两个报告中 `r,s>1` 与 `r,s\ge1` 的潜在 OCR 冲突。

### 2.3 Exact PPA 的 set-distance endpoint

令 (d_k=d(z^k,\bar Z))。Luque 的 (3.7) 在 exact 情形
(\varepsilon_k=0) 下直接给

\[
d_{k+1}
\le
\frac{a d_k^s}
{\bigl(c_k^2+a^{2/s}d(P_kz^k,\bar Z)^{2(s-1)/s}\bigr)^{s/2}}
\le
\frac{a}{c_k^s}d_k^s.
\]

因此：

- 端点 (s) 本身有 big-(O) upper recurrence，不只是“每个 (\tau<s)”；
- 常步长 (c_k\equiv\lambda) 给 (d_{k+1}\le a\lambda^{-s}d_k^s)；
- rate object 是 (d(z^k,\bar Z))，允许非孤立 (\bar Z)；
- 这不证明 Q-order 恰等于 (s)、two-sided exponent、正的 normalized factor，或非孤立情形的 (\lVert z^k-z^\infty\rVert) endpoint；
- 若解在所考察邻域中唯一，则 set distance 才等于 actual error。

故 frozen Corollary 5.2 在 maximal-monotone、full resolvent、(L=1)、fixed-step、(q=s) 的特例中，one-step 常数与 Luque 的 coarse endpoint **逐项相同**：

\[
\rho\left(\frac{1+L}{2\lambda}\right)^q
\Big|_{L=1,\rho=a,q=s}
=\frac{a}{\lambda^s}.
\]

## 3. Overlap 标签规则

- `EXACT_OVERLAP`：原始来源在同一对象、量词、假设与结论强度上给出相同 statement；透明记号替换允许。
- `SPECIAL_CASE`：存在明确 specialization 后得到相同核心 statement，但 frozen/source 的总 scope 互不相同。
- `ADJACENT`：共享机制或一部分结论，但 assumptions、rate object、quantifier、endpoint 或 algorithm scope 阻止蕴含。
- `NO_DIRECT_OVERLAP`：已读到足够原文，且该来源的已核 statement 不覆盖指定 frozen block。
- `PENDING`：来源深度不足；摘要沉默和 no-hit 均不能降为 `NO_DIRECT_OVERLAP`。

下表的 “既有已核 corpus” 包括本轮指定的四份 prior-art/alias 文件中已经全文核验的来源；它不是全领域 priority certificate。Wang 与 MV 两列只按本轮可访问深度判断。

## 4. Frozen theorem-by-theorem overlap matrix

| frozen block | 既有已核 corpus（不含 Wang/MV） | Luque 1981/1984 | Wang--Li--Ng 2023 | Moursi--Vanderwerff 2025 | 终审解释 |
|---|---|---|---|---|---|
| **Theorem 1.1**：RL/IP/reflector/firm-type 等价 | `SPECIAL_CASE` | `SPECIAL_CASE` | `PENDING` | `PENDING` | Power R-side 与一般 Hölder-map 文献有 formula-level `EXACT_OVERLAP`；(\gamma=1) operator slice 有 exact predecessors。任意 gauge、restricted graph 与四式整体 packaging 未被单一已核来源逐项覆盖；它仍主要是 Cayley 代数，不宜作 headline novelty。 |
| **Theorem 2.1**：(\gamma=1) 参数字典、inverse、scaling | `SPECIAL_CASE` | `NO_DIRECT_OVERLAP` | `PENDING` | `PENDING` | Part (a) 在 tied ((\mu,\rho))-semimonotonicity/Luke--Tam/Otero--Iusem 中有 formula-level `EXACT_OVERLAP`；(\gamma<1) inverse/scaling 是直接代数规则，当前只可作 calculus packaging。 |
| **Theorem 4.2**：localized gauge named-PPA、finite length、strong convergence | `ADJACENT` | `ADJACENT` | `PENDING` | `PENDING` | Li--Mordukhovich、Zhu、Luque 均连接 inverse/error growth 与 PPA；Luque 还允许 inexact/variable-step、非孤立解集。Frozen 的 candidate residue 是 named branch + anchored control + explicit invariance + finite length/strong limit；不构成对 Luque 的 subsumption。 |
| **Corollary 5.1**：(0<\gamma<1,L>0)，upper exponent (\gamma q) | `ADJACENT` | `NO_DIRECT_OVERLAP` | `PENDING` | `PENDING` | 一般 Hölder-map 与 exponent composition 是已知/初等背景；已读 Luque 没有独立 reflector exponent (\gamma)。当前仅可称 theorem-specific conditional upper law。 |
| **Corollary 5.2**：(\gamma=1)，upper (q)-phase | `SPECIAL_CASE` | `SPECIAL_CASE` | `PENDING` | `PENDING` | 在 maximal-monotone、(L=1)、full exact fixed-step 特例中，Luque (3.7) 与 frozen recurrence formula-level exact；frozen 的 broader named/nonmonotone/(L\ne1) scope 未被 Luque覆盖。(q=1) 时 Luque 的 firm bound更强。 |
| **Corollary 5.3**：(L=0) degenerate (q)-phase | `ADJACENT` | `ADJACENT` | `PENDING` | `PENDING` | Constant-reflector degeneracy 与 Luque flat inverse/finite termination 是不同轴；不得把 (L=0) 等同 (s=+\infty)。 |
| **Theorem 6.1**：output-near moving-anchor asymptotic reflection | `ADJACENT` | `NO_DIRECT_OVERLAP` | `PENDING` | `PENDING` | Cayley identity与 Liu--Moursi--Vanderwerff 2023 reflected-defect theory相邻；已读 Luque无 centered moving anchor。MV 2025 的 reflection blocks 未取得，排他性 claim 不可冻结。 |
| **Theorem 7.1**：fixed-anchor graph-germ (B_q\Leftrightarrow J_q\Leftrightarrow R_q) | `ADJACENT` | `ADJACENT` | `PENDING` | `PENDING` | Higher-order EB、resolvent derivatives与 Luque inverse growth邻近；三项等价大量来自 (R=2J-I) 与三角估计，结构清晰但单独证明复杂度低。 |
| **Proposition 7.2**：general gauges 与 dilation stability | `ADJACENT` | `ADJACENT` | `PENDING` | `PENDING` | 一般 modulus map theory与 Luque 的 inverse gauge均为先例背景；same-gauge dilation caveat 未在指定已读来源中见同型 theorem，但无 priority claim。 |
| **Proposition 7.3**：full EB 与 residual-complete branchwise bound | `ADJACENT` | `ADJACENT` | `PENDING` | `PENDING` | Luque full inverse growth与 local full PEB 在共同 localization 中是同一 residual-to-set mechanism；favorable branch 不足以推出 full EB 的 scope ledger 是 frozen 的明确化。 |
| **Theorem 7.4**：isolated-zero named PPA、(q)-flatness与 reflection remainder | `SPECIAL_CASE` | `SPECIAL_CASE` | `PENDING` | `PENDING` | Maximal-monotone/full/fixed-step 的 actual-error endpoint 已由 Luque覆盖；named nonmonotone branch、output return、ball invariance及 reflected remainder是 Luque-bounded residue。 |
| **Theorem 8.2**：nonisolated two-anchor alignment 与 (\theta q) | `ADJACENT` | `ADJACENT` | `PENDING` | `PENDING` | Luque已有 nonisolated set-distance endpoint (q)；Zhu已有 actual-iterate strict-subendpoint与渐近 normal alignment。Frozen 的候选区别是 map-level two-anchor profile、独立 (\theta) 与非firm branch中的 conditional composition。 |
| **Proposition 9.1**：same-sequence joint saturation | `NO_DIRECT_OVERLAP` | `NO_DIRECT_OVERLAP` | `PENDING` | `PENDING` | 指定已读来源中无同型三因子 statement；但命题本身是 normalized ratios 的乘法，不能单独承载重大新颖性。 |
| **GX-071**：exact (\gamma q) attainability | `NO_DIRECT_OVERLAP` | `NO_DIRECT_OVERLAP` | `PENDING` | `PENDING` | 不属于 Luque 的 maximal-monotone/nonexpansive-reflector class；在 frozen 声明 class 中支持 attainability 与 factor 1，不支持 universal optimality。 |
| **GX-072**：all-pairs (\gamma) 保守而 orbit 为 (q) | `NO_DIRECT_OVERLAP` | `NO_DIRECT_OVERLAP` | `PENDING` | `PENDING` | 支持 all-pairs exponent 不是 universal orbit exponent；未证明 normalized Q-factor。 |
| **GX-073**：one-step scale、expansion 与 domain escape | `NO_DIRECT_OVERLAP` | `NO_DIRECT_OVERLAP` | `PENDING` | `PENDING` | 支持 invariance 不能从 exponent 标签删除；其 full regularity power 是 1，故不是 (q>1) theorem 的反例。 |

矩阵中有三类“精确重复”必须单列，避免被较粗的整行标签隐藏：

1. Theorem 1.1(3) 的 power R-side inequality与一般 Hölder-map定义是 `EXACT_OVERLAP`，但原文未必发展 operator pullback。
2. Theorem 2.1(a) 的 (\gamma=1) tied semimonotonicity参数切片是 `EXACT_OVERLAP`；其余 (\gamma<1) 代数规则不随之自动成为新理论。
3. Corollary 5.2 在 maximal-monotone、(L=1)、fixed-step exact PPA specialization 中的 coarse endpoint recurrence与 Luque (3.7) 是 `EXACT_OVERLAP`；整条 frozen corollary 因 scope 更宽而标 `SPECIAL_CASE`。

## 5. 可保留的 novelty residue

以下是 **claim candidates**，不是 literature-first theorems：

1. **Restricted/named-branch scope**：在可能 nonmaximal、nonmonotone、多值、非满域 relation 上，分开 coverage、exclusion 与 invariance，并只对已命名 Minty branch 下结论。
2. **非平凡的 (\gamma<1) operator package**：价值不在“一般 Hölder map”或 Cayley pullback本身，而在它是否支持不能从 generic map theory直接复制的 graph calculus、local branch theorem与 sharp examples。
3. **Anchored RL + output EB 的局部算法闭合**：Theorem 4.2 的 finite-length、strong convergence与tail bound是在显式 local margin下取得；它不依赖 maximal monotonicity，但也不含 Luque的 inexact/variable-step维度。
4. **条件式 phase split**：Corollaries 5.1--5.3 把非退化 (\gamma q)、critical coefficient及 (L=0) 的 (q)-phase分开；(\gamma q) 只是一条 stated-class upper law。
5. **Fixed/moving anchor 与 reflection 的分层**：Theorems 6.1、7.1与7.4把 output-near moving center、fixed isolated center、resolvent flatness与 centered reflection remainder放在同一量词账本中。其 algebraic core 简单，价值取决于整套 scope与应用。
6. **Nonisolated two-anchor mechanism**：Theorem 8.2 把 nearest-solution drift编码成独立 profile (\theta)，从而在非firm/named branch中得到条件式 (\theta q) map-level upper bound。它不是“首次处理非孤立高阶 PPA”。
7. **Sharpness discipline**：Proposition 9.1与 GX-071--073 分开 attainability、conservative all-pairs certificate、positive-factor缺失和 domain escape；三例只支持其逐例判定。

Theorems 1.1、2.1、7.1/7.2 和 Proposition 9.1 中有相当部分属于透明代数或 bookkeeping。投稿主贡献不能只靠这些结果的编号数量；必须由第 1、3、4、6、7 项组成一个完整且自然的 theorem package。

## 6. Forbidden claims

后续稿件不得使用下列表述或其同义改写：

- “RL 在所有 (0<\gamma\le1) 上是新的 generalized monotonicity。”
- “首次提出 Hölder reflected-resolvent / Cayley map 条件。”
- “(\gamma=1) 的 RL、内积式或 parameter dictionary 是新理论。”
- “首次定义 (q>1) higher-order metric subregularity。”
- “首次把 higher-order subregularity / inverse growth 与 PPA rate 联系起来。”
- “首次在非孤立解集上得到 PPA 高阶或超线性 set-distance convergence。”
- “首次在 isolated zero 上得到 fixed-step PPA endpoint (q)-order。”
- “首次发现 PPA tangent/normal alignment。”
- “Luque 只给 linear rate、只处理 singleton、只处理 exact fixed step，或没有 endpoint (s)。”
- “Luque 已给 nonisolated actual-iterate endpoint (s)。”
- “Zhu 已证明 actual-iterate endpoint (q)”；其正式结果是每个 strict subendpoint。
- “Frozen Corollary 5.2 的 monotone (L=1) specialization 是新公式，或其 (q=1) bound改进 Luque。”
- “(L=0) reflector degeneracy就是 Luque flat inverse (s=+\infty)。”
- “Theorem 4.2 subsumes Luque”；两者在 operator、exact/inexact、fixed/variable step 与 convergence object 上交叉。
- “(\gamma q) 或 (\theta q) 是 universal exact Q-order / necessary compensation law / positive Q-factor。”
- “GX-071--073 证明 universal optimality 或 genericity。”
- “Wang 2023 不覆盖 (q>1)、endpoint、actual iterate或 nonisolated case。”
- “Moursi--Vanderwerff 2025 与 centered reflection、moving anchor、(\gamma<1) 或 PPA 无关。”
- 任意基于 no-hit 的 “first / novel / previously unknown / no prior work”。
- “RL 自动给 full domain、maximality或任意 full-resolvent selection 的收敛。”
- “1981 LIDS prepublication 与 1984 SIAM final text 已逐字验证相同。”

## 7. Claim-safe contribution statement

### 中文

> 本文不把 Hölder 映射条件、其 Cayley 拉回、(\gamma=1) semimonotonicity，或 higher-order metric subregularity本身作为新概念。我们研究一个固定步长 exact setting 中、可能 nonmaximal 或 nonmonotone relation 的指定 Minty branch。在显式 coverage、solution-anchored Hölder--Cayley control、output error bound 与 invariance 条件下，我们得到 finite-length local convergence 和相应的 map-level upper recurrences。对 (0<\gamma<1)，reflector exponent 与 (q)-power error bound给出条件式 upper exponent (\gamma q)；对非孤立解集，一个独立的 two-anchor alignment profile给出条件式 (\theta q)。Fixed/moving-anchor reflection公式与 GX examples用于区分 attainability、保守 certificate及 domain escape。该 package 不包含或取代 Luque 的 maximal-monotone、inexact、variable-step theory；它与 Wang--Li--Ng 2023及 Moursi--Vanderwerff 2025 的排他性关系仍待全文核验。

### English

> We do not present the Hölder mapping condition, its Cayley pullback, the Lipschitz-endpoint semimonotonicity, or higher-order metric subregularity as new concepts. We study a specified Minty branch of a possibly nonmaximal or nonmonotone relation in a fixed-step exact setting. Under explicit coverage, solution-anchored Hölder--Cayley control, an output error bound, and invariance, we obtain finite-length local convergence and map-level upper recurrences. For (0<\gamma<1), the reflector exponent composes conditionally with a (q)-power error bound to give the upper exponent (\gamma q); for nonisolated solution sets, a separate two-anchor alignment profile gives the conditional exponent (\theta q). Fixed- and moving-anchor reflection identities and explicit examples distinguish attainability, conservative certificates, and domain escape. This package neither contains nor replaces Luque's maximal-monotone inexact variable-step theory, and exclusionary comparisons with Wang--Li--Ng (2023) and Moursi--Vanderwerff (2025) remain pending full-text review.

## 8. Public naming recommendation

1. `RL` 继续只作内部代号。
2. 当前最安全的 provisional public descriptor 是 **restricted Hölder--Cayley graph condition**；一般 gauge 版可称 **restricted Cayley-modulus condition**。若需要符号，可暂用
   (\mathrm{HC}_{\lambda,L,\gamma})，但不把该符号解释成 literature-first class。
3. (\gamma=1) 分支应直接注明它是 **tied ((\mu,\rho))-semimonotonicity**；在相应 (L\ge1) convention 下同时给 Luke--Tam submonotonicity参数换算。不要把它重新命名为 RL-monotonicity。
4. 不建议使用 “RL-submonotonicity”“Hölder monotonicity”或“new Hölder reflected-resolvent condition”作为标题卖点；这些名称分别有术语碰撞、对象歧义或 map-side prior art 风险。
5. 正式 public name 当前仍是 **PROVISIONAL**。在 MV 2025 全文未核前，不冻结排他性名称或 “first Hölder--Cayley operator class” 叙述。

## 9. T2 stage-acceptance decision

| gate | decision | reason |
|---|---|---|
| Luque theorem identity | **PASS** | F. J. Luque、(r\ge1,s\ge1)、set-distance object 与 exact endpoint均已从 primary prepublication闭合。 |
| Luque overlap merge | **PASS WITH EDITORIAL REPAIR** | 数学判决可合并；损坏 TeX 宏不可逐字复制。 |
| Wang theorem-level comparison | **REPAIR** | 只有 official abstract + one-page preview；definition/exponent/rate-object/endpoint不可见。 |
| MV theorem-level comparison | **REPAIR** | 只有 official abstract + first-page/short preview；reflection/modulus/pointwise quantifiers不可见。 |
| exclusionary novelty wording | **FAIL GATE** | 两个 critical full-text risks仍开放；bounded no-hit不是priority proof。 |
| public naming freeze | **REPAIR** | descriptive working name可用，正式名称不可锁。 |
| **T2 overall** | **REPAIR / PARTIAL — NOT PASSED** | Luque风险已实质解决，但 Wang/MV与更广 citation-chain边界未闭合。 |

## 10. `work/novelty_luque.md` 文本完整性检查

对该文件执行 C0/control-byte 检查，未发现 `0x00--0x08`、`0x0B`、`0x0C`、`0x0E--0x1F` 或 `0x7F` 字节。因此它不是含原始控制字符的二进制污染文件。

终审时识别到由转义处理造成的 **TeX 宏损坏**：

- `\heta` 应读作 `\theta`（11 处）；
- `\au` 应读作 `\tau`（1 处）；
- `\o0` / `\o1` 应读作 `\to0` / `\to1`（合计 3 处）。

本终审没有逐字复制这些字符串；在终审完成后，源工作文件已将上述宏机械归一化为 `\theta`、`\tau`、`\to0`、`\to1`。数学裁决未改变，正式研究文件使用归一化后的表达。

## 11. Evidence and limitations

- `VERIFIED_USER_MATERIAL`：冻结稿 hash、四份既有 prior-art/alias 文件与六份本轮输出均已读取和交叉核对。
- `VERIFIED_SOURCE THROUGH REVIEWED FULL TEXT`：Luque LIDS-P-1142 的作者页、Theorem 3.1扫描页、Q-order定义与 (3.7)；Zhu/Li--Mordukhovich/Liu--Moursi--Vanderwerff 等结论按既有 primary-source audits使用。
- `AI_INFERENCE`：localization translation、Luque fixed-step specialization、矩阵标签、candidate residue、forbidden claims与 naming建议。
- `PENDING_VERIFICATION`：Wang 2023 与 MV 2025 的所有正文 definitions/theorems/examples；Luque 1981 prepublication 与 1984 final typeset version 的逐字一致性；既有 alias audit 中尚未全文核验的 nonlinear-gauge来源与正式引文数据库链。
- 本报告没有执行新 web search，因此 `NO_DIRECT_OVERLAP` 只相对于已读来源，绝不表示全领域不存在先例。

## 12. SCI-Skills Expert Contract 1.0

```yaml
contract_version: "1.0"
expert_skill: "independent novelty referee / integrator"
project_id: "monotonicity-regularity-seesaw-2026-09"
paper_family: "T"
stage_id: "T2"
task_id: "RL-NOV-FREEZE-REFEREE-15"
task_status: "COMPLETE"
inputs_reviewed:
  - "research/RL_foundations.md @ sha256:0adf8ca1593148bebce576e9659f3da50e61a77880c0b311cbcc35d0dcbb4ebd (read-only)"
  - "work/rl_foundations_structure_prior_art.md"
  - "work/rl_foundations_structure_claim_safe_matrix.md"
  - "work/rl_alias_landscape.md"
  - "work/rl_exact_prior_art.md"
  - "work/novelty_wang_search.md"
  - "work/novelty_wang_deepread.md"
  - "work/novelty_mv_search.md"
  - "work/novelty_mv_deepread.md"
  - "work/novelty_luque.md"
  - "work/novelty_luque_compare.md"
outputs:
  - "work/rl_novelty_freeze_referee.md"
evidence_status:
  - "VERIFIED_USER_MATERIAL: frozen baseline hash and all eleven specified local inputs"
  - "VERIFIED_CONTRACT_IDENTITY: all six wave outputs match their project/family/stage/task identities"
  - "VERIFIED_SOURCE: Luque primary-prepublication author, theorem hypotheses, Q-order object, and exact set-distance endpoint"
  - "AI_INFERENCE: overlap labels, contribution residue, forbidden claims, public naming, and T2 gate"
  - "PENDING_VERIFICATION: Wang 2023 and Moursi--Vanderwerff 2025 full theorem blocks"
  - "PENDING_VERIFICATION: verbatim identity of Luque 1981 prepublication and 1984 final typeset paper"
  - "NOT_EXECUTED: no new literature search or formal citation-database audit"
assumptions:
  - "EXACT_OVERLAP requires matched theorem-level object, quantifiers, assumptions, and conclusion strength."
  - "A source's abstract silence and bounded no-hit evidence never justify NO_DIRECT_OVERLAP."
  - "Luque notation is translated only under explicit T=F, solution-set equality, q=s, and fixed c_k=lambda specializations."
author_input_needed:
  - "Lawfully obtained searchable full-text PDFs of Wang--Li--Ng 2023 and Moursi--Vanderwerff 2025, with provenance."
manual_actions:
  - "Obtain the two legal full texts through an existing institutional subscription or author-shareable manuscript route; do not return credentials."
quality_checks:
  - "Frozen SHA-256 independently matched; no research/ file modified."
  - "All six Expert Contract identities and statuses audited."
  - "Luque r>=1, s>=1, superlinear subcase, author identity, rate object, and endpoint independently reconciled."
  - "All requested frozen results 1.1, 2.1, 4.2, 5.1--5.3, 6.1, 7.1--7.4, 8.2, 9.1, and GX-071--073 entered the matrix."
  - "EXACT_OVERLAP, SPECIAL_CASE, ADJACENT, NO_DIRECT_OVERLAP, and PENDING were not conflated."
  - "Upper order, two-sided exponent, exact Q-factor, set distance, and actual iterate kept separate."
  - "Malformed TeX escapes in work/novelty_luque.md identified and not copied."
  - "Candidate residue is separated from literature-first claims."
conflicts:
  - "Luque author recorded earlier as R. Luque versus primary-source Fernando Javier Luque."
  - "OCR/summary readings r>1,s>1 versus scanned theorem statement r>=1,s>=1."
  - "Supremum-order-only reading versus exact-PPA endpoint recurrence in Luque (3.7)."
  - "Luque report mathematical validity versus malformed TeX escape sequences."
conflict_resolution_status: "RESOLVED_FOR_LUQUE; OPEN_EVIDENCE_GATES_FOR_WANG_AND_MV"
merge_permission: "orchestrator_only"
recommended_next_action: "NEXT-1"
stage_acceptance_recommendation: "REPAIR"
```

## 13. One next action

**NEXT-1：合法取得并回传 Wang--Li--Ng 2023 与 Moursi--Vanderwerff 2025 的可检索全文，然后在同一 T2 任务中一次性重审本矩阵全部 `PENDING` 单元；在该联合审计完成前，不冻结正式公开名称或任何排他性新颖性表述。**
