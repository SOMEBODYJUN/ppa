# Wang–Li–Ng 2023：摘要级深读与冻结稿重叠审计

> **project_id**: `monotonicity-regularity-seesaw-2026-09`  
> **paper_family / stage / task**: `T / T2 / RL-NOV-WANG-DEEP-10`  
> **expert_skill**: `sci-skills-paper-deep-reading`  
> **reading_depth**: `DEEP requested; ABSTRACT/PUBLISHER-PREVIEW fallback executed`  
> **task_status**: `PROVISIONAL`  
> **审计日**: `2026-09-01`  
> **目标 DOI**: [10.1137/22M152147X](https://doi.org/10.1137/22M152147X)

## 1. Scope and inputs

### 1.1 冻结基线

- `research/RL_foundations.md` 已按要求只读核验。
- 实测 SHA-256：`0adf8ca1593148bebce576e9659f3da50e61a77880c0b311cbcc35d0dcbb4ebd`。
- 实测值与任务给定冻结值完全一致。
- 本任务未修改冻结稿。

同时检查了：

- `work/rl_foundations_structure_prior_art.md`；
- `work/rl_foundations_structure_claim_safe_matrix.md`。

两份既有审计均把 Wang–Li–Ng 2023 标为 `PENDING_FULL_TEXT`；本轮没有取得足以推翻该状态的新证据。

### 1.2 实际访问到的外部来源与深度

| ID | source locator | 实际可见内容 | 证据深度 | 可支持范围 |
|---|---|---|---|---|
| W1 | [SIAM official article page](https://epubs.siam.org/doi/10.1137/22M152147X) | 官方题录、摘要、关键词、出版史、参考文献；PDF/full-text 链接导向付费访问 | `VERIFIED_OFFICIAL_ABSTRACT_AND_METADATA` | 题名、作者、期刊、页码、Hilbert/maximal-monotone/inexact-exact PPA 的摘要级范围 |
| W2 | [ResearchGate record with SIAM publisher preview](https://www.researchgate.net/publication/372932490_Convergence_Rate_of_Inexact_Proximal_Point_Algorithms_for_Operator_with_Holder_Metric_Subregularity) | 明示“Publisher preview available / request full text”；仅显示期刊首页 p. 1996 | `PUBLISHER_PREVIEW_ONE_PAGE` | p. 1996 的问题设定与 Algorithm 1.1；不能支持 Definition/Theorem/Corollary 级核验 |
| W3 | [CUHK official research record](https://research.cuhk.edu.hk/en/publications/convergence-rate-of-inexact-proximal-point-algorithms-for-operato-2/) | 官方题录与摘要；文档入口仍指 DOI/出版社 | `VERIFIED_OFFICIAL_RECORD` | 独立核对题录与摘要；无正文 |
| W4 | [Hangzhou Normal University author profile](https://sxxy.hznu.edu.cn/c/2021-08-11/2574019.shtml) | 作者单位/研究方向页面 | `VERIFIED_OFFICIAL_PROFILE` | 仅核对作者身份；无目标论文正文 |

检索使用平台原生 web search/browsing，检索式包括目标 DOI、完整题名、作者名、`pdf`、`preprint`、`accepted manuscript`、Zhejiang/Hangzhou Normal/CUHK 域名限定。没有命中合法公开全文。Google Scholar 的版本页在当前受控浏览器中返回 automated-query block，未能作为补充版本入口。该访问失败只是一项检索限制，不是“无作者稿”或“无重叠”的证据。

### 1.3 Source-depth gate

**Gate result: FAIL for theorem-level reading.**

当前证据是“官方摘要 + 出版商单页 preview + 官方题录”，不是完整论文，也没有 Definitions、主要定理、证明、应用节或全文参考上下文。因此：

- 不生成伪装成逐定理精读的 theorem card；
- 不从题名、摘要、参考文献表或 Li–Mordukhovich 2012 的 convention 反推 Wang–Li–Ng 的 exponent convention；
- 不把“摘要未提及 reflection/alignment/sharpness”当作论文没有这些结果；
- 所有涉及具体 theorem number、rate formula、quantifier 或 endpoint 的重叠判定保持 `PENDING`。

## 2. Specialist findings: abstract-level 16-section deep-reading card

### 2.1 Bibliographic position

**原文事实 / VERIFIED_SOURCE.** Jinhua Wang, Chong Li, and K. F. Ng, “Convergence Rate of Inexact Proximal Point Algorithms for Operator with Hölder Metric Subregularity,” *SIAM Journal on Optimization* 33(3) (2023), 1996–2020, DOI 10.1137/22M152147X。SIAM 记录显示 2022-09-12 投稿、2023-02-27 接收、2023-08-04 在线发表。Locator: W1, publication information。

### 2.2 Research question

**原文事实 / VERIFIED_SOURCE.** 摘要层面的问题是：对实 Hilbert 空间上的 maximal monotone operator，研究 Rockafellar 型 inexact PPA 的 global/local strong convergence，并在 Hölder metric subregularity 下给出 quantitative rate estimates。Locator: W1 abstract；W2 p. 1996。

### 2.3 Background route

**原文事实 / VERIFIED_SOURCE.** 论文把 classical exact PPA 作为 inexact framework 的特例，并声称相应 exact-PPA 结果改进 Li–Mordukhovich 2012。Locator: W1 abstract。

**AI分析 / AI_INFERENCE.** 这使该文成为冻结稿 §§4–8 的必要高风险比较对象，但“改进 Li–Mordukhovich”本身不说明改进的是常数、步长、强收敛条件、距离率、实际迭代率还是 exponent 范围。

### 2.4 Unresolved pain point

**原文事实 / VERIFIED_SOURCE.** 摘要声称建立 unified global/local strong convergence，并给出 quantitative rates；这表明作者针对既有 PPA convergence/rate theory 的不足提出统一处理。Locator: W1 abstract。

**PENDING_VERIFICATION.** 全文缺失，无法确认“统一”的精确对象、已有定理的具体缺口以及作者在 introduction 中声明的 novelty boundary。

### 2.5 Core insight

**原文事实 / VERIFIED_SOURCE.** 可确认的唯一核心线索是：以 Hölder metric subregularity 作为 exact/inexact PPA 强收敛及 rate estimates 的正则性条件。

**PENDING_VERIFICATION.** 核心 proof device、Fejér/averagedness inequality、误差累计机制、局部到全局桥接、是否使用 projection/alignment 均不可见。

### 2.6 Method overview

**原文事实 / VERIFIED_SOURCE.** p. 1996 定义问题 `0 ∈ T(z)`，其中 `T:H⇒H` maximal monotone；classical exact PPA 写为

\[
x_{n+1}=(I+\lambda_nT)^{-1}x_n,\qquad \lambda_n>0.
\]

Locator: W2, journal p. 1996, Problem (1.1) and Algorithm 1.1。

**PENDING_VERIFICATION.** inexact algorithm 的误差准则、迭代变量、relative/absolute error、summability、relaxation、regularization 或 forcing sequence 不可见。

### 2.7 Module or mechanism logic

`PENDING_FULL_TEXT / NOT_EXECUTED.` 无法从摘要和 p. 1996 重构 section/module 逻辑；任何“先证明 set-distance recursion，再升级 actual iterate”之类描述都会是无来源推断。

### 2.8 Essential formulas and assumptions

#### 已核验

| 轴 | 已核验内容 | locator | label |
|---|---|---|---|
| ambient space | real Hilbert space | W2 p. 1996 | `VERIFIED_SOURCE` |
| operator | set-valued maximal monotone `T:H⇒H` | W2 p. 1996 | `VERIFIED_SOURCE` |
| target | solve `0∈T(z)` | W2 p. 1996, (1.1) | `VERIFIED_SOURCE` |
| exact step | `x_{n+1}=(I+λ_nT)^{-1}x_n` | W2 p. 1996, Algorithm 1.1 | `VERIFIED_SOURCE` |
| displayed exact stepsize | `λ_n>0` | W2 p. 1996 | `VERIFIED_SOURCE` |
| broad regularity | Hölder metric subregularity | W1 abstract/title | `VERIFIED_SOURCE` |
| inexact/exact scope | both studied; exact is a special case | W1 abstract | `VERIFIED_SOURCE` |

#### 未核验

| 轴 | 所需原文信息 | 当前状态 |
|---|---|---|
| exponent convention | definition inequality, symbol, range, base/residual neighborhoods | `PENDING` |
| solution set | notation, nonemptiness, closed/convex/proximinal use, isolated vs nonisolated | `PENDING` |
| stepsize hypotheses | lower/upper bounds, divergence, constancy, variable-step assumptions | `PENDING` |
| inexactness | error model and summability/relative-error conditions | `PENDING` |
| rate metric | `d(x_n,S)`, `||x_n-x^*||`, residual, objective gap, or a mixture | `PENDING` |
| rate strength | upper bound, two-sided exponent, Q-order, R-order, exact factor | `PENDING` |
| locality | pointwise/local/global HMSR and orbit-entry hypotheses | `PENDING` |

### 2.9 Data, cohort, material, or benchmark

**原文事实 / VERIFIED_SOURCE.** 这是 operator-theoretic 论文；摘要还称其结论应用于 optimization problems。

**PENDING_VERIFICATION.** 全文是否含例子、数值实验、具体 optimization classes 或 sharpness constructions 不可见。不能声称“无实验”或“只有理论”。

### 2.10 Experimental design, metrics, and baselines

`NOT_ASSESSED.` 摘要未报告实验设计。理论 baseline 可确认 Li–Mordukhovich 2012，但具体 theorem-to-theorem 改进不可见。

### 2.11 Claim-to-evidence table

| source claim | accessible evidence | evidence strength | allowed use |
|---|---|---|---|
| 研究 Hilbert-space maximal-monotone inexact PPA | W1 abstract + W2 p. 1996 | direct | 可用于范围描述 |
| 建立 global/local strong convergence | W1 abstract | direct but abstract-only | 只能说“摘要报告” |
| 提供 quantitative convergence rates | W1 abstract | direct but rate object absent | 不能写具体 rate/exponent |
| exact PPA 结果改进 Li–Mordukhovich 2012 | W1 abstract | direct but theorem absent | 不能说明改进方向 |
| 覆盖或排除项目 `Q>1` endpoint | 无定义/定理 | none | `PENDING` |
| 覆盖 actual-iterate/set-distance endpoint | 无定理 | none | `PENDING` |
| 覆盖 reflection/two-anchor/alignment/sharpness | 无相关正文 | none | `PENDING` |

### 2.12 Conclusion boundary

当前只可下列摘要级结论：Wang–Li–Ng 2023 与冻结稿共享“Hilbert 空间中 PPA + metric/Hölder subregularity + convergence rates”的宽主题，并且 exact PPA 是其研究范围的一部分。

当前不能判断它是否覆盖冻结稿任一指定 theorem 的全部 assumptions、quantifiers、endpoint、rate object 或 sharpness level。

### 2.13 Author-stated limitations

`PENDING_FULL_TEXT.` 摘要没有列出 limitations；不得代作者补写。

### 2.14 Critical assessment

**AI分析 / AI_INFERENCE.** 该文是高优先级 novelty risk，因为其年代新、主题直接、同时处理 exact/inexact PPA，并明确声称改进 Li–Mordukhovich 2012。反过来，当前证据深度太浅，既不能把它判为 direct overlap，也不能把它排除。最安全的结论不是 “no overlap”，而是“排他性 novelty gate 仍未闭合”。

### 2.15 Reusable knowledge and connections

- **原文事实 / VERIFIED_SOURCE**：maximal monotone/Hilbert/full PPA 是 Wang–Li–Ng 的环境。
- **VERIFIED_USER_MATERIAL**：冻结稿允许 named Minty branch，并显式区分 coverage、exclusion、invariance；因此其 operator scope 可能宽于 maximal-monotone full resolvent。
- **AI分析 / AI_INFERENCE**：scope 更宽不自动产生 novelty；若冻结定理在 maximal-monotone 特例中已被 Wang 覆盖，则仍需把贡献收窄到 branchwise packaging、reflection/two-anchor structure 或 sharpness。
- **PENDING_VERIFICATION**：Wang 是否确实覆盖 `Q>1`、isolated endpoint 或 nonisolated actual-iterate rate，必须读 Definition 与 exact-PPA corollary 后才能判断。

### 2.16 Testable follow-up idea

唯一 evidence-resolution hypothesis 是：全文中的 HMSR definition 与 exact-PPA corollary 将决定它是否进入冻结稿 `Q>1` endpoint 的直接重叠区。

- unresolved problem：原始 exponent convention、exact theorem rate object 与 endpoint 不可见；
- difference from source：不是提出新数学结论，而是对 source theorem 做可证伪的定位核验；
- required evidence：完整合法 PDF 中的 HMSR Definition、main inexact theorem、exact-PPA corollary、rate definitions、examples/remarks；
- falsifiable result：若定义范围排除项目 `Q>1` 且 theorem 无可逆换参，则相关 direct-overlap 风险被否证；若存在同向 `Q>1` endpoint actual-iterate/set-distance theorem，则风险被证实；
- minimum viable version：仅提取上述 definitions/theorems 的完整 assumptions、conclusions、proof dependencies 与页码；
- main risk：只凭符号同名误读 exponent inversion，或把 set distance upper rate误写成 actual-iterate exact Q-order。

## 3. Exponent convention and conditional translation

### 3.1 Wang 原始 convention

`PENDING.` 当前来源没有显示 HMSR definition、符号或 exponent range。特别地，以下说法均未获证：

- “Wang 的 exponent 限于 `(0,1]`”；
- “Wang 的 exponent 就是项目 `Q`”；
- “Wang 通过倒数换参覆盖 `Q>1`”；
- “Wang 不覆盖 higher-order subregularity”。

### 3.2 取得全文后使用的换参规则

以下只是条件翻译模板，不是对 Wang 原文的描述：

| 若原文定义为 | 与项目 `d(y,S)≤κ r_T(y)^Q` 的关系 |
|---|---|
| `d(y,S)≤κ r_T(y)^p` | `Q=p`（同向 residual exponent） |
| `r_T(y)≥c d(y,S)^α` | `Q=1/α`（需常数相应换算） |
| `d(y,S)^a≤κ r_T(y)^b` | `Q=b/a` |
| 仅对特定 selected residual `||w||` | 不能自动升级为 full residual `r_T(y)`；需 residual completeness/attainment |

项目关心的是 `Q>1`。在看到 Wang 的定义原式、允许范围和 theorem hypotheses 之前，不能执行换参判决。

## 4. Assumption and rate-object audit

| requested dimension | source-level finding | evidence label | frozen-project comparison |
|---|---|---|---|
| maximal monotone | confirmed | `VERIFIED_SOURCE` | Wang 的 operator framework 是 maximal-monotone；冻结稿不以 maximality 为统一前提 |
| Hilbert | confirmed | `VERIFIED_SOURCE` | ambient-space overlap |
| solution set | zero problem confirmed；geometry/quantifiers unknown | `VERIFIED_SOURCE + PENDING` | isolated/nonisolated、projection、closedness、limit membership 均不可比 |
| stepsize | exact Algorithm 1.1 displays `λ_n>0` | `VERIFIED_SOURCE` | fixed/variable、bounded below、divergent or constant hypotheses unknown |
| inexactness assumptions | unavailable | `PENDING` | cannot compare to named exact iteration or error accumulation |
| rate object | abstract says quantitative rate estimates | `VERIFIED_SOURCE` | metric and target unknown |
| upper vs exact | unavailable | `PENDING` | cannot compare upper order, two-sided exponent, exact Q-factor |
| actual iterate vs set distance | strong convergence theme confirmed; quantitative object unknown | `PENDING` for rate | cannot infer actual-iterate rate from strong convergence wording |
| reflected resolvent | unavailable | `PENDING` | absence from abstract is not absence from paper |
| local/global | abstract says both global/local strong convergence | `VERIFIED_SOURCE` | exact neighborhoods, orbit-entry and invariance mechanisms unknown |

## 5. Frozen-theorem overlap matrix

判定标签严格限于 `EXACT_OVERLAP / SPECIAL_CASE / ADJACENT / NO_DIRECT_OVERLAP / PENDING`。本轮因 full-text gate 未通过，以下全部是 `PENDING`；括号中的“broad thematic adjacency”只是风险说明，不替代主标签。

| frozen result | frozen object/strength | Wang accessible evidence | verdict | reason |
|---|---|---|---|---|
| Theorem 4.2 | named branch；anchored RL + output gauge EB；local invariance、finite length、strong convergence、set-distance linear upper contraction | abstract confirms global/local strong convergence and rates for inexact PPA | **PENDING** | broad thematic adjacency exists, but gauge, anchored condition, finite length, invariance, quantifiers and rate metric are inaccessible |
| Corollary 5.1 | `0<γ<1`, `L>0`; power EB；upper exponent `γq` with three phases | only “Hölder MSR + rates” visible | **PENDING** | no accessible `γ`, no exponent formula, no phase theorem |
| Corollary 5.2 | `γ=1`; fixed-step upper order `q`, including `q>1` | exact PPA included, but theorem absent | **PENDING** | this is the highest direct-overlap risk; cannot decide `q>1` or endpoint from abstract |
| Corollary 5.3 | degenerate `L=0`; rate phase controlled by `q`, not `γq` | no accessible degeneracy parameter | **PENDING** | no theorem-level comparison possible |
| Theorem 7.4 | isolated zero；full `q>1` EB；named branch；resolvent flatness, reflected remainder, actual orbit upper recurrence | maximal-monotone exact PPA confirmed; isolation/rate/reflection unavailable | **PENDING** | neither direct coverage nor noncoverage can be inferred |
| Theorem 8.2 | nonisolated solution set；two projections、drift/alignment profile；uniform set-distance upper exponent `θq` | no accessible anchor/projection/rate formula | **PENDING** | abstract does not resolve nonisolated quantifiers or alignment |
| Proposition 9.1 | same-sequence joint saturation; two-sided/exact-factor bookkeeping | no accessible sharpness theorem | **PENDING** | examples/remarks/full conclusions unavailable |
| GX-071 | nonisolated shear witness attaining `γq` with normalized limit 1 | no accessible examples | **PENDING** | no example-level evidence |
| GX-072 | all-pairs exponent can be conservative; isolated orbit has two-sided `q` scaling without proved Q-factor | no accessible examples | **PENDING** | no example-level evidence |
| GX-073 | one-step scale need not be convergence order; finite domain escape | no accessible examples | **PENDING** | no example-level evidence |

### Framework-only scope relation

**AI分析 / AI_INFERENCE（不是 theorem-overlap verdict）.** 在 maximal monotonicity 给出 full resolvent 的通常 Hilbert-space框架下，Wang 的 exact PPA 属于冻结稿 named-resolvent 语言可表达的一个更受限 operator class。该 scope relation 只能支持“潜在 special-case comparison”，不能在缺少 Wang 定理的情况下把任一行升级为 `SPECIAL_CASE`。

## 6. Claim-safe wording

### 6.1 当前可安全使用

> Wang, Li, and Ng study exact and inexact proximal point algorithms for maximal monotone operators on Hilbert spaces under Hölder metric subregularity and report global/local strong-convergence and quantitative-rate results. A theorem-level comparison with our `Q>1` endpoint, actual-iterate/set-distance, two-anchor, reflection, and sharpness statements remains pending because the accessible sources contain only the official abstract and a one-page publisher preview.

对应中文：

> Wang–Li–Ng 2023 在 Hilbert 空间 maximal monotone operator 框架下研究 exact/inexact PPA，并在 Hölder metric subregularity 下报告 global/local strong convergence 与 quantitative rate 结果。由于当前可访问证据仅为官方摘要和单页 publisher preview，其与本文 `Q>1` endpoint、actual-iterate/set-distance、two-anchor、reflection 及 sharpness 结论的逐定理关系仍待全文核验。

### 6.2 当前不安全

- “Wang–Li–Ng 只处理 exponent `≤1`。”
- “Wang–Li–Ng 不覆盖 `Q>1`。”
- “Wang–Li–Ng 只给 set-distance rate / 已给 actual-iterate endpoint。”
- “Wang–Li–Ng 没有 nonisolated solution set、reflection 或 alignment 结果。”
- “Theorem 7.4/8.2/GX package is new relative to Wang–Li–Ng.”
- 任何 `EXACT_OVERLAP`、`SPECIAL_CASE` 或 `NO_DIRECT_OVERLAP` 的逐定理断言。

## 7. Evidence and execution status

### 7.1 Evidence labels

- `VERIFIED_USER_MATERIAL`: 三个本地项目文件已检查；冻结稿 hash 匹配。
- `VERIFIED_SOURCE`: SIAM official abstract/metadata；CUHK official record；SIAM publisher preview p. 1996。
- `PENDING_VERIFICATION`: Wang 的 Definition、theorems、proofs、rate conventions、examples 与 limitations。
- `AI_INFERENCE`: maximal-monotone exact PPA 与冻结 named-branch language 的框架关系；条件式 exponent translation。
- `NOT_EXECUTED`: theorem-level extraction/overlap decision，因为没有合法完整正文。

### 7.2 Limitations and risks

1. 搜索有边界；没有命中公开全文不是全文不存在的证明。
2. 出版社付费页、ResearchGate request-full-text 页面和单页 preview 均不能冒充 full paper。
3. 摘要中的 “strong convergence” 不足以确定 quantitative rate 的对象。
4. “Hölder” 名称不足以确定 exponent 方向或范围。
5. 不能用 Li–Mordukhovich 2012 的 convention 替 Wang 定义。
6. 不能用摘要未出现某关键词推断对应 theorem 不存在。

## 8. Manual operation companion

### 操作目标与回传证据

- 目标：通过机构订阅、作者合法分享或其他合规途径取得 DOI 10.1137/22M152147X 的完整 PDF。
- 所需文件：完整论文 PDF，最好保留题名页、页码 1996–2020 和来源/许可说明。
- 完成证据：可打开、页码连续、包含 Definitions、main theorems、exact-PPA corollary、applications/references 的 PDF；附下列回传卡。
- 隐私限制：用户自行登录；不得把密码、验证码、cookie、token 或机构凭据发给任何对话。
- 返回后：只在同一 `task_id` 下重跑逐定理审计，不改变 stage authority。

#### 可复制到新对话的 Prompt

```text
你现在是“SCI-Skills 操作陪跑助手”。

请帮助我完成下面这项论文外部操作。每次只告诉我一个步骤，等待我确认或发送截图后再继续。不要假设我已经完成操作。如果页面、按钮或软件界面与预期不同，请让我截图，并根据截图重新指导。

不要索取或要求我粘贴密码、验证码、私钥、会话信息或完整访问凭据。如果需要登录，只指导我在网页中自行登录。不要把安装或配置软件作为主线前置条件；先给我无安装替代方案。只有我明确选择可选增强后，才说明软件来源、系统要求、磁盘空间、风险和卸载方法。

项目ID：monotonicity-regularity-seesaw-2026-09
论文类型：T
当前阶段：T2
任务ID：RL-NOV-WANG-DEEP-10-MANUAL-01
操作平台或软件：机构图书馆/SIAM 正版访问页，或作者合法分享渠道
本次目标：合法取得 Wang–Li–Ng 2023（DOI 10.1137/22M152147X）的完整 PDF，不绕过付费墙或访问控制
已有文件：官方 DOI、SIAM 摘要页、CUHK 官方题录；当前没有全文
完成标准：PDF 可打开，题名与 DOI 匹配，页码覆盖 1996–2020，正文含 definitions、theorems/corollaries、proofs 与 references
安全与隐私限制：我自行登录；不要索取或记录密码、验证码、cookie、token、机构凭据；不要使用非法镜像或绕过访问控制
需要带回原对话的材料：完整 PDF、合法来源说明，以及填写完毕的 SCI-Skills 操作回传卡

完成后，请核验生成或下载的文件，并输出一张“SCI-Skills 操作回传卡”，保留项目ID、阶段和任务ID，列明实际步骤、参数、文件、标识符、限制和未解决问题。
```

#### SCI-Skills 操作回传卡

```yaml
contract_version: "1.0"
project_id: "monotonicity-regularity-seesaw-2026-09"
paper_family: "T"
stage_id: "T2"
operation_task_id: "RL-NOV-WANG-DEEP-10-MANUAL-01"
platform_or_software:
operation_date:
completed_steps: []
queries_filters_or_parameters:
  - "DOI 10.1137/22M152147X"
generated_identifiers: []
returned_files: []
logs_or_screenshots: []
record_count_or_output_summary:
access_license_or_export_limits: []
problems_encountered: []
unresolved_items: []
user_confirmation:
credentials_or_secrets_included: false
```

## 9. Quality checks

- [x] `sci-skills-paper-deep-reading` 的 source-depth gate 已执行。
- [x] 冻结稿 SHA-256 与给定值一致；冻结稿未修改。
- [x] 先检查两个已有 prior-art/claim-safe 文件。
- [x] 只使用平台原生 web search/browsing 与本地文件；无第三方 API、key 或 SDK。
- [x] 官方摘要、单页 preview、官方题录与 full paper 明确分级。
- [x] 未把摘要冒充全文，未重构不可见 theorem。
- [x] exponent convention 未从题名或前序论文反推。
- [x] maximal monotone/Hilbert/solution set/stepsize/inexactness/rate-object 逐轴分开。
- [x] upper order、two-sided exponent、exact Q-factor 分开。
- [x] actual-iterate strong convergence 与 quantitative-rate object 分开。
- [x] 冻结 Theorem 4.2、Corollaries 5.1–5.3、Theorem 7.4、Theorem 8.2、Proposition 9.1、GX-071–073 均逐项列出。
- [x] 每个 theorem/example overlap verdict 使用允许标签，且证据不足时统一为 `PENDING`。
- [x] negative search boundary 未升级为 novelty proof。
- [x] 完整 Expert Contract 1.0 字段已输出。
- [x] 全文只定义一个 primary next action。

## 10. Deliverables

- `work/novelty_wang_deepread.md`：本次 PROVISIONAL 摘要级深读、冻结结果重叠矩阵、claim-safe wording、manual companion 与 Expert Contract。
- 本轮没有生成 theorem-level extraction，因为没有合法可读全文；该缺项已显式标为 `NOT_EXECUTED / PENDING_VERIFICATION`。

## 11. Expert Contract 1.0

```yaml
contract_version: "1.0"
expert_skill: "sci-skills-paper-deep-reading"
project_id: "monotonicity-regularity-seesaw-2026-09"
paper_family: "T"
stage_id: "T2"
task_id: "RL-NOV-WANG-DEEP-10"
task_status: "PROVISIONAL"
inputs_reviewed:
  - "research/RL_foundations.md @ sha256:0adf8ca1593148bebce576e9659f3da50e61a77880c0b311cbcc35d0dcbb4ebd"
  - "work/rl_foundations_structure_prior_art.md"
  - "work/rl_foundations_structure_claim_safe_matrix.md"
  - "SIAM official abstract/metadata for DOI 10.1137/22M152147X"
  - "SIAM publisher preview, journal p. 1996 only, as displayed on ResearchGate"
  - "CUHK official research record for DOI 10.1137/22M152147X"
  - "Hangzhou Normal University official author profile"
outputs:
  - "work/novelty_wang_deepread.md"
evidence_status:
  - "VERIFIED_USER_MATERIAL: frozen baseline hash and two existing prior-art files"
  - "VERIFIED_SOURCE: official abstract, metadata, and publisher-preview page 1996"
  - "PENDING_VERIFICATION: full definitions, theorems, proofs, exponent convention, rate objects, examples, and limitations"
  - "AI_INFERENCE: framework-only relation and conditional exponent translation"
  - "NOT_EXECUTED: theorem-level overlap audit because full text was not legally accessible"
assumptions:
  - "The frozen project convention is d(y,S)<=kappa*r_F(y)^Q with Q>1."
  - "A title or use of the word Holder does not determine Wang's exponent direction or range."
  - "Absence from an abstract is not evidence of absence from the full paper."
  - "No-hit search evidence is a bounded negative result, never novelty proof."
author_input_needed:
  - "A legally obtained complete PDF of Wang–Li–Ng 2023, DOI 10.1137/22M152147X, with source/access provenance."
manual_actions:
  - "Use the bundled operation-companion prompt in section 8 to obtain and return the lawful full PDF; do not share credentials or bypass access controls."
quality_checks:
  - "Frozen SHA-256 matched exactly and the baseline remained read-only."
  - "Official abstract, one-page publisher preview, and full text were not conflated."
  - "All requested assumption and rate-object axes were separately recorded."
  - "All requested frozen results received an allowed overlap label."
  - "Every theorem-level verdict remains PENDING rather than inferred from abstract silence."
  - "Claim-safe and unsafe wording were both supplied."
  - "Exactly one primary next action is defined."
conflicts: []
conflict_resolution_status: "NOT_REQUIRED"
merge_permission: "orchestrator_only"
stage_acceptance_recommendation: "REPAIR"
recommended_next_action: "NEXT-1"
```

## 12. One next action

**NEXT-1：通过机构订阅或作者合法分享取得 DOI 10.1137/22M152147X 的完整 PDF，并回传该 PDF，以便在同一 `task_id` 下执行逐定理重审。**
