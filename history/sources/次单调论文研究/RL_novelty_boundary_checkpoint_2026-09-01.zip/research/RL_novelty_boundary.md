# RL 新颖性边界：定理级冻结审计

> 项目：`monotonicity-regularity-seesaw-2026-09`  
> 阶段：`T2 — 理论谱系与精确先例核验`  
> 审计日：`2026-09-01`  
> 数学基线：`research/RL_foundations.md`  
> 基线 SHA-256：`0adf8ca1593148bebce576e9659f3da50e61a77880c0b311cbcc35d0dcbb4ebd`

## 0. 冻结判决

1. **数学基础不变。** 本轮没有修改 `RL_foundations.md`，也没有重开其定理、常数或证明。
2. **Luque 历史链已闭合。** F. J. Luque 的公开 primary prepublication 已完成逐式核验；它直接覆盖 maximal-monotone、full-resolvent、exact PPA 切片中的幂型集合距离端点递推。
3. **RL 的新颖性不能建立在“power error bound 首次产生 PPA 的 $q$-阶”上。** 该说法已被 Luque 1981/1984 排除；非孤立解集也不能挽救这一主张。
4. **当前可守的贡献位于离开 Luque 切片之后的结构：** genuine $0<\gamma<1$ 的 restricted reflector geometry、possibly nonmaximal/nonmonotone named branch、coverage/exclusion/invariance 账本、moving/fixed anchor 分解、条件性 $\theta q$ 组合，以及 GX-071--073 的边界与 sharpness 纪律。
5. **T2 暂不能完全通过。** Wang--Li--Ng 2023 与 Moursi--Vanderwerff 2025 仅取得官方摘要或出版商短预览；在合法全文核验前，相关定理一律为 `PENDING`。本文件冻结的是“当前证据允许的边界”，不是全领域 priority certificate。

阶段状态：**`PARTIALLY_PASSED — REPAIR_REQUIRED`**。  
基础理论状态：**`ACCEPTED_AS_FIXED_MATHEMATICAL_FOUNDATION`**。  
投稿状态：**`NOT_READY`**。

## 1. 判定标签

| 标签 | 含义 |
|---|---|
| `EXACT_OVERLAP` | 对象、假设、量词和结论在共同参数化后实质相同 |
| `SPECIAL_CASE` | 冻结结果的某一明确切片已被先例覆盖，或先例是冻结结果的明确切片 |
| `ADJACENT` | 主题或机制相邻，但不存在已核的定理蕴含 |
| `NO_DIRECT_OVERLAP` | 对已读全文而言，可确认其定理不覆盖指定结构；不是全领域不存在证明 |
| `PENDING` | 来源深度不足，不能作肯定或否定的定理级判断 |

任何 `NO_DIRECT_OVERLAP` 都绑定于指定来源；不得改写为 “first in the literature”。

## 2. 来源深度与书目更正

| 来源 | 实际证据深度 | 本轮可用范围 | 状态 |
|---|---|---|---|
| [F. J. Luque, LIDS-P-1142 (1981)](https://pdfs.semanticscholar.org/8733/1e54b6595ad42fdb76dbb13e347b0aa3128f.pdf)；[SIAM 正式记录](https://epubs.siam.org/doi/10.1137/0322019) | 36 页 primary prepublication 全文；关键扫描页视觉核验；正式元数据 | inverse growth、PPA、Theorems 2.1/3.1/3.2、式 (3.7)、rate object、步长与量词 | `VERIFIED_PRIMARY_FULL_TEXT` |
| [Wang--Li--Ng 2023](https://epubs.siam.org/doi/10.1137/22M152147X) | 官方摘要、题录、出版商第一页 | Hilbert/maximal-monotone、exact/inexact PPA、Hölder metric subregularity 的宽主题 | `PENDING_FULL_TEXT` |
| [Moursi--Vanderwerff 2025](https://link.springer.com/article/10.1007/s10957-025-02633-4) | 官方摘要、元数据、出版商第一页与图题 | bounded-set/at-each-point uniform monotonicity、nonexpansive mappings、reflection keyword 的宽主题 | `PENDING_FULL_TEXT` |
| Zhu 1995 primary prepublication | 全文定点复核 | finite-dimensional actual-iterate rate、alignment lemma、每个 strict subendpoint $t<q$ | `VERIFIED_PRIMARY_FULL_TEXT` |
| Luke--Tam、Barroso 等既有审计来源 | 原有公式级全文审计 | $\gamma=1$ 参数切片、ordinary Hölder map-side class、restricted reflected-resolvent 近邻 | `VERIFIED_IN_EXISTING_AUDIT` |

书目更正：1984 SIAM 论文作者是 **Fernando Javier Luque**，规范写作 **F. J. Luque**，不是此前账本中的 “R. Luque”。

## 3. Luque 定理 3.1 的精确历史边界

Luque 在实 Hilbert 空间中令 $T$ 为 multivalued maximal monotone operator，解集

\[
Z=T^{-1}(0)\ne\varnothing,
\]

并假设存在 $a>0,s\ge1,\delta>0$，使

\[
\forall w\in B(0,\delta),\ \forall z\in T^{-1}(w):
\qquad d(z,Z)\le a\lVert w\rVert^s.
\tag{L-IG}
\]

Theorem 3.1 的算法精度指数为 $r\ge1$，结论对象是集合距离

\[
d_k:=d(z^k,Z),
\]

其 Q-order 至少为 $\min\{r,s\}$。更关键的是，在 exact PPA、固定步长 $c_k\equiv\lambda$ 下，证明式 (3.7) 直接给出端点上界

\[
d_{k+1}\le \frac{a}{\lambda^s}d_k^s.
\tag{L-endpoint}
\]

这意味着：

- 它不是仅有“对每个 $t<s$”的结论；端点 $s$ 的 big-$O$ 已出现；
- 它仍只是集合距离 upper recurrence，不是一般非孤立情形的 actual-iterate endpoint；
- 它不证明 two-sided exact exponent，也不证明正的 exact Q-factor；
- $Z$ 可以非单点；所以“首次处理非孤立高阶 PPA set-distance”不成立；
- 当轨道最终处于 locally isolated zero $p$ 的邻域时，$d(z^k,Z)=\lVert z^k-p\rVert$，于是该端点递推成为 actual-iterate upper recurrence。

### 3.1 与冻结推论 5.2 的常数级重合

maximal monotonicity 使 full reflected resolvent nonexpansive；在冻结坐标中取

\[
\gamma=1,\qquad L=1,\qquad \rho=a,\qquad q=s.
\]

冻结推论 5.2 的式 (5.6) 变成

\[
r_{k+1}
\le a\left(\frac{1+1}{2\lambda}\right)^s r_k^s
=\frac{a}{\lambda^s}r_k^s,
\]

与 Luque 的固定步长粗端点上界逐项相同。因此该共同切片是 `SPECIAL_CASE` 级直接重叠，不能作为新公式。

在线性 $s=q=1$ 切片，Luque 利用 firm geometry 得到的因子

\[
\frac{a}{\sqrt{a^2+\lambda^2}}<1
\]

比冻结 generic named-branch 路径的 $a/\lambda<1$ 充分条件更强；冻结结果不能声称在 monotone slice 改进 Luque。

### 3.2 Luque 与 Zhu 不可串台

| 来源 | 空间与算法 | rate object | 已核 exponent 强度 |
|---|---|---|---|
| Luque 1981/1984 | 实 Hilbert；maximal-monotone；exact/inexact、variable step | $d(z^k,Z)$ | exact PPA 有 endpoint $O(d_k^s)$；无 exact factor |
| Zhu 1995 | 有限维；exact PPA | $\lVert z^k-z^\infty\rVert$ | 对每个 $1<t<q$ 的 actual-iterate 结论；正式定理未给 $t=q$ endpoint |

所以安全历史叙述是：Luque 先给非孤立集合距离端点；Zhu 后给有限维 actual-iterate 与 orbit-alignment，但 formal rate 是 strict subendpoint。

## 4. 冻结结果的逐块重叠矩阵

| 冻结对象 | 已核先例关系 | 判定 | 可守边界 |
|---|---|---|---|
| 定理 1.1：RL/内积/reflector/firm-type 等价 | Cayley pullback 后就是 reflector 的 ordinary Hölder continuity；map-side Hölder class 已知；$\gamma=1$ 有精确 operator-side 先例 | `EXACT_OVERLAP`（map-side 与 $\gamma=1$ 切片）；MV 2025 `PENDING` | 可保留统一 restricted-relation 账本与后续算法接口；不能把基本 Hölder map condition 称为新类 |
| 命题 1.3：任意 Hölder map 的 Cayley realization | 属标准 Minty--Cayley 构造的直接 pullback | `ADJACENT / ALGEBRAIC` | 作为自包含 realization lemma 有用，但不宜作为主要 novelty |
| 定理 2.1(a)：$\gamma=1$ tied semimonotonicity | equal-parameter semimonotonicity、Luke--Tam/Luke--Thao--Tam 切片已有 | `EXACT_OVERLAP` | 只能作为参数字典与基线 |
| 定理 2.1(b,c)：inverse/scaling | 精确代数规则；未形成独立重大先例差别 | `ADJACENT` | 可作为 calculus 组件，不作排他性 claim |
| 定理 4.2：localized gauge--PPA | Luque 已有 inverse gauge 到 PPA set-distance 的 maximal-monotone 路线；两者算法假设不可比 | `ADJACENT`；rate 核在 monotone slice 为 `SPECIAL_CASE` | named/nonmonotone branch、coverage、anchoring、output return、invariance、finite length 与 strong convergence 的组合 |
| 推论 5.1：genuine $0<\gamma<1,L>0$ 的 $\gamma q$ phase | Luque 没有独立 reflector exponent；map-side Hölder composition 本身是一般函数复合 | Luque `NO_DIRECT_OVERLAP`；Wang 2023 `PENDING` | 条件性 branchwise phase split 与 failure/critical regimes；不能称 universal compensation law |
| 推论 5.2：$\gamma=1$ 的 $q$-phase | $L=1$、maximal-monotone、exact full PPA 切片与 Luque 式 (3.7) 常数级相同 | `SPECIAL_CASE`；Wang 2023 `PENDING` | $L\ne1$、possibly nonmonotone/restricted named branch 与显式局部闭合条件 |
| 推论 5.3：$L=0$ 退化 | Luque 的 flat inverse condition 是另一退化轴，不等同于 constant reflector | `ADJACENT`；Wang 2023 `PENDING` | “printed $\gamma$ 失去作用、回到 $q$-phase”的参数纪律 |
| 定理 6.1 / 推论 6.2：moving-anchor 渐近反射 | Luque 不含 moving zero 或 centered reflection remainder；MV 2025 明确涉及 reflection，但正文不可见 | Luque `NO_DIRECT_OVERLAP`；MV 2025 `PENDING` | output-near moving anchor、relative reflection law 与 power defect |
| 定理 7.1 / 命题 7.2：fixed-anchor $q$-flatness/gauge 等价 | Cayley identity 使其部分结构代数性很强；Luque 不作该 graph-germ equivalence；MV 2025 `PENDING` | Luque `NO_DIRECT_OVERLAP`；更广 priority `PENDING` | residual flatness、resolvent flatness、centered reflection remainder 的 branchwise 等价及 dilation-stability 边界 |
| 命题 7.3：full EB 与 residual-complete branchwise bound | Luque full inverse growth 与 local full PEB 在共同 localization 中具有同一 residual-to-set 数学核 | `ADJACENT`；Wang 2023 `PENDING` | 明确 favorable branch 不足以推出 full error bound，并把 residual completeness 单列为升级条件 |
| 定理 7.4：isolated-zero named PPA | rate 部分在 maximal-monotone/full-resolvent/fixed-step 切片被 Luque 覆盖 | `SPECIAL_CASE`；Wang 2023 `PENDING` | named/nonmonotone scope、input/output windows、ball invariance、reflection remainder；不是 $q$-order 本身 |
| 定理 8.2：nonisolated alignment 与 $\theta q$ | Luque 已有 nonisolated set-distance $q$-endpoint但不用 two-anchor；Zhu 有 asymptotic normal alignment；Wang/MV 正文待核 | Luque/Zhu `ADJACENT`；Wang/MV `PENDING` | input/output nearest-solution drift 的独立定量化，以及非-firm branch 中的条件性 map-level $\theta q$ law |
| 命题 9.1：joint saturation | Luque 不分析 residual、alignment、output rate 三个同序列 normalized ratios | Luque `NO_DIRECT_OVERLAP`；更广 priority 未闭合 | upper/two-sided/factor 分层与同序列 saturation criterion |
| GX-071 | genuine $\gamma<1$、非孤立 tangential drift、exact $\gamma q$ witness | Luque `NO_DIRECT_OVERLAP`；Wang/MV `PENDING` | 声明 class 内 attainability 与 normalized limit 1；不证明 universality |
| GX-072 | all-pairs $\gamma$ 可保守，orbit 可达 $q>\gamma q$ | Luque `NO_DIRECT_OVERLAP`；Wang/MV `PENDING` | 反证“all-pairs exponent 决定 exact orbit order” |
| GX-073 | one-step Hölder scale 后有限步逃逸 | Luque full-domain PPA class不含该 restricted-domain escape；Wang/MV `PENDING` | 反证“one-step scale 自动产生 convergence order”，证明 invariance 不可省 |

## 5. 当前可守的新颖性残余

### 5.1 强残余

1. **Named-branch operator calculus。** 对 possibly nonmaximal/nonmonotone relation，将 natural Minty domain、coverage、remote-branch exclusion、anchoring 与 orbit invariance 分开，并在固定 named branch 上建立局部结论。
2. **Genuine $\gamma<1$ 的 operator-side Cayley geometry。** 新颖候选不是“存在 Hölder map”，而是该 map regularity被系统拉回 graph inequality，并与 branch existence、error bound 和算法闭合共同使用。
3. **Moving/fixed anchor 分层。** fixed-anchor $q$-flatness、output-near moving zero 的 asymptotic reflection，以及非孤立 input/output anchors 的 drift profile 是三个不同对象；冻结稿不把它们混成一个 exponent。
4. **条件性 $\theta q$ composition。** 贡献是两种独立退化尺度的显式组合及其适用边界，不是“指数相乘”这一行代数本身。
5. **Sharpness 与 failure architecture。** GX-071--073 分别展示 attainability、all-pairs exponent 的保守性和 invariance 失败；它们共同否定 universal $\gamma q$ 叙事。

### 5.2 中等或弱残余

- Theorem 1.1 的代数等价与 Cayley realization：对论文组织有价值，但 map-side class 与 $\gamma=1$ 切片已有先例。
- isolated $q$-order PPA：rate 本身已知；仅 branch/reflection/localization 包装可守。
- “误差界 exponent 与 Hölder exponent 相乘”：若无自然例子、逆命题、sharpness 或算法收益，单独不足以成为高水平论文核心。

## 6. Claim-safe contribution statement

### 6.1 可用于下一版引言的英文骨架

> We develop a local named-branch Cayley framework for possibly nonmaximal or nonmonotone relations. The framework separates branch coverage, anchoring, output error bounds, and invariance, and it exposes fixed-anchor reflection flatness and moving-anchor drift as distinct quantitative mechanisms. For a genuinely Hölder reflected branch, these mechanisms yield conditional upper phase laws, including $\gamma q$ and, for nonisolated solution sets, $\theta q$. These exponents are not asserted to be universal or exact: complementary examples show attainability, conservatism of all-pairs Hölder exponents, and failure under domain escape. The contribution is not the first higher-order error-bound rate for the proximal point method; that maximal-monotone set-distance mechanism already appears in Luque's work.

在 Wang--Li--Ng 与 Moursi--Vanderwerff 全文核验前，不得把其中任何句子升级为 “first”, “new class”, “strict generalization” 或 “not previously known”。

### 6.2 必须禁止的表述

| 禁止表述 | 理由 |
|---|---|
| “首次用 higher-order metric subregularity 得到 exact PPA 的 $q$-阶。” | Luque Theorem 3.1 与式 (3.7) 已给 set-distance endpoint |
| “首次在非孤立解集上得到高阶 PPA convergence。” | Luque 已允许非单点解集；Zhu 又给 actual-iterate 近端点结果 |
| “Luque 只给 $t<q$。” | 这是 Zhu actual-iterate theorem 的边界；Luque exact set-distance 有 endpoint $q$ |
| “RL 推论 5.2 在 monotone case 改进 Luque。” | $q>1$ 常数相同；$q=1$ Luque 更强 |
| “$L=0$ 就是 Luque 的 flat inverse。” | constant reflector 与 zero inverse gauge 是不同退化轴 |
| “RL 是新的 generalized monotonicity class。” | map-side 是 ordinary Hölder continuity；$\gamma=1$ 有精确 monotonicity 先例 |
| “$\gamma q$ 或 $\theta q$ 是 universal exact Q-order。” | 冻结稿只给条件性 upper law；GX-072 直接显示保守性 |
| “Luque 没有 reflector 内容。” | maximal monotonicity 已隐含 nonexpansive reflector；准确差别是没有显式 $\gamma<1$/centered/moving-anchor 结构 |
| “Wang 2023 或 MV 2025 不覆盖我们的定理。” | 当前只有摘要/短预览，公式级判断仍 `PENDING` |
| “RL 严格推广 Luque。” | 两者假设交叉：RL relation scope 更宽，Luque variable-step/inexact/full-resolvent theory 更宽 |

## 7. 命名判决

`RL` 继续作为内部代号，但暂不建议作为公开的 “new monotonicity” 名称。原因是：

- 核心条件在 Minty--Cayley 坐标中就是 reflected branch 的 Hölder continuity；
- $\gamma=1$ 已精确落入 tied semimonotonicity/submonotonicity 谱系；
- $0<\gamma<1$ 的主要差别是 scale-dependent Cayley geometry，而不是一个显然与传统 monotonicity 同序的强弱参数。

投稿稿件当前最安全的暂定描述词是：

> **restricted Hölder--Cayley graph condition**

一般 gauge 版本可称：

> **restricted Cayley--modulus condition**

在强调局部 branch geometry、而非定义名称时，可使用：

> **local Hölder Cayley geometry on a named Minty branch**

或更直接的：

> **Hölder reflected-resolvent geometry on a restricted branch**

正式名称仍保持 `PROVISIONAL`，直到 Moursi--Vanderwerff 2025 全文完成术语和公式碰撞核验。标题不宜使用 “RL monotonicity”“Hölder monotonicity”或 “a new generalized monotonicity”。

## 8. 对论文价值的当前判断

这套基础**仍有论文价值**，但价值形态已经改变：

- 它不是“发现一种新单调性并由 $q$-subregularity 得到首个高阶 PPA rate”；
- 它更像一个 **restricted Cayley geometry + local branch dynamics + anchor drift + sharpness** 的结构理论；
- 若只保留 Theorem 1.1 与 $\gamma q$ 一步递推，贡献偏薄；
- 若把 named-branch 合法性、fixed/moving anchor、$\theta q$ composition、自然而非纯工程化的 examples，以及算法 consequences 组织成一个不可拆的主定理链，才可能形成有竞争力的高水平变分分析/优化论文。

当前不能据此承诺 SIAM 级别，也不能否定其可能性。期刊级别将取决于：两个全文闸门是否安全、能否补足自然对象与 sharpness、以及是否把框架扩展为超出单一 PPA 递推的算法结果。

## 9. 尚未闭合的证据闸门

### 9.1 Wang--Li--Ng 2023

必须取得并核对：

- Hölder metric subregularity 的原始定义与 exponent convention；
- exact-PPA corollary 的 rate object；
- $Q>1$ 是否允许；
- endpoint、two-sided、actual-iterate/set-distance 的精确层级；
- nonisolated solution set、stepsize 与 inexactness 的量词。

### 9.2 Moursi--Vanderwerff 2025

必须取得并核对：

- “on bounded sets” 与 “at each point” 的完整量词；
- operator modulus 与 nonexpansive/strongly-nonexpansive map modulus 的对应；
- $R_A$ 或 $-R_A$ 的符号与 theorem blocks；
- 是否出现 $\gamma<1$、centered higher-order remainder、moving anchor 或 PPA；
- Example 4.4 的完整公式与作用。

摘要未提及某对象，既不证明它存在，也不证明它不存在。

## 10. 阶段验收与唯一下一步

### 10.1 T2 验收

- Luque blocker：`RESOLVED_AT_PRIMARY_PREPUBLICATION_THEOREM_LEVEL`；
- Wang--Li--Ng blocker：`PENDING_FULL_TEXT`；
- Moursi--Vanderwerff blocker：`PENDING_FULL_TEXT`；
- public name：`PROVISIONAL`；
- exclusionary novelty wording：`BLOCKED`；
- fixed mathematical foundation：`ACCEPTED`；
- submission manuscript：`NOT_READY`。

因此 T2 维持 `PARTIALLY_PASSED — REPAIR_REQUIRED`，不得提前进入排他性 contribution freeze。

### 10.2 唯一下一步

**通过机构订阅或作者合法分享一次性取得 Wang--Li--Ng 2023 与 Moursi--Vanderwerff 2025 的完整 PDF，然后只针对本文件中列出的 definitions/theorems/examples 做公式级复审，并据此锁定最终公开名称与 contribution statement。**

## 11. 审计来源账本

本文件综合但不替代以下工作文件：

- `work/novelty_luque.md`
- `work/novelty_luque_compare.md`
- `work/novelty_wang_search.md`
- `work/novelty_wang_deepread.md`
- `work/novelty_mv_search.md`
- `work/novelty_mv_deepread.md`
- `work/rl_foundations_structure_prior_art.md`
- `work/rl_foundations_structure_claim_safe_matrix.md`
- `work/rl_alias_landscape.md`
- `work/rl_exact_prior_art.md`

所有对 frozen theorem 的定位均绑定于页首 SHA-256。未核全文、bounded negative search 与 AI crosswalk 均没有被提升为 source theorem 或 novelty proof。
