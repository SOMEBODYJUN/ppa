# RLEB–PPA：极限解选择的最优稳定性

日期：2026-09-18。

- `research_note.md`：中文完整推导稿，包括一般连续模上界、闭图半代数二值反例、匹配下界、二次点收敛反例、结构推论和优先权边界。
- `verify_research.py`：可复现数值核查。Python 3.10+，依赖 NumPy。
- `results/verification_results.json`：两个模型各 100000 样本的检验结果。
- `results/geometric_phase.csv`：几何模型在对数初值下的切换与极限差。
- `results/quadratic_phase.csv`：二次模型的对数极限差与遗漏尾项界。
- `Codex_independent_audit.md`：可直接转交的独立证伪和优先权核查任务。

运行：

```bash
python verify_research.py --out results
```

数学结论依据证明，不依据有限随机测试。计算使用浮点数，不是形式化或区间算术证书。已完成定向文献核对，但全球优先权未确认。

本研究包不改写或覆盖用户原论文；拟新增研究对象为初值到最终解的映射，而非重复证明原有轨道收敛定理。
