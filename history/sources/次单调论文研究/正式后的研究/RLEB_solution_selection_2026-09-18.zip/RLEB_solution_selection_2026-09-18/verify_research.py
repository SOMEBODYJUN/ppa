"""Reproducible checks for RLEB limit-selection stability.

The proofs, not these finite tests, establish the theorems.
Requires Python 3.10+ and NumPy. Run: python verify_research.py --out results
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path
import numpy as np


def resolvent(x: np.ndarray, mode: str = "geometric") -> np.ndarray:
    x = np.asarray(x, dtype=float)
    if x.shape[-1] != 3:
        raise ValueError("Last dimension must be three.")
    r = np.abs(x[..., 2])
    y = r / 4.0 if mode == "geometric" else r * r
    return np.stack((x[..., 0] + np.sqrt(r),
                     x[..., 1] + np.sqrt(np.minimum(np.maximum(x[..., 1], 0.0), r)),
                     y), axis=-1)


def operator_branches(u: np.ndarray, mode: str = "geometric") -> tuple[np.ndarray, np.ndarray]:
    u = np.asarray(u, dtype=float)
    y = u[..., 2]
    if np.any(y < 0):
        raise ValueError("The operator is empty below y=0.")
    r = 4.0 * y if mode == "geometric" else np.sqrt(y)
    eta = np.maximum(u[..., 1], 0.0)
    # Stable evaluation of (sqrt(1+4*eta)-1)/2.
    unsaturated = 2.0 * eta / (np.sqrt(1.0 + 4.0 * eta) + 1.0)
    d = np.minimum(np.sqrt(r), unsaturated)
    common = (-np.sqrt(r), -d)
    return (np.stack((*common, r-y), axis=-1),
            np.stack((*common, -r-y), axis=-1))


def geometric_phase(t: float, r0: float = 0.01,
                    gamma: float = 0.5, q: float = 0.25,
                    amplitude: float = 1.0) -> dict[str, float | int]:
    """Exact saturation/tail formula, with epsilon=exp(-t).

    Work in log coordinates before the switch: epsilon need not be representable.
    Floating-point rounding aside, the post-switch infinite geometric tail is exact.
    """
    if not (t > 0 and 0 < r0 < 1 and 0 < gamma < 1 and 0 < q < 1 and amplitude > 0):
        raise ValueError("Invalid parameter range.")
    lp, lr = -t, math.log(r0)
    n = 0
    while lp < lr:
        lp = gamma * lp + math.log(amplitude) + math.log1p(
            math.exp((1-gamma)*lp) / amplitude)
        lr += math.log(q)
        n += 1
        if n > 100000:
            raise RuntimeError("Switch did not occur within the safety bound.")
    phase = math.exp(lp) + amplitude * math.exp(gamma*lr)/(1-q**gamma)
    beta = gamma*math.log(1/q)/math.log(1/gamma)
    return {"t": t, "switch": n, "phase": phase, "beta": beta,
            "normalized_phase": phase*(t/math.log(t))**beta if t > 1 else float('nan')}


def superlinear_phase(t: float, r0: float = 0.01,
                      gamma: float = 0.5, nu: float = 2.0,
                      amplitude: float = 1.0) -> dict[str, float | int]:
    """Log phase with a rigorously bounded omitted positive tail.

    The loop stops once the omitted tail is less than 1e-16 times the leading term.
    The `omitted_relative_bound` is an analytic geometric-series bound evaluated
    in floating point; it is not an interval-arithmetic certificate.
    """
    if not (t > 0 and 0 < r0 < 1 and 0 < gamma < 1 and nu > 1 and amplitude > 0):
        raise ValueError("Invalid parameter range.")
    lp, lr = -t, math.log(r0)
    n = 0
    while lp < lr:
        lp = gamma*lp + math.log(amplitude) + math.log1p(math.exp((1-gamma)*lp)/amplitude)
        lr *= nu
        n += 1
        if n > 100000:
            raise RuntimeError("Switch did not occur.")
    logs = [lp]
    power_log = gamma*lr
    omitted = float('inf')
    for _ in range(10000):
        logs.append(math.log(amplitude) + power_log)
        power_log *= nu
        mx = max(logs)
        ratio = math.exp((nu-1)*power_log)
        log_bound = math.log(amplitude)+power_log-math.log1p(-ratio)
        omitted = math.exp(log_bound-mx) if log_bound-mx > -745 else 0.0
        if omitted < 1e-16:
            break
    else:
        raise RuntimeError("Tail summation did not terminate.")
    mx = max(logs)
    log_phase = mx + math.log(sum(math.exp(z-mx) for z in logs))
    alpha = math.log(nu)/math.log(nu/gamma)
    return {"t": t, "switch": n, "log_phase": log_phase, "alpha": alpha,
            "normalized_log_phase": -log_phase/t**alpha,
            "omitted_relative_bound": omitted}


def check(seed: int = 20260918, sample_count: int = 100000) -> dict:
    rng = np.random.default_rng(seed)
    report: dict = {"seed": seed, "sample_count": sample_count,
                    "status": "Finite numerical checks; see the note for proofs."}
    for mode in ("geometric", "quadratic"):
        x = rng.uniform(-0.01, 0.01, size=(sample_count, 3))
        # Include seam points, both proximal-input signs, and tangent cusp points.
        x[:sample_count//10, 1] = 0.0
        x[sample_count//10:sample_count//5, 2] = 0.0
        u = resolvent(x, mode)
        fp, fm = operator_branches(u, mode)
        chosen = np.where((x[:,2] >= 0)[:,None], fp, fm)
        graph_error = float(np.max(np.abs(u+chosen-x)))
        branch_error = max(float(np.max(np.abs(resolvent(u+fp, mode)-u))),
                           float(np.max(np.abs(resolvent(u+fm, mode)-u))))
        norm2 = np.minimum(np.sum(fp*fp, axis=1), np.sum(fm*fm, axis=1))
        eb_rhs = norm2/4.0 if mode == "geometric" else norm2**2
        eb_violation = float(np.max(u[:,2]-eb_rhs))
        # Both input points remain in |r| <= .011. Pair distance <= .001.
        direction = rng.normal(size=x.shape)
        direction /= np.linalg.norm(direction, axis=1)[:,None]
        delta_requested = 10.0**rng.uniform(-10, -3, size=sample_count)
        xp = x + direction*delta_requested[:,None]
        delta = np.linalg.norm(x-xp, axis=1)
        reflected_difference = 2.0*(resolvent(x,mode)-resolvent(xp,mode))-(x-xp)
        ratio = np.linalg.norm(reflected_difference, axis=1)/np.sqrt(delta)
        D = 0.001
        normal_lipschitz = 1.5 if mode == "geometric" else 1.0+4.0*0.011
        L = 2.0*math.sqrt(2.0)+normal_lipschitz*math.sqrt(D)
        assert graph_error < 1e-12, graph_error
        assert branch_error < 1e-11, branch_error
        assert eb_violation < 1e-14, eb_violation
        assert float(np.max(ratio)) <= L+1e-10
        report[mode] = {"max_proximal_graph_identity_error": graph_error,
                        "max_both_branch_inverse_error": branch_error,
                        "max_error_bound_violation": eb_violation,
                        "max_sampled_RL_ratio": float(np.max(ratio)),
                        "proved_RL_constant_at_D": L, "D": D}
    R=.01
    report["geometric_compatibility"] = {
        "R":R, "L_R":2*math.sqrt(2)+1.5*math.sqrt(R),
        "certified_kappa":(2*math.sqrt(2)+2.5*math.sqrt(R))**2/16,
        "actual_distance_factor":0.25}
    ts = [1e2, 1e3, 1e4, 1e5, 1e6, 1e8, 1e12, 1e24, 1e48]
    report["geometric_phase"] = [geometric_phase(t) for t in ts]
    report["quadratic_phase"] = [superlinear_phase(t) for t in ts]
    # Direct iteration agrees with the exact geometric saturation formula.
    for t in (10., 30., 100., 300.):
        r,p = .01,math.exp(-t)
        for _ in range(200):
            p += math.sqrt(min(p,r))
            r *= .25
        assert math.isclose(p,float(geometric_phase(t)["phase"]),rel_tol=2e-13,abs_tol=1e-15)
    report["direct_iteration_cross_check"] = "passed"
    return report


def write_results(directory: Path, report: dict) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    (directory/"verification_results.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    for key in ("geometric_phase", "quadratic_phase"):
        rows = report[key]
        with (directory/(key+".csv")).open("w",newline="",encoding="utf-8") as f:
            writer = csv.DictWriter(f,fieldnames=list(rows[0]))
            writer.writeheader();writer.writerows(rows)


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path,default=Path("results"))
    parser.add_argument("--samples",type=int,default=100000)
    args=parser.parse_args()
    result=check(sample_count=args.samples)
    write_results(args.out,result)
    print(json.dumps({k:v for k,v in result.items() if not isinstance(v,list)},indent=2))
