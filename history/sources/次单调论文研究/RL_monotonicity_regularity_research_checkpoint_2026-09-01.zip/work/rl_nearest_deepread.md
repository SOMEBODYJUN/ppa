# RL 最近邻理论全文精读与逐公式新颖性审计

> project_id: `monotonicity-regularity-seesaw-2026-09`  
> paper_family: `T`  
> stage_id: `T2`  
> task_id: `T2-NOV-DEEP`  
> expert_skill: `sci-skills-paper-deep-reading`  
> contract_version: `1.0`  
> 状态边界：本报告只执行最近邻 primary-paper 深读和 RL 逐公式定位；不改变阶段，不给期刊档次结论，也不把五篇文献内未命中升级为全局新颖性证明。

## 0. 证据标签与全文访问深度

- **原文事实**：可在下列全文的定义、命题、定理、假设或公式中直接核对。
- **外部核验**：出版社正式元数据与预印本版本信息相互核对。
- **AI分析**：本报告根据原文公式完成的代数换元、反例检查或边界判断；不是作者原话。
- **研究假设**：值得下一轮检验、尚不能称为新颖结论的研究方向。
- **用户材料**：所附 RL 初稿中的定义、引理和拟议收敛定理。

| ID | 来源与访问深度 | 本报告实际读取位置 | 可支持的证据强度 |
|---|---|---|---|
| P1 | D. R. Luke & M. K. Tam, *Generalized Monotonicity and the Proximal Point Algorithm*, DOI [10.1287/moor.2025.0863](https://doi.org/10.1287/moor.2025.0863)；[出版社官方全文 PDF](https://pubsonline.informs.org/doi/pdf/10.1287/moor.2025.0863)，13 页 | 全文；尤其 Def. 1–2, Props. 1–6, Thms. 1–2, Assumption 2, Examples 1–2, Cor. 1, Remark 3 | **全文级原文事实**；不是 abstract-only |
| P2 | B. Evens, P. Pas, P. Latafat & P. Patrinos, *Convergence of the Preconditioned Proximal Point Method and Douglas–Rachford Splitting in the Absence of Monotonicity*；[arXiv 全文 v2](https://arxiv.org/pdf/2305.03605)，44 页；[Springer 正式论文页](https://link.springer.com/article/10.1007/s10107-024-02182-0) | 全文；尤其 Defs. 2.1, 4.1, Props. 4.3–4.12, Assumptions I–IV, Thms. 2.4, 2.13, 3.3, 5.2, §6 examples | **全文级原文事实 + 正式元数据核验** |
| P3 | R. Gárciga Otero & A. Iusem, *Regularity Results for Semimonotone Operators*, *Computational & Applied Mathematics* 30(1):5–17 (2011)；[SciELO 官方全文](https://www.scielo.br/j/cam/a/TDWFt7WPXgSTwXPnCt8rYdy/?format=pdf&lang=en)，13 页；[IMPA 2010 报告全文](https://webdoc.sub.gwdg.de/ebook/serien/e/IMPA_A/672.pdf)，10 页 | 两个全文版本；Def. 2, Props. 1–7, Lemma 1, Thms. 2–3, Corollaries 1–4 | **全文级原文事实**；2010 报告与 2011 发表稿是同一工作的版本，不计作两篇独立先例 |
| P4 | H. H. Bauschke, W. M. Moursi & X. Wang, *Generalized Monotone Operators and Their Averaged Resolvents*；[arXiv 全文](https://arxiv.org/pdf/1902.09827)，23 页；DOI [10.1007/s10107-020-01500-6](https://doi.org/10.1007/s10107-020-01500-6) | 全文；Def. 2.3, Lemmas 2.5–2.7, Thm. 2.16, Def. 3.1, Props. 3.8–3.13, Cor. 3.10, Prop. 4.3 | **全文级原文事实** |
| P5 | D. R. Luke, N. H. Thao & M. K. Tam, *Quantitative Convergence Analysis of Iterated Expansive, Set-Valued Mappings*；[arXiv 全文](https://arxiv.org/pdf/1605.05725)，40 页；[INFORMS 正式论文页](https://pubsonline.informs.org/doi/10.1287/moor.2017.0898) | 全文；Defs. 2.3, 2.9, 2.17, Props. 2.4, 2.8, Thm. 2.18, Cor. 2.19, Example 2.20，以及算法应用章节 | **全文级原文事实 + 正式元数据核验** |
| U1 | 用户上传的 `RL_Submonotonicity初稿.md` | 全文 828 行：RL/AFNE 定义、power/gauge subregularity、PPA 递推和拟议定理 | **用户材料**；其定理须独立校验，不能作为已发表事实 |

## 1. 先给结论：这五篇最近邻文献对 RL 新颖性的含义

### 1.1 可以安全落锤的部分

1. **\(\gamma=1\) 的 RL 定义本身没有可辩护的定义级新颖性。** 令 \(A=\lambda F\)。它与 Evens–Pas–Latafat–Patrinos 的 equal-parameter \((\theta,\theta)\)-semimonotonicity完全等价；当 \(L>1\) 时，又与 Otero–Iusem 2010/2011 的对称 \(r\)-semimonotonicity完全等价；当采用 Luke–Tam 的 restricted graph 时，与其常数 submonotonicity 也是同一不等式。
2. **Luke–Tam 2025 不只是“相似”。** 对 \(L\ge 1\)，其 violation 参数满足 \(\tau=(L^2-1)/4\)，而 reflected-resolvent Lipschitz 常数正是 \(\sqrt{1+4\tau}=L\)。不过其 Proposition 4 的正式命题范围另有限制 \(\tau<1/2\)，即 \(L<\sqrt3\)；这个限制不能从命题中删掉。
3. **\(0<\gamma<1\) 与上述常数二次 violation 不同。** 它对应随 pair scale 变化且在对角线附近发散的 violation。因而不能用一个有限的 Luke–Tam/Luke–Thao–Tam 常数 violation 覆盖含任意小 pair distance 的完整邻域。
4. **在本任务逐篇全文核对的五篇文献中，没有发现精确的 \(\|R x-R y\|\le L\|x-y\|^\gamma\)、等价的 \(t^{2\gamma}\) graph defect，或相应的“nonlinear-gauge semimonotonicity”定义。** 这是一个有边界的 negative finding，只能写成“在这五篇全文中未发现”，不能写成“文献中不存在”。
5. P5 确实包含 Hölder/gauge regularity：Def. 2.17 明确讨论 \(\mu(t)=\kappa t^\omega\), \(\omega<1\) 的 regularity of order \(\omega\)。但这是**残差/逆稳定性一侧的 gauge**；其 almost averaged/submonotone 几何仍是每个区域上的常数二次 violation。它不是 Hölder reflected-resolvent 的精确先例。

### 1.2 新颖性剩余在哪里

**AI分析。** 若 RL 论文只做以下三件事，其价值很弱：

- 给普通的 Hölder Cayley/reflected-resolvent continuity 换一个“generalized monotonicity”名字；
- 用平行四边形恒等式写出所谓 AFNE 形式；
- 将 \(Lr^\gamma\) 代入 \(\rho s^q\) 得到 \(r^{\gamma q}\)。

真正可能形成论文贡献的是一个**定理包**而非一个定义：

- 对 genuinely non-Lipschitz reflected geometry 建立无分支歧义、局部不变且适用于所有合法 PPA selections 的收敛定理；
- 给出 sharpness：\(\gamma q>1\)、\(=1\)、\(<1\) 三区间中自然且显式的正反例；
- 建立 nonlinear modulus \(\omega\) 的 calculus、inverse/scaling rules、restricted/maximal extension 或 existence/full-domain 机制；
- 展示至少一个现有 constant-violation almost-averaged 理论不能直接覆盖、但 RL 定理确实能处理的自然算法模型。

因此当前最安全判断是：**\(\gamma=1\) 是已知 tied slice；\(\gamma<1\) 有“公式级剩余”，但定义本身近似于重命名，论文价值取决于修复后的新定理、sharp examples 和结构性 calculus。**

## 2. RL 的共同坐标与精确代数

令

\[
a=u-v,\qquad b=u^*-v^*,\qquad x=a+\lambda b,\qquad r=a-\lambda b,
\]

其中两个 graph pairs 均来自所声明的 graph region。用户 RL 为

\[
\|r\|\le L\|x\|^\gamma. \tag{RL}_{\lambda,L,\gamma}
\]

平行四边形/Cayley 恒等式给出

\[
\|r\|^2=\|x\|^2-4\lambda\langle a,b\rangle,
\]

故 RL 与

\[
\lambda\langle a,b\rangle
\ge \frac14\bigl(\|x\|^2-L^2\|x\|^{2\gamma}\bigr) \tag{RL-IP}
\]

完全等价。这里不存在第二个独立几何假设；所谓 AFNE 只是同一恒等式的另一坐标。

### 2.1 Cayley range 上的精确含义

对所限制 graph 定义

\[
D_\Gamma:=\{u+\lambda u^*:(u,u^*)\in\Gamma\}.
\]

如果两个 graph pairs 产生同一个 \(x\in D_\Gamma\)，则 RL 右侧为零，因而它们的 \(r\) 相同；由

\[
u=\frac{x+r}{2},\qquad u^*=\frac{x-r}{2\lambda}
\]

知该 graph pair 唯一。因此 RL 自动给出 restricted \(J_{\lambda F}\) 和 \(R_{\lambda F}\) 在 \(D_\Gamma\) 上的 at-most-single-valuedness，并且

\[
\|R_{\lambda F}x-R_{\lambda F}y\|\le L\|x-y\|^\gamma.
\]

但 RL **不自动给出**：\(D_\Gamma\) 是邻域或全空间、\(J\) 是 self-map、迭代分支存在、graph maximality、range closedness，或迭代始终留在该 graph restriction 内。

### 2.2 \(\gamma=1\) 与二参数 semimonotonicity 的精确 tied slice

令 \(A=\lambda F\)，输出差记为 \(c=\lambda b\)。定义

\[
\theta_L:=\frac{1-L^2}{2(1+L^2)}\in(-1/2,1/2).
\]

直接移项得到

\[
\|a-c\|\le L\|a+c\|
\quad\Longleftrightarrow\quad
\langle a,c\rangle\ge\theta_L(\|a\|^2+\|c\|^2). \tag{2.1}
\]

所以：

\[
\boxed{A=\lambda F\text{ 满足 }(\theta_L,\theta_L)\text{-semimonotonicity}.}
\]

按 Evens et al. 对缩放的 convention，等价地 \(F\) 是 \((\mu_L,\rho_L)\)-semimonotone，其中

\[
\mu_L=\frac{\theta_L}{\lambda},\qquad
\rho_L=\lambda\theta_L,\qquad
\rho_L=\lambda^2\mu_L. \tag{2.2}
\]

这条 \(\rho=\lambda^2\mu\) 是固定 \(\lambda\) 后的一维 tied curve，不是完整的二参数类。

### 2.3 与 Otero–Iusem 参数的精确换算

Otero–Iusem 使用 \(r_O\in(0,1)\)：

\[
\langle a,c\rangle\ge-\frac{r_O}{2}(\|a\|^2+\|c\|^2).
\]

当 \(L>1\) 时，式 (2.1) 给出

\[
r_O=\frac{L^2-1}{L^2+1},\qquad
L=\sqrt{\frac{1+r_O}{1-r_O}}. \tag{2.3}
\]

因此 \(\gamma=1,L>1\) 与 2010/2011 对称 semimonotonicity 完全等价。\(L=1\) 是其 \(r_O\downarrow0\) 的 monotone 边界；\(L<1\) 是正 equal-parameter semimonotonicity，超出 Otero 的负-violation convention，但落在 Evens 二参数定义内。

### 2.4 与 Luke–Tam / Luke–Thao–Tam 参数的精确换算

对 \(A=\lambda F\)：

\[
\langle a,c\rangle\ge-\tau\|a+c\|^2,qquad
\tau=\frac{L^2-1}{4}. \tag{2.4}
\]

相应 almost-FNE violation 与 reflector Lipschitz 常数为

\[
\varepsilon=2\tau=\frac{L^2-1}{2},
\qquad \operatorname{Lip}(R)=\sqrt{1+4\tau}=L. \tag{2.5}
\]

P1 Def. 2 要求 \(\tau\ge0\)，所以只直接覆盖 \(L\ge1\)；P1 Prop. 4 为保持其 violation convention \(\varepsilon<1\)，正式要求 \(\tau<1/2\)，即 \(L<\sqrt3\)。式 (2.4) 本身是纯代数，不等于 P1 的全部命题和算法结论可以外推到更大 \(\tau\)。

### 2.5 \(0<\gamma<1\) 的 scale-dependent defect

令 \(t=\|a+\lambda b\|>0\)。RL-IP 可写成

\[
\lambda\langle a,b\rangle\ge-\tau_\gamma(t)t^2,
\qquad
\tau_\gamma(t)=\frac14\left(L^2t^{-2(1-\gamma)}-1\right). \tag{2.6}
\]

若文献 convention 只允许非负 violation，应使用 \([\tau_\gamma(t)]_+\)。关键是

\[
t\downarrow0\quad\Longrightarrow\quad\tau_\gamma(t)\uparrow+\infty.
\]

故 genuinely \(\gamma<1\) 并不是一个更大的固定 \(\tau\)，而是“近对角线恶化、远离对角线可能改善”的非齐次几何。它与 \(\gamma=1\) 一般不构成全局强弱全序：

- 在直径 \(D<\infty\) 的域上，\(K\)-Lipschitz 蕴含 \(\gamma\)-Hölder，常数可取 \(KD^{1-\gamma}\)；
- Hölder \(\gamma<1\) 不蕴含对角线附近 Lipschitz；
- 在无界域上，\(Kt\le Lt^\gamma\) 通常在 \(t\to\infty\) 失败，所以全局 Lipschitz 与全局 \(\gamma<1\) RL 也不能简单排序。

### 2.6 Evens et al. 一般二参数类的 resolvent window

**原文事实（P2 Prop. 4.12）。** 若 \(A\) 是 \((\mu,\rho)\)-semimonotone，且

\[
\mu\rho<\frac14
\quad\text{或}\quad
[\mu]_+[\rho]_+=\frac14,
\]

则在 admissible interval

\[
\gamma_s\in
\left(
\frac{2[-\rho]_+}{1+\sqrt{1-4\mu\rho}},
\frac{1+\sqrt{1-4\mu\rho}}{2[-\mu]_+}
\right) \tag{2.7}
\]

内（零分母按文中 extended-real convention 处理），\(J_{\gamma_s A}\) 的 Lipschitz modulus 可取

\[
L_J(\gamma_s)=
\frac{|1+2\rho/\gamma_s|+\sqrt{1-4\mu\rho}}
{2(1+\mu\gamma_s+\rho/\gamma_s)}. \tag{2.8}
\]

同一命题还给出：在该 window 中，\(J_{\gamma_s A}\) full-domain 当且仅当 \(A\) maximally \((\mu,\rho)\)-semimonotone。RL\(_1\) 的 tied parameters可代入此一般公式，但这不把 RL 扩张成完整二参数类。

### 2.7 RL 的 inverse 与缩放规则

**AI分析。** 交换 graph 坐标并提取尺度可得

\[
F\text{ 满足 RL}(\lambda,L,\gamma)
\Longleftrightarrow
F^{-1}\text{ 满足 RL}
\left(\lambda^{-1},L\lambda^{\gamma-1},\gamma\right). \tag{2.9}
\]

当 \(\gamma=1\) 时 \(L\) 对 inverse 不变，这与 Otero 的对称性、Evens 的 \((\mu,\rho)\leftrightarrow(\rho,\mu)\)、P1 的 \(U\leftrightarrow W\) symmetry一致；当 \(\gamma<1\) 时常数随单位变化。若 \(G=\alpha F\), \(\alpha>0\)，则把 resolvent step 同时改为 \(\lambda/\alpha\) 可保持同一个 \((L,\gamma)\) Cayley inequality；若固定 step 不变，则不能忽略参数重新标度。

**原文事实（P3 Thm. 3）。** 对 Otero 参数 \(r_O\in(0,1)\) 及 shift \(s\in(\beta(r_O),\eta(r_O))\)，

\[
\operatorname{Lip}(T+sI)^{-1}
\le
\frac{|1-r_Os|+\sqrt{1-r_O^2}}
{2s-r_O(1+s^2)}. \tag{2.10}
\]

这给 RL\(_1,L>1\) tied slice 的一个既有 inverse-regularity window；onto 仍需 maximality。

## 3. Full-quantifier comparison table

| 对象 | 空间/值型 | 量词与 locality | graph restriction | 精确 inequality | maximality | resolvent / reflected-resolvent 结论 | 与 RL 的严格关系 |
|---|---|---|---|---|---|---|---|
| 用户 RL（原稿文字版） | 实 Hilbert；\(F:H\rightrightarrows H\) | 按当前写法为指定 graph 上所有 pair；若称 local 必须另写 graph set | 原稿尚未系统写成 \(\Gamma\) 与 \(D_\Gamma\) | \(\|a-\lambda b\|\le L\|a+\lambda b\|^\gamma\) | 未定义 | 在 \(D_\Gamma\) 上 \(R\) at-most-single-valued 且 Hölder；不自动 full-domain | 基准对象 |
| P1 Luke–Tam 2025 Def. 2 | Euclidean；set-valued | \(u,v\in U\) 且所有 \(u^+\in F(u)\cap W,v^+\in F(v)\cap W\)：restricted all-pairs | 明确为 \(U\times W\)；Prop. 4 用 \(F_W\) 与 \(D=(I+F_W)(U)\) | \(\langle a,c\rangle\ge-\tau\|a+c\|^2\), \(\tau\ge0\) | 保持同一 restricted inequality 的 graph extension maximality；Zorn extension | Prop. 4 在 \(\tau<1/2\) 时：\(J\) a\(1/2\)-FNE violation \(2\tau\)，\(R\) Lipschitz \(\sqrt{1+4\tau}\) on \(D\) | \(\gamma=1,L\ge1\) 精确等价，参数 (2.4)；\(\gamma<1\) 不是有限常数 \(\tau\) 邻域类 |
| P2 Evens et al. Def. 4.1：pointwise | \(\mathbb R^n\)；set-valued | 固定 base graph point \((x',y')\)，与 gph \(A\) 中所有点比较 | 无显式 \(U,W\)，但可只在一个 graph point成立 | \(\langle x-x',y-y'\rangle\ge\mu\|x-x'\|^2+\rho\|y-y'\|^2\) | pointwise 不谈 maximality | 用于 solution-anchored DRS Assumption III；仍需 full-domain resolvents等 | anchored RL\(_1\) 是 tied \((\theta,\theta)\) slice；all-pairs RL 比 pointwise certificate 强 |
| P2 Evens et al. Def. 4.1：global | \(\mathbb R^n\)；set-valued | 每个 base graph point都成立，即 all-pairs | global graph | 同上 | graph inclusion maximality | Prop. 4.12：admissible step 下 J Lipschitz；J full domain iff maximal | \(A=\lambda F\) 时 RL\(_1\) 精确等价于 \((\theta_L,\theta_L)\)；一般二参数类不等价于 tied slice |
| P3 Otero–Iusem Def. 2 | real Hilbert；point-to-set | global all-pairs | 无 local restriction | \(\langle a,c\rangle\ge-(r_O/2)(\|a\|^2+\|c\|^2)\), \(0<r_O<1\) | graph extension maximality | Thm. 3 给适当 shift 的 inverse Lipschitz；maximality再给 onto | \(\gamma=1,L>1\) 精确等价，换算 (2.3) |
| P4 BMW \(\rho\)-(co)monotonicity | real Hilbert；set-valued | global all-pairs | 无 local restriction | monotone-coordinate：\(\langle a,c\rangle\ge\rho\|a\|^2\)；comonotone-coordinate：\(\ge\rho\|c\|^2\) | graph extension maximality | \(\rho>-1\) 阈值下 maximal comonotonicity ↔ full-domain conically averaged resolvent | 是一坐标切片/充分结构，不等价于 generic RL\(_1\)；更不等价于 RL\(_\gamma\) |
| P4 conically nonexpansive | real Hilbert；single-valued \(T:X\to X\) | global all-pairs | full domain in Cor. 3.10 | \(T=(1-\alpha)I+\alpha N\), \(N\) NE | 经 \(A=T^{-1}-I\) 对应 operator maximality | \(J_A\) 的精确结构；并给 \(R_A\) 的 affine-NE 表示 | 该结构可推出某些 Lipschitz bound，但 generic \(L\)-Lipschitz \(R\) 不必 conically averaged |
| P5 almost NE/averaged Def. 2.3 | Euclidean；set-valued | 固定 base \(y\)，所有 \(x\in D\) 及所有 selections；所有 base 时才升级为全域性质 | 可取任意 \(D,S\) | 固定 quadratic violation \(\varepsilon\) | 未给相应新 maximal extension | Prop. 2.8：J pointwise almost-FNE ↔ R pointwise almost-NE ↔ anchored graph inequality | RL\(_1\) anchored 版本落在其中；RL all-pairs 更强；RL\(_\gamma\) 不由 finite \(\varepsilon\) 邻域条件覆盖 |
| P5 pointwise submonotonicity Def. 2.9 | Euclidean；set-valued | 固定 \(v\) 及所有 \(u\) in a neighborhood；对所有 \(v\in U\) 才为 submonotone on \(U\) | local input neighborhood；无独立 output set \(W\) | \(\langle u-v,z-w\rangle\ge-\tau\|(u+z)-(v+w)\|^2\) | 未定义 | 作为 resolvent almost-FNE 的 graph side | 与 anchored RL\(_1\) 精确同型；量词弱于 all-pairs local RL |
| P5 gauge metric (sub)regularity Def. 2.17 | finite-dimensional \(E,Y\)；set-valued \(\Phi\) | \(x\in U\cap\Lambda,y\in V\)；\(V=\{\bar y\}\) 为 subregularity | relative-to-\(\Lambda\)，U/V 可非邻域 | \(d(x,\Phi^{-1}(y)\cap\Lambda)\le\mu(d(y,\Phi(x)))\) | 不适用 | 作用于 residual \(\Phi=T-I\)，不是直接给 J/R continuity | 与 RL 的 regularity side可组合，但不是 \(\gamma<1\) geometry 的先例 |

## 4. 深度研究卡 P1：Luke–Tam 2025

| 标准节 | 精读结果 |
|---|---|
| 1. Bibliographic position | **原文事实。** 2025-11-21 online，MOOR；13 页官方全文。作者明确说这是 2023 extended abstract 的细化和改进。 |
| 2. Research question | 在不要求 monotonicity、只有 metric subregularity 时，什么弱 graph geometry 可保证局部 PPA 线性收敛？ |
| 3. Background route | maximal monotonicity → FNE resolvent；hypomonotonicity路线；另一条是 metric regularity/strong subregularity 无单调路线。 |
| 4. Unresolved pain point | 普通 metric subregularity 比 strong metric subregularity弱；要恢复“任意合适 selection”收敛，需要额外的 quasi-contractivity geometry。 |
| 5. Core insight | 定义 sum-coordinate submonotonicity，使它与 almost-FNE resolvent / Lipschitz reflected resolvent直接对应，再与 residual error bound组合。 |
| 6. Method overview | restricted graph → resolvent geometry → 把 \(F\) 的 MSR 转给 \(\Phi_\lambda=I-J_{\lambda F}\) → 距离压缩 → selection sequence convergence。 |
| 7. Mechanism logic | Def. 2 提供 \(-\tau\|\Delta(I+F)\|^2\) 下界；Prop. 3 重写能量式；Prop. 4 转成 aFNE；Lemma 1 转 MSR；Thm. 2 拼出收缩率。 |
| 8. Essential formulas/assumptions | Def. 2 见本报告 (2.4)；Prop. 4: \(\tau<1/2\), \(\varepsilon=2\tau<1\), \(\operatorname{Lip}R=\sqrt{1+4\tau}\)。Prop. 5：\(F\) on \(U\) in \(W\) 与 \(F^{-1}\) on \(W\) in \(U\) 保持同一 \(\tau\)（含 maximality）。Thm. 2 的完整假设和率见 §9。 |
| 9. Data/material/benchmark | 纯理论；Examples 1–2 是一维/显式 graph examples，无统计数据。 |
| 10. Experimental design/metrics/baselines | 不适用实验学意义；比较基线为 monotone、hypomonotone、cohypomonotone 与已有 PPA rate。 |
| 11. Evidence-to-claim | Def. 2→Prop. 4 支持“常数 submonotonicity 等价 Lipschitz R”；Assumption 2→Thm. 2 支持“额外 range/self-map/maximality/MSR 条件下局部 R-linear”，不支持“submonotonicity+MSR 无条件足够”。 |
| 12. Conclusion boundary | Euclidean、固定 scaling \(\lambda\)、local branch、restricted graph；不能直接推广到一般 Hilbert、variable \(\lambda_n\)、无 maximality或全体 set-valued selections。 |
| 13. Author-stated limitations | 作者强调非 maximal monotonicity时 PPA 甚至可能不存在；Assumption 2 显式承担 existence/self-map/range/maximality。未把这些条件称为可删技术细节。 |
| 14. Critical assessment | **AI分析。** 它已把 RL\(_1\) 的核心几何和 regularity compensation定理做得很近；RL 必须避免把其 range/locality assumptions静默遗漏。Remark 3 的一个 rate 公式存在明显代数风险，见 §10.2。 |
| 15. Reusable connections | tied map：\(\tau\leftrightarrow L\leftrightarrow\varepsilon\)；Example 2 \(-\sqrt{x}\) 展示 submonotone 但无 finite hypomonotonicity；这对“不是旧 hypo 类”很有用，但仍是 \(\gamma=1\)。 |
| 16. Testable follow-up | 检验 P1 的证明能否在 solution-anchored Hölder Cayley + power/gauge EB 下重建，并精确列出哪些 maximality/range假设仍必需。 |

## 5. 深度研究卡 P2：Evens–Pas–Latafat–Patrinos

| 标准节 | 精读结果 |
|---|---|
| 1. Bibliographic position | **原文事实/外部核验。** arXiv:2305.03605v2 全文；正式发表于 *Mathematical Programming*。 |
| 2. Research question | 无 monotonicity 时，preconditioned PPA 与 DRS 能否在 oblique weak Minty / semimonotone assumptions下收敛？ |
| 3. Background route | PPPA 的 projective halfspace解释；DRS 作为 semidefinite-preconditioned PPPA；monotone/hypo/comonotone现有切片。 |
| 4. Unresolved pain point | 过去常要求 primal、dual 或 primal-dual 至少一个 monotone；作者要覆盖三者皆非 monotone 的区域。 |
| 5. Core insight | 以矩阵-valued oblique weak Minty控制 solution-anchored geometry；引入两参数 \((\mu,\rho)\) semimonotonicity建立可计算 sufficient conditions。 |
| 6. Method overview | 先证 abstract PPPA；建立 DRS–PPPA primal-dual correspondence；开发 semimonotone calculus；将 A/B 参数合成到 primal-dual oblique comonotonicity。 |
| 7. Mechanism logic | pointwise semimonotonicity at primal-dual solutions（Assump. III）足以推出 weak Minty；global maximal semimonotonicity（Assump. IV）则给 full structural route。 |
| 8. Essential formulas/assumptions | Def. 4.1 如比较表；inverse 交换 \((\mu,\rho)\)，缩放 \(\alpha A\) 给 \((\alpha\mu,\alpha^{-1}\rho)\)。Prop. 4.12 的 admissible step 与 J Lipschitz/full-domain；Thm. 5.2 见 §9。 |
| 9. Data/material/benchmark | 纯理论为主；§6 含线性 saddle examples、nonsmooth/nonconvex examples 及数值轨迹，用于展示/检验步长紧性。 |
| 10. Experimental design/metrics/baselines | 通过谱半径得到线性例子的 iff convergence interval，并与 semimonotonicity sufficient range比较；不是大样本实验。 |
| 11. Evidence-to-claim | Def. 4.1 + direct algebra 支持 RL\(_1\) tied slice；Thm. 5.2 只在 Assumptions II/III 或 IV、Table 3 step、relaxation条件下支持 DRS convergence。 |
| 12. Conclusion boundary | 算法框架写在 \(\mathbb R^n\)；pointwise semimonotonicity不是 global all-pairs；full-domain resolvent/outer semicontinuity不可由一个 pointwise inequality自动获得。 |
| 13. Author-stated limitations | 作者明确指出将 A/B 各自参数合成为 combined operator 会引入 looseness；semimonotonicity只是易检验 sufficient condition，而非其最抽象 weak-Minty condition。 |
| 14. Critical assessment | **AI分析。** 这是 RL\(_1\) 最强的“定义重合”先例；也说明算法 novelty不能靠定义。它同时提醒：solution-anchored geometry已经被成熟使用，RL all-pairs若非证明所需可能过强。 |
| 15. Reusable connections | 参数 scaling、inverse、sum/parallel-sum calculus、resolvent admissible step、DRS非单调例子，均可作为 RL nonlinear-gauge calculus 的对照模板。 |
| 16. Testable follow-up | 寻找一个 sharp-Hölder R 的 A/B pair，使 Evens 的任何 finite constant semimonotone certificate或 full-domain step条件不能直接给出同一 rate，而 RL theorem能给出。 |

## 6. 深度研究卡 P3：Otero–Iusem 2010/2011

| 标准节 | 精读结果 |
|---|---|
| 1. Bibliographic position | **原文事实。** 2010 IMPA report；2011 *Computational & Applied Mathematics* 30(1):5–17 正式发表；两个版本是同一工作。 |
| 2. Research question | 构造对 graph inverse 对称的 hypomonotonicity relaxation，并恢复适当 shift 下的 regularity/surjectivity。 |
| 3. Background route | monotone、hypomonotone、premonotone；指出 hypomonotonicity对 inverse 不对称。 |
| 4. Unresolved pain point | 很弱的非单调 operator 的 \(T+\lambda I\) 可能不 monotone；何时 inverse仍 point-to-point/Lipschitz，maximal时何时 onto？ |
| 5. Core insight | 用 \(-r_O(\|a\|^2+\|c\|^2)/2\) 对称地同时控制 input/output差；再通过线性 graph transform化到 monotone operator。 |
| 6. Method overview | 基础 calculus → 一维 slope characterization/example → graph linear transform → Minty → shift regularity window。 |
| 7. Mechanism logic | Thm. 2: \(T\) r-semimonotone iff \((T+\beta I)^{-1}+\gamma I\) monotone；maximality也等价；随后由 Minty得到 onto。 |
| 8. Essential formulas/assumptions | \(r_O\in(0,1)\)；\(\beta=(1-\sqrt{1-r_O^2})/r_O\), \(\gamma=r_O/(2\sqrt{1-r_O^2})\), \(\eta=(1+\sqrt{1-r_O^2})/r_O\)。Thm. 3: \((T+\lambda I)^{-1}\) 在 \(\lambda\in(\beta,\eta)\) Lipschitz；maximal性再给 onto。 |
| 9. Data/material/benchmark | 纯理论；Example 1 为显式 decreasing cubic，可 r-semimonotone但对所有 \(\lambda\ge0\) 非 hypomonotone。 |
| 10. Experimental design/metrics/baselines | 无数值实验；以谱区间和一维斜率作为可验证 benchmark。 |
| 11. Evidence-to-claim | Def. 2 直接支持 RL\(_1,L>1\) 精确换算 (2.3)；Thm. 3 支持适当 shift inverse Lipschitz，但不是 PPA convergence theorem。 |
| 12. Conclusion boundary | global all-pairs Hilbert-space理论；参数只取 \((0,1)\)，因为 \(r_O\ge1\) 时任意 operator 都满足，失去区分力。surjectivity需要 maximality。 |
| 13. Author-stated limitations | 作者明确区分必要的 inverse-Lipschitz条件与充分的 expansivity条件，并未声称二者等价于一个算法收敛理论。 |
| 14. Critical assessment | **AI分析。** 这篇论文足以直接否定“RL\(_1,L>1\) symmetric graph inequality 是新定义”。但它也不覆盖 \(t^{2\gamma}\) 非齐次 defect。 |
| 15. Reusable connections | inverse symmetry、自伴线性谱 gap、maximal extension后的 regularity window；可用于构造 RL gap examples 与检查 nonlinear transform是否可能。 |
| 16. Testable follow-up | 尝试把 Otero 的线性 graph transform推广到非二次 modulus；若不存在固定线性 transform，应明确证明 obstruction，而不是只换术语。 |

## 7. 深度研究卡 P4：Bauschke–Moursi–Wang

| 标准节 | 精读结果 |
|---|---|
| 1. Bibliographic position | **原文事实。** 2019 arXiv 全文，后正式发表于 *Mathematical Programming*，DOI 10.1007/s10107-020-01500-6。 |
| 2. Research question | maximal monotonicity ↔ FNE resolvent 的经典 correspondence 能否扩展到 signed mono/comonotonicity 与 averaged/conical resolvents？ |
| 3. Background route | \(\rho\)-monotone/comonotone、Minty、averaged mapping、proximal mappings。 |
| 4. Unresolved pain point | ordinary averaged resolvents覆盖不到某些 hypoconvex/nonmonotone operators；需要允许 averaging parameter \(\alpha>1\)。 |
| 5. Core insight | 定义 \(\alpha\)-conically nonexpansive：\(T=(1-\alpha)I+\alpha N\)，\(N\) nonexpansive；它精确对应 signed comonotonicity。 |
| 6. Method overview | inverse-shift monotone characterization → generalized Minty/full-domain → conical averagedness ↔ comonotonicity → J/R关系 → hypoconvex applications。 |
| 7. Mechanism logic | \(A\) \(\rho\)-comonotone iff \(A^{-1}-\rho I\) monotone；当 \(\rho>-1\) 且 maximal时，J full-domain；\(\rho=1/(2\alpha)-1\)。 |
| 8. Essential formulas/assumptions | Def. 2.3 为单坐标二次下界；Def. 3.1 为 affine-NE decomposition；Cor. 3.10/Prop. 3.13 给精确 correspondence。 |
| 9. Data/material/benchmark | 纯理论；linear operators、subspaces 和 hypoconvex functions提供显式 examples。 |
| 10. Experimental design/metrics/baselines | 无数值实验；以 parameter thresholds \(\rho=-1,-1/2,0\) 及 sharp examples核验。 |
| 11. Evidence-to-claim | Cor. 3.10 支持“conical J 是 comonotonicity 的精确 counterpart”；它不支持“任意 Lipschitz R 都 conically averaged”。 |
| 12. Conclusion boundary | global real Hilbert；full-domain必须结合 maximality和 \(\rho>-1\)；阈值外可失去 single-valuedness/surjectivity。 |
| 13. Author-stated limitations | 论文用 Example 2.14 明示 \(\rho>-1\) 对 full-domain/single-valuedness是关键阈值。 |
| 14. Critical assessment | **AI分析。** BMW 是 RL 的重要邻居但不是 exact synonym。取 \(R=L I,L>1\)：它是 RL\(_1\)，而对任意 \(\alpha>0\)，由 \(R=(1-2\alpha)I+2\alpha N\) 得 \(N=[1+(L-1)/(2\alpha)]I\)，不 nonexpansive；所以 generic Lipschitz R 不必 conically averaged。 |
| 15. Reusable connections | maximality/full-domain模板、inverse shift、conical decomposition、signed parameter thresholds；可作为 RL 最大扩张理论的最低对照。 |
| 16. Testable follow-up | 判断 sharp-Hölder R 是否存在 nonlinear affine/nonexpansive decomposition的合理替代，并证明其 full-domain或最大扩张条件；若只能重述 Hölder continuity，则结构贡献不足。 |

## 8. 深度研究卡 P5：Luke–Thao–Tam 2018

| 标准节 | 精读结果 |
|---|---|
| 1. Bibliographic position | **原文事实/外部核验。** arXiv 2016/2017 全文；MOOR 43(4):1143–1176 (2018)，DOI 10.1287/moor.2017.0898。 |
| 2. Research question | expansive、set-valued fixed-point mappings 的 Picard iteration怎样通过 local geometry + inverse stability获得定量收敛？ |
| 3. Background route | averaged mapping + fixed points；metric subregularity/error bounds；非凸投影、forward–backward、Douglas–Rachford。 |
| 4. Unresolved pain point | 一旦放松 nonexpansivity，Fejér monotonicity丢失；需要 inverse stability补偿 geometry violation。 |
| 5. Core insight | 将 pointwise almost averagedness 与 residual 的 gauge metric regularity/subregularity分离，再以明确兼容不等式组合。 |
| 6. Method overview | 构造 almost averaged calculus → abstract annular convergence theorem → gauge MSR → 多算法实例。 |
| 7. Mechanism logic | geometry给下降中的负 residual 项；MSR用 residual下界控制 distance；二者系数相减得到 \(c_i<1\)。 |
| 8. Essential formulas/assumptions | Def. 2.3、Prop. 2.8、Def. 2.9 见比较表；Def. 2.17 见 §0；Thm. 2.18/Cor. 2.19 的 \(c_i\) 与兼容条件见 §9。 |
| 9. Data/material/benchmark | 理论 + 算法案例：相切圆/线、非凸 cyclic projections、phase retrieval、forward–backward、Douglas–Rachford。 |
| 10. Experimental design/metrics/baselines | 主要是解析 examples；用 annuli 上的 \(\varepsilon_i,\alpha_i,\kappa_i\) 解释 linear-on-annulus / global sublinear behavior。 |
| 11. Evidence-to-claim | Def. 2.17 明确支持 nonlinear/Hölder regularity gauge；Prop. 2.8只支持 constant quadratic geometry violation；全文不提供 RL\(_\gamma\) 的 exact Hölder Cayley graph formula。 |
| 12. Conclusion boundary | finite-dimensional；pointwise at selected base set \(S\)；residual是 \(\Phi=T-I\)；gauge条件在 regions/annuli上且还要求 ratio被线性常数控制。 |
| 13. Author-stated limitations | 作者明确说明其术语“metric subregularity on a set”可让 U 非邻域，因而不完全等同传统定义；也把仅 calm selection theory留作未来方向。 |
| 14. Critical assessment | **AI分析。** 这是“monotonicity–regularity compensation”思想上最强的既有先例。RL若声称首次提出广义跷跷板会过度；剩余只能是特定 Hölder Cayley geometry、特定 composition exponent与相应 sharp theorem。 |
| 15. Reusable connections | anchored vs all-pairs量词、all-selections要求、annular localization、gauge EB、算法复合 calculus，都是 RL 证明应继承的严谨框架。 |
| 16. Testable follow-up | 把 RL power theorem写成 P5 式的 modulus–gauge compatibility theorem，并证明 power case的 \(\gamma q\) 是 sharp specialization，而非符号代入。 |

## 9. 算法定理的完整假设矩阵

| 来源/定理 | geometry hypothesis | regularity hypothesis | existence/domain hypothesis | algorithm parameters | 结论 | RL 不得省略的差异 |
|---|---|---|---|---|---|---|
| P1 Assumption 2 + Thm. 2 | 对每个 zero 附近，\(\lambda F\) 在 \(U\) in \(W\) maximal submonotone violation \(\tau\)；且 \(U'\subset(I+\lambda F_W)(U)\) | 每个 zero 附近 \(F\) 对 0 relative to \(D\) MSR，常数 \(\rho\)；\(\tau(1+\rho/\lambda)^2<1/2\) | \(\operatorname{zer}F\cap D\ne\varnothing\) closed；\(J_{\lambda F}:D\rightrightarrows D\)；local branch set nonempty | 固定 \(\lambda>0\)；选择 \(x_{n+1}\in J_{\lambda F}(x_n)\cap B_\delta(\bar x)\) | 任意这种 local selection R-linear；证明中取 \(\bar\rho>\rho\) 仍满足 compatibility，\(\kappa=\sqrt{1+2\tau-(\lambda/(\lambda+\bar\rho))^2}<1\) | RL graph inequality alone不提供 branch、self-map、range covering、maximality或闭性 |
| P2 Thm. 2.4 / 2.13 (PPPA) | oblique weak Minty at nonempty solution subset；linear rate另加结构 | Thm. 2.13 加 metric subregularity | outer semicontinuity；preconditioned resolvent full domain；PSD preconditioner等 | relaxation满足相应 positive interval / lower-bound | global/asymptotic PPPA；MSR下 local linear | 不是仅 semimonotonicity；是 solution-anchored projective framework |
| P2 Assump. III/IV + Thm. 5.2 (DRS) | III：A/B 在每个 primal-dual solution graph point分别 pointwise semimonotone；参数 sums与 negative parallel-product条件；或 IV：A/B maximally semimonotone | 不以 MSR作为主 convergence假设；rate另来自 abstract theorem/stronger情形 | Assumption II 路线要求 outer semicontinuity与 full-domain resolvents；IV路线以 maximality提供结构；zer非空 | \(\gamma\) 按 Table 3；\(\lambda_k\in(0,2\alpha)\)，且 \(\liminf\lambda_k(2\alpha-\lambda_k)>0\) | 继承 Thm. 3.3 convergence；额外 uniform条件给 estimates | 证明所需 geometry可只是 solution-anchored；all-pairs RL可能过强 |
| P3 Thms. 2–3 | global symmetric \(r_O\)-semimonotonicity | 无 error bound | inverse Lipschitz只需 semimonotonicity且在 range上；onto需 maximality | shift \(\lambda\in(\beta(r_O),\eta(r_O))\) | \((T+\lambda I)^{-1}\) Lipschitz/point-to-point；maximal时 onto | **没有 PPA convergence theorem**，不能把 inverse regularity自动当迭代收敛 |
| P4 Cor. 3.10 / Prop. 3.13 | \(\rho\)-comonotonicity ↔ conically averaged J | 无 error bound | full-domain correspondence需 maximality和 \(\rho>-1\) | conical \(\alpha=1/[2(\rho+1)]\) | 结构 characterization | **没有 RL-style MSR+PPA rate theorem** |
| P5 Thm. 2.18 / Cor. 2.19 | T 在 base set/fixed points pointwise almost averaged，annulus \(i\) 上参数 \(\alpha_i,\varepsilon_i\) | residual \(\Phi=T-I\) 在 annuli gauge MR/MSR；ratio constant \(\kappa_i<\sqrt{(1-\alpha_i)/(\varepsilon_i\alpha_i)}\) | \(T:\Lambda\rightrightarrows\Lambda\)，Fix closed/nonempty；region/selection assumptions | Picard selections；regions \(R_i\) | \(c_i=\sqrt{1+\varepsilon_i-(1-\alpha_i)/(\kappa_i^2\alpha_i)}<1\)；可解释 sublinear | 不能把 \(F\) 的 MSR未经桥接直接当 \(I-J\) 的 MSR；gauge在 regularity side不等于 Hölder R |
| RL 初稿拟议 PPA theorem | all-pairs或未完全锚定的 RL\(_\gamma\) | \(d(x,S)\le\rho d(0,F(x))^q\) 或 gauge | 当前需补：local branch existence、range/self-map/invariance、closed S、selection quantifier | 固定 \(\lambda\) 的推导较清楚；variable step未统一 | 拟议 \(\gamma q>1\) superlinear，\(=1\) contraction | 当前只能视为待修定理，不能拿递推草式替代完整 hypotheses |

## 10. 漏洞、文本风险与假设风险

### 10.1 对 RL 初稿的高优先级数学风险

1. **Graph restriction 未闭合。** “RL 在某邻域成立”究竟是 \(u,v\) 近 solution、Cayley inputs \(u+\lambda u^*\) 近 solution，还是 restricted outputs \(u^*,v^*\in W\)？三者不等价。
2. **存在性与唯一性混淆。** RL 能证明给定 Cayley input 在 restricted graph 上至多一个 pair；它不能证明附近每个 input 都存在 resolvent branch。
3. **All-pairs 与 anchored 不分。** PPA distance proof通常只把当前 graph point与 \((s,0)\) 比较。若证明只需要 anchored RL，应弱化定义或明确 all-pairs版本是为 calculus/continuity另设的强版本。
4. **局部不变性缺失。** 要在下一步继续调用 local RL 和 local MSR，必须证明 \(x_n\)、\(x_{n+1}\) 及相应 graph pair都留在声明区域。
5. **MSR 评价点错位。** PPA 给 \((x-x^+)/\lambda\in F(x^+)\)；power MSR必须在 \(x^+\) 处合法，而不是只知 \(x\) 在邻域。
6. **Set-valued selection 量词。** “存在一条收敛 selection”与“任何 local selection 收敛”不同；P1 专门为后者增加了 maximality/range/branch assumptions。
7. **Closedness/projector。** 使用 \(d(x,S)\) 的投影或选取最近点时，要声明有限维/闭集或改用近似投影。
8. **\(q>1\) 极强且 convention 易混。** 文献中的 Hölder metric regularity常写 exponent \(\omega<1\)；初稿 power subregularity允许 \(q>1\)。必须给自然 sharp examples并固定命名，避免把“higher-order”与通常 Hölder order混写。
9. **\(\gamma q\) 不是普遍 law。** 它来自特定链式估计：Cayley Hölder residual bound再代入 power EB。换 residual、锚点、gauge、算法或有 cancellation 时指数会变。
10. **临界区常数。** \(\gamma q=1\) 时必须给出真正小于 1 的完整系数；只写 exponent等于 1 不保证 contraction。\(\gamma q<1\) 的局部递推 \(r_{n+1}\le Cr_n^p,p<1\) 本身也不推出趋零。
11. **量纲/缩放。** \(\gamma<1\) 时 \(L\) 的单位是 length\(^{1-\gamma}\)；跨缩放比较 \(L\) 数值没有不变量意义。对 \(F^{-1}\)、\(\lambda\)、变量归一化要显式换算。
12. **“AFNE”命名风险。** 若其唯一定义是 RL-IP 的平行四边形重写，不应宣传成独立性质；最好直接叫 Hölder reflected-resolvent geometry，并将 graph形式作为等价 characterization。

### 10.2 P1 正式论文中的一个可复核文本风险

**原文事实。** P1 Remark 3, equation (31) 把 Leventhal 型距离收缩率印为

\[
r_{\rm print}=\frac{\lambda}{\sqrt{\lambda^2+\rho^2}},
\]

其中同文 \(\rho\) 是 metric-subregularity modulus。

**AI分析/反例检查。** 取 \(F(x)=x/\rho\) 于 \(\mathbb R\)。其最优 MSR modulus 为 \(\rho\)，且

\[
J_{\lambda F}x=\frac{\rho}{\rho+\lambda}x.
\]

当 \(\lambda/\rho\downarrow0\) 时，真实 contraction趋近 1，而 \(r_{\rm print}\to0\)，所以印刷式不可能作为一般上界。经典形状应交换分子角色，即 \(\rho/\sqrt{\lambda^2+\rho^2}\)。这应写成“公式/记号疑似笔误并有直接反例”，而不是据此否定 P1 的主定理；P1 Thm. 2 用的是另一条较弱桥接率。

### 10.3 文献间常见误读风险

- P1 Prop. 4 的 \(\tau<1/2\) 是正式命题/violation convention 的一部分；纯代数可写更大 \(\tau\) 不等于 published theorem外推。
- P2 的 pointwise semimonotonicity与 global maximal semimonotonicity是两条不同 DRS 路线；不能只抄 inequality而删 Assumptions II–IV。
- P3 的 maximality只在需要 onto时进入；semimonotonicity单独最多给 appropriate shift inverse 的 at-most-single-valued/Lipschitz on range。
- P4 的 conically averaged \(J\) 是 affine-nonexpansive structure，不是“R 有某个 Lipschitz常数”的同义词。
- P5 的 gauge作用于 residual inverse stability；geometry仍是 fixed quadratic violation。把两个 gauge混成一个“nonlinear semimonotonicity”是错误归因。

## 11. Claim-safe novelty residue

| 候选表述 | 本轮判定 | 可安全写法 | 何种证据会推翻/削弱 |
|---|---|---|---|
| “RL \(\gamma=1\) 是新 generalized monotonicity” | **已被精确先例否定** | 不作新定义声明；写成 Otero/Evens/Luke–Tam tied slice 并给参数换算 | 已有全文公式已足够，无需更多反例 |
| “RL \(\gamma<1\) 的 exact graph inequality 未见于最近邻文献” | **五篇全文内成立** | “在本报告核对的五篇全文中未发现精确形式” | 任何更早/同期开源全文出现 \(t^{2\gamma}\) defect、Hölder Cayley或等价 nonlinear graph gauge |
| “Hölder reflected resolvent 定义本身新颖且重要” | **证据不足/定义级偏弱** | 它首先就是 Cayley map 的 ordinary Hölder continuity；重要性须由结构定理证明 | Hölder-map 文献、metric-space fixed point文献或简单坐标重写即可进一步削弱定义 novelty |
| “RL-AFNE 是独立新性质” | **不成立** | 作为 RL 的等价 inner-product characterization | 平行四边形恒等式已经完全解释 |
| “\(\gamma q\) 是普遍 monotonicity–regularity law” | **不成立/目前仅机制线索** | “在特定 PPA residual bound + power EB 的 composition中出现” | 不同 residual/gauge/cancellation产生不同 exponent 即可否定普遍性 |
| “genuinely Hölder Cayley + power/gauge EB 可给新 PPA theorem” | **可能的 theorem-level residue** | 完整补齐 branch/range/invariance/selection assumptions后，再称为相对于五篇最近邻的定理差异 | 若 P5 抽象定理经直接一行 substitution已无额外困难且结论相同，贡献会显著变小 |
| “RL 建立新的统一跷跷板理论” | **目前不可写** | 只说它提供一个可检验的非齐次 phase point | 大量 cross-gap examples未完成，且 P5 已有 broad compensation paradigm |

### 11.1 定义重命名还是新理论：判别门槛

**AI分析。** 至少满足下列三项中的两项，RL\(_{\gamma<1}\) 才开始越过“定义重命名”门槛：

1. **结构门槛**：有非平凡的 inverse/scaling/composition/sum/maximal-extension/full-domain calculus，而不仅是把 Hölder R 拉回 graph。
2. **算法门槛**：有 rigorously repaired theorem，其合法对象不被 finite-violation almost averaged/semimonotone结果直接覆盖，并对所有声明 selections成立。
3. **模型门槛**：有自然 operator class（而非为定理反向设计的 Cayley map）给出 sharp \(\gamma<1\)；同时 q/gauge regularity可精确计算，rate达到或证伪 \(\gamma q\) prediction。

当前初稿具备一个明确算法想法，但尚未稳定通过第 2、3 门槛；第 1 门槛基本未建立。

## 12. 可检验研究想法（不宣称新颖）

### Idea A：以一般 modulus \(\omega\) 替代 power RL

- **未解决问题**：power \(Lt^\gamma\) 是否只是更自然 modulus theory 的一个例子？
- **与来源差异**：P1/P5 geometry 使用常数 quadratic violation；这里直接假设 \(\|Rx-Ry\|\le\omega(\|x-y\|)\)。
- **所需证据**：graph等价式、inverse/scaling rules、branch existence条件、与 EB gauge \(\psi\) 的精确递推。
- **可证伪结果**：若全部结论只是对任意 continuity modulus 的一行三角不等式，且无 sharpness/calculus，则不足以构成独立理论。
- **MVP**：一条无漏洞 anchored theorem + 两个 sharp nonlinear examples。
- **主要风险**：过度一般化后只剩形式 composition。

### Idea B：证明 \(\gamma q\) 三相的 sharpness，而不是只给 sufficient rate

- **未解决问题**：\(\gamma q>1,=1,<1\) 是否真正分相？
- **与来源差异**：P1/P5 的主 rate是 constant-violation + linear residual EB；这里允许两侧幂次退化。
- **所需证据**：同一自然 family 中精确 Cayley exponent \(\gamma\)、精确 EB exponent \(q\)、PPA orbit闭式或上下界。
- **可证伪结果**：若更精确计算显示主导项 cancellation，真实 order不是 \(\gamma q\)，则“law”失败但会形成有价值反例。
- **MVP**：一维三个参数区的显式 family，每区至少一个正例和一个失败机制。
- **主要风险**：为匹配 exponent 人工构造对象，缺乏数学自然性。

### Idea C：anchored RL 与 all-pairs RL 分层

- **未解决问题**：PPA theorem究竟需要哪一层量词？
- **与来源差异**：P2/P5 已成熟使用 solution-anchored geometry；用户 RL 当前更像 all-pairs Hölder continuity。
- **所需证据**：逐行 proof dependency audit；构造 anchored 成立但 all-pairs失败的对象；分别给算法和 calculus用途。
- **可证伪结果**：若 all-pairs在关键 existence/invariance步骤不可替代，则不能轻率弱化。
- **MVP**：定义 `RL-at-S` 与 `pairwise-RL-on-Γ`，给严格包含反例和一条只用前者的定理。
- **主要风险**：概念数量膨胀，反而削弱主线。

### Idea D：nonlinear maximal extension / range theorem

- **未解决问题**：Hölder Cayley graph class有无类似 P1 Zorn extension、P3/P4 monotone transform与 full-domain判据？
- **与来源差异**：固定 quadratic classes可通过线性 graph transform或 pairwise inequality保持；\(t^{2\gamma}\) 非齐次且非锥性。
- **所需证据**：chain union是否保持 class；maximal graph是否给任何闭值/range性质；必要时给 obstruction。
- **可证伪结果**：存在 maximal RL graph但 Cayley range仍有孔洞或非局部满射。
- **MVP**：先完成一维 classification，再判定高维 extension。
- **主要风险**：maximality只给集合论扩张，不给有用的 algorithmic existence。

## 13. 本轮总体证据结论

- **VERIFIED_SOURCE**：P1、P2、P3、P4、P5 均为 full-text 深读；没有使用 abstract-only 来断言公式等价。
- **VERIFIED_USER_MATERIAL**：RL 初稿的定义、内积形式、PPA residual/power-EB思路均已读取。
- **AI_INFERENCE**：\(\gamma=1\) 的三套参数换算、\(\gamma<1\) 的 scale-dependent violation、BMW 的 \(R=LI\) separation example，以及 P1 Remark 3 的 scalar countercheck。
- **UNRESOLVED**：五篇之外是否已有 exact nonlinear gauge semimonotonicity/Hölder Cayley；RL theorem修复后是否超出 P5 abstract framework；自然 sharp examples是否存在。
- **NOT CLAIMED**：全局新颖性、统一 seesaw theorem、期刊级别或录用概率。

## 14. Expert-result contract

```yaml
contract_version: "1.0"
expert_skill: "sci-skills-paper-deep-reading"
project_id: "monotonicity-regularity-seesaw-2026-09"
paper_family: "T"
stage_id: "T2"
task_id: "T2-NOV-DEEP"
task_status: "COMPLETE"
inputs_reviewed:
  - "用户上传 RL_Submonotonicity初稿.md（全文）"
  - "Luke & Tam 2025 official full text, DOI 10.1287/moor.2025.0863"
  - "Evens et al. arXiv:2305.03605v2 full text and official journal metadata"
  - "Gárciga Otero & Iusem 2011 SciELO full text and 2010 IMPA report"
  - "Bauschke, Moursi & Wang arXiv:1902.09827 full text and DOI metadata"
  - "Luke, Thao & Tam arXiv:1605.05725 full text and official publisher metadata"
outputs:
  - "work/rl_nearest_deepread.md"
evidence_status:
  - "VERIFIED_SOURCE: five nearest-neighbor primary works reviewed at full-text depth"
  - "VERIFIED_USER_MATERIAL: RL draft reviewed in full"
  - "AI_INFERENCE: exact parameter conversions and counterexample checks explicitly labeled"
  - "UNRESOLVED: no global novelty conclusion beyond the bounded five-paper corpus"
assumptions:
  - "RL is interpreted over real Hilbert geometry and over an explicitly declared graph region"
  - "All formula comparisons use A=lambda F when matching papers normalized at unit resolvent step"
  - "Otero 2010 report and 2011 publication are versions of one work, not independent novelty hits"
author_input_needed:
  - "Decide whether the intended primary geometry is solution-anchored RL or all-pairs RL"
  - "Provide/approve the natural genuinely gamma<1 model class to be used for sharpness tests"
manual_actions: []
quality_checks:
  - "Full-text access depth and theorem/definition locators recorded for every source"
  - "Pointwise, all-pairs, local, restricted-graph, maximal, and full-domain quantifiers separated"
  - "gamma=1 parameter maps rederived directly from the graph inequality"
  - "gamma<1 defect asymptotics checked at pair scale t down to zero"
  - "Algorithm claims audited against their complete assumption blocks"
  - "No journal-tier conclusion and no stage transition made"
conflicts: []
conflict_resolution_status: "NOT_REQUIRED"
merge_permission: "orchestrator_only"
stage_acceptance_recommendation: "REPAIR"
recommended_next_action: "把 RL 主定理改写为明确的 solution-anchored、restricted-range 定理，逐项补齐 branch existence、self-map/invariance、closed-zero-set 与 all-selections 量词后，再用一个 sharp gamma<1 自然例子检验 gamma*q 递推。"
```
