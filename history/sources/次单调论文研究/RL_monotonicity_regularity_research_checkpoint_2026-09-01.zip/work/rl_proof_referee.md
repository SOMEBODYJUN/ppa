# RL draft: proof-referee audit

> Scope.  This is a proof and quantifier audit of
> `upload/01-RL_Submonotonicity-.md`, checked against
> `research/example_properties.md` and `work/root_math_audit.md`.  It makes
> no literature or novelty claim.

## 1. Referee verdict

The algebraic core is sound:

1. (RL) and (RL-IP) are exactly equivalent.
2. On the natural Minty domain, all-pairs (RL) is exactly the stated
   firm-type inequality for the resolvent relation.
3. Once a legitimate resolvent step exists and all local hypotheses apply
   to that step and to the relevant zeros, Lemmas 2--5 give the printed
   one-step estimates.
4. The scalar recursion used in Theorems 1--3 does imply summability of the
   steps and point convergence under an explicit invariant localization.

The current document is nevertheless **not submission-ready**.  Theorem
1--3 are not complete mathematical statements: local graph quantifiers,
local resolvent coverage, the selected branch, invariant radii, and the
mechanism putting the Cauchy limit in the zero set are left in an informal
paragraph.  These omissions are submission-blocking, because (RL) alone
does not imply that the resolvent is defined on a neighborhood, and local
(RL) does not make the full resolvent single-valued when remote branches are
present.

This is a repairable theorem-package gap rather than evidence that the
underlying recurrence is false.

### Severity convention

- **FATAL-AS-STATED**: the printed assertion is undefined, can fail, or is
  not implied by its displayed assumptions.  It blocks submission.
- **REPAIRABLE**: the intended assertion is correct after explicit local
  assumptions or a claim-strength correction.
- **STYLISTIC**: terminology or presentation does not affect validity.

## 2. Definitions

### Definition 1: RL-\((\lambda,L,\gamma)\)

**Algebra: PASS.**  Squaring (RL) and using

\[
\|a-\lambda b\|^2=\|a+\lambda b\|^2-4\lambda\langle a,b\rangle
\]

gives (RL-IP) exactly, with no loss.

**Quantifiers: PASS globally; REPAIRABLE locally.**  The global definition
has an unambiguous all-pairs quantifier on \(\operatorname{gph}F\).  The
later phrase “local RL” needs a separate definition.  It must specify a
graph localization

\[
G\subset \operatorname{gph}F
\]

and require the inequality for **every two points of \(G\)**.  A
base-variable restriction, a graph/output-attentive restriction, a
solution-anchored inequality, and an estimate for one selected resolvent
branch are different hypotheses and cannot share the same label.

**Minty injectivity: omitted but essential.**  Let

\[
M_\lambda(u,u^*)=u+\lambda u^*.
\]

If two points of an RL graph have the same Minty input, then
\(a+\lambda b=0\), so RL gives \(a-\lambda b=0\); hence \(a=b=0\).
Thus \(M_\lambda\) is injective on the RL graph.  Consequently:

- global RL makes \(J_{\lambda F}\) single-valued on
  \(\operatorname{ran}(I+\lambda F)\);
- RL on \(G\) makes only the restricted inverse \(J_G\) single-valued on
  \(M_\lambda(G)\);
- neither statement gives surjectivity or even an input neighborhood in
  the Minty range.

Severity: **FATAL-AS-STATED for the later PPA use**, although the definition
itself is valid.

### Definition 2: additive firm nonexpansiveness

**Formula: PASS for coupled selections.**  For \(u\in Jx\), \(v\in Jy\),
the two terms must be coupled as

\[
\|u-v\|^2+\|(x-u)-(y-v)\|^2.
\]

Writing \(Jx\) and \((I-J)x\) without naming the same selection is
ambiguous for a relation.

**“Selection-wise” requires correction.**  If (AFNE) is required for all
coupled selections, then putting \(x=y\) gives

\[
2\|u-v\|^2\le0,
\]

so the relation is already single-valued on its domain.  If instead it
means that there exists a favorable selection, it is not equivalent to
all-graph RL.  The definition should therefore say:

> For all \(x,y\) in a printed domain \(D\), and all coupled
> \(u\in Jx,v\in Jy\), (AFNE) holds.  This condition itself implies that
> \(J\) is a map on \(D\).

Severity: **REPAIRABLE**, but it affects Lemma 1 and the branch language.

### Definition 3: power metric subregularity

**Convention: internally consistent.**  The power is on the residual:

\[
d(u,S)\le \rho\,d(0,F(u))^q.
\]

With this convention \(q>1\) is a stronger-than-linear local error bound
along residual sequences tending to zero.  No exponent from a convention
that puts a power on the left-hand side may be imported without inversion.

**Missing data.**  The definition should print:

- the reference \((\bar x,0)\in\operatorname{gph}F\);
- a neighborhood \(U\) in which the inequality holds;
- whether \(S=F^{-1}(0)\) is global or localized;
- a fixed finite uniform constant \(\rho\);
- the convention \(d(0,\varnothing)=+\infty\).

The last convention reveals a real issue: the error bound can hold
vacuously where \(F(u)=\varnothing\).  It therefore cannot supply
resolvent existence.

Severity: **REPAIRABLE as a definition; FATAL-AS-STATED when used as a
surrogate for PPA existence.**

### Definition 4: gauge subregularity

Require \(\psi:[0,\epsilon)\to[0,+\infty)\) to be finite,
nondecreasing, with \(\psi(0)=0\).  Monotonicity is what justifies

\[
\psi(d(0,F(x^+)))\le
\psi\!\left((r+Lr^\gamma)/(2\lambda)\right).
\]

Right continuity is not needed for the displayed recurrence if (GC) is
assumed directly.  If later arguments replace \(\psi\) by asymptotic
equivalents, either right continuity or a monotone/right envelope should be
specified.

Severity: **REPAIRABLE**.

## 3. Lemmas

### Lemma 1: RL \(\Longleftrightarrow\) AFNE

**Global natural-domain version: PASS.**  The exact statement is:

> Let \(D=\operatorname{ran}(I+\lambda F)\), view
> \(J=(I+\lambda F)^{-1}\) as a relation on \(D\), and quantify over all
> coupled selections.  Then all-graph RL is equivalent to AFNE on \(D\).
> Either condition makes \(J\) single-valued on \(D\).

**Local version: incomplete.**  For a graph localization \(G\), the
equivalence is between RL on \(G\) and AFNE for the restricted inverse on
\(M_\lambda(G)\).  It is not automatically a statement about the full
\(J_{\lambda F}\), because a graph point outside \(G\) may share the same
Minty input.

**Existence is not part of the equivalence.**  No displayed assumption
shows \(D=H\), or that \(D\) contains a ball around a solution.

Severity: **FATAL-AS-STATED for the theorem pipeline; PASS after the domain
and restricted-graph corrections.**

### Lemma 2: energy estimate

**Algebra: PASS.**  For every admissible \(p\in S\), AFNE gives

\[
\|x^+-p\|^2+\|x-x^+\|^2
\le \tfrac12\big(\|x-p\|^2+L^2\|x-p\|^{2\gamma}\big).
\]

Taking the infimum is legitimate because the right-hand scalar function is
increasing.  No projection onto \(S\) is required; an
\(\varepsilon\)-minimizing sequence suffices.

**Local qualifier: missing.**  Every near-minimizing \((p,0)\) used in the
infimum and the step graph point
\((x^+,(x-x^+)/\lambda)\) must lie in the same RL localization.  A
two-radius argument can ensure this, but it must be stated and proved.

Severity: **PASS globally; REPAIRABLE locally.**

### Lemma 3: step bound

**Algebra: PASS.**  The identity

\[
2(x-x^+)=(x-p)-\big((x^+-p)-(x-x^+)\big)
\]

and anchored RL give the factor \(1/2\).  Infimizing over \(p\) is valid.

The conclusion should read “a uniform upper bound” and
\(O(r^\gamma)\) as \(r\downarrow0\) within the valid window.  It is not an
exact asymptotic and its constant has not been shown optimal after also
using subregularity.

Severity: **PASS with local-quantifier repair.**

### Lemma 4: residual bound

**PASS**, provided the step exists.  Since
\((x-x^+)/\lambda\in F(x^+)\), the residual inequality is immediate.
It gives no existence or branch control in the reverse direction.

### Lemma 5: distance recurrence

**Algebra: PASS**, provided:

1. \(x^+\) lies in the neighborhood where the error bound holds;
2. the same solution set is used in the step estimate and the error bound;
3. \(q>0\), so raising the residual upper bound to \(q\) preserves order.

The statement

\[
d(x^+,S)=O(r^{\gamma q})
\]

is only an upper estimate.  It neither asserts nor proves an exact order.

Severity: **PASS as a conditional one-step lemma; REPAIRABLE statement.**

## 4. Theorems 1--3

### Common fatal gaps

#### 4.1 Resolvent existence

RL gives injectivity of the Minty parametrization, not surjectivity.  The
PPA may be undefined for points arbitrarily close to \(S\).

`GX-074` is an explicit warning: for
\(\operatorname{gph}F=K\times\{0\}\),
\(K=\{0\}\cup\{1/k:k\ge1\}\), the resolvent domain is only \(K\).
On a bounded local graph, subunit RL estimates are available, and the
fixed-target error bound outside the domain is vacuous under
\(d(0,\varnothing)=+\infty\); nevertheless PPA cannot start from a generic
nearby point.

Required repair: exhibit a graph localization \(G\) whose Minty image
contains an input ball, or assume a specified local resolvent map is
defined on that ball.

#### 4.2 Full relation versus local branch

RL on \(G\) makes the restricted resolvent \(J_G\) single-valued.  It does
not stop the full relation from having remote selections.  Thus

\[
x^{k+1}\in J_{\lambda F}(x^k)
\]

cannot mean an arbitrary selection sequence under only local RL.  The
theorems must iterate the named localization \(x^{k+1}=T(x^k)\), or impose
a branch-exclusion assumption making the full resolvent equal to \(T\) in
the input neighborhood.

This is not pedantry.  Start with a good local scalar branch such as
\(F_0(x)=\operatorname{sgn}(x)|x|^{1/2}\), which has the exact local error
bound \(|x|=|F_0(x)|^2\) and a locally Lipschitz Cayley map.  Add graph
points far from \((0,0)\) whose Minty inputs cover a small neighborhood of
zero.  The local graph hypotheses at \((0,0)\) are unchanged, but the full
resolvent has a remote branch that an arbitrary inclusion sequence may
select.  Only the localized branch is controlled.

#### 4.3 “Close to \(S\)” is not an invariant localization

For a nonisolated solution set, small \(d(x,S)\) controls only the normal
coordinate.  A step of size \(O(d(x,S)^\gamma)\) can drift tangentially out
of the graph window.

`GX-071` realizes this mechanism exactly.  Its recurrence is
\(r_+=r^{\gamma q}\), but the tangential coordinate changes by
\(|z|^\gamma\).  The whole printed rectangle is not a self-map; convergence
inside it requires a positive tangential margin.  Therefore “sufficiently
close to \(S\)” is false as a complete local hypothesis.  The initial point
must lie near a reference point in the full norm and its total step budget
must fit inside an outer radius.

#### 4.4 Limit membership

The scalar recurrence plus the step estimate makes the orbit Cauchy, but
\(d(x^k,S)\to0\) alone yields only a point in \(\overline S\).  A repaired
proof must either:

- assume \(S\) is closed in the invariant localization; or
- use that the named all-pairs RL branch is continuous and show its limit
  is a fixed point.

The current draft does neither explicitly.

### Theorem 1: \(\gamma q>1\)

Let \(p=\gamma q>1\).  On \(0<r\le\delta\), Lemma 5 gives

\[
r_+\le C_\delta r^p,
\qquad
C_\delta=\frac{\rho}{(2\lambda)^q}
             (\delta^{1-\gamma}+L)^q.
\]

After choosing \(\delta\) so that
\(\theta=C_\delta\delta^{p-1}<1\), one has
\(r_{k+1}\le\theta r_k\), hence
\(r_k\le\theta^k r_0\).  Then

\[
\sum_k\|x^{k+1}-x^k\|
\le \frac12\left(
  \frac{r_0}{1-\theta}+
  \frac{Lr_0^\gamma}{1-\theta^\gamma}
\right)<\infty.
\]

Thus the intended proof is valid after the common localization repairs.

**Rate language.**  The valid conclusion is

\[
r_{k+1}=O(r_k^{\gamma q}),
\]

or “Q-order at least \(\gamma q\) in the upper-bound sense,” not exact
order \(\gamma q\).  `GX-072` has the same mechanical all-pairs bound but
actual orbit order \(q>\gamma q\).  Finite termination would also make an
exact-order claim meaningless.

Severity: **FATAL-AS-STATED; correct and repairable theorem mechanism.**

### Theorem 2: \(\gamma q=1\)

The scalar argument is correct.  The recurrence coefficient satisfies

\[
\limsup_{r\downarrow0}\frac{r_+}{r}
\le \rho\left(\frac{L}{2\lambda}\right)^q.
\]

If the right-hand side is below one, choose a slightly larger
\(\theta<1\) and a sufficiently small radius; then
\(r_{k+1}\le\theta r_k\), and the same step-summability argument works.

This coefficient is a **sufficient coefficient obtained through Lemma 3**.
The draft supplies no necessity or sharpness proof.  It yields at least
linear convergence of the distance, not necessarily exact linear order.

Severity: **FATAL-AS-STATED because of the common gaps; scalar core PASS.**

### Theorem 3: gauge version

`GaugeRec`, (GC), and (GC') are algebraically correct under a finite
nondecreasing gauge and valid local branch.  In particular, if

\[
c:=\limsup_{r\downarrow0}\Phi(r)/r<1,
\]

then \(\Phi(r)\le\theta r\) for small \(r\) and some \(c<\theta<1\).
This gives geometric decay of \(r_k\) and summability of
\(O(r_k^\gamma)\) steps.

The condition (GC') is only a convenient sufficient condition.  It should
not be described as equivalent to (GC), and neither condition is shown
necessary.

Severity: **FATAL-AS-STATED because of the common gaps; scalar core PASS.**

## 5. A minimal repaired convergence statement

The cleanest repair separates the scalar convergence engine from the graph
conditions used to verify it.

### Localized branch theorem

Let \(S\subset H\) be nonempty and closed, let
\(\bar x\in S\), and set \(U=B(\bar x,R)\).  Let
\(T:U\to H\) be a specified single-valued localization satisfying
\(T(x)\in J_{\lambda F}(x)\).  Assume there are \(\delta>0\),
\(L>0\), \(0<\gamma<1\), and a finite nondecreasing gauge \(\psi\)
with \(\psi(0)=0\), such that for every \(x\in U\) with
\(r=d(x,S)\le\delta\),

\[
\|T(x)-x\|\le b(r):=\frac12(r+Lr^\gamma),                         \tag{A}
\]

\[
d(T(x),S)\le
\Phi(r):=\psi\!\left(\frac{r+Lr^\gamma}{2\lambda}\right).       \tag{B}
\]

Suppose

\[
c:=\limsup_{r\downarrow0}\frac{\Phi(r)}r<1.
\]

Choose \(c<\theta<1\) and \(0<\delta_1\le\delta\) so that
\(\Phi(r)\le\theta r\) for \(0<r\le\delta_1\).  If

\[
r_0=d(x^0,S)\le\delta_1
\]

and the explicit localization margin

\[
\|x^0-\bar x\|+
\frac12\left(
  \frac{r_0}{1-\theta}+
  \frac{Lr_0^\gamma}{1-\theta^\gamma}
\right)<R                                                     \tag{M}
\]

holds, then \(x^{k+1}=T(x^k)\) is well-defined, remains in \(U\), is
Cauchy, and converges to a point of \(S\).  Moreover
\(r_k\le\theta^k r_0\).

For \(\psi(t)=\rho t^q\):

- if \(\gamma q>1\), condition (GC) holds with limit zero and the sharper
  upper recurrence is \(r_{k+1}=O(r_k^{\gamma q})\);
- if \(\gamma q=1\), (GC) follows from
  \(\rho(L/(2\lambda))^q<1\).

### What is needed to derive (A)--(B) from RL

It is enough to print all of the following:

1. a graph localization \(G\subset\operatorname{gph}F\) on which RL holds
   for all pairs;
2. an input ball \(U\subset M_\lambda(G)\), so that the injectivity proved
   from RL defines the map
   \(T=\pi_1\circ(M_\lambda|_G)^{-1}\) on \(U\);
3. coverage of the local zero graph points used in the
   \(\varepsilon\)-nearest-point argument, or an explicit anchored RL
   assumption against those zeros;
4. the power/gauge error bound at every \(T(x)\) reached in the outer
   localization;
5. either local closedness of \(S\) or the fixed-point/continuity argument
   for the localized branch;
6. iteration of this named \(T\), unless a separate branch-exclusion
   hypothesis identifies it with the full resolvent on \(U\).

These are the mathematical contents hidden by the draft's phrase
“two-radius localization.”  Writing them explicitly repairs all three
theorems without changing their scalar recurrence.

## 6. Sharpness and scope of the current claims

| Claim | Referee status |
|---|---|
| RL \(\Leftrightarrow\) AFNE | Exact on the same natural/restricted Minty domain with all coupled selections. |
| Factor \(1/2\) in Lemma 3 | Valid and better than discarding a term from the squared estimate; not proved globally optimal after using all assumptions. |
| Exponent \(\gamma q\) | A guaranteed upper-recursion exponent, not an exact orbit law. |
| Universal compensation law | Not proved.  `GX-072` shows actual order can differ; `GX-073` shows strong all-pairs geometry can coexist with noninvariant dynamics. |
| Attainability | `GX-071` supplies a reverse-calibrated exact \(\gamma q\) recurrence once its invariant subwindow is imposed.  This is a valid constructed witness, not evidence of necessity or natural universality. |
| Critical constant | Sufficient through the present triangle/residual route; necessity and optimality unknown. |
| (GC') | Sufficient only. |
| “Convergence region” | Must be called a proved sufficient region, not the exact maximal region. |

## 7. Submission-readiness decision

**Current disposition: reject/major reconstruction on rigor, before any
novelty assessment.**  A journal referee can correctly object that the PPA
is not known to exist, that the iteration relation has no specified branch,
and that a distance-to-set neighborhood does not provide invariant local
coverage.  Those objections affect Theorems 1--3, the main advertised
results.

**What survives unchanged:** the RL inner-product identity, the Minty
injectivity observation, the exact natural-domain RL/AFNE equivalence, and
the conditional one-step inequalities.

**Minimum technical package before submission:**

1. replace the informal localization paragraph by a formal graphical
   localization and range-coverage assumption;
2. state the algorithm as iteration of a named local resolvent map;
3. include an explicit invariant-radius/step-budget proof;
4. close the limit-membership argument;
5. weaken every exact-order/sharp-region phrase to an upper guarantee unless
   a matching extremal theorem is proved;
6. keep the residual-exponent convention visible in every theorem.

After those repairs, the theorem package is mathematically plausible and
can be evaluated for novelty and journal fit.  No journal-level conclusion
can be supported by this proof-only audit.

## Expert contract

- task_id: `RL-PROOF-REFEREE-01`
- stage: `T2/T3 theorem validation and repair gate`
- inputs_reviewed: `upload/01-RL_Submonotonicity-.md; research/example_properties.md; work/root_math_audit.md`
- methods: `line-by-line algebra verification; quantifier audit; Minty-domain and branch analysis; scalar-recursion reconstruction; counterexample stress tests using GX-071, GX-072, GX-073, GX-074`
- evidence: `exact RL/IP and parallelogram calculations; injectivity of the Minty parametrization; explicit contraction and step-sum estimates; catalogued invariance and domain counterexamples`
- negative_results: `RL does not imply resolvent range coverage; local RL does not control remote full-resolvent branches; distance closeness does not imply local invariance; gamma*q is not an exact universal orbit order; sharpness of the critical coefficient is unproved`
- uncertainties: `optimal Lemma-3/critical constants under joint RL and subregularity; weakest elegant graph-localization assumptions; whether constructed attainability can be upgraded to a natural sharpness theorem`
- conflicts: `the draft's multivalued selection-wise wording conflicts with the fact that all-pairs RL/AFNE forces single-valuedness on the restricted domain; the draft's arbitrary inclusion notation conflicts with its intended selected local branch; “sufficiently close to S” conflicts with GX-071 tangential escape`
- outputs: `work/rl_proof_referee.md`
- recommended_next_action: `rewrite Definitions 1--4 and Theorems 1--3 around a named graphical resolvent localization, then prove the explicit margin theorem (M) before making novelty or journal-tier claims`
- confidence: `high (0.94) on algebra/domain/localization findings; medium-high (0.86) that the displayed repair is close to the weakest practical theorem wrapper`
