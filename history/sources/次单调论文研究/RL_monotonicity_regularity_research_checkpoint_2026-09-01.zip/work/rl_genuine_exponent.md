# \(q>1\) power subregularity 与 reflected-resolvent 指数：no-go 命题的精确判定

> 任务范围：只做内部数学推导，不做文献检索。本文独立核对
> upload/01-RL_Submonotonicity-.md、research/example_properties.md
> 以及 GX-071--073 的 C-stage 计算。

## 0. 结论先行

原候选强命题

> “\(q>1\) power metric subregularity 会迫使 reflected resolvent 局部
> all-pairs Lipschitz/isometric，因此任何 \(\gamma<1\) 都只是 inherited，
> 并且 \(\gamma q\) 必然非 sharp”

是 **假的**。

但它包含一个严格成立、而且更精确的结构定理：

1. 若 \(p\) 是 \(y=J_{\lambda F}x\) 的最近（或足够精确的近似最近）
   零点，则 \(q>1\) 强迫

   \[
   y-p=o(\lambda w),\qquad
   x-p=(y-p)+\lambda w,\qquad
   R_{\lambda F}x-p=(y-p)-\lambda w,
   \]

   因而

   \[
   \frac{\|R_{\lambda F}x-p\|}{\|x-p\|}\to1,
   \qquad
   R_{\lambda F}x-p=-(x-p)+O(\|x-p\|^q).
   \]

2. 若零点 \(p\) 局部孤立，上式中的 moving anchor 就是同一个固定
   \(p\)。此时沿任一局部 Minty branch，单凭 \(q\)-subregularity 就有

   \[
   J_{\lambda F}x-p=O(\|x-p\|^q),
   \]

   不需要 RL。因此孤立零点情形中，机械的 \(O(r^{\gamma q})\)
   被更强的 \(O(r^q)\) 支配。

3. 若零点集非孤立，上述结论只对 output-nearest anchor \(p_y\)
   成立；它一般不能换成 input-nearest anchor \(p_x\)、固定参考零点
   \(\bar p\)，也不能直接换成集合距离比值。

4. 即使零点孤立、\(q>1\)，reflected resolvent 仍可具有 genuinely
   \(\gamma<1\) 的 all-pairs 最优指数；只是 zero-anchored profile
   的指数为 1。GX-072 正是这种分离。

5. 非孤立零点时，\(p_x\) 与 \(p_y\) 的切向漂移可使
   \(d(Jx,S)=\Theta(d(x,S)^{\gamma q})\)。GX-071 正是 exact
   \(\gamma q\) 的反例。因此“\(\gamma q\) 一律非 sharp”也是假命题。

最准确的结论不是 no-go，而是

\[
\boxed{
\text{pairwise Cayley roughness}
\;\neq\;
\text{output-anchored reflection defect}
\;\neq\;
\text{solution-set drift/alignment}.}
\]

算法阶数由后两者与 error-bound gauge 的组合决定；all-pairs RL 指数只是
一个统一但可能过于悲观的上界。

---

## 1. 记号与四种不能混用的 anchor

固定 \(\lambda>0\)。对 \((y,w)\in\operatorname{gph}F\)，记

\[
x:=y+\lambda w,
\qquad
\widehat x:=y-\lambda w.
\tag{1.1}
\]

若相应 Minty localization 是单值的，则

\[
y=J_{\lambda F}x,
\qquad
\widehat x=R_{\lambda F}x.
\]

以下四种 anchor 不等价：

1. \(p_y\in P_S(y)\)：resolvent output \(y\) 的最近零点；
2. \(p_x\in P_S(x)\)：PPA input \(x\) 的最近零点；
3. 固定参考零点 \(\bar p\in S\)；
4. 任意另一个 Minty pair：all-pairs profile。

这里 \(P_S\) 可能为空。若 \(S\) 不是 proximinal，只需取

\[
p\in S,
\qquad
\|y-p\|\le d(y,S)+\varepsilon,
\tag{1.2}
\]

其中 \(\varepsilon=O(\|w\|^q)\)。只要 \(S\ne\varnothing\)，这样的
近似最近点总可由距离下确界选出；不需要闭性或凸性。若 \(S\) closed
convex，或处于有限维且 \(S\) closed，则可直接取精确投影。

---

## 2. 主结构定理：moving-anchor asymptotic reflection

### Theorem 2.1（power error bound 强迫 moving-anchor 反射）

设 \(q>1\)，且在所考察的局部区域内

\[
d(y,S)\le \rho\,d(0,F(y))^q.
\tag{2.1}
\]

取任意非零 \(w\in F(y)\)，并取 \(p\in S\) 满足

\[
\|y-p\|\le d(y,S)+c\|w\|^q
\tag{2.2}
\]

（精确最近点对应 \(c=0\)）。令 \(x,\widehat x\) 如 (1.1)。则

\[
\|y-p\|\le (\rho+c)\|w\|^q.
\tag{2.3}
\]

置

\[
\delta(w):=\frac{\rho+c}{\lambda}\|w\|^{q-1}.
\]

当 \(\delta(w)<1\) 时，

\[
\frac{1-\delta(w)}{1+\delta(w)}
\le
\frac{\|\widehat x-p\|}{\|x-p\|}
\le
\frac{1+\delta(w)}{1-\delta(w)},
\tag{2.4}
\]

以及

\[
\frac{\|\widehat x-p+(x-p)\|}{\|x-p\|}
\le
\frac{2\delta(w)}{1-\delta(w)}.
\tag{2.5}
\]

特别地，对任意 \((y_n,w_n)\to(\bar y,0)\) 的非平凡 graph sequence，
只要按 (2.2) 选择 \(p_n\)，就有

\[
\boxed{
\frac{\|\widehat x_n-p_n\|}{\|x_n-p_n\|}\to1,
\qquad
\widehat x_n-p_n=-(x_n-p_n)+o(\|x_n-p_n\|).}
\tag{2.6}
\]

#### Proof

由 \(w\in F(y)\)，

\[
d(0,F(y))\le\|w\|.
\]

故 (2.1)--(2.2) 给出 (2.3)。令

\[
a:=y-p,\qquad t:=\lambda w.
\]

则

\[
x-p=a+t,\qquad \widehat x-p=a-t,
\]

且 \(\|a\|/\|t\|\le\delta(w)\)。正反三角不等式立即给出
(2.4)。又

\[
(\widehat x-p)+(x-p)=2a,
\]

而 \(\|x-p\|\ge(1-\delta(w))\|t\|\)，故得 (2.5)。因为
\(q>1\)，\(\delta(w)\to0\)，所以得到 (2.6)。\(\square\)

### Remark 2.2（真正起作用的是 superlinear gauge）

幂函数并非必要。若 \(\psi\) 在原点附近有限且非降，并且

\[
d(y,S)\le\psi(d(0,F(y))),
\qquad
\frac{\psi(t)}t\to0,
\]

且近似投影误差也是 \(o(\|w\|)\)，同一证明仍给出 (2.6)。因此结构
核心是

\[
\boxed{\psi(t)=o(t),}
\]

而不是幂记号本身。

### Scope 2.3（这不是普通 all-pairs Lipschitz 定理）

(2.6) 的 base point \(p_n\) 随 graph pair 改变。它只证明一种
moving-anchor asymptotic reflection；它没有比较两个任意非零 graph
pairs，也没有证明 \(R_{\lambda F}\) 在输入变量上局部 Lipschitz。

若工作在 restricted graph
\(\Gamma\subset\operatorname{gph}F\)，并希望把
\(\widehat x-p\) 解释为 \(R_\Gamma x-R_\Gamma p\)，必须另外要求
\((p,0)\in\Gamma\)。若该 zero pair 被 localization 排除，(2.6)
仍是向量恒等式的后果，但不是 branch 内的 reflected-resolvent
comparison。

---

## 3. 孤立零点：branchwise 等价与直接 \(q\)-阶 PPA

### Theorem 3.1（isolated-zero \(q\)-flatness equivalence）

设 \(\bar p\in S\) 是局部孤立零点。缩小邻域后，对邻近 \(y\)，

\[
d(y,S)=\|y-\bar p\|.
\]

考虑任一 Minty-localized graph branch \(\Gamma\) at
\((\bar p,0)\)。以下三个 branchwise 性质等价（常数允许改变）：

\[
\begin{aligned}
\text{(B-qEB)}\quad&
\|y-\bar p\|=O(\|w\|^q),\\
\text{(J-qflat)}\quad&
\|y-\bar p\|=O(\|x-\bar p\|^q),\\
\text{(R-qreflection)}\quad&
\|\widehat x-(2\bar p-x)\|=O(\|x-\bar p\|^q).
\end{aligned}
\tag{3.1}
\]

映射 \(F\) 的 full \(q\)-metric subregularity 蕴含 (B-qEB) 于
每一个局部 graph branch；反向推出 full mapping property 时，则必须让
\(\Gamma\) 包含所有可能使 \(d(0,F(y))\) 变小的局部 values。

#### Proof

(B-qEB) \(\Rightarrow\) (J-qflat)：若
\(\|y-\bar p\|\le\rho\|w\|^q\)，则在 \(\|w\|\) 足够小时

\[
\|x-\bar p\|
\ge \lambda\|w\|-\rho\|w\|^q
\ge\frac\lambda2\|w\|.
\]

因此

\[
\boxed{
\|y-\bar p\|
\le \rho\left(\frac2\lambda\right)^q
\|x-\bar p\|^q.}
\tag{3.2}
\]

(J-qflat) \(\Rightarrow\) (B-qEB)：若
\(\|y-\bar p\|\le C\|x-\bar p\|^q\)，则充分靠近 \(\bar p\)
时 \(\|y-\bar p\|\le\frac12\|x-\bar p\|\)。由
\(\lambda w=x-y\)，

\[
\lambda\|w\|
\ge\|x-\bar p\|-\|y-\bar p\|
\ge\frac12\|x-\bar p\|,
\]

故

\[
\|y-\bar p\|\le C(2\lambda)^q\|w\|^q.
\]

最后

\[
\widehat x-(2\bar p-x)=2(y-\bar p),
\]

所以 (J-qflat) 与 (R-qreflection) 精确等价。\(\square\)

### Corollary 3.2（anchored modulus 与 PPA 阶）

在 Theorem 3.1 的假设下，full \(q\)-subregularity 给出

\[
\boxed{
R_\Gamma x-\bar p
=-(x-\bar p)+O(\|x-\bar p\|^q),}
\tag{3.3}
\]

从而只要 branch domain 非平凡地趋近 \(\bar p\)，

\[
\boxed{
\lim_{\substack{x\to\bar p\\x\in D_\Gamma,\ x\ne\bar p}}
\frac{\|R_\Gamma x-\bar p\|}{\|x-\bar p\|}=1.}
\tag{3.4}
\]

并且 PPA 一步直接满足

\[
\boxed{
\|J_\Gamma x-\bar p\|
\le C\|x-\bar p\|^q.}
\tag{3.5}
\]

这不使用任何 RL\(_\gamma\) 假设。若局部 branch 在一个输入球上存在，
并返回同一 graph localization，选 \(\delta>0\) 使
\(C\delta^{q-1}<1\)，则该小球自动 invariant，局部 PPA 具有
\(q\)-阶上递推并收敛到 \(\bar p\)。

因此，在 isolated zero 加已有 local branch existence 的情形，
\(\gamma<1\) 的 solution-anchored RL 只是冗余弱化；若原稿仍只报告
\(O(r^{\gamma q})\)，则损失了可由 subregularity 单独得到的信息。

### Caveat 3.3

Subregularity 本身不提供：

- \(I+\lambda F\) 的局部 range coverage；
- resolvent branch 的存在；
- full resolvent 的 branch exclusion；
- 任意 selection 的一致性。

所以 Corollary 3.2 不能被误写成“\(q\)-subregularity 单独保证 PPA
可定义”。它的内容是：一旦局部 Minty branch 已存在且保持在
localization 中，阶数不再需要 subunit RL exponent。

---

## 4. 非孤立零点：真正缺失的是 alignment / solution drift

令 \(y=J_\Gamma x\)，并取 \(p_y\in P_S(y)\)（或
\(O(\|w\|^q)\)-近似投影）。Theorem 2.1 进一步给出，充分局部时，

\[
d(y,S)\le C\|x-p_y\|^q.
\tag{4.1}
\]

证明只需由
\(\|x-p_y\|\ge\lambda\|w\|-O(\|w\|^q)\) 得到
\(\|w\|\le(2/\lambda)\|x-p_y\|\)。

设 \(r=d(x,S)\)。若另有 alignment profile

\[
\|x-p_y\|\le K r^\theta,
\qquad \theta>0,
\tag{4.2}
\]

则

\[
\boxed{
d(J_\Gamma x,S)=O(r^{\theta q}).}
\tag{4.3}
\]

| alignment | 可保证的 PPA set-distance 上界 |
|---|---|
| \(\|x-p_y\|=O(r)\) | \(O(r^q)\) |
| \(\|x-p_y\|=O(r^\gamma)\) | \(O(r^{\gamma q})\) |

原稿的 all-pairs RL\(_\gamma\)，拿 input-nearest \(p_x\) 与当前
graph pair 比较，给出

\[
\lambda\|w\|
\le\tfrac12(r+Lr^\gamma)=O(r^\gamma).
\]

再由 (2.3) 可得 \(\|x-p_y\|=O(r^\gamma)\)，从而恢复 (4.3)
的 \(\theta=\gamma\) 情形。

因此 \(\gamma q\) 更准确的解释是

\[
\boxed{
\text{solution-alignment/drift exponent }\theta
\quad\times\quad
\text{centered error-bound exponent }q,}
\]

而不一定是“reflected resolvent 对实际解 anchor 的真实 Hölder 指数
乘以 regularity exponent”。

---

## 5. 反例 A：孤立零点、\(q>1\)，但 all-pairs \(\gamma<1\) genuinely sharp

这一反例是对 GX-072 机制的独立一维 relation 版本。

固定 \(q>1\)、\(0<\gamma<1\)，令

\[
\beta:=\frac q\gamma-1>0,
\qquad
h(0)=0,
\qquad
h(t)=|t|^q\sin(|t|^{-\beta})\quad(t\ne0).
\]

在充分小的 \(I=[-\delta,\delta]\) 上定义

\[
\operatorname{gph}F
:=\{(h(t),\,t-h(t)):t\in I\},
\qquad \lambda=1.
\tag{5.1}
\]

则 Minty input 恰为 \(t\)，所以

\[
J_F(t)=h(t),
\qquad
R_F(t)=2h(t)-t.
\tag{5.2}
\]

### 5.1 零点与 \(q\)-subregularity

取 \(\delta\) 使 \(\delta^{q-1}<1/2\)。因
\(|h(t)|\le|t|^q<|t|\) 对 \(t\ne0\)，局部

\[
S=F^{-1}(0)=\{0\}.
\]

若 \(u=h(t)\)，则每个对应 residual value
\(v=t-u\in F(u)\) 都满足

\[
|v|
\ge |t|-|u|
\ge\tfrac12|t|
\ge\tfrac12|u|^{1/q}.
\]

对所有 preimages 取下确界，

\[
|u|\le2^q d(0,F(u))^q.
\tag{5.3}
\]

所以 \(F\) 在孤立零点处具有真正的 \(q>1\) strong power
subregularity。在振幅极值序列上 \(|u|=|t|^q\) 且
residual \(\asymp|t|\)，故指数 \(q\) 也是最大的 centered exponent。

### 5.2 all-pairs 指数严格等于 \(\gamma\)

标准 two-scale 分解可直接重做：对
\(0\le s\le t\le\delta\)，若
\(t-s\gtrsim t^{\beta+1}\)，用振幅
\(|h(t)-h(s)|\le2t^q\)；若
\(t-s\ll t^{\beta+1}\)，用

\[
|h'(\xi)|\lesssim \xi^{q-\beta-1}
\]

及均值定理。两种情形都给

\[
|h(t)-h(s)|\le C|t-s|^{q/(\beta+1)}
=C|t-s|^\gamma.
\]

异号点由振幅界处理。因此 \(R_F=2h-I\) 局部 all-pairs
\(\gamma\)-Hölder。

取相邻正负振幅极值 \(t_n,s_n\downarrow0\)，则

\[
|t_n-s_n|\asymp t_n^{\beta+1},
\qquad
|h(t_n)-h(s_n)|\asymp t_n^q.
\]

因为 \(q=\gamma(\beta+1)\)，任意 \(\eta>\gamma\) 都失败；线性项
\(|t_n-s_n|\) 比 \(t_n^q\) 更小，不能消除该 failure。故

\[
\boxed{\text{maximal local all-pairs exponent of }R_F=\gamma<1.}
\tag{5.4}
\]

### 5.3 anchored profile 与 PPA 却是 \(q\)-阶

由 (5.2)，

\[
R_F(t)=-t+O(|t|^q),
\qquad
\frac{|R_F(t)|}{|t|}\to1,
\]

而

\[
|J_F(t)|=O(|t|^q).
\]

在振幅极值序列上后者恰为 \(|t|^q\)。因此：

- \(\gamma<1\) 是 genuinely sharp 的 all-pairs 指数；
- zero-anchored 指数却是 1；
- PPA centered order 是 \(q\)，严格优于 \(\gamma q\)。

这严格否证“\(q>1\) 强迫 all-pairs Lipschitz”这一版本。

---

## 6. 反例 B：非孤立零点时，固定/\(p_x\) anchor 与集合距离都可失败

令 \(H=\mathbb R^2\)、\(q>1\)，

\[
\phi(z)=\operatorname{sgn}(z)|z|^{1/q},
\]

并对固定 \(c\ne-1\) 定义 single-valued map

\[
F_c(s,z)=(\phi(z),cz),
\qquad \lambda=1.
\tag{6.1}
\]

则

\[
S=\mathbb R\times\{0\},
\qquad
d((s,z),S)=|z|,
\]

且

\[
d(0,F_c(s,z))^q
=|z|\bigl(1+c^2|z|^{2-2/q}\bigr)^{q/2}
\ge|z|.
\tag{6.2}
\]

故 \(q\)-MSR 全局成立，局部 exact infimal modulus 为 1。

对 \(z=u^q>0\)、\(s=ku\)，相应 Minty/reflected pair 为

\[
y=(ku,u^q),
\qquad
w=(u,cu^q),
\]

\[
x=((k+1)u,(1+c)u^q),
\qquad
\widehat x=((k-1)u,(1-c)u^q).
\tag{6.3}
\]

### 6.1 固定参考零点失败

取固定 \(\bar p=(0,0)\)。若 \(k\ne-1\)，

\[
\frac{\|\widehat x-\bar p\|}{\|x-\bar p\|}
\to\frac{|k-1|}{|k+1|},
\tag{6.4}
\]

该极限一般不为 1；取 \(k=1\) 可得 0，取 \(k=-1\) 时该比值趋于
\(+\infty\)。

### 6.2 output-nearest anchor 仍满足主定理

对 \(y\) 的最近零点

\[
p_y=(ku,0),
\]

有

\[
x-p_y=(u,(1+c)u^q),
\qquad
\widehat x-p_y=(-u,(1-c)u^q),
\]

所以比值趋于 1，完全符合 Theorem 2.1。

### 6.3 input-nearest anchor 与 set-distance ratio 仍可失败

对 input 的最近零点

\[
p_x=((k+1)u,0),
\]

有

\[
\frac{\|\widehat x-p_x\|}{\|x-p_x\|}\to+\infty.
\tag{6.5}
\]

同时

\[
\frac{d(\widehat x,S)}{d(x,S)}
=\frac{|1-c|}{|1+c|},
\tag{6.6}
\]

可取任意非 1 的值（并可取 0）。因此 moving-anchor norm ratio
不能替换成 set-distance ratio。

### 6.4 genuine all-pairs exponent 与临界 \(\gamma q\)

\(I+F_c\) 是局部乃至全局双射，且

\[
R_{F_c}(\xi,\zeta)
=\left(
\xi-2\phi\!\left(\frac\zeta{1+c}\right),
\frac{1-c}{1+c}\zeta
\right).
\tag{6.7}
\]

故其 maximal local all-pairs exponent 为

\[
\gamma=1/q<1,
\]

且由输入到 PPA output 的集合距离递推恰为

\[
d(Jx,S)=\frac1{|1+c|}d(x,S).
\tag{6.8}
\]

这里 \(\gamma q=1\) 精确落在临界线；是否收缩由常数
\(1/|1+c|\) 决定。

---

## 7. GX-071--073 的独立重读

### GX-071：非孤立解集使 exact \(\gamma q\) 成为可能

在 \(\lambda=1\)、\(z>0\) 的简化记号下，GX-071 有

\[
J(t,z)=(t+z^\gamma,z^\alpha),
\qquad
\alpha=\gamma q>1,
\qquad
S=\mathbb R\times\{0\}.
\]

于是

\[
w=x-Jx=(-z^\gamma,z-z^\alpha).
\]

对 output-nearest zero

\[
p_y=(t+z^\gamma,0),
\]

有

\[
x-p_y=(-z^\gamma,z),
\]

而

\[
Rx-p_y=(z^\gamma,2z^\alpha-z).
\]

两者都由 \(z^\gamma\) 主导，故 norm ratio 趋于 1，符合
Theorem 2.1。

但 input-nearest zero 是

\[
p_x=(t,0),
\]

此时

\[
\|x-p_x\|=z,
\qquad
\|Rx-p_x\|\sim2z^\gamma,
\]

所以 \(p_x\)-anchored exponent genuinely 为 \(\gamma\)。同时

\[
d(Jx,S)=z^\alpha=d(x,S)^{\gamma q}.
\]

因此 GX-071 严格否证“\(\gamma q\) 总是非 sharp”。其机制不是
output-anchored reflection 粗糙，而是零点沿切向移动了
\(z^\gamma\)。

### GX-072：孤立零点下 all-pairs \(\gamma\) 与 orbit \(q\) 分离

GX-072 的

\[
J(x,y)=(P_qx,P_qy+h(x)),
\qquad
h(x)=|x|^q\sin(|x|^{-\beta}),
\qquad
\beta=q/\gamma-1
\]

满足局部孤立 \(S=\{0\}\)、sharp \(q\)-MSR/SMSR，且

\[
\|Jz\|=\Theta(\|z\|^q),
\qquad
Rz=-z+O(\|z\|^q).
\]

所以 anchored ratio 趋于 1，真实非零 orbit 具有 exact Q-order
\(q\)。另一方面，oscillatory two-scale pairs 使 all-pairs
maximal exponent 严格等于 \(\gamma<1\)。这正好验证：
Theorem 3.1 只刚化 centered/anchored profile，不会刚化 all-pairs
profile。

### GX-073：不满足 \(q>1\) 前提，因此不构成反例

GX-073 的 full-map fixed-target 最大 regularity exponent 是 1，
而不是 \(q>1\)。其 anchored reflected profile 为
\(|x|^\alpha\)、\(\alpha<1\)，selected iteration 还会离开局部窗口。
故它不与 Theorem 2.1/3.1 冲突；相反，它说明 superlinear
error-bound gauge \(\psi(t)=o(t)\) 是反射刚化不可删除的前提。

---

## 8. 命题状态总表

| 候选主张 | 状态 | 最小附加条件 / 反例 |
|---|---|---|
| \(q>1\Rightarrow\|Rx-p_y\|/\|x-p_y\|\to1\) | **TRUE** | \(p_y\) 为 \(y=Jx\) 的 exact 或 \(O(\|w\|^q)\)-近似最近零点 |
| \(q>1\Rightarrow R(x)=2p-x+O(\|x-p\|^q)\) | **TRUE** | \(p\) 局部孤立，或采用 moving \(p_y\) |
| isolated \(q>1\Rightarrow Jx-p=O(\|x-p\|^q)\) | **TRUE** | 已选 Minty branch 留在 graph localization；不保证 branch 存在 |
| \(q>1\Rightarrow R\) local all-pairs Lipschitz | **FALSE** | 反例 A；GX-072 |
| \(q>1\Rightarrow\) fixed-\(\bar p\) ratio 趋 1（非孤立 \(S\)） | **FALSE** | 反例 B |
| \(q>1\Rightarrow p_x\)-anchored ratio 趋 1 | **FALSE** | 反例 B；GX-071 |
| moving-anchor ratio 趋 1 \(\Rightarrow d(Rx,S)/d(x,S)\to1\) | **FALSE** | 反例 B，式 (6.6) |
| \(\gamma<1\) RL exponent 必为 inherited | **FALSE as all-pairs claim** | 反例 A；GX-072 genuinely sharp |
| \(\gamma<1\) 在 isolated solution-anchored rate 中冗余 | **TRUE** | Theorem 3.1；branch existence 仍需另证 |
| \(\gamma q\) 必然非 sharp | **FALSE** | GX-071 exact；反例 B 在临界线 exact |
| isolated \(q>1\) 时 \(\gamma q\) 被 \(q\) 支配 | **TRUE** | Theorem 3.1 |

---

## 9. 对 RL 新颖性与论文主线的影响

### 9.1 对当前主张的负面影响

1. 不能把 \(\gamma q\) 写成普遍的“真实 convergence order”。它只是由
   all-pairs 或粗 anchored upper profile 经 error bound 复合得到的保证。
2. 在孤立零点且 \(q>1\) 时，RL\(_\gamma\) 并不负责 superlinear
   rate；q-subregularity 加局部 branch existence 已经给 \(q\)-阶。
3. “\(q>1\) 与 \(\gamma<1\) 相互补偿”若不区分零点是否孤立，会混合
   两种完全不同的机制。

### 9.2 反而可能形成的更强结构贡献

本轮推导支持把论文从单一 \(\gamma q\) 乘法升级为三个 profile：

1. pairwise Cayley profile：任意两个 graph pairs 的最坏 Hölder 模量；
2. centered reflection-defect profile：

   \[
   \|R x-(2p_y-x)\|=2\|Jx-p_y\|;
   \]

3. solution-alignment profile：

   \[
   \|x-p_y\| \quad\text{相对于}\quad d(x,S)
   \]

   的尺度。

Theorem 2.1/3.1 表明 superlinear subregularity 与第二个 profile
的 q-flatness 有 branchwise 等价；GX-071/072 表明第一个与第三个
profile 独立。这比“定义一个 Hölder reflected map，再把指数相乘”
更有结构内容。

### 9.3 最值得进一步证明的定理包

1. 把 Theorem 3.1 写成一般 gauge \(\psi=o(t)\) 的 exact branchwise
   equivalence；
2. 为非孤立 \(S\) 定义可检验的 alignment/drift gauge，并证明

   \[
   d(Jx,S)\lesssim \psi(\chi(d(x,S)));
   \]

3. 给出何种图几何（如 normal/tangent decomposition、prox-regular
   solution manifold、inner semicontinuous projection branch）
   保证 \(\chi(r)=O(r)\)，以及何时只保证
   \(\chi(r)=O(r^\gamma)\)；
4. 将 all-pairs RL 降为真正算法所需的 anchored/alignment 假设，
   并比较二者严格性；
5. 用自然非孤立 inclusion，而非 reverse-calibrated GX-071，验证
   genuine tangential drift。

若这些步骤完成，RL 的潜在价值更可能来自“pairwise roughness、
centered reflection 与 solution drift 的分解”，而不是
\(\gamma q\) 本身。

---

## 10. 证据与限制

- VERIFIED-ALG：Theorem 2.1、Theorem 3.1、alignment 推论、
  反例 A/B 的全部公式与量词。
- VERIFIED-PROJECT-ASSET：GX-071--073 的公式与本轮独立代入相符。
- AI-INFERENCE：上述结构是否足以构成可发表的新主线；本任务按要求没有
  做 prior-art 搜索，因此绝不把它标为文献意义上的新 theorem。
- NOT-CLAIMED：“通常”“generic”“大概率 sharp/nonsharp”等统计性
  判断；当前例子只证明可能性与严格边界。

## Expert contract

~~~yaml
contract_version: "1.0"
expert_skill: independent-mathematical-analysis
project_id: monotonicity-regularity-seesaw-2026-09
paper_family: T
stage_id: T2
task_id: T2-RL-GENUINE-EXPONENT
task_status: COMPLETE
inputs_reviewed:
  - upload/01-RL_Submonotonicity-.md
  - research/example_properties.md
  - work/c_gx066_077.md
  - work/rl_proof_referee.md
outputs:
  - work/rl_genuine_exponent.md
evidence_status:
  - VERIFIED-ALG: moving-anchor reflection theorem and isolated-zero equivalence
  - VERIFIED-ALG: scalar oscillatory and nonisolated shear counterexamples
  - VERIFIED-PROJECT-ASSET: independent substitution checks for GX-071--073
  - AI-INFERENCE: publication and novelty implications only
assumptions:
  - lambda is fixed and strictly positive
  - analyzed graph pairs remain where the error bound holds
  - a reflected-resolvent map interpretation requires a named Minty branch
  - full PPA convergence additionally requires branch existence, coverage, and invariance
author_input_needed: []
manual_actions: []
quality_checks:
  - separated output-nearest, input-nearest, fixed, and all-pairs anchors
  - treated exact projection, approximate projection, isolated, and nonisolated solution sets
  - distinguished branchwise error bounds from full-mapping metric subregularity
  - supplied counterexamples to every overstrong implication
  - did not use literature claims or call a conjecture a theorem
conflicts:
  - conflict_id: RL-NOGO-ALLPAIRS
    conflict_type: theorem_counterexample
    claim: q>1 forces local all-pairs reflected-resolvent Lipschitzness
    resolution: false; scalar oscillatory relation and GX-072 have genuine all-pairs gamma<1
  - conflict_id: RL-GAMMAQ-UNIVERSAL-NONSHARP
    conflict_type: theorem_counterexample
    claim: q>1 makes gamma*q universally nonsharp
    resolution: false; GX-071 attains exact gamma*q through nonisolated solution drift
conflict_resolution_status: RESOLVED_MATHEMATICALLY
merge_permission: orchestrator_only
recommended_next_action: promote the isolated-zero equivalence and nonisolated alignment profile into a claim-safe theorem package, then run a dedicated prior-art audit on that package rather than on the raw RL definition
stage_acceptance_recommendation: REPAIR_AND_STRENGTHEN
~~~
