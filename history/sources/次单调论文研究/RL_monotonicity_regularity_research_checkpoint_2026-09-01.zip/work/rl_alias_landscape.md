# RL 的“异名 / 不同数学入口”先例扫描

> project：`monotonicity-regularity-seesaw-2026-09`  
> stage：T2（reopened novelty audit）  
> task：`T2-NOV-ALIAS`  
> 检索日期：2026-09-01（UTC）  
> 检索纪律：只把原始论文、作者预印本、官方出版页或官方机构库作为证据；未调用第三方学术 API；搜索未命中不作为新颖性证据。  
> 证据标签：**[VS]** 原文/官方页已核；**[VM]** 可直接复核的代数推论；**[PV]** 已定位候选但仍需全文公式核验；**[NS]** 仅为有边界的负向检索结果，不支持“文献不存在”。

## 0. 先给结论边界

本轮最重要的结果不是“找不到先例”，而是找到了一组必须认真处理的**精确 map-side 先例**。

1. **[VS, VM] RL 的 reflected-resolvent 条件作为一个映射不等式并不新。** 令 (T=R_{lambda F})。Kirk 至少在 1997/1998 年已经研究
   
   \[
   \|Tx-Ty\|\le h\|x-y\|^p,
   \]
   
   而 Barroso 2022/2023 明确定义了任意 (L>0) 的 “\(\alpha\)-Hölder (L)-Lipschitz / nonexpansive / contractive” 映射。取 (p=\alpha=\gamma)、(h=L)、(T=R_\Gamma)，就是 RL 的 map-side 公式。Barroso 的定义甚至允许 (T:K\to X)，不要求 self-map，因此量词上与受限 reflected resolvent 很贴近。

2. **[VS, VM] 一般 gauge 版也已有 map-side 框架。** Barroso–Bedoya–da Silva 2025 定义
   
   \[
   \rho(Tx,Ty)\le c\rho(x,y)+\omega(\rho(x,y)).
   \]
   
   取 (c=0)、\(\omega(t)=Lt^\gamma\) 即得到 RL 的 Hölder 模量；不过该文把 (T) 当作 metric-space self-map，不能无条件覆盖 (R_\Gamma:D_\Gamma\to H) 的 non-self 情形。

3. **[VS] γ=1 已有精确 operator-side 先例。** Luke–Tam 2025 的 restricted submonotonicity 与受限 reflected resolvent 的 Lipschitz 性精确等价。缩放 (A=\lambda F) 后，
   
   \[
   \mathrm{RL}(\lambda,L,1)
   \iff
   \langle a,\lambda b\rangle
   \ge-\frac{L^2-1}{4}\|a+\lambda b\|^2
   \]
   
   （(L\ge1) 且采用其非负 violation convention）。

4. **[NS] 本轮尚未核实到一篇原始文献，明确把 γ<1 的 power-Hölder Cayley 拉回定义为一种 set-valued operator generalized monotonicity，并同时系统处理 graph maximality、restricted/full resolvent、PPA 与 metric subregularity。** 这只是本轮有限检索的状态，绝不是新颖性证明。

5. 因此可以安全表达的判断是：

   - **高风险、不能作为主要新颖性**：单独提出 “(R_{\lambda F}) 是 Hölder 映射”，或把它代回 graph 写成内积式；前者是已有映射类，后者是标准 Cayley 坐标恒等变换。
   - **仍可能构成贡献、但必须继续核验**：把该 map class 系统拉回非单调 set-valued operator graph；精确定义 restricted/maximal RL；建立非平凡 calculus、inverse/scaling、sharp examples；以及与 higher-order/gauge subregularity 联合产生不能由通用 Hölder fixed-point 理论直接得到的算法定理。

## 1. 审计问题与判别标准

本报告不把“名字相同”视为先例，也不把“名字不同”视为新颖。对每个候选都做以下七项判别：

1. 原文公式能否通过固定且公开的变量变换精确变成 RL；
2. 是 (R) 的性质、(J) 的性质、(F^{-1}) 的性质，还是仅解映射的 calmness；
3. 是 all-pairs 还是只在一个基点/解点 anchored；
4. 是 global、local all-pairs，还是 bounded-set estimate；
5. 定义域是任意 (D\subset H)、full (H)，还是必须 self-map (D\to D)；
6. 是否强迫 resolvent 单值、full domain 或 operator maximality；
7. 原文是否真的提出 operator-side class，还是我们事后作 Cayley pullback。

判定用语：

- **exact map-side alias**：公式和 all-pairs 量词精确相同，但文献研究的是一般映射 (T)，未必讨论 (T=R_{\lambda F})；
- **exact operator-side predecessor**：文献本身在 operator graph / resolvent 语言中提出同一条件；
- **bounded/local consequence**：在有界域或附加局部尺度后可以推出 RL，但不是原条件的全局等价；
- **anchored-only**：只比较 \(x\) 与固定 \(\bar x\)，不能反推 all-pairs RL；
- **near but non-equivalent**：对象、坐标、模量或量词不同。

## 2. Cayley 字典：为什么一般 Hölder 映射是精确先例

固定 graph 部分 (\Gamma\subset\operatorname{gph}F) 和 (\lambda>0)。对两点

\[
(u,u^*),(v,v^*)\in\Gamma,
\qquad a=u-v,\quad b=u^*-v^*,
\]

记

\[
d=a+\lambda b,
\qquad r=a-\lambda b.
\]

令

\[
D_\Gamma=(I+\lambda F)(\Gamma),
\qquad
R_\Gamma(u+\lambda u^*)=u-\lambda u^*.
\]

则

\[
x-y=d,
\qquad
R_\Gamma x-R_\Gamma y=r.
\]

所以

\[
\boxed{
\|a-\lambda b\|\le L\|a+\lambda b\|^\gamma
\iff
\|R_\Gamma x-R_\Gamma y\|\le L\|x-y\|^\gamma
\quad(x,y\in D_\Gamma).
}
\tag{2.1}
\]

RL 还自动排除 Cayley input collision：若两个 graph 点给出同一 (x=u+\lambda u^*)，则 (2.1) 右端为零，两个 reflected output 相同；再由

\[
u=\frac{x+R_\Gamma x}{2},
\qquad
u^*=\frac{x-R_\Gamma x}{2\lambda}
\]

可知 graph 点相同。因此 (R_\Gamma) 单值。

反之，任意 Hölder 映射 (T:D\to H) 都生成 relation

\[
\Gamma_T=
\left\{
\left(\frac{x+Tx}{2},\frac{x-Tx}{2\lambda}\right):x\in D
\right\},
\tag{2.2}
\]

并且该 relation 精确满足 RL。这一事实说明：**在不附加 maximality、full domain、calculus 或算法结论时，RL 与一般 Hölder map class 是同一个数学对象在 Cayley 坐标中的两个写法。**

经典 Minty parametrization 本身当然不是新事实。Bauschke–Moursi–Wang 对 (\rho)-comonotone operator 给出了

\[
\operatorname{gra}A
=\{(J_Ax,(I-J_A)x):x\in\operatorname{ran}(I+A)\},
\]

并在 maximal 情形把参数域扩展到全空间；其 Corollary 2.17 也明确写出 reflected-resolvent 坐标

\[
(x,z)\in\operatorname{gra}R_A
\iff
\left(\frac{x+z}{2},\frac{x-z}{2}\right)\in\operatorname{gra}A.
\]

见 [Bauschke–Moursi–Wang, arXiv:1902.09827, Theorem 2.16 and Corollary 2.17](https://arxiv.org/pdf/1902.09827)。**[VS]**

### 2.1 (J)-Hölder 与 (R)-Hölder不能混写

因为 (R=2J-I)，若

\[
\|Jx-Jy\|\le C\|x-y\|^\gamma,
\]

只能直接得到

\[
\|Rx-Ry\|
\le 2C\|x-y\|^\gamma+\|x-y\|.
\tag{2.3}
\]

在直径至多 (D) 的域上，线性项可吸收为

\[
\|x-y\|\le D^{1-\gamma}\|x-y\|^\gamma,
\]

所以 bounded-set (J)-Hölder 可推出 bounded-set RL，常数为 (2C+D^{1-\gamma})。但在无界域上，(2.3) 一般不能推出 (R) 的 γ-Hölder 上界。故下文所有“resolvent Hölder”文献都必须检查它指的是 (J) 还是 (R)。

### 2.2 局部尺度警告

若 (R) 在直径 (D<\infty) 的域上是 (K)-Lipschitz，则对任意 (0<\gamma<1)，

\[
\|Rx-Ry\|\le KD^{1-\gamma}\|x-y\|^\gamma.
\tag{2.4}
\]

因此在固定的 bounded neighborhood 上，“存在某个 γ<1 的 RL 常数”可能只是 Lipschitz 性的自动降格。若要证明 γ 是 genuinely sharp，必须研究：

- 最小模量 (\omega_R(t)=\sup_{\|x-y\|\le t}\|Rx-Ry\|) 的渐近阶；
- 常数随 neighborhood radius 缩小时的行为；
- 或者给出不满足任何局部 Lipschitz bound 的显式对象。

另一方面，在无界域上 γ<1 要求 sublinear increment growth；它在大尺度反而可能比 Lipschitz 更强。因此 RL(γ<1) 不是沿一条全局“一维强弱轴”的简单放宽。

## 3. 可复现 query log

### 3.1 检索方法

- 使用平台原生普通 web search 和网页/PDF 打开功能；未调用 Crossref、Semantic Scholar、OpenAlex、Scopus 等第三方 API。
- 证据只接受 arXiv 原文、作者/高校/国家机构仓储、出版社官方页、期刊官方页。
- ResearchGate、Semantic Scholar、Academia 等结果只在偶然发现题名时作为 discovery pointer；没有用其内容支持正式结论。
- 搜索界面不稳定地显示总命中数，因此不能给出数据库意义上的 hit count。下面记录的是 query 与前排结果的人工筛查状态；日期均为 2026-09-01 UTC。

### 3.2 Query families

| 入口 | 原样 query（可复制） | 前排结果筛查与去向 |
|---|---|---|
| reflected resolvent Hölder | `"reflected resolvent" "Hölder continuous" operator`; `"reflected resolvent" Hölder operator`; `"2J_A-I" Hölder resolvent operator` | 未核实到 γ<1 operator-side exact source；命中 Huang 2025 的 (J)-Hölder及若干只把 Hölder 用于 error bound 的论文 **[NS]** |
| Cayley transform modulus | `"Cayley operator" "Hölder" monotone`; `"Cayley transform" "Hölder" "monotone operator"`; `"Cayley transform" modulus continuity resolvent` | 命中 classical Cayley/nonexpansive、ML Cayley parameterization；未核实到 power-Hölder Cayley operator class **[NS]** |
| Hölder map class | `"Hölder nonexpansive" mapping definition`; `"Hölderian nonexpansive" mapping`; `"Hölder contractive mappings" fixed point arXiv`; `William A. Kirk "Hölder continuity and minimal displacement" pdf` | 核实 Kirk 1997/1998 与 Barroso 2022/2023；为 exact map-side predecessor **[VS]** |
| general modulus map class | `"ω-nonexpansive" mapping fixed point paper`; `"L-ω-nonexpansive" maps`; `nonlinear nonexpansive mapping modulus continuity` | 核实 Barroso–Bedoya–da Silva 2025 **[VS]** |
| almost NE / averaged | `"pointwise almost nonexpansive" violation`; `almost averaged mappings reflected resolvent`; `almost nonexpansive Hölder mapping` | 核实 Luke–Thao–Tam 2016/2018；finite exponent-1 violation，非 exact γ<1 **[VS]** |
| uniform / p-uniform monotonicity | `"p-uniformly monotone" resolvent Hölder`; `"uniformly monotone" "resolvent" Hölder continuous`; `"power uniformly monotone" inverse Hölder operator` | 核实 Liu–Moursi–Vanderwerff 2022/2023、Reem–Reich 2017；分别给 (R) defect / inverse or protoresolvent Hölder，非 RL **[VS]** |
| nonlinear graph gauge | `operator submonotone modulus graph inequality`; `submonotonicity gauge operator`; `semimonotone modulus operator graph`; `"ρ-paramonotone" κ`; `"α(·)-monotone multifunction" inequality` | 定位 Rolewicz、Ngai–Tron–Vu–Théra、Ngai–Penot、László；部分全文受限，列为优先 deep-read **[PV]** |
| Hölder calmness | `"Hölder calmness" resolvent mapping monotone`; `"isolated calmness" resolvent monotone`; `"Hölder continuity" resolvent "maximal monotone"` | 命中多为 solution/KKT mapping stability；没有把 calmness 误当 all-pairs continuity **[NS]** |
| Hölder Minty | `"Hölder Minty" operator`; `"Minty parametrization" Hölder`; `"localized Minty parametrization" resolvent` | 核实 Luo et al. localized Minty formula；没有 Hölder modulus **[VS, NS]** |
| graph-coordinate geometry | `"scaled relative graph" Hölder operator`; `"scaled relative graph" reflected resolvent`; `metric transform graph coordinates a+b a-b monotone` | 核实 SRG 编码 incremental gain/angle；标准 SRG 丢失 RL 所需的 pair scale **[VS, VM]** |
| terminology false positives | `nonexpansive operator "Hölder-type growth condition"`; `bounded Hölder regularity fixed point operator`; `Hölder regular reflected resolvent` | Park–Ryu 的“Hölder-type growth”是 anchored uniform monotonicity/error growth，不是 (R) 的 Hölder continuity **[VS]** |

### 3.3 访问限制日志

| 来源 | 状态 | 对结论的影响 |
|---|---|---|
| Kirk 1998 Taylor & Francis PDF | 官方题名/DOI页可访问，PDF 抓取不稳定；Kirk 1997 官方 UMCS companion 已显示 power formula | 原始 1998 论文的严格/非严格不等号及最广 domain convention 仍需人工全文核对 |
| Rolewicz 1999 IMPAN PDF | 官方元数据页可访问；PDF OCR 为零/抓取不稳定 | 不能在未读全文时断言其 (\alpha(\cdot))-monotonicity公式与 RL 的精确关系 |
| Ngai–Tron–Vu–Théra 2021/2022 HAL | HAL 被反爬页阻断；Springer 官方摘要可访问 | (\rho)-paramonotonicity 的精确公式、locality 与 maximality待全文核验 |
| Ngai–Penot 2007 | Elsevier 官方摘要页可访问，正文付费 | 仅列为 nonlinear-gauge/approximate-monotonicity候选，不作 exactness claim |

## 4. 已核候选总矩阵

| ID | 文献中的对象与公式 | local / global | all-pairs / anchored | domain / codomain | maximality | 对 RL 的判定 |
|---|---|---|---|---|---|---|
| M1 | Barroso 2023：\(\rho(Tx,Ty)\le L\rho(x,y)^\alpha\) | global on (K) | all-pairs | (T:K\to X)，(K) 任意 metric subset；定义不要求 self-map | 无 operator maximality | **exact map-side alias**，取 (T=R_\Gamma,\alpha=\gamma) |
| M2 | Kirk 1997/1998：\(\|Tx-Ty\|\lesssim h\|x-y\|^p\) | global on bounded \(K\) | all-pairs | bounded closed convex \(K\) in Banach，\(T:K\to K\) | 无 | power-Hölder 先例；同常数 exactness 尚受 strict/non-strict convention 小差异影响 |
| M3 | Barroso–Bedoya–da Silva 2025：\(\rho(Tx,Ty)\le c\rho(x,y)+\omega(\rho(x,y))\) | global on (M) | all-pairs | metric self-map (T:M\to M) | 无 | (c=0,\omega(t)=Lt^\gamma) 时 exact map inequality；仅 self-map 情形直接覆盖 RL |
| O1 | Luke–Tam 2025：\(\langle a,b\rangle\ge-\tau\|a+b\|^2\) | restricted/local or global by (U,W) | all-pairs on restricted graph | finite-dimensional Euclidean；(D=(I+F_W)(U)) | 不要求 full domain/maximal | **exact operator-side predecessor for γ=1**；非 γ<1 |
| N1 | Luke–Thao–Tam：\(\|T x-T y\|\le\sqrt{1+\varepsilon}\|x-y\|\) at (y) | pointwise/local/global variants | anchored or uniform all-pairs | set-valued (T:D\rightrightarrows E)，不要求 self-map | 无 | exponent 1 + finite violation；与 genuine γ<1 non-Lipschitz map 不等价 |
| N2 | Liu–Moursi–Vanderwerff：\(\|d\|^2-\|\Delta R_A\|^2\ge4\phi(\|\Delta J_A\|)\) | global | all-pairs | maximally monotone Hilbert operator，full (R_A:H\to H) | 是 | uniform monotonicity 的 **defect** characterization；不是 (R_A) 的 Hölder upper bound |
| N3 | Reem–Reich：\(\|(A+B)^{-1}w_1-(A+B)^{-1}w_2\|\le(\|w_1-w_2\|/\beta)^{1/(p-1)}\) | global where inverse exists | all-pairs | reflexive Banach；protoresolvent；max monotone + fully Legendre conditions | 可给 full domain/single-valuedness | (J)/protoresolvent Hölder，非 reflected (R)；标准 Hilbert resolvent仍由 identity term分离 |
| N4 | Huang–Peng–Tang 2025：\(\|J_r x-J_r y\|\le C_R\|x-y\|^{q-1}\) | bounded balls | all-pairs | Banach generalized resolvent (J_r=(J+rA)^{-1}J) | range assumptions | (J)-Hölder，不是 (R)-Hölder；Hilbert (q=2) 退化为 exponent 1 |
| N5 | Rolewicz / \(\rho)-paramonotonicity / approximate monotonicity | 依具体文献 | 多为 graph all-pairs | Banach (X\rightrightarrows X^*) 或更抽象 multifunction | 待核 | nonlinear gauge 位于 primal difference 或抽象函数差，不是已核的 Minty-input gauge；**deep-read required** |
| N6 | localized Minty：\(\operatorname{gph}A\cap W_\lambda=\{(J_{\lambda A}x,\lambda^{-1}(x-J_{\lambda A}x)):x\in U\}\) | local/restricted | parameterization, not a pair modulus | \(J\) single-valued on \(U\) | 不推出 maximal | 提供坐标字典，无 Hölder estimate |
| N7 | SRG：\(z_\pm=(\|\Delta T\|/\|\Delta x\|)e^{\pm i\angle}\) | global class descriptor | all-pairs | Hilbert operators | 取决于类 | 固定 SRG 区域编码 scale-homogeneous ratio；RL γ<1 的 ratio (\le L\|\Delta x\|^{\gamma-1}) 依赖 pair scale，故标准 SRG 不是 exact alias |

## 5. 候选原文定位与公式转写

### 5.1 M1：Barroso 的 Hölder-Lipschitz type maps——最直接的精确异名

Cleon S. Barroso, *Hölder-contractive mappings, nonlinear extension problem and fixed point free results*, JMAA 528 (2023), article 127521；[arXiv 原文](https://arxiv.org/pdf/2207.03057)，[期刊官方页](https://www.sciencedirect.com/science/article/abs/pii/S0022247X23005243)。

Definition 1.1 令 (K) 为 metric space (X) 的非空子集，(T:K\to X)。原文按常数区间分名：

\[
\rho(Tx,Ty)\le L\rho(x,y)^\alpha\quad(x,y\in K),
\tag{5.1}
\]

- (0<L<1)：α-Hölder (L)-contractive；
- (L=1)：α-Hölder nonexpansive；
- (L>1)：α-Hölder (L)-Lipschitz。

该定义明确研究 α<1，而且 (T:K\to X) 并不要求 (T(K)\subset K)；只有其固定点部分才进一步使用 self-map/bounded closed convex set。**[VS]**

取

\[
K=D_\Gamma,
\qquad T=R_\Gamma,
\qquad \alpha=\gamma,
\]

则 (5.1) 与 RL 精确等价。这里没有常数损失、没有 local-to-global 补丁、也不是 anchored estimate。**[VM]**

但是该文没有被本轮核实为做了以下事情：

- 从 (T) 的 Hölder 条件定义对应 set-valued (F) 的 graph class；
- 讨论 (F) 的 maximal RL extension；
- 研究 (J=(I+T)/2) 作为 PPA resolvent；
- 把 γ 与 metric subregularity exponent 联立。

因此它既是**定义层面的强 prior-art 风险**，又未必覆盖一个经过充分发展的 operator-side theory。

### 5.2 M2：Kirk 1997/1998——power-Hölder 条件的早期明确先例

William A. Kirk, *Hölder continuity and minimal displacement*, Numer. Funct. Anal. Optim. 19 (1998), 71–79, [出版社官方 DOI 页](https://www.tandfonline.com/doi/abs/10.1080/01630569808816815)。其 1997 官方 companion article *Remarks on Approximation and Approximate Fixed Points in Metric Fixed Point Theory* 的 Section 2 明确写出

\[
\|T(x)-T(y)\|\le h\|x-y\|^p
\tag{5.2}
\]

（PDF OCR 中不等号可能显示为严格形式），其中 (K) 为 Banach 空间的 bounded closed convex subset，(T:K\to K)，重点讨论 (p<1)。见 [UMCS 官方 PDF](https://bc.umcs.pl/Content/30480/PDF/czas4050_51_2_1997_15.pdf)。**[VS]**

把 (T) 换成 (R_\Gamma)、(p=\gamma,h=L)，即为相同的 power-Hölder modulus。需注意两点：

1. Kirk 的范围是 bounded convex self-map；RL 的受限 (R_\Gamma) 一般只是 (D_\Gamma\to H)。
2. 1997 PDF 的 strict/non-strict symbol OCR 不够可靠；若原式为严格 `<`，则它与 RL 的 `≤` 在“同一个 sharp 常数”上并非字面等价，但把常数任意放大即可转换。这个小差异不改变 “power-Hölder map class 已存在”的先例判断。

### 5.3 M3：(L)-ω-nonexpansive maps——一般 gauge 的 map-side 容器

C. S. Barroso, J. V. Bedoya, C. S. R. da Silva, *On (L)-ω-nonexpansive maps*, Results in Mathematics 80 (2025), article 157, [arXiv 原文](https://arxiv.org/pdf/2507.00859)，[Springer 官方页](https://link.springer.com/content/pdf/10.1007/s00025-025-02475-6.pdf)。Definition 1/5 为

\[
\rho(Tx,Ty)\le c\rho(x,y)+\omega(\rho(x,y)),
\tag{5.3}
\]

其中 (c\in[0,1])，ω 是连续非负、ω(0)=0 的 modulus；(c=0) 称 ω-nonexpansive。原文还特别研究 ω(δ)/δ 在 δ↓0 时发散的 regime；power ω(δ)=Lδ^γ（γ<1）恰在该 regime。**[VS]**

令 (c=0)、ω(t)=Lt^γ，则 (5.3) 是 RL 的 map-side inequality。区别在于原文的 (T:M\to M) 是 self-map；若 (R_\Gamma(D_\Gamma)\not\subset D_\Gamma)，只能说其 target-generalized 形式相同，不能说原定义逐字覆盖。

这一文献进一步削弱了“把幂函数换成一般 gauge”本身的定义新颖性。若 RL 未来推广为

\[
\|a-\lambda b\|\le\omega(\|a+\lambda b\|),
\]

则其 map-side 正是 ω-continuity / ω-nonexpansiveness；operator contribution 必须来自 Cayley pullback 后的新结构，而非 modulus language 本身。

### 5.4 O1：Luke–Tam——γ=1 的精确 operator-side 基线

D. Russell Luke and Matthew K. Tam, *Generalized Monotonicity and the Proximal Point Algorithm*, Mathematics of Operations Research, online 2025, [官方全文页](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863)。Definition 2 在 (U,W) 上定义

\[
\langle u-v,u^+-v^+\rangle
\ge-\tau\|(u+u^+)-(v+v^+)\|^2.
\tag{5.4}
\]

Proposition 4 令 (D=(I+F_W)(U))，证明在 τ<1/2 的命名/算法范围内

\[
F\text{ submonotone with }\tau
\iff J_{F_W}\text{ is almost }1/2\text{-FNE with violation }2\tau
\]

并等价于

\[
\operatorname{Lip}(2J_{F_W}-I)\le\sqrt{1+4\tau}
\quad\text{on }D.
\tag{5.5}
\]

对 (A=\lambda F)，RL(γ=1) 给

\[
\tau=\frac{L^2-1}{4}.
\]

因此 γ=1、(L\ge1) 是 exact operator-side predecessor；(L<1) 对应 signed negative τ，超出其 violation convention。**[VS, VM]**

对 γ<1，RL 可写成 scale-dependent coefficient

\[
\langle a,\lambda b\rangle
\ge-\tau_\gamma(t)t^2,
\qquad
\tau_\gamma(t)=\frac14\left(L^2t^{-2(1-\gamma)}-1\right),
\quad t=\|a+\lambda b\|.
\tag{5.6}
\]

当 (t\downarrow0)，τ_γ(t)→∞；所以 genuine γ<1 不能被任何 fixed finite Luke–Tam violation 在含任意小 pair distances 的邻域统一覆盖。

### 5.5 N1：almost nonexpansive / almost averaged——有限 Lipschitz violation，不是 power-Hölder

Luke–Thao–Tam, *Quantitative convergence analysis of iterated expansive, set-valued mappings*, [arXiv 原文](https://arxiv.org/html/1605.05725v2)。Definition 2.3 的 pointwise almost nonexpansiveness 是

\[
\|x^+-y^+\|\le\sqrt{1+\varepsilon}\|x-y\|
\]

对固定 base (y) 成立；若同一 ε 对每个 base point 成立，才成为 uniform all-pairs 条件。Proposition 2.4 的 almost averaged inequality 为

\[
\|x^+-y^+\|^2
\le(1+\varepsilon)\|x-y\|^2
-\frac{1-\alpha}{\alpha}
\|(x-x^+)-(y-y^+)\|^2.
\tag{5.7}
\]

其定义允许 set-valued (T:D\rightrightarrows E)，也不要求 self-map。**[VS]**

与 RL 的关系：

- finite ε 是 exponent 1；在 bounded (D) 上由 (2.4) 可推出任意较小 γ 的 RL，但常数依赖 (\operatorname{diam}D)；
- RL(γ<1) 可以由 (T(x)=|x|^\gamma) 类对象实现而不局部 Lipschitz，故不蕴含有限 ε 的 almost nonexpansiveness；
- pointwise-at-solution 只 anchored，严格弱于 all-pairs RL；
- 一些 RL map 也可能 Lipschitz/constant，所以两个类有交集，不能简单写成互斥。

### 5.6 N2：uniform monotonicity 与 reflected-resolvent defect

Liu–Moursi–Vanderwerff, *Strongly Nonexpansive Mappings Revisited: Uniform Monotonicity and Operator Splitting*, [arXiv 原文](https://arxiv.org/pdf/2205.09040)，定义

\[
\langle x-y,x^*-y^*\rangle\ge\phi(\|x-y\|).
\tag{5.8}
\]

Lemma 3.4 对 maximally monotone (A) 给出

\[
\|x-y\|^2-\|R_Ax-R_Ay\|^2
\ge4\phi\!\left(\frac12\|(x-y)+(R_Ax-R_Ay)\|\right)
=4\phi(\|J_Ax-J_Ay\|).
\tag{5.9}
\]

Proposition 3.5 给出 (A) uniformly monotone 当且仅当 (-R_A) super strongly nonexpansive。**[VS]**

这不是 RL：

1. (5.9) 先保证 (R_A) nonexpansive，再控制 nonexpansive defect；RL 直接上界 (\|\Delta R\|) 为 (L\|\Delta x\|^\gamma)。
2. (5.9) 的 modulus 作用于 (\|\Delta J_A\|)，不是 Minty input (\|\Delta x\|)。
3. maximally monotone/full-domain (R_A) 在 bounded domain 自动满足较低 exponent 的 RL，但这只是 (2.4) 的降格。
4. global 上，即便 (A=cI) 强单调，其 (R_A=kI)（通常 (k\ne0)）也不能满足任意 γ<1 的 global RL，因为 (kt\le Lt^\gamma) 在 (t\to\infty) 失败。

若 (A) 是 power-uniformly monotone，(5.8) 还能通过 Cauchy–Schwarz给 (A^{-1}) 的 Hölder modulus；这属于 inverse stability，不是 reflected Cayley modulus。

### 5.7 N3：Reem–Reich 的 Hölder protoresolvent——重要但对象不同

Daniel Reem and Simeon Reich, *Solutions to Inexact Resolvent Inclusion Problems with Applications to Nonlinear Analysis and Optimization*, [arXiv 原文](https://arxiv.org/pdf/1610.01871)。Definition 6.2 令 (B) power-uniformly monotone：

\[
\langle u_1-u_2,y_1-y_2\rangle\ge\beta\|y_1-y_2\|^p,
\qquad p>1.
\]

Lemma 6.3 得到

\[
\|(A+B)^{-1}w_1-(A+B)^{-1}w_2\|
\le
\left(\frac{\|w_1-w_2\|}{\beta}\right)^{1/(p-1)}.
\tag{5.10}
\]

Corollary 6.4 将其用于 (B=\nabla f)，得到 ( (\nabla f+\lambda A)^{-1}) 的 Hölder continuity；在 (A) maximally monotone、(f) fully Legendre 等条件下还得到单值/full-domain protoresolvent。**[VS]**

这是本轮最需要避免混淆的“resolvent Hölder”先例：

- 它确实是 all-pairs modulus，不是 calmness；
- 真正 γ<1 可由 (p>2) 产生；
- 但它控制 (J)-type inverse/protoresolvent，不控制 (R=2J-I)；
- identity term 使 global reflected map 往往仍为线性增长。标量 (B(x)=x^3) 时 (J_B(x)\sim x^{1/3})，而 (R_B(x)=2J_B(x)-x\sim-x)，故 global γ<1 RL 失败。

因此它不是 exact alias，却是论文 novelty positioning 中必须正面引用的近邻。

### 5.8 N4：Banach-space resolvent 的 bounded-set Hölder 性

Huang–Peng–Tang, *Hölder property of the resolvent of a monotone operator in Banach spaces*, [arXiv 原文](https://arxiv.org/pdf/2510.03774)。Theorem 3.3 对 q-uniformly smooth、2-uniformly convex Banach space中的 firmly-nonexpansive-type map，在 “(\|x\|,\|y\|\le R)” 下证明

\[
\|Tx-Ty\|\le C_R\|x-y\|^{q-1},
\qquad 1<q\le2.
\tag{5.11}
\]

Theorem 3.4 将其用于 generalized resolvent

\[
J_r=(J+rA)^{-1}J.
\]

**[VS]**

不等价原因：

- 这是 bounded-ball、all-pairs 的 (J_r)-estimate；
- Banach duality map (J:E\to E^*) 参与定义，不是 Hilbert 的 (I)；
- 没有控制 (2J_r-I)；
- 在 Hilbert specialization 中 (q=2)，exponent 回到 1。

### 5.9 N5：nonlinear-gauge monotonicity / paraconvexity 谱系

这一入口存在真实文献，不应因名称不同而忽略；但目前全文访问不足，必须保持 **[PV]**。

1. Stefan Rolewicz, *On α(·)-monotone multifunctions and differentiability of γ-paraconvex functions*, Studia Mathematica 133 (1999), 29–37，[IMPAN 官方页](https://www.impan.pl/en/publishing-house/journals-and-series/studia-mathematica/all/en/publishing-house/journals-and-series/studia-mathematica/all/133/1/111120/on-monotone-multifunctions-and-differentiability-of-paraconvex-functions)。官方摘要表明其对象是 (\Gamma:X\to2^\Phi) 的 α(·)-monotonicity；它比 Hilbert operator (F:H\rightrightarrows H) 更抽象，尚不能仅凭摘要写成 RL 等价。
2. Rolewicz 后续 paraconvex analysis 明确称 α(·)-monotonicity 是 Spingarn submonotonicity 的 uniformization；这表明“nonlinear gauge defect”不是空白命名空间。
3. Huynh Van Ngai–Nguyen Huu Tron–Nguyen Van Vu–Michel Théra, *Variational Analysis of Paraconvex Multifunctions*, JOTA 193 (2022), 180–218，[Springer 官方页](https://link.springer.com/article/10.1007/s10957-022-02021-2)，研究由 (\rho:X\to[0,\infty)) 控制的 paraconvex multifunction；搜索片段指向 ρ-paramonotonicity，但 HAL 全文在本轮被反爬页阻断。
4. Huynh Van Ngai–Jean-Paul Penot, *Approximately convex functions and approximately monotonic operators*, Nonlinear Analysis 66 (2007), 547–564，[Elsevier 官方页](https://www.sciencedirect.com/science/article/abs/pii/S0362546X05010072)。这是 approximate/submonotone gauge 的直接候选。
5. S. László, *θ-monotone operators and θ-convex functions*, Taiwanese Journal of Mathematics 16 (2012), 733–759；其后续文献说明 θ-kernel 可统一多种 relaxed monotonicity。仍需核对 θ 的参数位置、对称性与 maximal-resolvent 结论。

即便候选公式形如

\[
\langle a,b\rangle\ge-\kappa\rho(a),
\tag{5.12}
\]

也不等于 RL-IP

\[
\lambda\langle a,b\rangle
\ge\frac14\left(\|a+\lambda b\|^2-L^2\|a+\lambda b\|^{2\gamma}\right),
\tag{5.13}
\]

因为 (5.12) 的 gauge 作用于 primal difference (a)，而 (5.13) 的非线性尺度作用于 mixed Minty coordinate (a+\lambda b)，并包含一个正二次项。除非文献明确允许 gauge 依赖完整 graph pair 或先作 Cayley rotation，否则不能称 exact predecessor。

### 5.10 N6：localized Minty parametrization——坐标先例而非 modulus 先例

Luo et al., *Level proximal subdifferential, variational convexity, and ...*, [arXiv 原文](https://arxiv.org/html/2406.00648v2)，Lemma 4.3：若 (J_{\lambda A}) 在 (U) 上单值，则

\[
\operatorname{gph}A\cap W_\lambda
=\left\{
\left(J_{\lambda A}(x),\lambda^{-1}[x-J_{\lambda A}(x)]\right):x\in U
\right\}.
\tag{5.14}
\]

**[VS]** 这对 RL 很重要，因为它证明“restricted graph + local resolvent parameterization”已有明确语言；但 (5.14) 没有 Hölder 模量，也不推出 full domain 或 maximality。

### 5.11 N7：SRG / graph rotation——为何标准二维区域不能直接编码 γ<1

Ryu–Hannah–Yin, *Scaled Relative Graphs*, [arXiv 原文](https://arxiv.org/pdf/1902.09788)，以及 Quan–Evens–Sepulchre–Patrinos 的 nonmonotone SRG 扩展 [arXiv:2411.17419](https://arxiv.org/pdf/2411.17419)，把 operator pair 编为

\[
z_\pm(\Delta x,\Delta T)
=\frac{\|\Delta T\|}{\|\Delta x\|}
e^{\pm i\angle(\Delta x,\Delta T)}.
\tag{5.15}
\]

**[VS]** 对 RL，

\[
\frac{\|\Delta R\|}{\|\Delta x\|}
\le L\|\Delta x\|^{\gamma-1}.
\tag{5.16}
\]

右端依赖被标准 SRG 归一化掉的 pair scale。故一个固定 disk/region 不能精确表示 γ<1 RL；至少需要把 radius/scale 作为第三坐标或 family of slices。这解释了 RL 为什么不自然地落在传统 SRG 的一维强弱顺序中，但这不是新颖性证据。

### 5.12 术语陷阱：Hölder regularity / Hölder-type growth 通常不是 Hölder continuity

Park–Ryu, *Exact Optimal Accelerated Complexity for Fixed-Point Iterations*, [arXiv 原文](https://arxiv.org/pdf/2201.11413)，把 anchored 条件

\[
\langle Ax,x-x^*\rangle\ge\mu\|x-x^*\|^{\alpha+1}
\]

称为 Hölder-type growth；它只比较 (x) 与 zero (x^*)，本质是 uniform monotonicity/error growth，不是 (R_A) 的 Hölder continuity。**[VS]**

同样，fixed-point literature 中的 bounded Hölder regularity 常指

\[
\operatorname{dist}(x,\operatorname{Fix}T)
\le C\|x-Tx\|^q,
\]

属于 metric subregularity/error bound 侧，而非 (T) 的 Hölder modulus。两种 “Hölder” 恰是本项目要比较的两侧，不能在 prior-art 检索时互相替代。

## 6. 精确等价、局部推论与不等价机制

### 6.1 已经可以写成定理的事实

**命题 A [VM].** 对任意 graph restriction (\Gamma)、(0<\gamma\le1)、(L>0)，RL 与 (R_\Gamma:D_\Gamma\to H) 的 all-pairs γ-Hölder continuity 精确等价；RL 同时强迫 (R_\Gamma) 单值。

**命题 B [VS, VM].** Barroso 2023 Definition 1.1 在 (T=R_\Gamma)、(K=D_\Gamma)、α=γ 时就是命题 A 的 map-side 条件。因此 RL(γ<1) 不是一个新的 map regularity class。

**命题 C [VS, VM].** Luke–Tam submonotonicity 在 \(A=\lambda F\) 上精确给出 RL\((\gamma=1,L\ge1)\)，参数 \(\tau=(L^2-1)/4\)；其 Proposition 4 的正式范围另要求 \(\tau<1/2\)。

### 6.2 不能写成等价的近邻

| 近邻 | 失败机制 | 最多能得到什么 |
|---|---|---|
| (J) Hölder | (R=2J-I) 含 identity term | bounded domain 上可吸收线性项；global 一般不行 |
| Hölder calmness of \(J\) at \((\bar x,\bar y)\) | anchored、通常 set-valued inverse stability | 只能得以 \(\bar x\) 为基点的 estimate |
| pointwise almost averaged at a fixed point | exponent 1、anchored、可 set-valued | bounded/local 条件下推出较弱 Hölder upper bound |
| uniform monotonicity | 控制 (R) 的 nonexpansive defect，且 modulus argument 是 (\Delta J) | bounded域上由 nonexpansiveness 自动得 RL；global γ<1一般失败 |
| power monotonicity | 主要给 (A^{-1}) 或 protoresolvent 的 Hölder modulus | inverse-side Hölder，不是 reflected Cayley-side Hölder |
| ρ/φ/θ-monotonicity | gauge 通常作用于 (a=x-y) 或 abstract function differences | 需作非平凡 coordinate pullback 后逐式比较 |
| localized Minty | 只有 parameterization，无 modulus | 为 RL 的 restricted-domain 写法提供标准容器 |
| SRG | 归一化掉 (\|\Delta x\|)，而 RL ratio 依赖该尺度 | 可做 scale-indexed SRG family，不是标准二维 region |

### 6.3 anchored 与 all-pairs 的严格区别

all-pairs RL 显然推出任一 anchor \(\bar x\) 的

\[
\|Rx-R\bar x\|\le L\|x-\bar x\|^\gamma.
\]

反向不成立。即使对所有 (x) 有 anchored estimate，三角不等式只给

\[
\|Rx-Ry\|
\le L\|x-\bar x\|^\gamma+L\|y-\bar x\|^\gamma,
\]

它不能由 (\|x-y\|^\gamma) 控制，因为 (x,y) 可以彼此极近而共同远离 anchor。因此只在 solution/fixed point 基点成立的 theorem 不能列为 RL 的 exact prior art。

## 7. 对“新颖且有价值”的直接含义

### 7.1 已被 prior art 明显压缩的 claim

以下表述风险很高：

1. “我们首次提出 reflected resolvent 的 Hölder generalized nonexpansiveness”；
2. “γ<1 首次把 nonexpansive/Lipschitz 推广为 power-Hölder”；
3. “内积式 (5.13) 本身构成新的 generalized monotonicity identity”；
4. “把 power 换成 arbitrary gauge 是新的 map-side framework”；
5. “Hölder resolvent 从未被研究”。

其中 1–2 被 Kirk/Barroso 直接威胁；3 是 Cayley 恒等式；4 被 modulus-of-continuity/(L)-ω map literature 威胁；5 被 Reem–Reich 与 Huang–Peng–Tang 直接否定（虽然它们研究 (J)/protoresolvent而非 (R)）。

### 7.2 仍可能保留的 operator-theoretic residue

以下方向没有被本轮来源直接覆盖，但都必须在 deep-read 后才可声称：

1. **restricted relation theory**：在非单调、多值、非满域情形，用 RL 强制 restricted resolvent 单值并精确定义 graph locality；
2. **maximal RL extension**：是否存在合适的 graph-inclusion maximality、full-domain characterization，及与一般 Hölder self/non-self maps 的 extension theory对应；
3. **calculus**：inverse、scaling、sum、parallel sum、composition、preconditioning 是否保持某种 power/gauge RL，参数如何变换；
4. **sharp graph examples**：构造 genuine γ<1、非局部 Lipschitz 的 (R)，并证明对应 (F) 具有自然的 variational origin；
5. **algorithmic theorem**：RL 与 higher-order/gauge metric subregularity 联合后，得到不能从 generic Hölder map + generic error bound 直接抄出的 sharp convergence law；
6. **scale-aware geometry**：用三维/分层 SRG 或 nonlinear metric transform 保留 (\|\Delta x\|) 尺度，解释为何 γ<1 是 local-weak/global-strong 的双重性质。

### 7.3 关于 γq 的谨慎判断

本轮先例扫描没有发现支持“γq 是普遍 compensation law”的文献。generic composition of Hölder estimates 的确容易产生指数乘积，但这本身只是函数复合代数；要成为新理论，至少应证明：

- 指数乘积来自不可改进的 graph/inverse mechanism，而非 proof 中两次粗糙代入；
- 存在达到该 rate 的显式 RL operator；
- 在某些邻近理论中指数不是简单相乘，从而界定 γq law 的适用边界。

目前应把 γq 写成 **research hypothesis / theorem-specific exponent**，不能写成 universal law。

## 8. Deep-read 优先论文清单

### P0：直接决定 novelty 边界

1. **Kirk 1998**，核对原始 definition、strict/non-strict convention、unbounded/non-self variants及引用链。  
   官方定位：[DOI 10.1080/01630569808816815](https://www.tandfonline.com/doi/abs/10.1080/01630569808816815)。
2. **Barroso 2023**，完整追溯 Hölder-Lipschitz map genealogy，尤其其所引 Kirk 1974/1998 与 extension theory。  
   [arXiv:2207.03057](https://arxiv.org/pdf/2207.03057)。
3. **Barroso–Bedoya–da Silva 2025**，检查 ω-nonexpansive 的 target-generalized/non-self variants与 arbitrary modulus examples。  
   [arXiv:2507.00859](https://arxiv.org/pdf/2507.00859)。
4. **Luke–Tam 2025**，作为 γ=1 operator baseline，核对 restricted graph、pointwise vs all-pairs、maximality 与 PPA assumptions。  
   [官方全文](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863)。
5. **Reem–Reich 2017**，重建 power-uniform monotonicity → protoresolvent Hölder 的完整 exponent map，并明确为何不控制 reflected map。  
   [arXiv:1610.01871](https://arxiv.org/pdf/1610.01871)。
6. **Rolewicz 1999/2002 + Ngai et al. 2022 + Ngai–Penot 2007**，获取全文后逐字核对 nonlinear-gauge monotonicity、maximality和 resolvent characterization。该组最可能在“不同名字的 operator graph gauge”方向缩小剩余空间。

### P1：重要近邻与表达框架

7. **Liu–Moursi–Vanderwerff 2022/2023**：uniform monotonicity ↔ super strongly nonexpansive (-R_A)。  
   [arXiv:2205.09040](https://arxiv.org/pdf/2205.09040)。
8. **Huang–Peng–Tang 2025**：Banach generalized resolvent 的 bounded-set Hölder 性。  
   [arXiv:2510.03774](https://arxiv.org/pdf/2510.03774)。
9. **Luo et al. 2024/2025**：localized Minty parametrization，供 RL local definition 使用。  
   [arXiv:2406.00648](https://arxiv.org/html/2406.00648v2)。
10. **Ryu–Hannah–Yin 2019/2021 与 Quan et al. 2024/2025**：评估 scale-augmented SRG 是否能自然容纳 RL。  
    [arXiv:1902.09788](https://arxiv.org/pdf/1902.09788)，[arXiv:2411.17419](https://arxiv.org/pdf/2411.17419)。
11. **László 2012 θ-monotone operators**：核对 general kernel 是否允许 mixed graph coordinates，及其 maximal extension/surjectivity结果。

## 9. 建议写入主稿/atlas 的最小安全表述

可安全写为：

> 在任意受限 graph (\Gamma) 上，RL 与受限 reflected resolvent (R_\Gamma) 的 all-pairs Hölder continuity 精确等价。作为一般 mapping property，power-Hölder continuity 至少自 Kirk 的工作以来已有固定点理论，并由 Barroso 以 Hölder-Lipschitz/nonexpansive/contractive maps 的形式系统研究。因此本文不主张 Hölder map inequality 本身为新。本文待核验的潜在贡献位于其 Cayley pullback 后的 set-valued operator theory、restricted/maximal graph structure及其与 higher-order metric subregularity 联合产生的算法结论。现有 bounded search 尚未核实到完全相同的 γ<1 operator-side framework，但该负向结果不构成新颖性证明。

不建议写：

> “RL is the first Hölder generalization of reflected-resolvent nonexpansiveness.”

## 10. 尚需作者/人工完成的核验

1. 通过机构订阅或作者稿获取 Kirk 1998、Rolewicz 1999/2002、Ngai–Penot 2007、Ngai et al. 2022 全文；逐式录入定义，而不是依赖摘要或搜索片段。
2. 对上述 P0 文献做 backward/forward citation chaining；普通 web 搜索不等于数据库穷尽检索。
3. 检查专利、学位论文和非英语文献中是否已有“Cayley transform with Hölder modulus”明确表述；此项只能作为补充，不能取代 primary journal/preprint 核验。
4. 将 RL 的新颖性拆成独立 claim：定义、等价、maximality、calculus、examples、algorithm theorem；逐项做 claim chart，避免“一篇近邻文献覆盖/不覆盖整篇论文”的粗判断。

## 11. Quality checks

- [x] 精确区分了 (J)-Hölder、(R)-Hölder、(F^{-1})-Hölder 与 solution-map calmness。
- [x] 精确区分了 all-pairs、anchored、local-all-pairs、bounded-set 与 global。
- [x] 对每个 exact candidate 检查了 domain/codomain/self-map 条件。
- [x] 没有从 RL 推出 full domain 或 classical maximality。
- [x] 没有把搜索未命中写成 novelty。
- [x] 正式证据均来自原始/官方来源；第三方聚合页未作为证据。
- [x] 没有进行期刊分档或投稿级别推荐。
- [x] 将 algebraic equivalence 与 source-explicit operator theory 分开陈述。

## 12. Expert result

```yaml
contract_version: "1.0"
expert_skill: "sci-skills-literature-search"
project_id: "monotonicity-regularity-seesaw-2026-09"
paper_family: "T"
stage_id: "T2"
task_id: "T2-NOV-ALIAS"
task_status: "completed_with_targeted_fulltext_gaps"
inputs_reviewed:
  - "upload/01-RL_Submonotonicity-.md"
  - "research/project_state.yaml"
  - "research/expert_tasks.yaml"
  - "research/theory_atlas.md"
  - "work/a_rl_position.md"
  - "work/a_terminology_sources.md"
outputs:
  - "work/rl_alias_landscape.md"
evidence_status:
  verified_primary_sources:
    - "Kirk 1997 companion / 1998 official metadata"
    - "Barroso 2023"
    - "Barroso-Bedoya-da Silva 2025"
    - "Luke-Thao-Tam 2016/2018"
    - "Luke-Tam 2025"
    - "Reem-Reich 2017"
    - "Liu-Moursi-Vanderwerff 2022/2023"
    - "Huang-Peng-Tang 2025"
    - "Bauschke-Moursi-Wang 2019"
    - "Luo et al. 2024/2025"
    - "Ryu-Hannah-Yin 2019/2021"
  pending_formula_verification:
    - "Rolewicz 1999/2002 alpha(.)-monotonicity"
    - "Ngai-Penot 2007 approximate monotonicity"
    - "Ngai-Tron-Vu-Thera 2022 rho-paramonotonicity"
    - "Laszlo 2012 theta-monotonicity"
assumptions:
  - "RL is interpreted on a fixed graph restriction Gamma with D_Gamma=(I+lambda F)(Gamma)."
  - "Exact map-side alias does not imply that the source developed the Cayley-pulled operator class."
  - "Search coverage is bounded and search-engine total hit counts were unavailable."
author_input_needed:
  - "Institutional or author-copy access to the four pending formula-level sources would materially strengthen the novelty audit."
manual_actions:
  - "Obtain and archive the P0 paywalled/blocked full texts."
  - "Run backward and forward citation chaining from Kirk 1998, Barroso 2023, Reem-Reich 2017, and Rolewicz 1999."
  - "Build a claim-by-claim novelty chart after deep reading rather than a paper-level yes/no judgment."
quality_checks:
  - "Primary/official-source-only evidence rule satisfied."
  - "No third-party API used."
  - "No negative-search novelty inference made."
  - "J/R/inverse/calmness and anchored/all-pairs distinctions audited."
  - "No journal-tier recommendation included."
conflicts:
  - "The raw reflected-resolvent Holder inequality is an existing mapping class, which conflicts with any definition-level firstness claim."
  - "No verified exact gamma<1 operator-side source was found, but this remains an open verification gap rather than evidence of absence."
conflict_resolution_status: "resolved_for_safe_positioning; unresolved_for_exhaustive_novelty"
merge_permission: "merge_into_T2_with_evidence_labels"
recommended_next_action: "Deep-read the P0 gauge-monotonicity and early Holder-map papers and produce a formula-level claim chart against each proposed RL theorem."
stage_acceptance_recommendation: "do_not_close_T2_until_P0_formula_verification_and_claim_chart_are_complete"
```
