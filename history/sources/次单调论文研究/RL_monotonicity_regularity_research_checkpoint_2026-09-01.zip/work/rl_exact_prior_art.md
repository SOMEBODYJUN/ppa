# RL 条件的公式级先例检索与新颖性威胁审计

> **Project**: `monotonicity-regularity-seesaw-2026-09`  
> **Paper family / stage / task**: `T / T2 / T2-NOV-EXACT`  
> **Expert skill**: `sci-skills-literature-search`  
> **Contract**: `1.0`  
> **检索日**: **2026-09-01**  
> **方法边界**: 仅使用平台原生 web search、出版社/期刊官网、作者公开稿与 arXiv 等 primary/official sources；未调用第三方 API。没有正式数据库的命中总数、主题词树和完整引文网络，因此所有“未命中”都只是本轮可访问范围内的阴性检索结果，不是新颖性证明。

## 0. 先给结论边界

1. **当 \(\gamma=1\) 时，RL 的核心数学结构不是新的。** 经 \(A=\lambda F\) 缩放后，它精确等价于 equal-parameter \((\mu,\rho)\)-semimonotonicity；在 \(L\ge 1\) 区间，又精确等价于 Luke–Tam 的常数 submonotonicity / Lipschitz reflected-resolvent 条件。pointwise/anchored 同型 graph inequality 至少已见于 Luke–Thao–Tam 2018，Luke–Tam 另有 2023 RAMP 扩展摘要，2025 期刊文给出更完整的 restricted all-pairs theory。\(L=1\) 是经典 Minty–Cayley 的 monotonicity/nonexpansiveness 对应。
2. **当 \(0<\gamma<1\) 时，本轮没有在可访问 primary/official 文献中检到把同一 Hölder Cayley/reflected-resolvent 公式作为算子 graph class 系统研究的原文。** 但这不能提升为“已证明新颖”。最接近的重大威胁是：
   - 一般映射的 \(\alpha\)-Hölder 条件 \(\|Rx-Ry\|\le L\|x-y\|^\alpha\) 已有直接文献；
   - Minty/Cayley graph 旋转是经典结构；
   - 两者结合即可形式上得到 RL graph 的 pullback。因此，**“reflected resolvent 是 Hölder 映射”这个句子本身不宜作为新贡献**。
3. 若后续要主张可发表的新内容，潜在贡献应落在一般 Hölder-map 文献没有自动给出的部分：算子侧的非平凡 calculus/maximality/full-domain 结果、sharp exponent 与 genuine examples、local/anchored/all-pairs 的严格分离、以及与 regularity/算法结论的可证 sharp 配合。上述只是研究定位，不是本任务的期刊判断。
4. 一篇 2025 年 JOTA 论文关于“bounded sets / at each point”的 uniform monotonicity 与 strong nonexpansiveness 只获得了官方摘要，全文尚未核验；它是本轮最重要的残余文献风险之一。

证据标签：

- **[VERIFIED_SOURCE]**：原始论文全文或官方出版页直接支持；
- **[AI_INFERENCE]**：本任务从已核验定义作出的代数推导；
- **[PENDING_VERIFICATION]**：仅有摘要/元数据，或尚需正式数据库与全文复核。

---

## 1. 概念块：RL 到 Cayley/Hölder 几何的精确归一化

### 1.1 Graph 旋转

设 \(H\) 为实 Hilbert 空间，\(F:H\rightrightarrows H\)，\(\lambda>0\)。对

\[
(u,u^*),(v,v^*)\in\operatorname{gph}F,
\qquad a=u-v,\quad b=u^*-v^*,
\]

RL 条件为

\[
\tag{RL}_{\lambda,L,\gamma}
\|a-\lambda b\|\le L\|a+\lambda b\|^\gamma,
\qquad 0<\gamma\le1.
\]

置

\[
A:=\lambda F,\qquad c:=\lambda b,
\qquad x:=a+c,qquad r:=a-c.
\]

则 RL 只是

\[
\tag{1.1}
\|r\|\le L\|x\|^\gamma.
\]

令

\[
D_A:=(I+A)(\operatorname{dom}A),
\qquad J_A=(I+A)^{-1},
\qquad R_A=2J_A-I.
\]

在 graph 的 Minty 坐标中，\(x=(u+\lambda u^*)-(v+\lambda v^*)\)，而
\(r=(u-\lambda u^*)-(v-\lambda v^*)\)。因此

\[
\boxed{
\mathrm{RL}_{\lambda,L,\gamma}
\iff
R_{\lambda F}:D_A\to H\text{ 单值且 }
\|R_{\lambda F}x-R_{\lambda F}y\|
\le L\|x-y\|^\gamma .}
\tag{1.2}
\]

这里的 domain 是 Minty range \(D_A\)，除非另有 maximality/surjectivity 假设，不能无条件写成 \(R_A:H\to H\)。RL 还自动排除同一 Minty 输入的两个不同 graph 点：若 \(x=0\)，右端为零，故 \(r=0\)，从而相应两点相同。以上为直接代数 **[AI_INFERENCE]**。

反向地，任意定义在 \(D\subset H\) 上的映射 \(R:D\to H\) 都可形成 Cayley pullback

\[
\tag{1.3}
\Gamma_R=
\left\{
\left(\frac{x+Rx}{2},\frac{x-Rx}{2\lambda}\right):x\in D
\right\}.
\]

若 \(R\) 是 \(\gamma\)-Hölder，则 \(\Gamma_R\) 满足 RL。式 (1.3) 是经典 Minty/Cayley 坐标的直接使用；“任意 Hölder map 生成一个 RL graph”是本任务推导，不是 Barroso 论文中的算子定理 **[AI_INFERENCE]**。

### 1.2 内积形式

恒等式

\[
4\lambda\langle a,b\rangle
=\|a+\lambda b\|^2-\|a-\lambda b\|^2
\]

给出精确等价

\[
\boxed{
\lambda\langle a,b\rangle
\ge\frac14\left(
\|a+\lambda b\|^2
-L^2\|a+\lambda b\|^{2\gamma}
\right).}
\tag{1.4}
\]

当 \(0<\gamma<1\)，写 \(t=\|a+\lambda b\|>0\)，还可表示为 scale-dependent signed submonotonicity

\[
\tag{1.5}
\lambda\langle a,b\rangle
\ge-\tau_\gamma(t)t^2,
\qquad
\tau_\gamma(t)=\frac14\big(L^2t^{-2(1-\gamma)}-1\big).
\]

注意 \(\tau_\gamma(t)\to+\infty\) 当 \(t\downarrow0\)，而 \(\tau_\gamma(t)\to-1/4\) 当 \(t\to\infty\)。所以 \(\gamma<1\) 不是 Luke–Tam 常数 violation 的简单参数延拓；它在小尺度与大尺度的作用方向不同 **[AI_INFERENCE]**。

### 1.3 Inverse 与 scaling 变体

交换 graph 坐标并整理，得到

\[
\boxed{
F\in\mathrm{RL}(\lambda,L,\gamma)
\iff
F^{-1}\in\mathrm{RL}
\left(\lambda^{-1},L\lambda^{\gamma-1},\gamma\right).}
\tag{1.6}
\]

对任意 \(c_0>0\)，

\[
\boxed{
F\in\mathrm{RL}(\lambda,L,\gamma)
\iff
c_0F\in\mathrm{RL}(\lambda/c_0,L,\gamma).}
\tag{1.7}
\]

当 \(\gamma=1\)，inverse 保持 \(L\)；当 \(\gamma<1\)，\(L\lambda^{\gamma-1}\) 表明 Hölder 常数具有量纲/缩放依赖，不能脱离 \(\lambda\) 与单位比较数值大小 **[AI_INFERENCE]**。

---

## 2. \(\gamma=1\)：已知理论中的精确位置

### 2.1 Equal-parameter semimonotonicity

当 \(\gamma=1\)，平方展开式 (RL) 得

\[
\tag{2.1}
\langle a,b\rangle
\ge
\mu_L\|a\|^2+\rho_L\|b\|^2,
\]

其中

\[
\tag{2.2}
\theta_L:=\frac{1-L^2}{2(1+L^2)},
\qquad
\mu_L=\frac{\theta_L}{\lambda},
\qquad
\rho_L=\lambda\theta_L=\lambda^2\mu_L.
\]

等价地，对 \(A=\lambda F\) 的 graph 差 \((a,c)\)，

\[
\tag{2.3}
\langle a,c\rangle
\ge\theta_L(\|a\|^2+\|c\|^2).
\]

Evens–Pas–Latafat–Patrinos 将

\[
\langle x-x',y-y'\rangle
\ge\mu\|x-x'\|^2+\rho\|y-y'\|^2
\]

作为 \((\mu,\rho)\)-semimonotonicity 的核心定义，并给出 inverse/scaling/resolvent 规则。故 RL\((\lambda,L,1)\) 是该二维参数族中 tied curve \(\rho=\lambda^2\mu\)，或缩放后 \((\theta_L,\theta_L)\) 的一维切片 **[VERIFIED_SOURCE + AI_INFERENCE]**。论文定理主体在有限维 Euclidean 空间；式 (2.1)–(2.3) 的 Hilbert 版本只用内积恒等式，但不能据此自动外推其所有有限维 maximality/算法结论。

反解为

\[
\tag{2.4}
L=\sqrt{\frac{1-2\theta}{1+2\theta}},
\qquad -\frac12<\theta<\frac12.
\]

### 2.2 Luke–Tam submonotonicity / reflected Lipschitz

Luke–Tam 对缩放算子 \(A=\lambda F\) 的形式为

\[
\tag{2.5}
\langle a,c\rangle\ge-\tau\|a+c\|^2.
\]

与 (RL) 在 \(\gamma=1,L\ge1\) 时精确换算：

\[
\boxed{
\tau=\frac{L^2-1}{4},
\qquad
\operatorname{Lip}R_A=\sqrt{1+4\tau}=L.}
\tag{2.6}
\]

Luke–Tam 2025 Definition 2 与 Proposition 4 在其 restricted operator/domain 设定下把 submonotonicity、almost firm nonexpansiveness 和 reflected-resolvent Lipschitz 联系起来。其 Proposition 4 的陈述还要求 \(\tau<1/2\)，即 \(L<\sqrt3\)；纯代数等价 (2.6) 并不需要这一限制，但论文的定理范围不能据此扩大 **[VERIFIED_SOURCE]**。原文空间是 Euclidean；(2.5)–(2.6) 的代数只用实 Hilbert 内积恒等式，因而公式本身可直接重写到实 Hilbert 空间，但原文的算法/maximality结论不得因此自动外推。

时间上还需区分：Luke–Thao–Tam 2018 Proposition 2.3 已把 pointwise a\(1/2\)-FNE 转成一端 anchored 的同型 graph inequality；Luke–Tam 2023 RAMP 扩展摘要是 2025 期刊文自述的早期版本。故“all-pairs class 的完整期刊处理”和“该公式思想首次出现”不是同一个时间点 **[VERIFIED_SOURCE at full-text/reference-list level]**。

### 2.3 Otero–Iusem semimonotone convention

Otero–Iusem 2011 使用

\[
\tag{2.7}
\langle a,c\rangle
\ge-\frac{\varrho}{2}(\|a\|^2+\|c\|^2),
\qquad \varrho\in(0,1).
\]

对于 \(L>1\)，(2.3) 与其精确一致，参数为

\[
\tag{2.8}
\varrho=\frac{L^2-1}{L^2+1},
\qquad -\frac{\varrho}{2}=\theta_L.
\]

该文同时强调 Hilbert/set-valued 语境及自对偶/逆映射相关正则性。它是 \(\gamma=1,L>1\) 的直接等价先例之一 **[VERIFIED_SOURCE + AI_INFERENCE]**。

### 2.4 三个 \(L\) 区间

| RL 参数 | 精确 graph 含义 | reflected resolvent | 既有理论位置 |
|---|---|---|---|
| \(0<L<1\) | \(\theta_L>0\) | contraction | positive equal-parameter semimonotonicity；同时给 strong monotonicity 与 cocoercivity 下界 |
| \(L=1\) | \(\theta_L=0\) | nonexpansive | ordinary monotonicity / Minty–Cayley 对应 |
| \(L>1\) | \(\theta_L<0\) | Lipschitz expansive allowed | Luke–Tam submonotonicity；Otero–Iusem negative semimonotone convention；negative equal-parameter semimonotonicity |

因此，**不能以完整 \(\gamma\in(0,1]\) 家族的定义掩盖 \(\gamma=1\) 分支已有精确理论这一事实**。

---

## 3. \(0<\gamma<1\)：与邻近理论的公式级比较

### 3.1 一般 Hölder mapping 是最直接的先例威胁

Barroso 2023 的 map-side 定义包含

\[
\tag{3.1}
d(Tx,Ty)\le Ld(x,y)^\alpha.
\]

令 \(T=R_{\lambda F}\)、\(\alpha=\gamma\)，式 (3.1) 就是 RL 的 reflected-resolvent 表述。原文研究的是一般 Hölder-contractive mappings、extension/fixed-point 问题；其核心 fixed-point 设置包含 bounded closed convex sets，不能把那些定理直接外推为无界 Hilbert-domain 结果。本轮没有在该文中发现它把 (3.1) 经 Minty pullback 定义为新的 generalized-monotonicity 类 **[VERIFIED_SOURCE]**。

因此证据应分成两层：

- “\(R\) 是 \(\gamma\)-Hölder map”已有直接文献 **[VERIFIED_SOURCE]**；
- “将这种 map property 拉回 operator graph 后建立 RL calculus/算法理论”是否已有系统先例，仍待扩大检索 **[PENDING_VERIFICATION]**。

### 3.2 Local / bounded / anchored 变体

若 \(D\) 的直径不超过 \(\Delta\)，则任何 \(K\)-Lipschitz \(R:D\to H\) 都满足

\[
\tag{3.2}
\|Rx-Ry\|\le K\Delta^{1-\gamma}\|x-y\|^\gamma.
\]

所以在有界 restricted Minty range 上，\(\gamma<1\) 可能只是既有 Lipschitz 结果的弱化重写。要证明 exponent 有内容，至少需要：

1. \(R\) 在目标点附近并非 Lipschitz；
2. \(\gamma\) 是 sharp Hölder exponent；
3. 清楚区分 all-pairs、local pairwise 和 anchored-at-solution 三种量词。

Luke–Thao–Tam 2018 Proposition 2.3 的 pointwise a\(1/2\)-FNE 对应于如下 anchored graph 形式：一端 Minty 输入在 \(U\)，另一端在 base set \(S\)，并有

\[
-\frac{\varepsilon}{2}
\|(u+u^+)-(v+v^+)\|^2
\le \langle u-v,u^+-v^+\rangle.
\]

所以它对 **\(\gamma=1\) anchored/restricted 量词是 exact predecessor**，而对本任务的 all-pairs Hölder RL 仍只是邻接先例。Luke–Tam 2025 则把 restricted graph 的 all-pairs submonotonicity系统化 **[VERIFIED_SOURCE]**。

另有 Moursi–Vanderwerff 2025 官方摘要明确涉及 maximally monotone operators 在 bounded sets / at each point 的 uniform monotonicity 与相应 nonexpansiveness notions。官方页还把 `Reflection operator` 列作关键词，参考文献包含 weakly contractive mappings；但公开预览中检索 `Hölder` 与 `Definition` 均无正文命中，全文仍不可访问。因此这些线索只提高核验优先级，不能据此推断其 modulus 已覆盖 Hölder Cayley 形式 **[PENDING_VERIFICATION]**。

### 3.3 Global \(\gamma<1\) 与 Lipschitz 不可按单轴排序

在无界域上，\(t\le Kt^\gamma\) 对 \(t\to\infty\) 不可能统一成立。因此，一个非零线性 reflected resolvent 即使是 contraction，也通常不满足 global \(\gamma<1\) RL。例如 \(A=\alpha I\) 且 \(\alpha\ne1\) 时，\(R_A=((1-\alpha)/(1+\alpha))I\)，它是 Lipschitz contraction，却不是任一 global \(\gamma<1\) Hölder map。

反过来，\(\gamma<1\) Hölder 控制在 \(t\downarrow0\) 比 Lipschitz 弱。因此 local 与 global 下的“强弱”方向不同；\(\gamma<1\) 不能简单称作“更弱 monotonicity”而不说明尺度和 domain **[AI_INFERENCE]**。

### 3.4 Uniform monotonicity / power type 并非等价结构

若 maximally monotone \(A\) 具有 uniform monotonicity modulus \(\phi\)：

\[
\langle a,c\rangle\ge\phi(\|a\|),
\]

对 \(s=x-y\)、\(r=R_Ax-R_Ay\) 有 \(a=(s+r)/2,c=(s-r)/2\)，故

\[
\tag{3.3}
\|s\|^2-\|r\|^2
\ge4\phi\!\left(\frac12\|s+r\|\right)
=4\phi(\|J_Ax-J_Ay\|).
\]

Liu–Moursi–Vanderwerff 2023 对 uniform monotonicity、strong nonexpansiveness 及 operator splitting 给出系统对应；式 (3.3) 是其核心 deficit geometry 的同类表达 **[VERIFIED_SOURCE]**。但它控制的是以 \(J_A\) increment 为自变量的**平方差 deficit**，不是 \(\|r\|\le L\|s\|^\gamma\) 的 absolute Hölder envelope。

若进一步有 power-type lower bound

\[
\tag{3.4}
\langle a,c\rangle\ge m\|a\|^p,
\qquad p>1,
\]

Cauchy–Schwarz 给出

\[
\tag{3.5}
\|a\|\le m^{-1/(p-1)}\|c\|^{1/(p-1)}.
\]

这是 \(A^{-1}\) 的 Hölder control，而不是 \(R_A\) 的 Hölder control；两者坐标不同，不能当作等价先例。强/均匀单调也不保证 global \(\gamma<1\) RL：线性 \(A=\alpha I\) 已提供反例，除特殊 \(R_A=0\) 情形外 **[AI_INFERENCE]**。

### 3.5 Comonotonicity 只给 \(\gamma=1\) 的充分界

若 \(F\) 为 \(\beta\)-comonotone，采用

\[
\tag{3.6}
\langle a,b\rangle\ge\beta\|b\|^2,
\]

则对 \(c=\lambda b\) 有 \(\langle a,c\rangle\ge(\beta/\lambda)\|c\|^2\)。Bauschke–Moursi–Wang 将这类 generalized monotonicity 与 conically averaged resolvents 联系起来 **[VERIFIED_SOURCE]**。当 \(\beta>-\lambda\) 时，直接在 Cayley 坐标中优化可得类级 sharp 的 gamma1 保证

\[
\tag{3.7}
\|R_{\lambda F}x-R_{\lambda F}y\|
\le
\begin{cases}
\|x-y\|, & \beta\ge0,\\[2mm]
\dfrac{\lambda-\beta}{\lambda+\beta}\|x-y\|,
&-\lambda<\beta<0.
\end{cases}
\]

式 (3.7) 是 (3.6) 的充分 envelope，不是 RL tied graph inequality的反向等价：comonotonicity只控制 \(\|b\|^2\) 一侧，而 gamma1 RL 同时控制 \(\|a\|^2\) 与 \(\|b\|^2\)。它也不推出无界域上的 global \(\gamma<1\) RL；线性 \(F=\alpha I\) 已说明这一点。故 comonotone/power-type 理论属于 gamma1 exact neighborhood 或 gamma<1 adjacency，而不是同一结构 **[AI_INFERENCE]**。

### 3.6 Ordinary resolvent 的 Hölder 结果

Huang–Peng–Tang 2025 arXiv 预印本题为 *Hölder property of the resolvent of a monotone operator in Banach spaces*。其对象是 Banach 空间 duality-map resolvent，在 bounded balls 上由空间光滑性/凸性得到 Hölder 性；不是 Hilbert reflected resolvent 的式 (1.2)。它是术语和技术上的邻接文献，但不是 exact RL 先例 **[VERIFIED_SOURCE at abstract/preprint level]**。

---

## 4. 检索协议与 query log

### 4.1 协议

| 项目 | 本轮做法 |
|---|---|
| 日期 | 2026-09-01 |
| 检索入口 | 平台原生 web search；无第三方 API |
| 语言 | 以英文公式/术语为主；未设语言排除 |
| 年份 | 不设起始年；同时专项检索 2024–2026 邻近论文 |
| 来源过滤 | 优先出版社官网、期刊官网、Project Euclid、AMS、arXiv/作者稿；聚合页只作为发现线索，不作为结论证据 |
| 公式策略 | exact fragments、去 LaTeX 变体、\(x-y\pm\lambda(u-v)\) 变体、Cayley/Minty/reflected-resolvent 变体、graph inner-product 变体 |
| 概念策略 | Hölder maps、local/pointwise/restricted、uniform monotonicity、power type、inverse Hölder、semimonotonicity、submonotonicity、conically averaged resolvents |
| 命中数 | 平台未提供稳定可复现总命中数，故不伪造 counts |
| 纳入标准 | 原文出现同式，或通过一至两步明确代数得到同式；并记录额外假设/domain/量词 |
| 排除标准 | 仅有 “Hölder”“Cayley”“resolvent”同词，但对象为 PDE coefficient、semigroup approximation、matrix/spectral Cayley、量子变换或 metric-regularity residual，且无 operator-graph 对应 |
| access depth | `FULL_TEXT_OFFICIAL`、`FULL_TEXT_PRIMARY_PREPRINT`、`OFFICIAL_ABSTRACT_METADATA`、`BIBLIOGRAPHIC_ONLY`、`PENDING_FULL_TEXT` |

### 4.2 公式与符号变体查询

以下查询均在 **2026-09-01** 通过同一平台原生 web search 执行；过滤均为 primary/official source 优先。表中“结果”是筛查摘要，不代表穷尽性。

| ID | Query（原样或等价输入） | 主要目的 / 结果 |
|---:|---|---|
| Q01 | `"Hölder continuous" "reflected resolvent" operator` | exact phrase；无同式 operator hit，出现邻近 resolvent/nonexpansive 结果 |
| Q02 | `"Hölder continuity" "reflected resolvent"` | 同上；无 exact gamma<1 hit |
| Q03 | `"Hölder" "Cayley transform" monotone operator` | Cayley 变体；大量线性/谱论噪声，无同式 hit |
| Q04 | `"reflected proximal" Hölder continuous` | reflected proximal 变体；无同式 hit |
| Q05 | `"a - λb" "a + λb" monotone operator` | exact symbolic fragment；无可核验原文命中 |
| Q06 | `"a-lambda b" "a+lambda b" monotonicity` | ASCII 公式；无可核验原文命中 |
| Q07 | `"x-y-λ(u-v)" operator` | graph-difference 变体；无 exact hit |
| Q08 | `"x-y+λ(u-v)" "Hölder"` | paired graph coordinate；无 exact hit |
| Q09 | `"x-y-(u-v)" "x-y+(u-v)"` | \(\lambda=1\) 展开；无 gamma<1 hit |
| Q10 | `"x-y-u+v" "x-y+u-v" monotone` | 去括号变体；无 gamma<1 hit |
| Q11 | `"u-v" "x-y" "reflected resolvent" Hölder` | input/output increment 变体；无 exact hit |
| Q12 | `"u-v" "x-y" "Cayley transform" monotone graph` | Cayley graph；命中经典概念，未命中 Hölder RL |
| Q13 | `"x+x*" "x-x*" Hölder monotone` | Minty coordinate 变体；无 exact hit |
| Q14 | `"Minty transform" "Hölder" monotone map` | Minty/Hölder；邻近历史文献，无 exact operator class |
| Q15 | `"Minty transformation" "Hölder" graph monotone` | 同上 |
| Q16 | `"Cayley transformation" graph "Hölder" monotone` | 同上 |
| Q17 | `"Minty parametrization" "Hölder continuous" operator` | parameterization；无同式系统理论 hit |
| Q18 | `"Minty parameterization" Hölder continuous` | 美式拼写；无同式 hit |
| Q19 | `"Cayley graph" Hölder operator` | 图旋转；无 exact hit |
| Q20 | `"Cayley transform" Hölder accretive operator resolvent` | accretive 变体；无 exact hit |
| Q21 | `"reflected resolvent" "Hölder-Lipschitz"` | 术语变体；无 exact hit |
| Q22 | `"reflected resolvent" "Hölder nonexpansive"` | 术语变体；无 exact hit |
| Q23 | `"Cayley operator" Hölder monotone mapping` | 术语变体；无 exact hit |
| Q24 | `"Hölder continuous reflected resolvent" optimization` | 完整短语；无 exact hit |
| Q25 | `"reflected resolvent" "Hölder" monotone operator` | 较宽 formula concept；无 exact hit |
| Q26 | `"Cayley transform" "Hölder continuous" maximal monotone operator` | maximality 变体；无 exact hit |
| Q27 | `"reflected proximal mapping" "Hölder"` | proximal 变体；无 exact hit |
| Q28 | `"Minty parametrization" "Hölder" operator` | 组合查询；无 exact hit |

### 4.3 一般 Hölder-map / local / anchored 查询

| ID | Query | 主要目的 / 结果 |
|---:|---|---|
| Q29 | `"Hölder nonexpansive" mapping operator` | 命中一般 map-side 文献 |
| Q30 | `"α-Hölder nonexpansive" mapping fixed point` | 一般 Hölder nonexpansive 术语 |
| Q31 | `"Hölder nonexpansive maps" Banach` | Banach fixed-point 邻近文献 |
| Q32 | `"Hölder-contractive mappings" fixed point` | 命中 Barroso 2023 |
| Q33 | `"Hölder nonexpansive type mappings"` | 命中 Barroso–da Silva 2026 预印本 |
| Q34 | `"pointwise Hölder" "fixed point" mapping` | anchored/pointwise；无 operator-RL exact hit |
| Q35 | `"Hölder calmness" fixed point mapping` | regularity-side 同词；与 RL 坐标不同 |
| Q36 | `"Hölder continuous at fixed points" iteration` | anchored 变体；无 exact graph class |
| Q37 | `"Hölder almost nonexpansive"` | almost-nonexpansive 变体；无 exact hit |
| Q38 | `"almost firmly nonexpansive" Hölder` | Luke 系列邻近框架，gamma1/violation 为主 |
| Q39 | `"almost nonexpansive" Hölder mapping` | 同上；无 exact gamma<1 operator class |
| Q40 | `"Hölder firmly nonexpansive"` | 无可核验 exact RL hit |
| Q41 | `"Hölder continuous" proximal mapping set-valued` | 普通 proximal map continuity，非 reflected graph condition |
| Q42 | `"Hölder continuity" "proximal mapping"` | 同上 |
| Q43 | `"Hölder continuous" "proximal map" optimization` | 同上 |
| Q44 | `"Hölder" "reflected proximal mapping"` | reflected 变体；无 exact hit |

### 4.4 Semimonotonicity / uniform monotonicity / power-type 查询

| ID | Query | 主要目的 / 结果 |
|---:|---|---|
| Q45 | `submonotone modulus "u+u*" operator` | graph modulus；Luke–Tam 邻近，无 gamma<1 exact hit |
| Q46 | `generalized submonotonicity modulus "a+b"` | variable modulus；无 exact hit |
| Q47 | `"semimonotone" "reflected resolvent"` | 命中 semimonotonicity/resolvent 邻近文献 |
| Q48 | `"semimonotonicity" "reflected resolvent"` | 同上 |
| Q49 | `"(μ,ρ)-semimonotone" resolvent` | 命中 Evens et al. |
| Q50 | `"reflected resolvent" Lipschitz semimonotone` | gamma1 exact neighborhood |
| Q51 | `"Cayley operator" Lipschitz generalized monotonicity` | gamma1 邻近 |
| Q52 | `"Lipschitz reflected resolvent" monotonicity` | Luke–Tam / splitting adjacency |
| Q53 | `"reflected resolvent" submonotone` | Luke–Tam exact gamma1 |
| Q54 | `"Hölder semimonotone" operator` | 无同式可核验 hit |
| Q55 | `"Hölder submonotone" mapping` | 无同式可核验 hit |
| Q56 | `"power semimonotone" operator` | 无同式 hit；power monotonicity邻近 |
| Q57 | `"nonlinear semimonotonicity" operator modulus` | 邻近非线性 modulus；无 exact Cayley Hölder hit |
| Q58 | `"uniformly monotone" "reflected resolvent"` | 命中 uniform monotonicity/strong nonexpansiveness 文献 |
| Q59 | `"uniform monotonicity" "Cayley operator"` | 同上，Cayley 同词噪声较多 |
| Q60 | `"power type" resolvent monotone operator Hölder` | ordinary resolvent/inverse邻近 |
| Q61 | `"uniformly monotone operators" "Hölder continuous" inverse` | inverse-side Hölder |
| Q62 | `"uniformly monotone" "inverse" Hölder operator power` | inverse-side Hölder |
| Q63 | `"p-uniformly monotone" "Hölder continuous inverse"` | power inverse；未形成 RL 等价 |
| Q64 | `"power type" "uniform monotonicity" inverse operator` | 同上 |
| Q65 | `"uniformly monotone" "uniformly continuous inverse" operator` | 命中 Liu–Moursi–Vanderwerff 结论链 |
| Q66 | `"On Further Notions of Strong Nonexpansiveness and Corresponding Notions of Monotonicity"` | 命中 Moursi–Vanderwerff 2025 官方页；全文未得 |
| Q67 | `"The computational content of super strongly nonexpansive mappings and uniformly monotone operators"` | 命中 Sipoş 2026 官方页/arXiv |

### 4.5 Bibliography / DOI / status 查询

| ID | Query | 主要目的 / 结果 |
|---:|---|---|
| Q68 | `"Generalized Monotonicity and the Proximal Point Algorithm" DOI` | 核验 Luke–Tam 官方书目信息 |
| Q69 | `"Regularity results for semimonotone operators" DOI` | 核验 Otero–Iusem DOI/venue |
| Q70 | `"Convergence of the preconditioned proximal point method" DOI` | 核验 Evens et al. DOI/venue |
| Q71 | `"Hölder-contractive mappings, nonlinear extension problem and fixed point free results" DOI` | 核验 Barroso DOI/venue |
| Q72 | `"Strongly Nonexpansive Mappings Revisited" DOI` | 核验 Liu et al. DOI/venue |
| Q73 | `"Hölder property of the resolvent of a monotone operator in Banach spaces"` | 核验预印本状态 |
| Q74 | `"On the extension of Lipschitz, Lipschitz-Hölder continuous, and monotone functions" DOI` | 核验 Minty 1970 历史文献 |
| Q75 | `"Generalized monotone operators and their averaged resolvents" DOI` | 核验 Bauschke–Moursi–Wang |
| Q76 | `"Douglas-Rachford Splitting for the Sum of a Lipschitz Continuous and a Strongly Monotone Operator" DOI` | 核验 Moursi–Vandenberghe |
| Q77 | `correction OR corrigendum OR retraction "Generalized Monotonicity and the Proximal Point Algorithm"` | 可见 notice 检查；未见命中，不是正式无撤稿证明 |
| Q78 | `correction OR corrigendum OR retraction "Regularity results for semimonotone operators"` | 同上 |
| Q79 | `correction OR corrigendum OR retraction "Hölder-contractive mappings"` | 同上 |
| Q80 | `correction OR corrigendum OR retraction "Strongly Nonexpansive Mappings Revisited"` | 同上 |
| Q81 | `correction OR corrigendum OR retraction "Generalized monotone operators and their averaged resolvents"` | 同上 |

补充说明：平台搜索的排序和 snippet 不是稳定数据库记录；本报告没有用“第几页仍无命中”制造伪精确性。

### 4.6 补充定向检索与官方页内核验

| ID | Query / action | 结果与 access depth |
|---:|---|---|
| Q82 | `site:arxiv.org OR site:uwaterloo.ca "On Further Notions of Strong Nonexpansiveness and Corresponding Notions of Monotonicity" pdf` | 未找到作者公开全文；`PENDING_FULL_TEXT` |
| Q83 | `site:projecteuclid.org "On the extension of Lipschitz, Lipschitz-Hölder continuous, and monotone functions"` | 核验 Minty 1970 issue record；`OFFICIAL_METADATA` |
| Q84 | `site:pubsonline.informs.org/doi/10.1287/moor.2025.0863 "Generalized Monotonicity"` | 核验 S01 全文、日期、早期 RAMP reference；`FULL_TEXT_OFFICIAL` |
| Q85 | `site:arxiv.org/abs/2207.03057 "Hölder-contractive mappings"` | 核验 Barroso 摘要及 general Hölder-map formula；`FULL_TEXT_PRIMARY_PREPRINT` |
| Q86 | `site:ams.org/bull/1970-76-02/S0002-9904-1970 "On the extension of Lipschitz"` | 核验 AMS stable PDF identifier `S0002-9904-1970-12466-1` |
| Q87 | `site:doi.org "On the extension of Lipschitz, Lipschitz-Hölder continuous, and monotone functions" Minty` | 交叉核验题名/引用；未用聚合结果作公式证据 |
| Q88 | `"On Further Notions of Strong Nonexpansiveness" pdf` | 仅得出版社订阅页/聚合线索，无公开全文 |
| Q89 | `"On Further Notions of Strong Nonexpansiveness" "Lambert W"` | 出版社预览 notes 可见 Lambert W，但无 theorem context；不作内容推断 |
| Q90 | `site:uwaterloo.ca "uniformly monotone at each point" Moursi Vanderwerff` | 未得作者稿 |
| Q91 | `"uniformly monotone at each point" "reflection operator"` | 回到官方摘要/相关论文；未得 exact RL 公式 |
| A01 | Open S10 official article page | 核验 abstract、DOI、日期、`Reflection operator` keyword、subscription barrier；`OFFICIAL_ABSTRACT_METADATA` |
| A02 | Open S10 direct PDF URL | 重定向 subscription preview；未取得正文 |
| A03 | Find `Hölder` within accessible S10 preview | 无匹配；仅说明公开预览未出现，不说明全文没有 |
| A04 | Find `reflection` within accessible S10 preview | 命中 keyword `Reflection operator`，无 theorem text |
| A05 | Find `weakly contractive` within accessible S10 preview | 命中参考文献与 Lambert-W note，正文 context 不可见 |
| A06 | Find `Definition` within accessible S10 preview | 无匹配，确认不是可检索全文 |
| A07 | Open arXiv:2205.09040 official record | 核验作者为 Leon Liu、Walaa M. Moursi、Jon Vanderwerff及摘要中的 reflected-resolvent scope |
| A08 | Open arXiv:2510.03774 and arXiv:2605.30678 official records | 核验作者、提交日期、版本及 abstract scope |

---

## 5. Primary-source ledger：来源、书目信息与 access depth

| ID | Primary/official source | 已核验 bibliographic facts | 本任务使用内容 | Access depth | 可见 correction/retraction 状态（截至 2026-09-01） |
|---|---|---|---|---|---|
| S01 | D. R. Luke, M. K. Tam, [*Generalized Monotonicity and the Proximal Point Algorithm*](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863) | *Mathematics of Operations Research*, online 2025-11-21；DOI `10.1287/moor.2025.0863` | Def. 2 submonotonicity；Prop. 4 restricted resolvent/aFNE/reflected Lipschitz；inverse invariance与 examples | `FULL_TEXT_OFFICIAL` | 官方页未见 notice；title+status 定向查询未见命中。非 Crossmark/撤稿库证明 |
| S02 | D. R. Luke, N. H. Thao, M. K. Tam, [*Quantitative Convergence Analysis of Iterated Expansive, Set-Valued Mappings*](https://pubsonline.informs.org/doi/10.1287/moor.2017.0898) | *Mathematics of Operations Research* 43(4), 1143–1176 (2018)；online 2018-07-27；DOI `10.1287/moor.2017.0898` | pointwise/restricted almost nonexpansive/averaged 与 gauge metric subregularity框架 | `FULL_TEXT_OFFICIAL` | 官方页未见 notice；未作注册库级认证 |
| S03 | R. Gárciga Otero, A. Iusem, [*Regularity results for semimonotone operators*](https://www.scielo.br/j/cam/a/TDWFt7WPXgSTwXPnCt8rYdy/abstract/?lang=en)；[full report/PDF](https://webdoc.sub.gwdg.de/ebook/serien/e/IMPA_A/672.pdf) | *Computational & Applied Mathematics* 30(1), 5–17 (2011)；DOI `10.1590/S1807-03022011000100002` | Hilbert/set-valued semimonotone定义、自对偶与 regularity | `FULL_TEXT_PRIMARY` + `OFFICIAL_METADATA` | 官方页未见 notice；定向查询未见命中，非正式状态证明 |
| S04 | L. Evens, P. Pas, P. Latafat, P. Patrinos, [official journal page](https://link.springer.com/article/10.1007/s10107-024-02182-0)；[full preprint](https://arxiv.org/pdf/2305.03605) | *Mathematical Programming* 214, 247–301 (2025)；online 2025-02-04；DOI `10.1007/s10107-024-02182-0` | \((\mu,\rho)\)-semimonotonicity、inverse/scaling、resolvent characterization | `FULL_TEXT_PRIMARY_PREPRINT` + `OFFICIAL_METADATA` | 官方页未见 notice；未作注册库级认证 |
| S05 | C. S. Barroso, [arXiv full text](https://arxiv.org/pdf/2207.03057)；[publisher page](https://www.sciencedirect.com/science/article/abs/pii/S0022247X23005243) | *Journal of Mathematical Analysis and Applications* 528(1), article 127521 (2023)；DOI `10.1016/j.jmaa.2023.127521` | 一般 \(L\)-Hölder map 的直接定义与 fixed-point/extension 语境 | `FULL_TEXT_PRIMARY_PREPRINT` + `OFFICIAL_METADATA` | 出版页/定向查询未见 notice；非撤稿状态证明 |
| S06 | C. S. Barroso, C. S. R. da Silva, [*Fixed point results for asymptotically Hölder nonexpansive type mappings*](https://arxiv.org/abs/2605.30678) | arXiv:2605.30678v1，submitted 2026-05-29 | 2026 年最新 map-side 邻近术语 | `FULL_TEXT_PRIMARY_PREPRINT` | arXiv 页面未标 withdrawn；无 journal DOI |
| S07 | G. J. Minty, [*On the extension of Lipschitz, Lipschitz-Hölder continuous, and monotone functions*](https://projecteuclid.org/journals/bulletin-of-the-american-mathematical-society/volume-76/issue-2/On-the-extension-of-Lipschitz-Lipschitz-H%C3%B6lder-continuous-and-monotone/bams/1183531485.pdf) | *Bulletin of the AMS* 76(2), 334–339 (1970)；DOI `10.1090/S0002-9904-1970-12466-1` | 历史上的 Hölder/Lipschitz extension 与 monotone functions 邻接 | `BIBLIOGRAPHIC_ONLY`（本轮 PDF 渲染受限） | 历史记录未见 notice；内容细节不据题名外推 |
| S08 | G. J. Minty, [*Monotone (nonlinear) operators in Hilbert space*](https://projecteuclid.org/journals/duke-mathematical-journal/volume-29/issue-3/Monotone-nonlinear-operators-in-Hilbert-space/10.1215/S0012-7094-62-02933-2.short) | *Duke Mathematical Journal* 29(3) (1962)；官方 Project Euclid record | 经典 Minty parameterization/Cayley graph 基础 | `OFFICIAL_ABSTRACT_METADATA` / classical record | 未见 notice；不作 registry-level 声明 |
| S09 | L. Liu, W. M. Moursi, J. Vanderwerff, [official SIAM page](https://epubs.siam.org/doi/10.1137/22M1501696)；[full preprint](https://arxiv.org/pdf/2205.09040) | *SIAM Journal on Optimization* 33(4), 2570–2597 (2023)；online 2023-10-11；DOI `10.1137/22M1501696` | uniform monotonicity、super strong nonexpansiveness、reflected-resolvent deficit、inverse uniform continuity | `FULL_TEXT_PRIMARY_PREPRINT` + `OFFICIAL_METADATA` | 官方页/定向查询未见 notice；非注册库证明 |
| S10 | W. M. Moursi, J. Vanderwerff, [*On Further Notions of Strong Nonexpansiveness and Corresponding Notions of Monotonicity*](https://link.springer.com/article/10.1007/s10957-025-02633-4) | *Journal of Optimization Theory and Applications* 205, article 50 (2025)；published 2025-04-18；DOI `10.1007/s10957-025-02633-4` | bounded-set / pointwise uniform monotonicity与nonexpansiveness（仅摘要核验）；官方关键词含 `Reflection operator` | `PENDING_FULL_TEXT` | 官方页未见 notice；全文未核验，风险保持开放 |
| S11 | A. Sipoş, [official page](https://link.springer.com/article/10.1007/s11856-025-2824-0)；[arXiv](https://arxiv.org/abs/2303.02768) | *Israel Journal of Mathematics* 272, 437–465 (2026)；version of record 2025-09-29；DOI `10.1007/s11856-025-2824-0` | quantitative moduli for super strongly nonexpansive/uniformly monotone operators | `FULL_TEXT_PRIMARY_PREPRINT` + `OFFICIAL_METADATA` | 官方页未见 notice；非注册库证明 |
| S12 | H. H. Bauschke, W. M. Moursi, X. Wang, [official page](https://link.springer.com/article/10.1007/s10107-020-01500-6)；[preprint](https://arxiv.org/pdf/1902.09827) | *Mathematical Programming* 189, 55–74 (2021)；online 2020-04-25；DOI `10.1007/s10107-020-01500-6` | generalized monotonicity、comonotonicity 与 conically averaged resolvents | `FULL_TEXT_PRIMARY_PREPRINT` + `OFFICIAL_METADATA` | 官方页/定向查询未见 notice；非注册库证明 |
| S13 | W. M. Moursi, L. Vandenberghe, [*Douglas–Rachford Splitting for the Sum of a Lipschitz Continuous and a Strongly Monotone Operator*](https://link.springer.com/article/10.1007/s10957-019-01517-8) | *Journal of Optimization Theory and Applications* 183, 179–198 (2019)；published 2019-04-27；DOI `10.1007/s10957-019-01517-8` | reflected resolvent Lipschitz/contraction sufficient classes，gamma1 | `OFFICIAL_ABSTRACT_METADATA` | 官方页未见 notice；非注册库证明 |
| S14 | C. Huang, J. Peng, Y. Tang, [*Hölder property of the resolvent of a monotone operator in Banach spaces*](https://arxiv.org/abs/2510.03774) | arXiv:2510.03774v1，submitted 2025-10-04 | ordinary Banach resolvent 的 bounded-ball Hölder property | `FULL_TEXT_PRIMARY_PREPRINT` | arXiv 页面未标 withdrawn；无已核验 journal DOI |
| S15 | D. R. Luke, M. K. Tam, *Generalized monotonicity and the proximal point algorithm* | *Proceedings of the 35th RAMP Symposium*, Research Association of Mathematical Programming, Tokyo, 39–48 (2023)；书目信息由 S01 的作者参考文献表核验 | S01 自述其为早期 extended abstract；不据此单独外推全部公式 | `BIBLIOGRAPHIC_ONLY_FROM_PRIMARY_REFERENCE_LIST` | 未找到独立官方全文/notice；仅作时间线记录 |

---

## 6. 候选筛选 / 排除表

| 候选 | 筛选等级 | 纳入理由 | 必须排除或限制的过强解释 |
|---|---|---|---|
| Luke–Tam 2025 | **EXACT, \(\gamma=1,L\ge1\)** | 原文 graph inequality + reflected Lipschitz；参数精确换算 (2.6) | Prop. 4 的 \(\tau<1/2\)、restricted domain 不能删除；不覆盖 gamma<1 |
| Evens et al. 2025 | **EQUIVALENT, \(\gamma=1\)** | tied \((\mu,\rho)\) slice 精确重写 | 原文一般二维参数族不等于 RL 一维 tied curve；有限维算法结论不自动扩展 Hilbert |
| Otero–Iusem 2011 | **EQUIVALENT, \(\gamma=1,L>1\)** | equal negative semimonotone 形式精确换算 | 其术语/参数 convention 不能未经换算混用 |
| Minty 1962 | **EQUIVALENT FOUNDATION, \(\gamma=1,L=1\)** | monotone graph ↔ nonexpansive Cayley 是经典基础 | 不能称其直接研究 gamma<1 RL |
| Barroso 2023 | **FORMULA-EQUIVALENT MAP SIDE** | 一般 \(\gamma\)-Hölder map 公式就是 R-side RL | 原文未把它命名/系统化为 reflected-resolvent operator class；pullback 是本任务 inference |
| Luke–Thao–Tam 2018 | **EXACT ANCHORED \(\gamma=1\) / ADJACENT ALL-PAIRS** | Prop. 2.3 的 pointwise aFNE 对应同型 anchored graph inequality | pointwise base-pair 不等于 all-pairs Hölder；不覆盖 gamma<1 |
| Luke–Tam 2023 RAMP abstract | **BIBLIOGRAPHIC PREDECESSOR** | S01 明示为其早期 extended abstract | 未取得独立全文，不能把 2025 全部定义/定理倒推到 2023 |
| Liu–Moursi–Vanderwerff 2023 | **ADJACENT MODULUS** | uniform monotonicity ↔ strong nonexpansiveness，精确 deficit geometry | deficit modulus不等于 absolute Hölder envelope |
| Moursi–Vanderwerff 2025 | **ADJACENT / UNRESOLVED THREAT** | 摘要涉及 bounded sets / at each point 的 nonlinear notions | 全文未核，不能判断是否已有同式或等价 modulus |
| Sipoş 2026 | **ADJACENT QUANTITATIVE** | quantitative moduli for uniform mono/strong nonexpansiveness | 不等于 RL；需全文公式级比较后才能进一步降级风险 |
| Huang–Peng–Tang 2025 | **ADJACENT RESOLVENT** | 标题和正文研究 resolvent Hölder | ordinary Banach resolvent，不是 Hilbert reflected resolvent；bounded-ball geometry |
| Bauschke–Moursi–Wang 2021 | **ADJACENT \(\gamma=1\)** | comonotonicity ↔ conically averaged resolvents | quadratic homogeneous/Lipschitz geometry，不覆盖 gamma<1 exact formula |
| Moursi–Vandenberghe 2019 | **ADJACENT \(\gamma=1\)** | reflected resolvent contraction/Lipschitz for structured sums | sufficient subclass，不是 RL 定义等价族 |
| Barroso–da Silva 2026 | **ADJACENT MAP SIDE** | recent asymptotic Hölder nonexpansive terminology | asymptotic iterates，不是 operator graph Cayley class |
| Minty 1970 | **HISTORICAL ADJACENT** | Hölder/Lipschitz extension + monotone functions in title/record | 本轮未读到全文公式，不能据题名声称覆盖 RL |
| PDE “resolvent estimates with Hölder coefficients” | **UNRELATED / EXCLUDED** | 同词命中 | Hölder 修饰 coefficient/domain regularity，不是 mapping increment inequality |
| Semigroup/rational Cayley approximation | **UNRELATED / EXCLUDED** | Cayley + resolvent 同词 | 研究线性生成元近似/谱，不是 graph monotonicity |
| Matrix/quantum Cayley transform Hölder estimates | **UNRELATED / EXCLUDED** | Cayley + Hölder 同词 | 不属于 set-valued operator resolvent geometry |
| Hölder metric subregularity of \(I-T\) | **UNRELATED TO EXACT PRIOR ART** | 与算法 regularity 相关 | 控制 \(d(x,\operatorname{Fix}T)\) 与 residual，不是 pairwise \(R\) Hölder；可在综合任务另比较 |
| 单纯 “Hölder's inequality + resolvent” 命中 | **UNRELATED / EXCLUDED** | 搜索词形碰撞 | Hölder 是不等式人名，不是 continuity exponent |

---

## 7. Exact / equivalent / adjacent / unrelated 四级矩阵

等级定义：

- **EXACT**：原文在同一 operator/reflected-resolvent 语境给出同式（允许显式参数重命名）；
- **EQUIVALENT**：原文定义经透明可逆代数变换得到同式，但未必用 RL 名称；
- **ADJACENT**：共享一个坐标、modulus 或算法机制，但存在方向/domain/量词/指数结构差异；
- **UNRELATED**：只有关键词重合，没有数学映射。

| 数学块 | EXACT | EQUIVALENT | ADJACENT | UNRELATED / 排除 |
|---|---|---|---|---|
| \(\gamma=1,L>1\) all-pairs graph | Luke–Tam 2025 restricted-graph submonotonicity + reflected Lipschitz | Otero–Iusem negative semimonotonicity；Evens tied negative semimonotonicity | hypomonotonicity/cohypomonotonicity sufficient bounds；structured DRS reflected Lipschitz | PDE resolvent estimates |
| \(\gamma=1,L=1\) | 经典 monotone/reflected nonexpansive 对应（在 standard maximal/restricted domain assumptions 下） | Minty Cayley parameterization | conically averaged resolvents | matrix Cayley numerics |
| \(\gamma=1,0<L<1\) | 未发现用 RL 名称的必要先例 | Evens tied positive semimonotonicity；strong mono+cocoercive equal-parameter slice | contraction results for structured operators | semigroup Cayley approximation |
| \(0<\gamma<1\), R-side | Barroso 公式在**一般 mapping**层面 exact；非 operator-specific | 通过 classical Cayley pullback 得 RL graph，连接为本任务 **[AI_INFERENCE]** | asymptotic Hölder maps；ordinary resolvent Hölder | Hölder coefficients/PDE |
| \(0<\gamma<1\), operator graph 内积式 (1.4) | **本轮未检到可访问原文** | 未检到已核验来源 | nonlinear/uniform monotonicity modulus；power inverse Hölder | Hölder’s inequality hits |
| local/restricted pairwise | gamma1 Luke–Tam restricted theory | bounded-domain Lipschitz \(\Rightarrow\) Hölder（elementary） | Moursi–Vanderwerff bounded-set notions（全文待核） | global-only spectral results |
| anchored/at-solution | Luke–Thao–Tam 2018 给出 gamma1 pointwise aFNE ↔ 同型 anchored graph inequality | pairwise RL \(\Rightarrow\) anchored Hölder（单向） | Hölder calmness/error bounds；gamma<1 exact operator hit仍未得 | unrelated fixed-point heuristics |
| inverse/scaling | gamma1 inverse invariance在相关文献中存在 | RL gamma<1 换算 (1.6) 是直接代数 | power-uniform mono gives Hölder \(A^{-1}\) | 把 inverse Hölder 当 reflected Hölder |

关键判定：

1. **gamma1 是 exact/equivalent prior art 密集区。**
2. **gamma<1 的 R-side 公式不是新的 map property。**
3. **gamma<1 的 operator-graph 组织方式与后续定理是否已有，仍是未决问题；本轮阴性检索不足以定案。**

---

## 8. Novelty threat ledger

| Threat ID | 严重度 | 威胁内容 | 证据状态 | 对 manuscript claim 的约束 | 缓解所需证据 |
|---|---|---|---|---|---|
| NT-01 | **Critical** | \(\gamma=1,L\ge1\) 与 Luke–Tam submonotonicity/reflected Lipschitz 精确等价；anchored 同型式至少已见于 2018，另有 2023 扩展摘要 | VERIFIED_SOURCE + algebra | 不得把 gamma1 class 或其 anchored 公式本身称为新 generalized monotonicity | 明确列参数换算、时间线、restricted domain 与 theorem range |
| NT-02 | **Critical** | \(\gamma=1\) 是 Evens et al. \((\mu,\rho)\)-semimonotonicity的 tied curve | VERIFIED_SOURCE + algebra | 不得把整个 gamma1 semimonotone graph inequality称新 | 在 related work 正面定位一维切片 |
| NT-03 | **High** | Barroso 已直接研究一般 \(\gamma\)-Hölder maps；R-side 公式逐字等型 | VERIFIED_SOURCE | 不得以“reflected resolvent Hölder”这一性质本身作为主要 novelty | 展示 operator-specific 非平凡 theorem，而非仅定义/pullback |
| NT-04 | **High** | 经典 Minty/Cayley graph rotation + 一般 Hölder map 使 RL 定义具有形式 pullback 的直接性 | VERIFIED_SOURCE + AI_INFERENCE | 单纯改坐标/命名可能被审稿人视为 tautological repackaging | 提供不可从任意 Hölder map 理论自动推出的 calculus/maximality/algorithm result |
| NT-05 | **High** | 有界 local domain 上 Lipschitz 自动蕴含任意较小 exponent Hölder | AI_INFERENCE | local gamma<1 例若仍 Lipschitz，则 exponent 不具 genuine 内容 | 给非-Lipschitz R 与 sharp Hölder exponent 的自然例子 |
| NT-06 | **High / unresolved** | Moursi–Vanderwerff 2025 可能含 bounded-set/pointwise nonlinear modulus 与 reflected geometry | PENDING_FULL_TEXT | local/pointwise novelty 暂不能下结论 | 获取全文并逐式比较定义、等价定理、modulus transfer |
| NT-07 | **Medium–High** | Uniform monotonicity / super strong nonexpansiveness 已有精确 deficit-modulus 理论 | VERIFIED_SOURCE | 不得笼统声称首次把 nonlinear monotonicity 与 reflected geometry联系 | 明确 absolute Hölder envelope 与 deficit modulus 的不等价，并给反例 |
| NT-08 | **Medium** | Power-type uniform monotonicity已给 inverse Hölder behavior | VERIFIED_SOURCE + algebra | 不得把所有 exponent interaction都归于 RL | 区分 inverse coordinate、Cayley coordinate与metric subregularity exponent |
| NT-09 | **Medium** | Huang–Peng–Tang 已使用“resolvent Hölder property”术语 | VERIFIED_SOURCE | 标题/摘要需明确 reflected resolvent、Hilbert graph、domain | 公式并列对照普通 resolvent与 reflected resolvent |
| NT-10 | **High** | RL 只在 Minty range 上迫使单值；不自动有 full-domain/maximality | AI_INFERENCE | 不得无假设写 \(R:H\to H\) 或使用 maximal-monotone定理 | 单列 branch/range/maximality assumptions |
| NT-11 | **High** | global gamma<1 同时强迫大尺度 sublinear increments；可能过于限制自然算子 | AI_INFERENCE | 不得把 global gamma<1仅描述为“放宽 monotonicity” | 分开 local/global 理论并提供无界域自然例 |
| NT-12 | **Medium** | “submonotonicity”已有多个历史 convention；Luke–Tam 还说明其术语为重新使用 | VERIFIED_SOURCE | `RL-submonotonicity` 名称可能造成术语碰撞 | 定义前声明 convention；考虑 descriptive 名称 |
| NT-13 | **High procedural** | 无 MathSciNet/zbMATH/Scopus/WoS 公式/引文链；一篇关键全文缺失 | PENDING_VERIFICATION | 当前不能写“据我们所知首次”作为无保留事实 | 做正式数据库前后向引文复核与全文核验 |
| NT-14 | **Medium procedural** | correction/retraction 只做官方页 banner + title query 可见检查 | PENDING_VERIFICATION | “未见 notice”不能写作认证无更正/撤稿 | 投稿前重新查 Crossmark/出版社更新记录 |
| NT-15 | **High conceptual** | \(\gamma q\) 可能只是特定 proof composition，而非普遍 compensation law | 尚未由本任务检验 | 不得把 \(\gamma q\) 当现有理论或 novelty 基础事实 | 用 sharp examples与lower bounds独立验证；属于后续阶段 |

### 8.1 可安全使用的定位句（不是 novelty 声明）

> The proposed condition is exactly a Hölder continuity requirement on the Cayley/reflected-resolvent parametrization of the graph. Its Lipschitz endpoint is a tied semimonotonicity condition and, in the expansive regime, coincides with the submonotonicity framework of Luke and Tam after an explicit parameter conversion. For exponents below one, our formula-level search found general Hölder-map theory and several adjacent nonlinear monotonicity moduli, but did not identify an accessible primary source that develops the same all-pairs Hölder Cayley condition as an operator class. This negative search result is not a proof of novelty.

### 8.2 当前不安全的句子

- “We introduce the first Hölder reflected-resolvent condition.”
- “RL is a new generalized monotonicity for every \(0<\gamma\le1\).”
- “Uniform monotonicity and existing semimonotonicity do not cover our theory.”
- “No prior work has considered this inequality.”
- “The product \(\gamma q\) is a universal monotonicity–regularity law.”

---

## 9. 本轮阴性检索的解释边界

本轮的精确 gamma<1 阴性结果只表示：在所列查询、可访问 primary/official 页面和全文中，没有发现如下三项同时成立的原文：

1. 对 set-valued operator graph 的所有 pairs；
2. 使用 Cayley/reflected-resolvent increment；
3. exponent \(0<\gamma<1\) 的 absolute Hölder envelope，等价于式 (1.4)。

它**不排除**：

- 文献使用非英文或完全不同术语；
- 公式埋在 theorem/proof 中而搜索引擎未索引；
- 书籍、学位论文、会议论文或付费全文中已有；
- nonlinear modulus \(\omega(\|x-y\|)\) 的一般理论将 RL 作为特例；
- 2025 JOTA 论文或其引用链已有更接近内容；
- 经典 accretive/operator extension 文献用 modulus of continuity 表述同一 Cayley graph class。

因此，本文件的用途是**压缩 novelty claim 的安全范围并列出下一步审计对象**，不是出具“新颖性证书”。

---

## 10. Formula-level conclusions by requested variant

| Requested variant | 本轮结论 | 证据等级 |
|---|---|---|
| exact RL formula / symbol variants | gamma1 有 exact/equivalent 先例；gamma<1 未检到 operator-graph 原文 | VERIFIED_SOURCE / PENDING negative search |
| Hölder reflected resolvent | 一般 Hölder map 公式已有；operator-specific system theory未定 | VERIFIED_SOURCE + PENDING |
| Hölder Cayley transform | 经典 Cayley坐标 + Hölder map可直接组成；未检到同名 operator class | AI_INFERENCE + PENDING |
| Hölder reflected proximal map | 未检到 exact primary hit；普通 proximal/resolvent Hölder结果不等价 | PENDING negative search |
| inner-product formula (1.4) | gamma1 化为已知二次 semimonotonicity；gamma<1 同式未检到 | VERIFIED_SOURCE + PENDING |
| inverse variants | gamma1 文献有 inverse symmetry；gamma<1 常数换算见 (1.6)，是直接推导 | VERIFIED_SOURCE + AI_INFERENCE |
| scaling variants | semimonotone文献有 scaling规则；RL专用式 (1.7)直接推导 | VERIFIED_SOURCE + AI_INFERENCE |
| local/restricted | gamma1 有成熟 restricted/pointwise框架；gamma<1 受 bounded-domain trivialization威胁 | VERIFIED_SOURCE + AI_INFERENCE |
| anchored | pointwise almost-averaged/calmness邻近；不等价 all-pairs RL | VERIFIED_SOURCE |
| uniformly monotone / comonotone / power type | uniform mono 给 reflected deficit，power type 给 inverse Hölder，comonotone 给 gamma1 conical/Lipschitz envelope；均不等价 gamma<1 absolute Cayley Hölder结构 | VERIFIED_SOURCE + AI_INFERENCE |

---

## 11. Standard expert-result（contract 1.0）

```yaml
contract_version: "1.0"
expert_skill: "sci-skills-literature-search"
project_id: "monotonicity-regularity-seesaw-2026-09"
paper_family: "T"
stage_id: "T2"
task_id: "T2-NOV-EXACT"
task_status: "PROVISIONAL"
inputs_reviewed:
  - "upload/01-RL_Submonotonicity-.md"
  - "research/theory_atlas.md"
  - "work/a_rl_position.md"
  - "Primary/official sources S01-S15 listed in this report"
outputs:
  - "work/rl_exact_prior_art.md"
evidence_status:
  - label: "VERIFIED_SOURCE"
    item: "gamma=1 exact relations: Luke-Tam submonotonicity/reflected Lipschitz; Evens et al. tied semimonotonicity; Otero-Iusem convention"
  - label: "VERIFIED_SOURCE"
    item: "general map-side Hölder condition in Barroso 2023"
  - label: "VERIFIED_SOURCE"
    item: "uniform monotonicity/strong nonexpansiveness adjacency in Liu-Moursi-Vanderwerff 2023"
  - label: "AI_INFERENCE"
    item: "Cayley pullback equivalence, gamma=1 parameter conversions, inverse/scaling formulas, bounded-domain and power-type comparisons"
  - label: "PENDING_VERIFICATION"
    item: "no exact gamma<1 operator-class hit in accessible web search; this is not proof of novelty"
  - label: "PENDING_VERIFICATION"
    item: "full formula-level content of Moursi-Vanderwerff 2025 and formal citation-chain/database audit"
assumptions:
  - "Real Hilbert space for the displayed inner-product algebra"
  - "All-pairs RL is interpreted on the graph subset under discussion; local/restricted claims use the corresponding Minty range"
  - "Publisher/arXiv metadata visible on 2026-09-01 is current"
  - "No correction/retraction banner or targeted title-query hit is only a limited visible-status check"
author_input_needed:
  - "Access to Moursi-Vanderwerff 2025 full text if available through the author's institution"
  - "Any earlier unpublished notes or known references using nonlinear moduli on Cayley/Minty graph coordinates"
manual_actions:
  - "Obtain the Moursi-Vanderwerff 2025 full text and run a formula/citation-chain audit in MathSciNet, zbMATH, Scopus or Web of Science using Q01-Q91 variants and backward/forward citations from S01, S05, S09 and S10."
quality_checks:
  - "Separated source-stated facts from project-derived algebra"
  - "Recorded domain, locality and all-pairs versus anchored quantifiers"
  - "Verified DOI/venue/year from official pages where accessible"
  - "Recorded access depth and correction/retraction visibility limits"
  - "Did not infer novelty from non-detection"
  - "Did not provide journal-tier or acceptance conclusions"
  - "Did not modify project_state"
conflicts:
  - "The gamma<1 operator-class novelty question remains unresolved because one close 2025 source lacks full-text verification and formal citation databases were unavailable."
  - "General Hölder-map prior art makes a broad claim of novelty for the reflected-resolvent property itself unsafe, even if the operator-side theory proves new."
conflict_resolution_status: "UNRESOLVED"
merge_permission: "orchestrator_only"
recommended_next_action: "取得并逐页核验 Moursi–Vanderwerff 2025 全文，同时用正式数学/引文数据库对 S01、S05、S09、S10 做前后向引文链与 Q01–Q91 公式变体复核；完成前不提出 gamma<1 的无保留新颖性结论。"
stage_acceptance_recommendation: "REPAIR"
```
