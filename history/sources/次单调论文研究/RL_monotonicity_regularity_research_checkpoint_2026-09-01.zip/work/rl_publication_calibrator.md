# RL 理论的投稿成熟度与期刊层级校准

> 评估日期：2026-09-01  
> 证据边界：这是基于现有研究底稿的**条件性校准**，不是正式投稿推荐，也不预测录用。`theory_atlas.md`、`example_properties.md` 与 `seesaw_synthesis.md` 只用于诊断和筛选可进入论文的结果；它们不能作为一篇 RL 论文已经完成的贡献来计数。

## 1. 结论先行

当前 RL 工作是一个**有潜力、但尚未完成新颖性隔离与定理封闭的理论种子**。

- **当前原稿不可直接投稿。** 主要原因不是排版，而是核心局部 PPA 定理仍缺 range coverage、branch exclusion、two-radius localization、self-map/invariance、uniform regularity、zero-set closedness 与 finite-length 等完整量词和证明。
- **新颖性不是零，但目前只能写成“可能的新颖残余”。** `gamma=1` 已精确落入 tied semimonotonicity / Luke--Tam 的参数曲线；`0<gamma<1` 的一般 Hölder 映射性质本身也不能宣称新。最可能保留下来的新意是：将 Hölder Cayley/reflected-resolvent 几何系统地拉回算子图，配合 higher-order/gauge subregularity，得到一个量词完整、sharpness 有证据的 PPA 理论。
- **若只修正漏洞并完成一篇聚焦论文，合理校准是专业理论期刊层级。** 若再证明必要性或 sharp compatibility、发展 anchored/gauge 统一定理、加入自然算子类与不止一个算法机制，才有资格讨论更高的优化/运筹方法论期刊。

这里最重要的判断是：**定义 + Cayley 等价变换 + 一条直接复合上界，不足以支撑高层级论文；严谨的定理、与最近邻理论的非平凡差异、sharpness 和自然例子才决定稿件层级。**

## 2. 贡献矩阵

评分仅用于显示当前短板，满分 5；它不是录用概率模型。

| 贡献维度 | 当前证据与判定 | 当前强度 | 可安全主张 | 升级门槛 |
|---|---|---:|---|---|
| 定义新颖性 | `gamma=1` 与 tied semimonotonicity / Luke--Tam 精确接轨；`gamma<1` 可能形成新的 operator-side Hölder--Cayley class，但 exact/alias prior art 尚未穷尽 | 1.5/5 | “提出并研究一个 Hölder Cayley 图条件”尚可；“首次 Hölder reflected-resolvent”不可写 | 完成公式级 prior-art 矩阵；证明该 graph class 的非平凡结构而非仅是任意 Hölder map 的换坐标 |
| 等价变换 | RL、inner-product 形式、restricted reflected resolvent Hölder 性质和 AFNE 之间的代数等价正确；RL 本身还强迫 restricted resolvent 单值 | 2.0/5 | 可作为基础命题和结构字典 | 给出超越恒等式的结果：最大扩张、稳定性、封闭性、反演/缩放、sharp moduli 或可验证充分条件 |
| 核心定理深度 | 一步 residual 与 gauge-composition 估计可信；完整 PPA 收敛定理仍是待修复命题 | 1.5/5 | 只能主张 conditional one-step bound | 明确自然域与分支，完成 two-radius/invariance/uniformity/finite-length 证明，并区分 fixed 与 variable steps |
| Sharpness / necessity | 若干 GX 例子给出 sharp exponent/constant；但核心 compatibility 条件没有必要性，`gamma q` 只是一条可能非 sharp 的上界 | 2.0/5 | 可说“bound attainable in a designed model” | 至少一组自然 equality/boundary 例和一组条件失败时的收敛/发散配对；证明 exact order 所需的 two-sided profiles |
| Examples | 项目有大量显式例子，但许多是 atlas/gap-search 资产或 reverse-calibrated construction，不等于 RL 论文的自然验证 | 2.5/5 | 可筛选少量反例与机制例 | 选 4--8 个与主定理直接相关的自然类；分清 genuine/inherited Hölder、all-pairs/anchored、local/global 与 stepsize |
| Algorithm breadth | 当前只有 exact fixed-step PPA | 1.0/5 | 一篇聚焦 PPA 论文仍可成立 | 若瞄准更高层级，至少扩展到 variable/inexact/relaxed PPA，或证明同一 gauge-Cayley 机制可用于 FB、DR/AP 中的一个非平凡分支 |
| Literature differentiation | atlas 已识别 Luke--Tam、semimonotonicity、higher-order MSR 与 fixed-point regularity，但 RL 原稿本身没有完整 related work / bibliography | 1.5/5 | 目前只能作 provisional novelty statement | 对最近邻逐定理比较公式、量词、定义域、maximality、rate object 和结论；任何“首次”主张须通过该矩阵 |

### 当前真正可能有价值的“新颖残余”

1. **`0<gamma<1` 的 operator-side Hölder Cayley 图几何。** 价值不在于“Hölder map”三个字，而在于能否导出新的、可检验的算子结构与 PPA 结论。
2. **anchored 与 all-pairs Cayley profile 的分离。** GX-072/073 已显示 worst-case all-pairs exponent 可能与轨道看到的 anchored profile 不同，这可能比原始 RL 定义更有理论价值。
3. **一般 gauge composition，而不是机械的 `gamma q` product law。** 若能给出 sharp/necessary 的 compatibility theorem，这会把目前的一步估计升级为真正理论。
4. **允许非有限 hypomonotonicity defect 的临界 Cayley flatness。** 若能给出自然算子族和算法后果，它可能形成与 Luke--Tam `gamma=1` 理论真正不同的区域。

### 不能单独作为主要贡献的部分

- `gamma=1` 的参数换算；
- RL 与 reflected resolvent Hölder 性质的定义级等价；
- 把平方恒等式改写成 AFNE；
- 从 `r^gamma` 与 residual exponent `q` 直接得到 `O(r^{gamma q})`；
- broad atlas 或 77 个 GX 记录本身。

## 3. 最近邻工作的“成果包门槛”

这三篇已发表工作说明，不同期刊层级看重的是一个完整成果包，而不是单一新定义。

- Luke--Tam 的 *Generalized Monotonicity and the Proximal Point Algorithm* 不只给一个 graph inequality；文章还研究 maximal submonotonicity、与 almost firmly nonexpansive resolvent 的联系，并在明确局部假设下证明 PPA 序列收敛。[官方论文页](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863)
- Lin--Xu 在 JFPTA 的 GAN 工作同时给出 generalized averaged nonexpansiveness、指数相关的 fixed-point 收敛率，以及三个凸优化问题的应用；这表明“新 fixed-point class + rate theory + applications”是一个可识别的专业期刊成果包。[官方论文页](https://link.springer.com/article/10.1007/s11784-022-00972-7)
- Li--Mordukhovich 的 Hölder metric subregularity 工作包含必要/充分判据、exact bound、fractional error bounds 与 maximal-monotone PPM 应用；这比“把已有 regularity 假设代入一步估计”更深。[官方论文页](https://epubs.siam.org/doi/10.1137/120864660)

这些对照不构成期刊排名，也不意味着复制其结构即可录用；它们只说明审稿人会期待何种理论深度。

## 4. 三种成果包的层级校准

| 成果包 | 必须包含的内容 | 可达到的条件性层级 | Desk / reviewer 风险 |
|---|---|---|---|
| **Current-as-is** | 现有四定义、五 Lemma、三条 PPA 声明与系数讨论 | **不建议投任何正式期刊；内部研究底稿或带显著免责声明的预印本阶段** | Desk 风险极高：新意尚未隔离、无完整 related work、正文仍有对话式段落。Reviewer 风险极高：局部定理量词和 invariance/branch 证明不闭合，`gamma q` 易被判为直接复合上界 |
| **Repaired-focused** | 聚焦 `0<gamma<1`；严格 restricted-domain 定义；完整 local PPA theorem；正确 gauge threshold；2--3 个 sharp boundary 例；3--5 个自然算子例；最近邻逐定理对照 | **扎实的专业理论期刊层级**。固定点取向可用 JFPTA 作 scope 校准；set-valued/operator-inclusion 取向可用 SVVA 作 scope 校准；若优化算法含义更强，可把 JOTA 作为冲刺校准 | Desk 风险中等：若 exact prior art 发现等价类，定义贡献会塌缩。Reviewer 风险中高：可能被认为是 Luke--Tam/Hölder-map 的技术变体；必须靠 sharpness、自然例子与严谨量词化解 |
| **Strengthened-unifying** | 一般 gauge-Cayley / anchored framework；必要或近必要 compatibility boundary；exact/asymptotically sharp rate；variable/inexact PPA 或另一算法族；自然非凸/变分问题应用；清楚否证 universal seesaw | **强专业期刊到一线领域期刊的候选层级**。JOTA/SVVA 可作主投 scope 校准；SIOPT 只在优化理论和算法后果足够广时作冲刺；MOR 只在方法论具有持续意义且 OR/MS 动机明确时作冲刺 | Desk 风险仍不低：统一框架若只是事后定义 gauge 会被视为 tautological；SIOPT/MOR 会追问重要性、广度与优化/OR 相关性，而不只数学正确性。Reviewer 风险集中于 necessity、sharpness、naturalness 与算法适用面 |

“层级”在这里指成果包的理论深度和受众广度，不对应任何未经核验的分区、影响因子或录用率。

## 5. 条件性 scope 校准，不是正式 shortlist

| 期刊 | 官方 scope 与 RL 的可能连接 | 只有满足什么才合理 | 当前判断 |
|---|---|---|---|
| Journal of Fixed Point Theory and Applications | 官方范围包括 fixed-point theory、convex analysis / variational inequalities 和 fixed-point algorithms。[官方 scope](https://link.springer.com/journal/11784/aims-and-scope) | 论文主线是 resolvent/fixed-point class、完整 rate theorem，并有可识别应用 | repaired-focused 的自然校准；不是当前原稿的投稿建议 |
| Set-Valued and Variational Analysis | 官方范围包括 set-valued/variational analysis、set-valued fixed points 与 operator inclusions。[官方 scope](https://link.springer.com/journal/11228/aims-and-scope) | 强化 operator graph、inverse regularity、localization/maximality 与 gauge 结构 | repaired-focused 或 strengthened 的自然校准 |
| Journal of Optimization Theory and Applications | 官方范围包括 optimization methods、算法计算方法以及 variational/convex analysis。[官方 scope](https://link.springer.com/journal/10957/aims-and-scope) | 必须把 RL 定理落到有优化意义的算法与问题类，并显著超过定义级推广 | repaired-focused 的冲刺或 strengthened 的主投校准 |
| SIAM Journal on Optimization | 官方范围覆盖 optimization theory/practice、algorithms 以及 nonsmooth/variational analysis。[官方 scope](https://www.siam.org/publications/siam-journals/siam-journal-on-optimization/) | 需要 substantial variational theory、sharp results 和广泛优化后果；只有单一 PPA upper bound 不够 | 仅 strengthened-unifying 的冲刺校准 |
| Mathematics of Operations Research | 官方 editorial statement 接受 continuous optimization 与 convergence analysis，但强调 originality、importance、mathematical depth 和 OR/MS relevance，且明确“正确性本身不够”。[官方 statement](https://pubsonline.informs.org/page/moor/editorial-statement) | 需要具有持续意义的方法论、明确 OR/MS 定位和明显超越最近邻工作的深度 | 仅 strengthened-unifying 的高风险冲刺校准 |

OA、APC、分区、收录、审稿时间和当前特刊不在本次校准范围；若形成正式 shortlist，须在投稿当日重新核验。

## 6. 当前稿件最可能遭遇的审稿意见

1. **“This is a reparameterization of a Hölder Cayley map.”** 如果没有 operator-side structure theorem，这条意见很难反驳。
2. **“The `gamma=1` case is already contained in semimonotonicity / Luke--Tam.”** 因此正文必须把 `gamma=1` 当边界校准，不可当主要创新。
3. **“The convergence theorem omits existence and localization assumptions.”** 当前原稿对 two-radius localization 只用一句说明，无法替代定理假设和闭合证明。
4. **“The order `gamma q` is not shown sharp.”** GX-072 已证明真实轨道可为 `q > gamma q`；只能把它写成 upper order，除非增加 two-sided/branch-alignment 假设。
5. **“Examples are reverse-engineered.”** GX-071/072 很有诊断价值，但发表价值需由自然算子类、临界问题或算法实例补强。
6. **“The term submonotonicity is overloaded.”** 正式命名宜先用公式或 `Hölder--Cayley` 工作名，待 prior-art 审计完成再决定是否保留 RL-submonotonicity。
7. **“The paper has only one algorithm and no practical or structural payoff.”** 对专业期刊可用一个深而完整的 PPA 结果化解；对更高层级则通常需要更广影响。

## 7. 可执行的升级标准

### 从 current-as-is 升到 repaired-focused

- 重写主定义为 restricted graph / Minty domain 版本，并删除“多值时 selection-wise”；
- 给出一条量词完整的局部 PPA 定理，逐项证明 existence、branch、invariance、uniformity 与 finite length；
- 把 `gamma=1` 阈值与 `0<gamma<1` 分开，把不连续 gauge 换为右包络；
- 只把 `gamma q` 写成 upper order，除非新增 exactness 假设；
- 完成 exact/alias prior-art 表，并将 `gamma=1` 放入已知理论边界；
- 从 GX 库筛选自然且非重复的例子，至少包含一个 sharp attainment、一个非sharp 轨道和一个不变性反例；
- 将当前“回答式”第八节改写为正式 proposition/remark，补齐英文摘要、引言、related work、参考文献和完整证明。

### 从 repaired-focused 升到 strengthened-unifying

- 证明 anchored gauge-composition theorem，说明何时 all-pairs profile 可由 anchored profile替代；
- 给出 compatibility 条件的 necessity / near-necessity 或 sharp lower bounds；
- 扩展到 variable/inexact PPA，或至少一个真正不同的 splitting/fixed-point 算法；
- 在 prox-regular、critical Cayley cusp、degenerate gradient 或自然 set-valued inclusion 中给出非工程化应用；
- 证明框架不是“事后定义 exact radial gauge”的同义反复，并明确可检验条件和失败边界。

## 8. 质量核查与证据状态

- `VERIFIED_USER_MATERIAL`：RL、RL-IP、AFNE 与一步 residual/gauge 公式可从原稿复核。
- `AI_INFERENCE`：上述期刊层级和 desk/reviewer 风险是基于稿件内容、最近邻成果包与官方 scope 的判断，不是录用概率。
- `PENDING_VERIFICATION`：`0<gamma<1` 的 exact/alias prior art；核心 local PPA theorem 的最终版本；compatibility 的 necessity/sharpness。
- `VERIFIED_SOURCE`：五个期刊 scope，以及 Luke--Tam、Lin--Xu、Li--Mordukhovich 的官方论文页。核验账见 `work/rl_publication_calibrator_journal_ledger.csv`。
- 没有使用影响因子、分区、收录、录用率或审稿周期传闻。

## Expert contract

```yaml
contract_version: "1.0"
expert_skill: sci-skills-journal-recommendation
project_id: monotonicity-regularity-seesaw-2026-09
paper_family: T
stage_id: T2
task_id: null
task_status: PROVISIONAL
inputs_reviewed:
  - upload/01-RL_Submonotonicity-.md
  - research/theory_atlas.md
  - research/example_properties.md
  - research/seesaw_synthesis.md
  - official journal scope pages and three official nearest-work pages
outputs:
  - work/rl_publication_calibrator.md
  - work/rl_publication_calibrator_result.yaml
  - work/rl_publication_calibrator_journal_ledger.csv
evidence_status:
  - VERIFIED_USER_MATERIAL: RL algebra and the state of the draft
  - VERIFIED_SOURCE: official scope and publication-page facts
  - AI_INFERENCE: quality scores, attainable package tiers, and desk/reviewer risks
  - PENDING_VERIFICATION: formula-level novelty for gamma<1 and exact theorem closure
assumptions:
  - the intended article is a theoretical research article centered on RL and PPA
  - broad atlas and phase-cloud assets will not be claimed as completed results of the focused paper
author_input_needed:
  - choose whether the repaired paper is primarily fixed-point/resolvent theory or variational/operator theory
  - decide whether to pursue a focused first paper or delay for a stronger unifying package
manual_actions: []
quality_checks:
  - all four requested files were inspected
  - gamma=1 prior-art containment and gamma-q evidence boundary were retained
  - official journal scope pages were checked on 2026-09-01
  - no mutable ranking or acceptance-rate claim was used
  - recommendation gate and journal verification ledger were validated locally
conflicts:
  - conflict_id: NOVELTY-RL-GAMMA-LT1
    conflict_type: incomplete_prior_art
    claim: gamma<1 operator-side Holder-Cayley formulation may retain novelty
    competing_interpretations:
      - new operator-side structure and convergence theory
      - direct pullback of a known Holder mapping class
    recommended_resolution: complete exact-formula and alias-level prior-art audit before a novelty claim
conflict_resolution_status: UNRESOLVED
merge_permission: orchestrator_only
recommended_next_action: complete one formula-level nearest-prior-art matrix and use it to freeze a single claim-safe main theorem before rewriting the manuscript
stage_acceptance_recommendation: REPAIR
```
