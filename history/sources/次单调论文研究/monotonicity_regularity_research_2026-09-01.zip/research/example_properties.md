# Generalized monotonicity--regularity example properties

> **C-stage final integration, 2026-09-01.**  This file consolidates the
> independent calculations in `work/c_gx001_013.md` through
> `work/c_gx066_077.md`.  The B-stage cards in `gap_examples.md` identify
> objects and intended gaps only; whenever a label or constant differs, the
> calculation recorded here prevails.  This is a property ledger and phase
> input, **not** a seesaw synthesis.

## 0. Conventions and reusable calculation rules

For two graph points ((x,u),(y,v)), set

\[
a=x-y,\qquad b=u-v,\qquad d=a+\lambda b,\qquad r=a-\lambda b,
\qquad Q_{\lambda,\gamma}=\frac{\|r\|}{\|d\|^\gamma}.
\]

A pair (d=0\ne r) is a **Minty collision** and defeats every finite
all-pairs RL constant.  A selected resolvent branch or a solution-anchored
estimate never repairs such a full-graph failure.  All (J_{\lambda F}) and
(R_{\lambda F}=2J_{\lambda F}-I) statements are on their printed natural
Minty domain unless full domain is stated.

Statistical/phase-cloud counting is by canonical mathematical object.  A
different reference point, stepsize, restriction, truncation, or algorithmic
residual is retained as an observation record, not counted as another
independent operator.  Distinct mappings on the same underlying sets (for
example `N_L`, `I-P_L`, and a Douglas--Rachford residual) are not literal
aliases.

An RL datum is the tuple (graph/window, \lambda, exponent, constant,
local/global, all-pairs/anchored, genuine/inherited, map/relation).
Suppressing any coordinate invalidates comparisons across GX cards.

The signed quadratic graph moduli are

\[
m_*:=\inf_{a\ne0}\frac{\langle a,b\rangle}{\|a\|^2},\qquad
c_*:=\inf_{b\ne0}\frac{\langle a,b\rangle}{\|b\|^2},
\]

and

\[
\Sigma(F):=\{(\mu,\rho):\langle a,b\rangle\ge
\mu\|a\|^2+\rho\|b\|^2\ \text{for all printed graph pairs}\}.
\]

Thus (m_*>0) is the sharp strong-monotonicity modulus,
(m_*=-\sigma) is the sharp finite hypomonotonicity defect, and similarly
for (c_*) and coco/cohypomonotonicity.  Infimum (-\infty) is recorded as
“no finite modulus.”  A coefficient made arbitrary by (a=0) or (b=0)
is marked graph-vacuous rather than counted as curvature.

Regularity uses the residual-exponent convention

\[
d(x,F^{-1}(\bar y))\le \kappa\,d(\bar y,F(x))^q.
\]

`Core=(MR,MSR,SMR,SMSR)` and `Inv=(Aubin, calm, isolated calm)` always list
properties in that order.  Every regularity record has two
exponent/modulus slots: (i) fixed-target MSR/SMSR, equivalent respectively
to calm/isolated calm at the printed graph point, and (ii)
nearby-target-uniform MR/SMR, equivalent respectively to Aubin and to the
required single-valued inverse localization.  Constants are transferred
only through the appropriate exact equivalence, never across these slots.
HREG and UHREG are printed separately because they control nearest inverse
points at a fixed base, not all inverse branches.

An exact modulus (0) means the infimum of admissible constants after
arbitrarily shrinking neighborhoods; it need not mean that the literal
zero-constant inequality holds on a fixed neighborhood.  Every such entry
is tagged by one of `BIG-SOLUTION`, `DOMAIN-VACUOUS`, `FULL-VALUE`,
`BRANCH-PINNING`, `RESIDUAL-JUMP`,
`RESIDUAL-ESCAPE/GRAPH-ISOLATION`, or `SUPERLINEAR-GERM`.  Zero moduli
with different mechanisms are not compared as one strength level.

For the steepest-rate characterization we use the extended-real reciprocal
\[
\operatorname{subreg}_{\rm strong}F
=\frac{1}{|F|^\downarrow},\qquad
\frac1{+\infty}=0,\quad \frac10=+\infty,
\]
never the undefined literal product (0\cdot(+\infty)=1).  Every extended
gauge is understood with the endpoint convention
(\varphi(+\infty)=+\infty).

The following rules are cited below only to avoid repeating identical
one-line asymptotics; each distinct reference and algorithmic residual still
gets its own property row.

1. **Exact power law.**  If
   (d(x,S)\sim C\,r_F(x)^p) along nonvacuous sequences, then the largest
   fixed-target exponent is (q_*=p), the endpoint modulus is (C), every
   (q<p) has exact point modulus (0), and every (q>p) fails.  The
   corresponding two-target modulus is recorded separately and is never
   inferred from the fixed-target law.
2. **Linear residual law.**  If (d(x,S)=C r_F(x)), then fixed-target
   (q=1) has exact modulus (C), (q<1) has point modulus (0), and
   (q>1) fails.  A gauge (\varphi) has asymptotic modulus
   (C\limsup_{t\downarrow0}t/\varphi(t)).  This says nothing by itself
   about nearby-target coverage or isolation.
3. **Inherited subunit RL.**  If (R) is (K)-Lipschitz on a Minty set of
   pair-diameter (\Delta), then
   (L_{\gamma}\le K\Delta^{1-\gamma}).  Equality is sharp when a
   norm-attaining diameter direction exists.  Such (\gamma<1) estimates,
   and tuned constant-map estimates, are marked **inherited**, not genuinely
   Hölder.  “Genuine” means that the maximal local all-pairs exponent at the
   stated reference is strictly below (1).
4. **Coverage and vacuity.**  Empty nearby inverse fibers defeat MR/Aubin
   for every positive power and every finite gauge, even when fixed-target
   MSR is excellent.  `GRAPH-VACUOUS` and `NONCLOSED-RANGE` remain
   graph/range diagnostics; zero-modulus mechanisms use only the seven
   tags printed above.

The RL identity used in every card is

\[
4\lambda\langle a,b\rangle=\|d\|^2-\|r\|^2,
\]

so the user condition
(\|r\|\le L\|d\|^\gamma) is exactly its displayed inner-product form.
Unlike the provisional wording in the uploaded draft, all-pairs RL itself
forces the restricted (J,R) to be single-valued; it is not a
selection-wise property of a colliding relation.

When present, the set-pair map (\Phi), the primal normal/cone operator, and
the algorithmic residual (I-T) occupy separate rows.  Their input/output
norms are stated independently and their constants are never transferred
without an explicit metric equivalence.

## 1. Linear, matrix and elementary normal-cone calibrations

### GX-001 -- zero operator

| Property row | Independent C result |
|---|---|
| Canonical object / reference / source | (F=0) on a nonzero Hilbert space; ((\bar x,0)), arbitrary (\bar x).  Aliases LC-01/EX-19/SVG-05; `ALG-CHECKED`.  (S=H), (F^{-1}(y)=H) for (y=0) and empty otherwise. |
| Graph geometry | (b=0), so (\langle a,b\rangle=0), (m_*=0); maximal monotone, not strict/strong.  Every finite positive coco coefficient is graph-degenerate and the supremum is (+\infty).  (\Sigma=\{(\mu,\rho):\mu\le0,\rho\in\mathbb R\}). |
| (J/R) and RL | (J=R=I).  (Q_{\lambda,\gamma}=\|a\|^{1-\gamma}).  Global RL only at (\gamma=1), sharp (L=1); every global (\gamma<1) fails by scaling.  On pair-diameter (\Delta), (L_\gamma^*=\Delta^{1-\gamma}), inherited. |
| Regularity / residual | (d(x,S)=0): MSR and every fixed-target power/gauge MSR have exact modulus (0), solely `BIG-SOLUTION`.  SMSR/isolated calm fail.  MR/SMR/Aubin fail by empty nonzero-target fibers.  Inverse calm has modulus (0). |
| C verdict | B yes/no labels pass.  Upgrade: cocoercivity has no largest finite coefficient; the modulus-zero MSR carries no phase weight as inverse stability. |

### GX-002 -- positive scalar (F=cI), (c>0)

| Property row | Independent C result |
|---|---|
| Object / reference | Full-domain linear bijection on (H\ne\{0\}), reference ((0,0)); LC-02/CP-03.  (S=\{0\}), (F^{-1}=c^{-1}I). |
| Graph geometry | (b=ca), (\langle a,b\rangle=c\|a\|^2=c^{-1}\|b\|^2).  (m_*=c, c_*=1/c), and (\Sigma=\{(\mu,\rho):\mu+\rho c^2\le c\}).  Maximally strong, cocoercive, paramonotone and rectangular. |
| (J/R), RL | (J=(1+\lambda c)^{-1}I), (R=k_\lambda I), (k_\lambda=(1-\lambda c)/(1+\lambda c)).  (Q=|k_\lambda|\|d\|^{1-\gamma}).  RL\(_1) is sharp at (L=|k_\lambda|<1).  If (\lambda c=1), (R=0) and every exponent holds globally with (L=0); otherwise global subunit RL fails and bounded-window (L=|k_\lambda|\Delta^{1-\gamma}) is inherited. |
| Regularity / gauge | Core (=(1/c,1/c,1/c,1/c)); Inv (=(1/c,1/c,1/c)).  Exact laws (\|x\|=c^{-1}\|Fx\|) and (d(x,F^{-1}y)=c^{-1}\|y-Fx\|).  Largest fixed/two-target power is (1); gauge asymptotic modulus is (c^{-1}\limsup t/\varphi(t)). |
| Mechanism / verdict | Isolated, nonvacuous, every constant attained on rays.  B labels pass. |

### GX-003 -- negative scalar (F=-cI), (c>0)

| Property row | Independent C result |
|---|---|
| Object / reference | Full-domain linear bijection, ((0,0)); LC-03/MGB-03/MGB-22.  (S=\{0\}), (F^{-1}=-c^{-1}I). |
| Graph geometry | (b=-ca), (\langle a,b\rangle=-c\|a\|^2=-c^{-1}\|b\|^2).  (m_*=-c, c_*=-1/c), (\Sigma=\{(\mu,\rho):\mu+\rho c^2\le-c\}); maximally ((-c))-monotone, neither monotone nor cocoercive. |
| (J/R), RL | If (\lambda c\ne1), (J=(1-\lambda c)^{-1}I), (R=((1+\lambda c)/(1-\lambda c))I), and sharp (L_1=(1+\lambda c)/|1-\lambda c|>1).  Global (\gamma<1) fails; bounded-window constants are inherited.  At (\lambda c=1), (D=\{0\}), (J(0)=H), and (d=0\ne r) for every nonzero graph difference, so all RL exponents fail. |
| Regularity / gauge | Core and Inv all have exact modulus (1/c); (\|x\|=c^{-1}\|Fx\|).  Largest fixed/two-target exponent (1), with the linear-law gauge ratio. |
| Mechanism / verdict | Isolated and nonvacuous.  B labels pass; important augmentation: (J) is a contraction for (\lambda c>2) despite adverse graph curvature, while (R) never contracts. |

### GX-004 -- pure skew rotation (F=\omega K)

| Property row | Independent C result |
|---|---|
| Object / reference | (K(x_1,x_2)=(-x_2,x_1)), (\omega>0), on (\mathbb R^2), at ((0,0)); LC-04/MGB-13.  (S=\{0\}), (F^{-1}=-(1/\omega)K). |
| Graph geometry | (b=\omega Ka), (\langle a,b\rangle=0), (\|b\|=\omega\|a\|).  (m_*=c_*=0), (\Sigma=\{(\mu,\rho):\mu+\rho\omega^2\le0\}).  Maximally monotone but neither strong/coco, paramonotone nor rectangular. |
| (J/R), RL | With (t=\lambda\omega), (J=(I-tK)/(1+t^2)), (\|J\|=(1+t^2)^{-1/2}); (R=(I-tK)(I+tK)^{-1}) is a rotation, (\|R\|=1).  (Q=\|d\|^{1-\gamma}); global RL only at (\gamma=1,L=1), bounded-window subunit estimates inherited. |
| Regularity | Core and Inv all exact (1/\omega); (\|x\|=\omega^{-1}\|Fx\|).  Largest power (1), linear-law gauge ratio. |
| Verdict | Isolated/nonvacuous.  B labels pass.  This supplies neutral pairwise curvature, Cayley isometry and full inverse stability simultaneously. |

### GX-005 -- shifted rotation (F=\mu I+\omega K)

| Property row | Independent C result |
|---|---|
| Object / reference | (\mu,\omega>0) on (\mathbb R^2), reference ((0,0)); LC-05.  (S=\{0\}), (F^{-1}=(\mu I-\omega K)/(\mu^2+\omega^2)). |
| Graph geometry | (\langle a,b\rangle=\mu\|a\|^2=\mu\|b\|^2/(\mu^2+\omega^2)).  (m_*=\mu, c_*=\mu/(\mu^2+\omega^2)); (\Sigma=\{(m,\rho):m+\rho(\mu^2+\omega^2)\le\mu\}). |
| (J/R), RL | (D_+=(1+\lambda\mu)^2+(\lambda\omega)^2), (D_-=(1-\lambda\mu)^2+(\lambda\omega)^2).  (J=[(1+\lambda\mu)I-\lambda\omega K]/D_+), (\|J\|=D_+^{-1/2}); (\|R\|=\sqrt{D_-/D_+}<1).  Sharp global RL\(_1) is that norm; every global subunit exponent fails because (R\ne0) is linear, while window estimates are inherited. |
| Regularity | With (s=\sqrt{\mu^2+\omega^2}), Core and Inv all exact (1/s); residual law (\|x\|=s^{-1}\|Fx\|), largest power (1). |
| Verdict | Isolated/nonvacuous; all constants attained.  B labels pass. |

### GX-006 -- singular PSD diagonal (F=\operatorname{diag}(0,c))

| Property row | Independent C result |
|---|---|
| Object / reference | (F(x_1,x_2)=(0,cx_2)), (c>0), at ((0,0)); LC-06/SVG-11/MGB-12.  (S=\mathbb R\times\{0\}); inverse fibers are horizontal lines for targets in (\{0\}\times\mathbb R), empty otherwise. |
| Graph geometry | For (a=(p,q)), (b=(0,cq)): (\langle a,b\rangle=cq^2=c^{-1}\|b\|^2).  (m_*=0, c_*=1/c); (\Sigma=\{(m,\rho):m\le0, m+\rho c^2\le c\}).  Maximally monotone, paramonotone and rectangular, not strong. |
| (J/R), RL | (J=\operatorname{diag}(1,(1+\lambda c)^{-1})), (R=\operatorname{diag}(1,(1-\lambda c)/(1+\lambda c))).  Sharp global RL\(_1=1), attained on the kernel; subunit global RL fails, while (L_\gamma=\Delta^{1-\gamma}) on a window is inherited. |
| Regularity / residual | (d(x,S)=|x_2|=c^{-1}\|Fx\|).  MSR and inverse calm exact (1/c); MR/Aubin fail by empty off-range targets; SMSR/isolated calm fail by the zero line; SMR fails.  Fixed (q_*=1), gauge ratio (c^{-1}\limsup t/\varphi(t)). |
| Verdict | Nonisolated but transverse EB is nonvacuous.  B labels pass. |

### GX-007 -- nilpotent shear

| Property row | Independent C result |
|---|---|
| Object / reference | (F=N=\begin{psmallmatrix}0&1\\0&0\end{psmallmatrix}) on (\mathbb R^2), at ((0,0)); LC-07.  (S=\mathbb R\times\{0\}), inverse fibers horizontal when the target second coordinate is zero and empty otherwise. |
| Graph geometry | (a=(p,q),b=(q,0)), (\langle a,b\rangle=pq\).  (m_*=-1/2), attained at ((1,-1)); (c_*=-\infty).  (\Sigma=\{(m,\rho):m<0, m(m+\rho)\ge1/4\}).  Maximally ((-1/2))-monotone, no finite cohypomonotonicity. |
| (J/R), RL | (J=I-\lambda N), (R=I-2\lambda N).  (\|J\|=\sqrt{1+\lambda^2/4}+\lambda/2), and sharp (L_1=\|R\|=\sqrt{1+\lambda^2}+\lambda).  Global subunit RL fails; window constant (L_1\Delta^{1-\gamma}) is inherited. |
| Regularity / residual | (d(x,S)=|x_2|=\|Nx\|).  MSR/calm exact 1; MR/Aubin fail by targets with nonzero second coordinate; SMSR/isolated calm fail by nonisolation; SMR fails.  Fixed (q_*=1), linear gauge law. |
| Verdict | Nonisolated, nonvacuous transverse EB.  B labels pass. |

### GX-008 -- indefinite diagonal bijection

| Property row | Independent C result |
|---|---|
| Object / reference | (F=\operatorname{diag}(-c,d)), (c,d>0), on (\mathbb R^2), ((0,0)); LC-08.  (S=\{0\}), (F^{-1}=\operatorname{diag}(-1/c,1/d)). |
| Graph geometry | (\langle a,b\rangle=-cp^2+dq^2).  (m_*=-c, c_*=-1/c), and (\Sigma=\{(m,\rho):m+\rho c^2\le-c, m+\rho d^2\le d\}).  Maximally ((-c))-monotone, nonmonotone/noncoco. |
| (J/R), RL | For (\lambda c\ne1), (J=\operatorname{diag}((1-\lambda c)^{-1},(1+\lambda d)^{-1})) and (R) has diagonal entries ((1+\lambda c)/(1-\lambda c)), ((1-\lambda d)/(1+\lambda d)).  Sharp (L_1=(1+\lambda c)/|1-\lambda c|>1); subunit global RL fails.  At (\lambda c=1), Minty collision kills every exponent. |
| Regularity | Let (s_{\min}=\min\{c,d\}).  Core and Inv all exact (1/s_{\min}); largest power (1) and gauge ratio (s_{\min}^{-1}\limsup t/\varphi(t)). |
| Verdict | Isolated/nonvacuous.  B labels pass; (J) contracts exactly when (\lambda c>2), despite indefinite curvature. |

### GX-009 -- compact positive diagonal on (\ell^2)

| Property row | Independent C result |
|---|---|
| Object / reference | ((Fx)_n=x_n/n) on (\ell^2), ((0,0)); LC-09.  (S=\{0\}); (F^{-1}y=(ny_n)) only on a dense, proper, nonclosed range. |
| Graph geometry | (\langle a,b\rangle=\sum |a_n|^2/n>0) for (a\ne0), and (\ge\|b\|^2).  Strict/maximal monotone, (m_*=0, c_*=1); (\Sigma=\{(m,\rho):m+\rho/n^2\le1/n\ \forall n\}). |
| (J/R), RL | ((Jx)_n=nx_n/(n+\lambda)), ((Rx)_n=(n-\lambda)x_n/(n+\lambda)).  Both norms equal 1 only as tail suprema and are not attained.  Sharp global RL\(_1=1); global subunit RL fails, window (L_\gamma=\Delta^{1-\gamma}) is an approached inherited supremum. |
| Regularity / gauge | Although the zero is isolated, MR/MSR/SMR/SMSR and Aubin/calm/isolated calm all fail by `NONCLOSED-RANGE` singular directions.  Every power (q>0) and every vanishing gauge MSR/SMSR fails; the diagonal sequences in C give the full local quantifiers. |
| Verdict | B labels pass and are strengthened: no genuine vanishing-gauge error bound exists.  Failure is not multiple solutions or vacuity. |

### GX-010 -- shifted half-line normal (F=\mu I+N_{[0,\infty)})

| Property row | Independent C result |
|---|---|
| Canonical object / source | (F(x)=\mu x) for (x>0), (F(0)=(-\infty,0]), empty for (x<0), (\mu>0); LC-10/SVG-07.  (S=\{0\}), (F^{-1}(y)=y_+/\mu). |
| Graph geometry | Differences are vertical ((a=0)) or have slope (k\ge\mu).  (m_*=\mu, c_*=0), (\Sigma=\{(m,\rho):\rho\le0, m+\rho\mu^2\le\mu\}).  Maximally (\mu)-strong, no positive cocoercivity. |
| (J/R), RL | (J(p)=p_+/(1+\lambda\mu)); (R(p)=-p) for (p\le0) and (kp) for (p\ge0), (k=(1-\lambda\mu)/(1+\lambda\mu)).  (\operatorname{Lip}J=(1+\lambda\mu)^{-1}), sharp global RL\(_1=1) from the negative ray; all global subunit exponents fail, window bounds inherited. |
| Reference ((0,0)): regularity | Core and Inv all exact (1/\mu).  The positive ray gives (x=\mu^{-1}d(0,F(x))); the negative domain side is empty but does not determine the modulus.  Largest fixed/two-target exponent (1), gauge ratio (\mu^{-1}\limsup t/\varphi(t)). |
| Reference ((0,\bar y<0)): separate row | The inverse is locally the constant singleton 0; Core and Inv all have exact infimum 0 by `BRANCH-PINNING`.  This is not the kink modulus (1/\mu). |
| C verdict | `C-CLARIFY`: B's (1/\mu) statement is correct at the zero/kink and as a global inverse Lipschitz bound, not at every vertical graph point. |

### GX-011 -- positive-part map (F(x)=x_+)

| Property row | Independent C result |
|---|---|
| Object / reference | Full-domain scalar map, ((0,0)); LC-11.  (S=(-\infty,0]); positive targets have singleton inverse, target 0 has the negative half-line, negative targets have empty fibers. |
| Graph geometry | Every secant is (b=ka), (k\in[0,1]).  (m_*=0, c_*=1), (\Sigma=\{(m,\rho):m\le\min(0,1-\rho)\}).  Maximal, paramonotone, rectangular; not strong. |
| (J/R), RL | (J(p)=p) and (R(p)=p) for (p\le0); (J=p/(1+\lambda)), (R=(1-\lambda)p/(1+\lambda)) for (p\ge0).  Sharp global RL\(_1=1); global subunit RL fails on the fixed negative ray; bounded-window estimates inherited. |
| Regularity / residual | (d(x,S)=x_+=|F(x)|).  MSR/calm exact 1; SMSR/isolated calm fail by nonisolated zeros; MR/Aubin and SMR fail by negative target fibers.  Fixed (q_*=1), linear gauge law. |
| Verdict | EB nonvacuous from the positive side.  B labels pass. |

### GX-012 -- half-line normal cone (N_{[0,\infty)})

| Property row | Independent C result |
|---|---|
| Canonical object | (F(x)=0) for (x>0), (F(0)=(-\infty,0]), empty for (x<0); LC-12/SVG-01/02.  (F^{-1}(y)=\{0\}) for (y<0), ([0,\infty)) for (y=0), empty for (y>0). |
| Graph / (J/R) / RL | (\langle a,b\rangle\ge0), with horizontal and vertical pairs giving (m_*=c_*=0); (\Sigma=(-\infty,0]^2).  (J=P_{[0,\infty)}), (R=|\cdot|).  Sharp global RL\(_1=1); subunit global RL fails, window estimates inherited. |
| Reference ((0,0)) | (S=[0,\infty)).  MSR, every power/gauge MSR and inverse calm have exact 0 by `DOMAIN-VACUOUS + BIG-SOLUTION`; SMSR/isolated calm fail.  MR/Aubin and SMR fail by small positive targets. |
| Reference ((0,-1)) | For all nearby negative targets, (F^{-1}(y)=\{0\}).  Core and Inv all have exact infimum 0; every positive Hölder/gauge version also has infimum 0.  Mechanism: `BRANCH-PINNING + RESIDUAL-JUMP`, not the target-zero triviality. |
| Verdict | B labels pass.  The two references are different property rows and must not be averaged into one phase point. |

### GX-013 -- restricted positive slope

| Property row | Independent C result |
|---|---|
| Object / reference | (F(x)=\mu x) for (x\ge0), empty for (x<0), at ((0,0)); LC-13/SVG-08.  (S=\{0\}), (F^{-1}(y)=y/\mu) for (y\ge0), empty otherwise. |
| Graph geometry | (b=\mu a), (\langle a,b\rangle=\mu a^2=\mu^{-1}b^2); (m_*=\mu, c_*=1/\mu), (\Sigma=\{(m,\rho):m+\rho\mu^2\le\mu\}).  Strong+coco but nonmaximal. |
| (J/R), RL | Natural (D_\lambda=[0,\infty)); (J=p/(1+\lambda\mu)), (R=kp), (k=(1-\lambda\mu)/(1+\lambda\mu)).  Sharp natural-domain RL\(_1=|k|).  Tuned (\lambda\mu=1) gives (R=0); otherwise global-on-(D) subunit RL fails and window bounds are inherited. |
| Regularity / residual | (x=\mu^{-1}|F(x)|) on the real domain branch.  MSR/SMSR/calm/isolated calm exact (1/\mu); MR/Aubin and SMR fail by negative targets.  Fixed (q_*=1), gauge ratio (\mu^{-1}\limsup t/\varphi(t)). |
| Verdict | Isolated and nonvacuous from the positive ray.  B labels pass. |

## 2. Cayley-generated scalar maps, powers and gauges

For GX-015--018 the generating-step parameterization

\[
u(s)=\frac{s+T(s)}2,
\qquad v(s)=\frac{s-T(s)}{2\lambda _0}
\]

gives, for (h=s-t) and (\Delta T=T(s)-T(t)),

\[
a=\frac{h+\Delta T}{2},\quad
b=\frac{h-\Delta T}{2\lambda _0},\quad
\langle a,b\rangle=\frac{h^2-(\Delta T)^2}{4\lambda _0},\quad
Q_{\lambda _0,\gamma}=\frac{|\Delta T|}{|h|^\gamma}.
\tag{Cayley-generator}
\]

At another step (\eta), (\theta=\eta/\lambda _0), the Minty input is
(g_\theta(s)=((1+\theta)s+(1-\theta)T(s))/2); the generating (T)
must not be reused if this map folds.

### GX-014 -- restricted zero graph

| Property row | Independent C result |
|---|---|
| Object / reference | (F(x)=0) on ([-1,1]), empty outside, at ((0,0)); LC-14.  (S=[-1,1]), inverse empty away from target 0; nonmaximal restricted graph. |
| Graph geometry | (b=0), (\langle a,b\rangle=0), (m_*=0); every (b)-scaled coefficient is graph-degenerate.  (\Sigma=\{(\mu,\rho):\mu\le0,\rho\in\mathbb R\}). |
| (J/R), RL | (D_\lambda=[-1,1]), (J=R=I).  Sharp (L_1=1) and (L_\gamma=2^{1-\gamma}) for (0<\gamma<1), attained by endpoints; on diameter (\Delta), (L_\gamma=\Delta^{1-\gamma}).  All subunit exponents are bounded-domain inherited. |
| Regularity | Every fixed-target power/gauge MSR has exact 0 by `DOMAIN-VACUOUS + BIG-SOLUTION`; SMSR/isolated calm fail.  MR/Aubin and SMR fail by empty nonzero-target fibers; inverse calm exact 0. |
| Verdict | B labels pass after the two vacuity flags and inherited-RL qualifier are retained. |

### GX-015 -- power-Hölder Cayley graph

| Property row | Independent C result |
|---|---|
| Object / source | (T=P_\alpha), (0<\alpha<1), generating step (\lambda _0>0).  The increasing (u) defines a full-domain single-valued (F); (S=\{-1,0,1\}).  LC-15/EX-11; bounded AR-01 is an observation, not another object. |
| Graph geometry | If (k=\Delta P_\alpha/h>0), (\langle a,b\rangle=(1-k^2)h^2/(4\lambda _0)), (b/a=(1-k)/(\lambda _0(1+k))).  (m_*=-1/\lambda _0) (not attained), so (F) is maximally (1/\lambda _0)-hypomonotone; (c_*=-\infty).  Exact (\Sigma) is equation (15.2) of the C ledger. |
| Generating-step RL | (R_{\lambda _0F}=P_\alpha).  The **unique global exponent** is (\gamma=\alpha), with sharp (L=2^{1-\alpha}); (\gamma>\alpha) fails at 0 and (\gamma<\alpha) fails at infinity.  The maximal local exponent at Minty 0 is (\alpha): genuinely Hölder. |
| Other steps | Put (\theta=\eta/\lambda _0).  For (0<\eta<\lambda _0), only global RL\(_1\) survives, with sharp constant ((1+\theta)/(1-\theta)); every global subunit exponent fails.  At (\eta=\lambda _0), the unique global exponent is (\alpha), with sharp (L=2^{1-\alpha}).  For (\eta>\lambda _0), (g_\theta) folds and all-graph RL fails by Minty collisions. |
| Reference ((0,0)) | Core all hold with exact modulus (\lambda _0); Inv all exact (\lambda _0).  Largest fixed/two-target residual exponent is 1.  The global inverse has three branches near target 0, but the graphical localization at this graph point is single-valued. |
| References ((\pm1,0)) | Separately, Core and Inv all hold with exact modulus (\lambda _0(1+\alpha)/(1-\alpha)); each zero is locally isolated and nonvacuous. |
| Verdict | B labels pass.  Required qualifications: local branch SMR rather than global inverse uniqueness, exact step threshold, and the (1/\lambda _0) graph scale. |

### GX-016 -- tanh-Cayley

| Property row | Independent C result |
|---|---|
| Object | (T(s)=\tanh s) with general (\lambda _0>0); (F,F^{-1}) are global single-valued homeomorphisms and (S=\{0\}).  LC-16/EX-13. |
| Graph geometry | Tanh secants (k\in(0,1)) give (\langle a,b\rangle=(1-k^2)h^2/(4\lambda _0)>0).  Strict/maximal monotone, (m_*=0, c_*=\lambda _0); graph defect degenerates at 0. |
| (J/R), RL | At (\lambda _0), (J=(I+\tanh)/2), (R=\tanh), and (L_1^*=1).  For (0<\gamma<1), 

\[
L_\gamma^*=2^{1-\gamma}\max_{z>0}\frac{\tanh z}{z^\gamma},
\qquad \frac{2z_\gamma}{\sinh(2z_\gamma)}=\gamma.
\]

All subunit exponents hold globally at this generating step but are inherited from Lipschitzness plus bounded range; every point has local exponent 1.  At every (\eta\ne\lambda _0), only global RL\(_1\) survives, with sharp constant 1; nonzero linear tails defeat every global subunit exponent. |
| Fixed-target regularity at 0 | (u(s)=s-s^3/6+O(s^5)), (v(s)=s^3/(6\lambda _0)+O(s^5)).  (q_*=1/3), exact MSR/SMSR modulus ((6\lambda _0)^{1/3}); ordinary MSR/SMSR fail. |
| Two-target inverse regularity | The inverse leading term is ((6\lambda _0)^{1/3}P_{1/3}).  Exact (1/3)-MR/Hölder-Aubin (and branch strong-Hölder) modulus is ((24\lambda _0)^{1/3}).  Ordinary MR/SMR/Aubin/calm/isolated calm fail. |
| Verdict | Isolated/nonvacuous.  B labels pass; fixed-target and two-target constants are not interchangeable. |

### GX-017 -- rational bounded Cayley map

| Property row | Independent C result |
|---|---|
| Object | (T(s)=s/(1+s^2)), (\lambda _0=1); (u=(s+T(s))/2), (v=s^3/[2(1+s^2)]).  (F,F^{-1}) are global homeomorphisms, (S=\{0\}); LC-17. |
| Graph geometry | T secants lie in ([-1/8,1]), so (\langle a,b\rangle\ge0), (m_*=0), and sharp (c_*=7/9) (approached near (s=\pm\sqrt3)).  Strict/maximal monotone. |
| (J/R), RL | Every step has a single-valued resolvent.  At step 1,

\[
Q_{1,\gamma}(s,t)=\frac{|s-t|^{1-\gamma}|1-st|}{(1+s^2)(1+t^2)}.
\]

(L_1^*=1); every subunit exponent holds globally and is inherited from Lipschitzness plus bounded range.  For (0<\gamma<1), its exact sharp constant is

\[
L_\gamma^*=2^{-\gamma}(1+\gamma)^{(1+\gamma)/2}
(1-\gamma)^{(1-\gamma)/2}.
\]

At every step (\eta\ne1), RL\(_1\) remains globally sharp with constant 1, but nonzero linear tails defeat every global subunit exponent. |
| Regularity | (q_*=1/3); exact fixed MSR/SMSR modulus (2^{1/3}), exact two-target (1/3)-MR/Hölder-Aubin modulus 2.  Ordinary Core and ordinary Inv properties fail. |
| Verdict | Isolated/nonvacuous.  B labels pass.  At the generating step the subunit constants above are exact; the step coordinate cannot be suppressed. |

### GX-018 -- cubic Cayley relation

| Property row | Independent C result |
|---|---|
| Object | (T(s)=s-s^3), (u=s-s^3/2), (v=s^3/2), (\lambda _0=1).  (F) is set-valued, while (F^{-1}(y)=\sqrt[3]{2y}-y) is globally single-valued; (S=\{0\}).  LC-18. |
| Graph geometry | With (q=s^2+st+t^2), (a=(1-q/2)h, b=(q/2)h), (\langle a,b\rangle=q(2-q)h^2/4).  (c_*=-1) (sharp 1-cohypomonotonicity); (m_*=-\infty). |
| (J/R), RL by step | At (\eta=1), (J=u,R=s-s^3) but every global exponent fails by cubic growth; local RL\(_1) at 0 has point modulus 1 and subunit window estimates are inherited.  If (0<\eta<1), Minty folds kill all-graph RL.  If (\eta>1), (J) is a map and sharp global (L_1=(\eta+1)/(\eta-1)); no global subunit exponent. |
| Regularity | Remote (u=0) branches have outputs away from 0.  Locally (d(0,F(x))\sim|x|^3/2): (q_*=1/3), fixed MSR/SMSR modulus (2^{1/3}), two-target (1/3)-MR/Hölder-Aubin modulus 2.  Ordinary Core and Inv properties fail. |
| Verdict | Isolated/nonvacuous.  B labels pass after the three step regimes are separated. |

### GX-019 -- bounded negative dilation

| Property row | Independent C result |
|---|---|
| Object | (F(x)=-x/3) for (|x|\le3/2), empty outside; (S=\{0\}), (F^{-1}(y)=-3y) for (|y|\le1/2).  LC-19.  The graph is nonmaximal. |
| Graph geometry | (\langle a,b\rangle=-|a|^2/3=-3|b|^2), so (m_*=-1/3, c_*=-3), and (\Sigma=\{(m,\rho):m+\rho/9\le-1/3\}). |
| (J/R), RL | For (\lambda\ne3), (J(p)=p/(1-\lambda/3)), (R(p)=(1+\lambda/3)p/(1-\lambda/3)) on the bounded Minty domain.  For every (0<\gamma\le1), sharp

\[
L_{\lambda,\gamma}^*=(3+\lambda)|3-\lambda|^{-\gamma}.
\]

Subunit exponents are bounded-domain inherited.  At (\lambda=3), (D=\{0\}) and collisions defeat every exponent. |
| Regularity at ((0,0)) | Zero is interior to the graph projection/range.  Core and Inv all exact 3; residual law (|x|=3|F(x)|), largest fixed/two-target exponent 1. |
| Verdict | Isolated/nonvacuous.  B's step-one constants pass; arbitrary-step formula and exceptional step are required. |

### GX-020 -- clipped projection residual (F=I-P_{[-1,1]})

| Property row | Independent C result |
|---|---|
| Canonical object | Piecewise (x+1,0,x-1); (S=[-1,1]).  LC-20.  (F^{-1}(y)=-1+y) for (y<0), the interval for (y=0), and (1+y) for (y>0). |
| Graph geometry | (\langle a,b\rangle\ge|b|^2), sharp (c_*=1); (m_*=0).  Maximally monotone. |
| (J/R), RL | (J,R) are the exact three-piece affine formulas (20.1)--(20.2) in the C ledger.  For every step, sharp (L_1=1).  If (\lambda\ne1), all global subunit exponents fail on affine tails.  At tuned (\lambda=1), (R=P_{[-1,1]}) and (L_\gamma^*=2^{1-\gamma}); inherited, not genuine. |
| Global residual observation | (d(x,S)=|F(x)|), so global MSR has exact 1.  This is a global observation, not the local modulus at every zero. |
| Interior reference ((\bar x,0), |\bar x|<1) | Local MSR/calm exact 0 by `BIG-SOLUTION` (an open local solution set); SMSR/isolated calm fail.  MR/Aubin, SMR, HREG and UHREG fail because small nonzero targets have inverse points near remote endpoints rather than (\bar x).  Every fixed-target gauge bound is locally trivial. |
| Boundary references ((\pm1,0)) | Local MSR/calm exact 1, attained from the exterior; (q_*=1).  SMSR/isolated calm still fail.  MR/Aubin, SMR and HREG/UHREG fail by the opposite-sign target branch. |
| Verdict | B labels pass.  Step tuning and reference dependence must remain separate property rows. |

### GX-021 -- cubic power (F(x)=x^3)

| Property row | Independent C result |
|---|---|
| Canonical operator / aliases | Full-domain maximal cyclically monotone homeomorphism at ((0,0)); LC-21/EX-01/SVG-04/RM-02/CP-05 are one operator.  (S=\{0\}), (F^{-1}=P_{1/3}). |
| Graph geometry | (\langle a,b\rangle=(x-y)^2(x^2+xy+y^2)\ge0).  Strict/maximal cyclic, (m_*=0), no positive global coco modulus; on ([-\delta,\delta]), sharp (c_*=1/(3\delta^2)).  Global (\Sigma=(-\infty,0]^2). |
| (J/R), RL | (J(p)=u) solves (u+\lambda u^3=p), (R=u-\lambda u^3).  With (q=x^2+xy+y^2), (Q=|x-y|^{1-\gamma}|1-\lambda q|/(1+\lambda q)^\gamma).  Sharp global RL\(_1=1); every global subunit exponent fails because (R(p)=-p+o(p)) at infinity. |
| Operator residual at ((0,0)) | Exact (|x|=|F(x)|^{1/3}).  Fixed (q_*=1/3), MSR/SMSR modulus 1; two-target (1/3)-MR/Hölder-Aubin modulus (2^{2/3}).  Ordinary Core and ordinary Inv properties fail. |
| PPA fixed-point residual (G_\lambda=I-J_{\lambda F}) | With (p=u+\lambda u^3), (G_\lambda(p)=\lambda u^3), so (|p|\sim\lambda^{-1/3}|G_\lambda p|^{1/3}).  Endpoint fixed-point EB modulus is (\lambda^{-1/3}), not the operator modulus 1. |
| Scaled gradient/prox-gradient residual (\eta F) | (d(x,S)=\eta^{-1/3}\|\eta F(x)\|^{1/3}); endpoint modulus (\eta^{-1/3}).  This is another residual observation, not an independent phase point. |
| Verdict | Isolated/nonvacuous.  B labels pass; the residual rows prevent duplicate weighting and modulus conflation. |

### GX-022 -- signed square-root power (F=P_{1/2})

| Property row | Independent C result |
|---|---|
| Object | Full-domain maximal monotone homeomorphism, (S=\{0\}), (F^{-1}(y)=P_2(y)); LC-22. |
| Graph geometry | Every secant has (b=ka, k>0), so (\langle a,b\rangle=k|a|^2=k^{-1}|b|^2\).  Globally (m_*=c_*=0).  On ([-\delta,\delta]), sharp strong modulus (1/(2\sqrt\delta)); no positive local coco modulus at 0. |
| (J/R), RL | For (z(p)=(\sqrt{\lambda^2+4|p|}-\lambda)/2), (J(p)=\operatorname{sgn}(p)z(p)^2), (R=2J-I).  Sharp global RL\(_1=1); all global subunit exponents fail.  Near 0, (R(p)=-p+o(p)), so window subunit estimates are inherited. |
| Fixed-target regularity | Exact (|x|=|F(x)|^2).  Fixed MSR/SMSR holds precisely for (q\le2), endpoint modulus 1; ordinary exact modulus is 0 by `SUPERLINEAR-GERM` (nonvacuous, residual (\to0)). |
| Two-target / ordinary core | The inverse (P_2) is locally Lipschitz with point modulus 0.  Core and Inv all hold ordinarily with exact infimum 0 by `SUPERLINEAR-GERM` (nonvacuous, residual (\to0)), including SMR.  No two-variable (q)-MR for any (q>1), because every neighborhood contains a nonzero inverse point with nonzero derivative. |
| Verdict | Isolated/nonvacuous.  B labels pass; fixed-target higher order must not be promoted to pairwise higher-order MR. |

### GX-023 -- flat exponential

| Property row | Independent C result |
|---|---|
| Object | (F(0)=0, F(x)=\operatorname{sgn}(x)e^{-1/|x|}) otherwise; increasing homeomorphism onto ((-1,1)), (S=\{0\}).  LC-23. |
| Graph geometry | Secants (b=ka, k>0).  (m_*=0), and the derivative maximum (4e^{-2}) gives sharp global (c_*=e^2/4).  Maximally monotone. |
| (J/R), RL | Implicit single-valued (J); sharp global RL\(_1=1), while all global subunit exponents fail in saturation tails.  Near 0, (R(p)=p+o(p)), so none is genuine locally. |
| Fixed-target gauge | With (\phi_{\log}(r)=1/\log(1/r)), exact (|x|=\phi_{\log}(|F(x)|)).  Fixed gauge MSR/SMSR modulus 1.  Every positive power MSR/SMSR, hence every ordinary Core property, fails. |
| Two-target gauge | The odd inverse has exact local (\phi_{\log})-Aubin/gauge-MR modulus 2; its fixed-target gauge isolated-calm modulus is 1.  No positive-power inverse calm/Aubin property holds. |
| Verdict | Isolated/nonvacuous.  B labels pass; fixed and pairwise gauge constants differ. |

### GX-024 -- inverse-log cusp

| Property row | Independent C result |
|---|---|
| Object | (F(0)=0, F(x)=\operatorname{sgn}(x)/\log(e+1/|x|)); increasing homeomorphism onto ((-1,1)), (F^{-1}(y)=\operatorname{sgn}(y)/(e^{1/|y|}-e)), (S=\{0\}).  LC-24. |
| Graph geometry | Secants are positive; globally (m_*=c_*=0).  On a small zero window (m_\delta\sim[\delta\log^2(1/\delta)]^{-1}>0), but no positive local coco coefficient because slopes are unbounded.  Maximally monotone. |
| (J/R), RL | Implicit (J); sharp global RL\(_1=1).  Saturation tails defeat global subunit RL; locally (R(p)=-p+o(p)), so subunit estimates are inherited. |
| Fixed-target regularity | With (\psi(r)=1/(e^{1/r}-e)), exact (|x|=\psi(|F(x)|)) and (\psi(r)=o(r^q)) for every (q>0).  Every fixed power MSR/SMSR holds with exact 0 by `SUPERLINEAR-GERM` (nonvacuous, residual (\to0)); exact (\psi)-gauge modulus is 1. |
| Two-target / ordinary core | (F^{-1}) is (C^1) with derivative 0 at 0.  Core and Inv all hold ordinarily with exact 0 by `SUPERLINEAR-GERM` (nonvacuous, residual (\to0)).  Every two-target (q>1) MR fails; even the exact fixed gauge (\psi) fails as a pairwise inverse gauge by nonzero nearby derivatives. |
| Verdict | Isolated/nonvacuous.  B labels pass; “super-power” is strictly fixed-target. |

### GX-025 -- oscillating gauge (F_+)

Fix (0<c<1/\sqrt2), (s=\log(1/t)),
(A(s)=cs\sin(\log s)), and
(\phi_+(t)=e^{-s-A(s)}) for (t\le e^{-1}), extended by (t) outside;
(F_+^{-1}=\Phi_+), the odd extension of (\phi_+).

| Property row | Independent C result |
|---|---|
| Object / reference | Full-domain increasing odd homeomorphism (F_+), ((0,0)), (S=\{0\}); EX-05/GX-025. |
| Graph geometry | (\langle a,b\rangle=[\Phi_+(t)-\Phi_+(r)](t-r)\ge0).  Derivative phases approach 0 and (+\infty) in every zero neighborhood, so local/global (m_*=c_*=0); (\Sigma=(-\infty,0]^2). |
| (J/R), RL | At any step, sharp global (L_1=1).  If (\lambda\ne1), linear tails defeat all global subunit exponents.  At tuned (\lambda=1), the Cayley tails cancel, (R) is bounded nonexpansive, and every subunit exponent holds **inherited**.  Its sharp (L_\gamma) is the variational supremum (25.7); closed form **UNKNOWN**. |
| Power regularity | (q_*=1-c).  Fixed MSR/SMSR endpoint modulus 1; the same maximal two-target Hölder-MR exponent survives.  Its exact pairwise modulus (K_+) is **UNKNOWN**, with (2^c\le K_+\le\max\{2^c,(1+c\sqrt2)/(1-c)\}).  Ordinary Core/Inv properties fail. |
| Gauge row | Exact fixed (\phi_+)-MSR/SMSR modulus 1.  Every (\phi_-)-MSR constant fails along the adverse phase subsequence (25.12)--(25.14). |
| Verdict | `C-DISAGREE`: B's tail-based subunit-RL failure is false at (\lambda=1).  The map is isolated/nonvacuous and remains distinct from GX-026. |

### GX-026 -- oscillating gauge (F_-)

Use (\phi_-(t)=e^{-s+A(s)}), its odd extension (\Phi_-), and
(F_-^{-1}=\Phi_-).

| Property row | Independent C result |
|---|---|
| Object / reference | Full-domain increasing odd homeomorphism (F_-), ((0,0)), (S=\{0\}); EX-06/GX-026. |
| Graph geometry | Same exact product formula as GX-025, with phases reversed.  Maximally monotone; (m_*=c_*=0) even locally, (\Sigma=(-\infty,0]^2). |
| (J/R), RL | Sharp global (L_1=1).  Global subunit RL fails for (\lambda\ne1); at (\lambda=1), every subunit exponent holds by bounded-range inheritance.  Sharp (L_\gamma) is the corresponding variational supremum and remains **UNKNOWN**. |
| Power regularity | Same (q_*=1-c), fixed endpoint modulus 1, and pairwise endpoint exponent (1-c).  Exact pairwise modulus (K_-) remains **UNKNOWN** within the same proved bounds.  Ordinary Core/Inv properties fail. |
| Gauge row | Exact fixed (\phi_-)-MSR/SMSR modulus 1.  Every (\phi_+)-MSR constant fails along the complementary explicit phase subsequence. |
| Verdict | Same `C-DISAGREE` at tuned step.  GX-025/026 have identical power signatures but incomparable exact gauges, so shared algebra is not duplicate phase evidence. |

## 3. Scalar nonlinear, multibranch and oscillatory objects

### GX-027 -- asymmetric mixed powers

| Property row | Independent C result |
|---|---|
| Object / reference | (F(x)=x^2) for (x\ge0), (F(x)=-\sqrt{-x}) for (x<0); full-domain increasing homeomorphism, (F^{-1}(y)=\sqrt y) for (y\ge0), (-y^2) for (y<0), (S=\{0\}). |
| Graph geometry | Exact products are ((x-y)^2(x+y)) on the positive side, ((s-t)^2(s+t)) for (x=-s^2,y=-t^2), and ((x+t^2)(x^2+t)) across sides.  Thus (\langle a,b\rangle\ge0), (m_*=0), but no positive local coco modulus at 0.  Maximal monotone. |
| (J/R), RL | (J) is the explicit quadratic-root branch on each side (C §GX-027); no collision.  (R) is globally nonexpansive with sharp (L_1=1).  Both unbounded tails defeat global subunit RL; window estimates are inherited and the local exponent is 1. |
| Regularity | Residual is (x^2) on (x\ge0) and (|x|^{1/2}) on (x<0).  Fixed (q_*=1/2), MSR/SMSR modulus 1.  The inverse is exactly locally (1/2)-Hölder with two-target MR/strong-Hölder-MR, Aubin/calm/isolated-calm endpoint modulus 1.  All ordinary Core/Inv and ordinary HREG/UHREG fail; centered (1/2)-HREG/UHREG have modulus 1. |
| Verdict | Isolated/nonvacuous.  B labels pass; C adds the complete two-target (q=1/2) signature. |

### GX-028 -- even polynomial (F(x)=x^2)

| Property row | Independent C result |
|---|---|
| Object / reference | Full-domain single-valued (F=x^2), set-valued inverse (F^{-1}(y)=\{\pm\sqrt y\}) for (y\ge0), empty for (y<0); (S=\{0\}). |
| Graph geometry | (b=(x+y)a), (\langle a,b\rangle=(x+y)a^2).  On ([-\delta,\delta]), sharp hypomonotonicity defect (2\delta); in every two-sided zero neighborhood, (c_*=-\infty).  Not monotone. |
| (J/R), RL | (J_{\lambda F}(p)=\{[-1\pm\sqrt{1+4\lambda p}]/(2\lambda)\}).  The full graph has a Minty collision for every (\lambda>0), so every global exponent fails.  On the central branch (|x|\le\delta<1/(2\lambda)), sharp RL\(_1) is ((1+2\lambda\delta)/(1-2\lambda\delta)); at equality the ratio blows up, above it an exact collision occurs.  Subunit branch bounds are inherited. |
| Regularity | Exact (|x|=|F(x)|^{1/2}): fixed MSR/SMSR and inverse calm/isolated-calm have endpoint (q=1/2), modulus 1; ordinary versions fail.  Negative targets defeat HREG/UHREG, MR/Aubin and every two-target (q)-MR; branch multiplicity also defeats SMR. |
| Verdict | Isolated/nonvacuous.  B labels and the critical branch distinction pass. |

### GX-029 -- nonisolated cubic cylinder

| Property row | Independent C result |
|---|---|
| Object / reference | (F(x,z)=(x^3,0)) on (\mathbb R^2), at (((0,\bar z),(0,0))).  (S=\{0\}\times\mathbb R); inverse fibers are cylinders when the target second coordinate is zero, empty otherwise. |
| Graph geometry | (\langle a,b\rangle=(x-y)^2(x^2+xy+y^2)\ge0).  (m_*=0), global (c_*=0); on (|x|,|y|\le\delta), sharp local (c_*=1/(3\delta^2)).  Maximal monotone. |
| (J/R), RL | (J(p_1,p_2)=(j_\lambda(p_1),p_2)), (R=(2j_\lambda-p_1,p_2)), (j+\lambda j^3=p_1).  Sharp global RL\(_1=1), forced by the identity coordinate; every global subunit exponent fails. |
| Regularity | (d((x,z),S)=|x|=\|F(x,z)\|^{1/3}).  Fixed (q_*=1/3), MSR/calm endpoint modulus 1.  SMSR/isolated calm fail for every exponent by the zero line.  MR/Aubin, SMR and HREG/UHREG fail by empty off-plane target fibers; no two-target (q)-MR. |
| Verdict | Nonisolated but the transverse power EB is nonvacuous.  B labels pass. |

### GX-030 -- critical Cayley cusp (F(x)=x^3-x)

| Property row | Independent C result |
|---|---|
| Object / zeros | Full-domain scalar map, (S=\{-1,0,1\}).  Each graph reference ((0,0),(\pm1,0)) is treated locally despite the global three-branch inverse. |
| Graph geometry | With (c=x^2+xy+y^2), (b=(c-1)a), (\langle a,b\rangle=(c-1)a^2).  Global (m_*=-1), (c_*=-\infty).  Point slope is (-1) at 0 and (2) at (\pm1) (point coco (1/2)). |
| RL, (0<\eta<1) | Minty map is a global homeomorphism; sharp global RL\(_1=(1+\eta)/(1-\eta)).  All global subunit exponents fail by the unbounded tail. |
| RL, critical (\eta=1) | (J(p)=\sqrt[3]p, R=2\sqrt[3]p-p).  Near 0 the maximal all-pairs exponent is genuinely (1/3), with sharp local (L=2^{5/3}); larger exponents fail on symmetric pairs.  No global exponent holds. |
| RL, (\eta>1) | Full graph has distinct pairs with (d=0\ne r), so every global exponent fails; a sufficiently small zero branch still has local RL\(_1). |
| Regularity at ((0,0)) | Core and Inv all exact 1; HREG/UHREG exact 1.  Largest fixed/two-target exponent 1. |
| Regularity at ((\pm1,0)) | Core, Inv, HREG and UHREG all exact (1/2); each inverse localization is single-valued. |
| Verdict | `C-REFINE`: B's qualitative label passes; the critical sharp local constant is (2^{5/3}), not a triangle-bound surrogate. |

### GX-031 -- clipped power Cayley map

| Property row | Independent C result |
|---|---|
| Object | (C_\alpha(s)=\operatorname{sgn}(s)\min\{|s|^\alpha,1\}), (0<\alpha<1); (u=(s+C_\alpha s)/2), (v=(s-C_\alpha s)/(2\lambda _0)).  Full-domain single-valued (F), (S=\{-1,0,1\}). |
| Graph geometry | (\langle a,b\rangle=(|\Delta s|^2-|\Delta C|^2)/(4\lambda _0)).  Sharp (m_*=-1/\lambda _0); (c_*=-\infty). |
| (J/R), RL | At the generating step (J=u,R=C_\alpha), no collision.  For every (0<\gamma\le\alpha), exact global (L_\gamma^*=2^{1-\gamma}); every (\gamma>\alpha) fails near 0.  Maximal exponent (\alpha) is genuine; smaller global exponents also use clipping. |
| Reference ((0,0)) | Core, Inv, HREG and UHREG all exact (\lambda _0), largest regularity exponent 1. |
| References ((\pm1,0)) | Core and Inv all exact (\lambda _0(1+\alpha)/(1-\alpha)); local zeros isolated and branch-local. |
| Verdict | B labels pass; C proves the exact global constants for all (\gamma\le\alpha). |

### GX-032 -- Luke--Tam restricted negative square root

| Property row | Independent C result |
|---|---|
| Object / source | (F(t^2)=-t), (0\le t\le1/4), i.e. (U=[0,1/16]), (W=\mathbb R), at ((0,0)), step 1.  `P3-DIRECT` object/restriction from Luke--Tam Example 2; all constants independently recomputed.  (S=\{0\}). |
| Graph geometry | For (c=s+t), (a=(t-s)c, b=-(t-s)), (ab=-(t-s)^2c).  No finite hypomonotonicity in any right zero-neighborhood.  Sharp restricted (c_*=-1/2), i.e. cohypomonotonicity defect (1/2). |
| LT / (J/R) / RL | (d=(t-s)(c-1), r=(t-s)(c+1)).  Sharp LT violation (\tau_*=2), sharp RL\(_1) constant (L=3).  (D=[-3/16,0]), (J(p)=t^2), (R=t^2+t) with (t=(1-\sqrt{1+4p})/2).  No collision.  Subunit exponents on the bounded restriction are inherited; maximal local exponent 1. |
| Regularity | Exact (x=|F(x)|^2).  Fixed MSR/SMSR and inverse calm/isolated calm hold for (q\le2), endpoint modulus 1; ordinary exact modulus 0 by `SUPERLINEAR-GERM` (nonvacuous, residual (\to0)).  MR/Aubin, SMR and HREG/UHREG fail for every power by small positive target fibers being empty. |
| Verdict | Isolated, nonvacuous on (x\downarrow0^+).  B labels pass; source restriction and (\tau=2) cannot be altered. |

### GX-033 -- single-valued absolute-value map (F(x)=|x|)

| Property row | Independent C result |
|---|---|
| Object | Full-domain scalar map, (S=\{0\}); inverse (\{\pm y\}) for (y>0), singleton 0 at 0, empty for (y<0).  EX-16/SVG-14. |
| Graph geometry | Positive branch slope 1, negative branch slope (-1), cross products (r^2-s^2).  Sharp local/global (m_*=-1); (c_*=-\infty). |
| RL for (0<\lambda<1) | (J=p/(1-\lambda)) on (p<0), (p/(1+\lambda)) on (p\ge0); sharp global RL\(_1=(1+\lambda)/(1-\lambda)).  Global subunit exponents fail. |
| RL for (\lambda\ge1) | At (\lambda=1) the negative branch collapses to input 0; for (\lambda>1) two branches share every small positive input.  Full-graph RL fails for all exponents.  For (\lambda>1) only, the solution-anchored RL\(_1) ratio is finite, sharp ((1+\lambda)/(\lambda-1)); it does not imply all-pairs RL. |
| Regularity | Exact (d(x,S)=d(0,F(x))=|x|).  MSR/SMSR/calm/isolated calm exact 1, fixed (q_*=1).  MR/Aubin, SMR and HREG/UHREG fail by negative targets and branch coverage. |
| Verdict | Isolated/nonvacuous.  B labels pass; anchored/full relation separation is essential. |

### GX-034 -- oscillatory coefficient (F(x)=x(2+\sin(1/x)))

| Property row | Independent C result |
|---|---|
| Object | (F(0)=0), full-domain scalar map, (S=\{0\}); inverse is the full root set of (x(2+\sin(1/x))=y). |
| Graph geometry | (\langle a,b\rangle=(x-y)[2(x-y)+x\sin(1/x)-y\sin(1/y)]).  Derivative phases give (m_*=c_*=-\infty) in every zero neighborhood. |
| Anchored RL | Against ((0,0)), for every (\eta>0), sharp

\[
L_{\rm anc}(\eta)=\max\left\{\frac{|1-\eta|}{1+\eta},
\frac{|1-3\eta|}{1+3\eta}\right\}<1.
\]

This is a graph-anchored estimate, not a selected Cayley-map property. |
| Full (J/R), RL | (g_\eta(u)=u[1+\eta(2+\sin(1/u))]) is noninjective in every zero neighborhood.  Accumulating Minty collisions make (J,R) relations and defeat every local all-pairs exponent. |
| Regularity | ( |x|\le|F(x)|\le3|x|\).  MSR/SMSR/calm/isolated calm exact 1; fixed (q_*=1).  MR/SMR/Aubin fail by accumulating folds/critical points.  HREG and UHREG hold with exact (1/3), using the nearest oscillatory preimage. |
| Verdict | Isolated/nonvacuous.  B's anchored/all-pairs split passes; `C-ADD`: exact HREG/UHREG modulus (1/3). |

### GX-035 -- two-branch relation (F(x)=\{-x,x\})

| Property row | Independent C result |
|---|---|
| Object | Self-inverse relation, (S=\{0\}); EX-18/SVG-12, qualitative source locator in CDK. |
| Graph geometry | Same-branch products are (\pm a^2); cross branch (a=x-y,b=x+y), (ab=x^2-y^2).  Explicit sequences give (m_*=c_*=-\infty) locally. |
| (J/R), RL | If (\lambda\ne1), (J(p)=\{p/(1+\lambda),p/(1-\lambda)\}); at (\lambda=1) the negative branch collapses to input 0.  Same-input distinct reflections occur for every step and in every zero window, so every all-graph exponent fails. |
| Regularity | Global identity (d(x,F^{-1}y)=\min\{|x-y|,|x+y|\}=d(y,F(x))).  MR/MSR/SMSR exact 1; Aubin/calm/isolated calm and HREG/UHREG exact 1.  SMR alone fails because every nonzero target has two local inverse points.  All (q\le1) versions hold; (q>1) fails. |
| Verdict | Isolated/nonvacuous.  B labels pass; this is the canonical MR+SMSR-not-SMR witness. |

### GX-036 -- vertical slab multifunction

| Property row | Independent C result |
|---|---|
| Object | (F(x)=\mathbb R) for (|x|\le1), empty otherwise; (F^{-1}(y)=[-1,1]) for all (y), (S=[-1,1]). |
| Graph geometry | Local (a,b) vary independently; scale-swapped pairs give (m_*=c_*=-\infty). |
| (J/R), RL | (J(p)=[-1,1]), (R(p)=2[-1,1]-p).  Pairs (a\ne0,b=-a/\lambda) give collisions, so every exponent fails locally/globally. |
| Regularity at ((0,0)) | After shrinking inside the slab, (d(x,F^{-1}y)=d(y,F(x))=d(x,S)=0).  MR/MSR, Aubin/calm and HREG/UHREG hold for every power with exact 0 by `FULL-VALUE + BIG-SOLUTION`.  SMSR/isolated calm and SMR fail by interval fibers. |
| Verdict | No empty-domain vacuity at the reference, but the regularity is still trivial.  B labels pass. |

### GX-037 -- inverse oscillation (F=G^{-1}), (G(t)=t\sin(1/t))

| Property row | Independent C result |
|---|---|
| Object | (G(0)=0), (F=G^{-1}), (S=\{0\}); (F(0)=\{0\}\cup\{1/(k\pi):k\ne0\}). |
| Graph geometry | Parameter product (\langle a,b\rangle=(t-s)[G(t)-G(s)]).  Derivative phases yield (m_*=c_*=-\infty) in every zero neighborhood. |
| (J/R), RL | Minty parameter (H_\lambda(t)=t[\lambda+\sin(1/t)]) is noninjective in every zero neighborhood, so all local all-pairs exponents fail.  Anchored denominator already vanishes if (\lambda\le1); for (\lambda>1), anchored RL\(_1) has sharp ((\lambda+1)/(\lambda-1)), but collisions remain. |
| Fixed-target regularity | (|x|\le d(0,F(x))), with equality on phase sequences.  MSR/SMSR/calm/isolated calm exact 1; fixed (q_*=1). |
| Two-target Hölder regularity | Ordinary MR/SMR/Aubin fail because (G) is not Lipschitz.  (G) is locally (1/2)-Hölder all-pairs and no better, so (F) has (1/2)-MR and a single-valued (1/2)-strong-MR localization.  The exact endpoint modulus is

\[
K^*=\sup_{\Delta>0}\frac{2|\sin(\Delta/2)|}{\sqrt\Delta}
=\frac{\sqrt2\sin x_*}{\sqrt{x_*}}
\approx1.20383666149,
\]

where (x_*\in(0,\pi/2)) is the unique root of (\tan x_*=2x_*). |
| HREG/UHREG | HREG exact 1 since (|G(y)|\le|y|); UHREG fails along perturbations of the extra points in (F(0)). |
| Verdict | Isolated fixed zero and nonvacuous EB.  `C-ADD`: maximal pairwise exponent (1/2) and HREG/UHREG separation; no B reversal. |

### GX-038 -- sparse vertical fibers plus signed-square curve

| Property row | Independent C result |
|---|---|
| Object | (K=\{0\}\cup\{1/n:n\ge1\}); (F(x)=\mathbb R) for (x\in K), otherwise (F(x)=\operatorname{sgn}(x)x^2).  (S=K), (F^{-1}(y)=K\cup\{\operatorname{sgn}(y)\sqrt{|y|}\}). |
| Graph geometry | Vertical-fiber sequences give (m_*=c_*=-\infty). |
| (J/R), RL | (K\subset J_{\lambda F}(p)) for every (p), hence (2K-p\subset R(p)).  Explicit accumulating collisions (d=0\ne r) defeat every local/global exponent. |
| Fixed-target regularity | (d(x,K)\le|x|=d(0,F(x))^{1/2}), with equality for negative (x\to0).  (q_*=1/2), MSR endpoint modulus 1.  SMSR and isolated calm fail for every exponent because (1/n\to0) are zeros. |
| Two-target inverse regularity | Ordinary MR/Aubin/calm fail.  Exact (1/2)-MR, (1/2)-Aubin and (1/2)-calm modulus is 1, using the common (K) branch; no Hölder strong MR because every localization contains infinitely many (K)-points. |
| HREG/UHREG | Both exact 0 by `FULL-VALUE`: (0\in F^{-1}(y)) for every target and (F(0)=\mathbb R). |
| Verdict | `C-ADD`: exact fractional MR/Aubin and centered moduli.  Ordinary B labels pass. |

### GX-039 -- saturated identity

| Property row | Independent C result |
|---|---|
| Object | (F(x)=\operatorname{clip}(x,-1,1)), (S=\{0\}); inverse is identity for (|y|<1), half-lines at endpoints, empty outside range. |
| Graph geometry | (\langle a,b\rangle\ge|b|^2\).  Global (m_*=0, c_*=1); on a zero neighborhood (m_*=c_*=1). |
| (J/R), RL | Exact three-piece formulas are in C §GX-039.  Sharp global RL\(_1=1), no collision.  Affine tails defeat every global subunit exponent; window bounds are inherited. |
| Local regularity at ((0,0)) | (F) and its inverse are identity localizations.  Core, Inv, HREG and UHREG all exact 1; largest fixed/two-target exponent 1.  Isolated/nonvacuous. |
| Global residual observation | No global fixed-power EB: (|x|\to\infty) while (d(0,F(x))=1) on the tails. |
| Verdict | B labels pass; local and global error-bound quantifiers are separate rows. |

## 4. Set-valued normals, set regularity and reference/residual separation

For GX-047--052 the set mapping (\Phi:X\rightrightarrows X^2) is not an
endomorphism.  Operator inner products, (J,R), and RL are therefore **N/A**,
not “false.”  The output norm is the max product norm, while the input uses
the Euclidean/Hilbert norm.

### GX-040 -- vertical normal (N_{\{0\}})

| Property row | Independent C result |
|---|---|
| Canonical object / aliases | (F(0)=H), empty elsewhere; SVG-06/RM-04 are aliases in the printed fixed space.  The GX-070 primal is another member of the dimension-parameterized canonical (N_{\{0\}}) family, not necessarily a literal same-space alias.  (S=\{0\}), (F^{-1}(y)=\{0\}) for every (y). |
| Graph geometry | Every difference has (a=0), (\langle a,b\rangle=0).  Every input-scaled strong coefficient is `GRAPH-VACUOUS`; best (c_*=0).  (\Sigma=\{(\mu,\rho):\rho\le0,\mu\in\mathbb R\}). |
| (J/R), RL | (J(p)=0, R(p)=-p).  Sharp global RL\(_1=1); global subunit RL fails.  Output-truncated window estimates are inherited, with open-window supremum ((2\lambda\delta)^{1-\gamma}). |
| Regularity at every ((0,\bar y)) | Core and Inv all exact 0; HREG/UHREG exact 0.  The inverse is a global constant singleton, so MR/SMR use `BRANCH-PINNING`; mapping-side MSR/SMSR use `DOMAIN-VACUOUS`.  Every power/gauge version has the same infimum 0. |
| Verdict | Zero is isolated.  B labels pass, but neither vacuous graph strength nor mapping-side vacuity is evidence for a trade-off. |

### GX-041 -- singleton graph

| Property row | Independent C result |
|---|---|
| Object | (\operatorname{gph}F=\{(0,0)\}), (S=\{0\}); nonmaximal. |
| Graph / (J/R) / RL | Only (a=b=0): every monotonicity and RL formula is `GRAPH-VACUOUS`.  (D_\lambda=\{0\}), (J(0)=R(0)=0), infimal (L=0) for every exponent; there is no full-domain resolvent. |
| Regularity | MSR/SMSR and inverse calm/isolated calm have exact 0 by `DOMAIN-VACUOUS`; zero is isolated.  MR/SMR/Aubin, HREG and UHREG fail because every nonzero nearby target has empty inverse. |
| Verdict | B labels pass.  This shows domain-vacuous SMSR does not imply target coverage. |

### GX-042 -- subspace normal and projection residual

| Property row | Independent C result |
|---|---|
| Canonical normal map | (F=N_L) for a proper closed subspace (L); (\operatorname{gph}F=L\times L^\perp), (S=L), inverse is (L) on (L^\perp) and empty otherwise.  SVG-10. |
| (N_L) graph / RL | (a\in L,b\in L^\perp), so (\langle a,b\rangle=0), (m_*=c_*=0), (\Sigma=(-\infty,0]^2).  (J=P_L, R=2P_L-I) is an isometry.  Sharp global RL\(_1=1); subunit global RL fails and window constant (\Delta^{1-\gamma}) is inherited. |
| (N_L) regularity at ((\bar x,0)) | MSR/calm exact 0 by `DOMAIN-VACUOUS + BIG-SOLUTION`; SMSR/isolated calm fail.  MR/Aubin, SMR and HREG/UHREG fail by targets with an (L)-component. |
| Distinct residual (G=I-P_L=P_{L^\perp}) | (\langle a,Ga\rangle=\|Ga\|^2): (m_*=0,c_*=1).  (J_{\lambda G}=P_L+(1+\lambda)^{-1}P_{L^\perp}), (R=P_L+(1-\lambda)(1+\lambda)^{-1}P_{L^\perp}), sharp global RL\(_1=1); subunit global RL fails on (L). |
| (G) regularity / residual | Exact nonvacuous (d(x,L)=\|Gx\|), so MSR/calm modulus 1, (q_*=1).  MR/Aubin and HREG/UHREG fail by off-range targets; SMSR/isolated calm and SMR fail by the zero subspace. |
| Verdict | B labels pass.  The normal-cone residual and projection/fixed-point residual are separate property rows, not aliases. |

### GX-043 -- vertical-value multifunction

| Property row | Independent C result |
|---|---|
| Object | (F(x_1,x_2)=\{x_1\}\times\mathbb R), (S=\{0\}\times\mathbb R), (F^{-1}(y)=\{y_1\}\times\mathbb R). |
| Graph geometry | (a=(\alpha,\beta),b=(\alpha,\delta)), (\langle a,b\rangle=\alpha^2+\beta\delta).  Scale swaps give (m_*=c_*=-\infty), locally and globally. |
| (J/R), RL | (J(p)=\{p_1/(1+\lambda)\}\times\mathbb R), (R(p)=\{(1-\lambda)p_1/(1+\lambda)\}\times\mathbb R).  Same-input distinct selections give collisions, so every exponent fails. |
| Regularity | Global identity (d(x,F^{-1}y)=|x_1-y_1|=d(y,F(x))).  MR/MSR, Aubin/calm and HREG/UHREG exact 1.  SMSR/isolated calm and SMR fail because every inverse fiber is a vertical line.  Largest nontrivial power is 1. |
| Verdict | Full domain and finite residuals: target-uniform regularity is genuine despite arbitrarily bad graph moduli.  B labels pass. |

### GX-044 -- union (F(x)=\{0,x\})

| Property row | Independent C result |
|---|---|
| Object | Horizontal zero branch plus identity branch; (S=\mathbb R), inverse is (\mathbb R) at 0 and singleton (y) otherwise. |
| Graph geometry | Cross product (\langle a,b\rangle=(x-y)x); explicit scale choices yield (m_*=c_*=-\infty) locally. |
| (J/R), RL | (J(p)=\{p,p/(1+\lambda)\}), (R(p)=\{p,(1-\lambda)p/(1+\lambda)\}).  Cross branches collide at every nonzero input, so all local/global exponents fail. |
| Fixed-target regularity | MSR/calm exact 0 for every power/gauge only by `BIG-SOLUTION`; SMSR/isolated calm and SMR fail.  MR/Aubin fails by the target-to-zero ratio at fixed (x\ne0). |
| HREG/UHREG | Both exact 1 at ((0,0)), because (d(0,F^{-1}y)=|y|=d(y,F(0))). |
| Verdict | B candidate UHREG audit is resolved positively; MSR+HREG still does not give MR. |

### GX-045 -- unit-circle full normal and norm-truncated graph

| Property row | Independent C result |
|---|---|
| Canonical object / source | (F=N_{S^1}), (N_{S^1}(x)=\mathbb Rx); `P2-DERIVED` from the prox-regular circle context.  (S=S^1), inverse of (y\ne0) is (\{\pm y/\|y\|\}). |
| Full graph geometry | For ((x,tx),(y,sy)),

\[
\langle a,b\rangle=(t+s)(1-\langle x,y\rangle)
=\frac{t+s}{2}\|x-y\|^2.
\]

The full cone has (m_*=c_*=-\infty). |
| Full (J/R), RL | (J(p)=S^1) at (p=0), and (J(p)=\{\pm p/\|p\|\}) for (p\ne0); (R=2J-I).  At input 0 distinct normals collide, so every global or full-normal local exponent fails. |
| Truncated graph (|t|\le r_0) | Sharp (m_*=-r_0), while (c_*=-\infty).  If (\lambda r_0<1), the Minty annulus has unique (J=p/\|p\|), (R=2p/\|p\|-p), with sharp global-on-annulus RL\(_1=(1+\lambda r_0)/(1-\lambda r_0)).  Subunit estimates are compact-annulus inherited.  At (\lambda r_0\ge1), collision or blow-up defeats every exponent. |
| Local attentive normal branch | At ((\bar x,0)), an output truncation (r_0<1/\lambda) has limiting local RL\(_1) modulus 1.  This is the prox-regular branch, not the full normal cone. |
| Regularity at ((\bar x,0)) | MSR/calm exact 0 by `DOMAIN-VACUOUS + BIG-SOLUTION`; SMSR/isolated calm fail.  MR/Aubin, SMR and HREG/UHREG fail by tangential/nonparallel targets. |
| Verdict | B labels pass.  Prox-regularity controls only value-truncated normals; it supplies neither a full-cone quadratic modulus nor a full resolvent. |

### GX-046 -- limiting subgradient of (-|x|) and affine shift

| Property row | Independent C result |
|---|---|
| Canonical object / references | (F=\partial(-|x|)): value 1 for (x<0), ({-1,1\}) at 0, value (-1) for (x>0).  Main reference ((0,1)).  The shifted map (F-1=\partial(-|x|-x)) at ((0,0)) has identical graph differences and shifted target regularity. |
| Attentive branch | An output neighborhood of 1 retains (x\le0,u=1): (b=0,\langle a,b\rangle=0).  It is monotone with (m_*=0); positive coco coefficients are graph-degenerate.  RL\(_1=1) on a base window; subunit estimates are inherited. |
| Full graph geometry | Cross pairs have (a=-h,b=2,\langle a,b\rangle=-2h).  No finite local hypomonotonicity on a two-sided base window.  On (|x|,|y|\le\delta), sharp (c_*=-\delta); globally (c_*=-\infty). |
| Full/restricted (J/R), RL | The full relation has branches (p\pm\lambda) and reflected values (p\pm2\lambda), hence global collisions and no global exponent.  On the full two-branch base restriction (|x|\le\delta<\lambda), sharp

\[
L_1^*=\frac{\lambda+\delta}{\lambda-\delta},\qquad
L_\gamma^*=\max\left\{\delta^{1-\gamma},
2^{1-\gamma}\frac{\lambda+\delta}{(\lambda-\delta)^\gamma}\right\}.
\]

At (\delta\ge\lambda), collision occurs. |
| Regularity at ((0,1)) | For (x>0), solution distance (x) but residual 2; hence MSR/calm exact 0 by `RESIDUAL-JUMP`.  SMSR/isolated calm fail by the half-line solution set.  MR/Aubin, SMR and HREG/UHREG fail because nearby targets other than 1 have empty inverse. |
| Prox-regularity row | (-|x|) is not prox-regular at ((0,1)): the support test requires (r\ge4/t).  An attentive monotone branch alone is insufficient. |
| Verdict | `C-DISAGREE-SCOPE`: “no finite local RL” is false for a small base restriction; only the untruncated global relation necessarily fails.  Shifted reference inherits all values. |

### GX-047 -- transverse coordinate axes set mapping

| Property row | Independent C result |
|---|---|
| Object | (A=\mathbb Re_1,B=\mathbb Re_2), (\Phi(x)=(A-x)\times(B-x)), (S=\{0\}).  (\Phi^{-1}(u,v)=\{(-v_1,-u_2)\}). |
| Graph / RL | N/A: (\Phi:X\rightrightarrows X^2).  The individual normal cones are different objects. |
| Regularity | With max output norm, Core all exact (\sqrt2); Inv all exact (\sqrt2); HREG/UHREG exact (\sqrt2).  Global inverse is single-valued, and the estimates are nonvacuous. |
| Set geometry | Transversal lines at angle (\pi/2); exact LR constant (\sqrt2=1/\sin(\pi/4)). |
| Verdict | B labels pass. |

### GX-048 -- identical lines set mapping

| Property row | Independent C result |
|---|---|
| Object | (A=B=L=\mathbb Re_1), (\Phi(x)=(L-x)^2), (S=L).  Inverse is a translated horizontal line when (u_2=v_2), empty otherwise. |
| Graph / RL | N/A. |
| Regularity | Exact global fixed-target law (d(x,S)=d_{\max}(0,\Phi(x))=|x_2|): MSR/calm modulus 1.  SMSR/isolated calm fail by nonisolation.  MR/Aubin, SMR and HREG/UHREG fail by incompatible small translations. |
| Set geometry | Not transversal, but globally subtransversal/linearly regular with exact constant 1. |
| Verdict | B labels pass; this is the strict transversality-to-subtransversality witness. |

### GX-049 -- tangent line and parabola set mapping

| Property row | Independent C result |
|---|---|
| Object | (A=\{(s,0)\}, B=\{(t,t^2)\}), (\Phi(x)=(A-x)\times(B-x)), (S=\{0\}).  Inverse has two/single/empty branches according as (v_2-u_2) is positive/zero/negative. |
| Graph / RL | N/A. |
| Fixed-target regularity | For (r(x)=\max\{d(x,A),d(x,B)\}),

\[
\limsup_{x\to0}\frac{\|x\|}{r(x)^{1/2}}=\sqrt2.
\]

Thus maximal (q_*=1/2), exact MSR/SMSR and (1/2)-calm/isolated-calm modulus (\sqrt2); ordinary MSR/SMSR/calm/isolated calm fail. |
| Target-uniform properties | MR/Aubin, SMR and HREG/UHREG fail by small translations with (v_2-u_2<0) and empty inverse. |
| Set geometry / verdict | Tangent, nontransversal and not linearly subtransversal; surviving geometry is second order.  `VERIFIED-ALG; C-UPGRADE`: B's full-neighborhood candidate is proved with sharp constant (\sqrt2). |

### GX-050 -- infinite-dimensional zero-angle subspaces

| Property row | Independent C result |
|---|---|
| Object | (H=\ell^2\oplus\ell^2), (A=\ell^2\oplus\{0\}), (B=\operatorname{gra}T), (Te_n=e_n/n); (\Phi(x)=(A-x)\times(B-x)), (S=\{0\}). |
| Graph / RL | N/A. |
| Regularity | Scaled (e_n) directions prove that MSR/SMSR and inverse calm/isolated calm fail for **every** power (q>0); MR/Aubin, SMR and HREG/UHREG fail as well, directly also by outputs outside (\operatorname{ran}T). |
| Set geometry | Friedrichs angle 0 and (A+B=\ell^2\oplus\operatorname{ran}T) nonclosed.  Even though the bare normal intersection is trivial, there is no transversality or subtransversality. |
| Verdict | Isolated and nonvacuous failure.  B labels pass; `NONCLOSED-RANGE` is the operative mechanism. |

### GX-051 -- isolated component plus tangent component

| Property row | Independent C result |
|---|---|
| Object | (A=\mathbb R\times\{0\}), (B=\{0\}\cup\{(2+t,t^2)\}), (\Phi(x)=(A-x)\times(B-x)), (S=\{(0,0),(2,0)\}). |
| Graph / RL | N/A. |
| Reference (\bar x=0) | Locally the isolated component is the nearest point: (d(x,S)=d(x,B)=\max\{d(x,A),d(x,B)\}).  MSR/SMSR and calm/isolated calm exact 1, (q_*=1).  MR/Aubin, SMR and HREG/UHREG fail by a small vertical translation producing an empty inverse. |
| Bounded-set observation | Near the second solution (x_t=(2+t,0)), the linear ratio is at least (1/|t|).  Hence no bounded or global linear regularity despite exact local constant 1 at 0. |
| Verdict | B labels pass; local reference and bounded-set observations are separate rows. |

### GX-052 -- isolated point plus asymptotic hyperbola

| Property row | Independent C result |
|---|---|
| Object | (A=\mathbb R\times\{0\}), (B=\{0\}\cup\{(t,1/t):t\ge1\}), (\Phi(x)=(A-x)\times(B-x)), (S=\{0\}). |
| Graph / RL | N/A. |
| Local reference (0) | Locally (d(x,S)=d(x,B)=\max\{d(x,A),d(x,B)\}).  MSR/SMSR and calm/isolated calm exact 1, (q_*=1).  MR/Aubin, SMR and HREG/UHREG fail by small negative-height translations with empty inverse. |
| Bounded/global observation | On (\|x\|\le R), safe LR modulus (\kappa_R=\max\{1,4R^2\}) (not claimed sharp).  Along ((t,0)), the global ratio is at least (t^2\), so no global LR. |
| Verdict | B labels pass; local, bounded and global quantifiers remain distinct. |

## 5. Generalized-monotonicity separation records

### GX-053 -- restricted negative square (F(x)=-x^2)

| Property row | Independent C result |
|---|---|
| Object / reference | (F(x)=-x^2) on (0\le x\le1/2), empty otherwise; (S=\{0\}), (F^{-1}(y)=\sqrt{-y}) for (-1/4\le y\le0).  Project `ALG`; Spingarn historical naming remains `PENDING_PRIMARY_FULLTEXT`. |
| Graph geometry | With (s=x+y\in[0,1]), (b=-sa), (\langle a,b\rangle=-sa^2).  Sharp global-on-domain (m_*=-1), while (c_*=-\infty) as (s\downarrow0).  Both one-fixed and two-moving first-order liminf formulae at a base point equal 0; only the formula, not the pending historical name, is asserted. |
| RL for (0<\lambda<1) | Minty map is injective; sharp (L_1=(1+\lambda)/(1-\lambda)) and LT (\tau=\lambda/(1-\lambda)^2).  Global subunit behavior is bounded-domain inherited. |
| Critical (\lambda=1) | (J(p)=(1-\sqrt{1-4p})/2) on (D=[0,1/4]).  No finite RL\(_1); maximal exponent is genuinely (1/2), sharp (L=2).  For (0<\gamma\le1/3), sharp (L_{1,\gamma}=3\,2^{2\gamma-2}); for (1/3\le\gamma<1/2), sharp (L_{1,\gamma}=(1-\gamma)^{-1}[(1-2\gamma)/(1-\gamma)]^{1-2\gamma}).  Every (\gamma>1/2) fails. |
| (\lambda>1) | The Minty map folds in the domain, so every exponent fails by collision. |
| Reference ((0,0)) | Exact (x=|F(x)|^{1/2}).  Fixed (q_*=1/2), MSR/SMSR and (1/2)-calm/isolated-calm modulus 1; ordinary versions fail.  MR/Aubin, SMR and HREG/UHREG fail for every exponent requiring nearby positive targets. |
| Reference ((1/2,-1/4)) | Fixed-target linear MSR/SMSR exact 1; two-sided MR/SMR/HREG fail because targets below (-1/4) have empty inverse. |
| Verdict | B labels pass; C adds all-step phase and sharp subcritical constants. |

### GX-054 -- negative cubic (F(x)=-x^3)

| Property row | Independent C result |
|---|---|
| Object | Full-domain decreasing homeomorphism, (S=\{0\}), (F^{-1}(y)=-\sqrt[3]y). |
| Graph geometry | (\langle a,b\rangle=-(x^2+xy+y^2)a^2).  No finite global hypomonotonicity; on ([-M,M]), sharp defect (3M^2).  No finite cohypomonotonicity in any zero neighborhood. |
| (J/R), RL | For every (\lambda>0), (g_\lambda(0)=g_\lambda(\pm\lambda^{-1/2})=0), so global all-graph RL fails by a three-point collision.  On ([-M,M]) with (3\lambda M^2<1), sharp branch (L_1=(1+3\lambda M^2)/(1-3\lambda M^2)) and (\tau=3\lambda M^2/(1-3\lambda M^2)^2); subunit branch estimates inherited. |
| Regularity at 0 | Exact (|x|=|F(x)|^{1/3}).  Fixed MSR/SMSR modulus 1 at (q_*=1/3); two-target (1/3)-MR/Hölder-Aubin and branch strong-Hölder modulus (2^{2/3}).  Ordinary Core/Inv properties fail. |
| Nonzero reference | Ordinary SMR modulus (1/(3x_0^2)). |
| Verdict | Isolated/nonvacuous.  B labels pass; C supplies explicit Minty collision and fixed/pairwise constant split. |

### GX-055 -- isolated point plus pole branch

| Property row | Independent C result |
|---|---|
| Object | (F(0)=0, F(x)=-1/x) for (0<x\le\varepsilon<1), empty otherwise.  Closed disconnected graph, (S=\{0\}); small nonzero targets have empty inverse. |
| Graph geometry | Positive-branch pairs have (\langle a,b\rangle=a^2/(xy)>0); a pole point against ((0,0)) has product (-1).  Thus (m_*=-\infty), even locally at 0.  Sharp global (c_*=-\varepsilon^2).  The displayed anchored Spingarn quotient tends to (-\infty). |
| (J/R), RL | For (\lambda>\varepsilon^2), (D=(-\infty,\varepsilon-\lambda/\varepsilon]\cup\{0\}), (J(p)=(p+\sqrt{p^2+4\lambda})/2) on the pole cluster and (J(0)=0).  Sharp (L_1=(\lambda+\varepsilon^2)/(\lambda-\varepsilon^2)), (\tau=\lambda\varepsilon^2/(\lambda-\varepsilon^2)^2).  For (\lambda\le\varepsilon^2), collision or denominator collapse defeats all RL.  No global subunit exponent because (R(p)\sim|p|). |
| Regularity at 0 | For every (q>0), (|x|/|F(x)|^q=x^{q+1}\to0).  MSR/SMSR/calm/isolated calm of every fixed power have exact 0 by `RESIDUAL-ESCAPE/GRAPH-ISOLATION`, not pure domain vacuity.  MR/Aubin, SMR and HREG/UHREG fail by missing small target fibers. |
| Verdict | B labels pass; exact cohypomonotonicity and step threshold are C additions. |

### GX-056 -- rational/irrational sign staircase

| Property row | Independent C result |
|---|---|
| Object | (F(0)=0); for (0<|x|<\delta<1/2), (F(x)=\operatorname{sgn}(x)) on rationals and (2\operatorname{sgn}(x)) on irrationals.  (S=\{0\}).  Graph is locally closed at isolated ((0,0)), but not at nonzero branch points. |
| Graph geometry | Dense same-side level switches yield (m_*=-\infty).  Sharp global-on-window (c_*=-\delta).  The one-fixed first-order quotient at 0 is at least 1; the two-moving liminf is exactly (-1). |
| (J/R), RL | For every (\lambda>\delta), sharp (L_1=(\lambda+\delta)/(\lambda-\delta)), (\tau=\lambda\delta/(\lambda-\delta)^2).  For (\lambda\le\delta), denominators approach/cross zero and no finite RL holds.  At step 1 the Minty domain is a bounded union of five clusters, so subunit exponents hold only by bounded-domain inheritance. |
| Regularity | Off zero the residual is 1 or 2.  Every fixed power MSR/SMSR and inverse calm/isolated calm has exact 0 by `RESIDUAL-JUMP`.  MR/Aubin, SMR and HREG/UHREG fail because the range omits a target neighborhood. |
| Verdict | `C-SHARPEN`: B's ((1+2\delta)/(1-2\delta)) was a safe bound; the sharp step-one constant is ((1+\delta)/(1-\delta)).  `C-DISAGREE-SCOPE`: the graph is locally closed at the isolated reference ((0,0)), though not at nonzero branch points. |

### GX-057 -- product splice (F=F_{053}\times F_{056})

| Property row | Independent C result |
|---|---|
| Object | Euclidean product of GX-053 and GX-056, reference ((0,0;0,0)), zero (\{(0,0)\}). |
| Graph geometry | (\langle a,b\rangle=-s_1a_1^2+a_2b_2).  The staircase coordinate gives (m_*=-\infty); the negative-square coordinate gives (c_*=-\infty). |
| Global/catalog-step RL | At (\lambda=1), GX-053 already makes (Q_{1,1}) unbounded, so global RL\(_1) fails; the staircase supplies the independent two-moving first-order failure. |
| Local graph/output-window RL | Near (((1/2,0),(-1/4,0))), output localization removes the staircase branches.  Maximal exponent is genuinely (1/2), sharp (L=2), inherited from the critical first coordinate.  A domain-only restriction has a different, not asserted sharp, constant. |
| Regularity at zero | Exact product residual gives fixed (q_*=1/2), MSR/SMSR modulus 1.  Ordinary Core/Inv and HREG/UHREG fail; coverage fails through the staircase coordinate. |
| Verdict | `VERIFIED-ALG; C-UPGRADE`: B's product exponent candidate is proved with exact modulus 1; graph/output localization is mandatory for the sharp RL statement. |

### GX-058 -- (K+N_B) on the closed unit ball

| Property row | Independent C result |
|---|---|
| Object / source | (K=\begin{psmallmatrix}0&1\\-1&0\end{psmallmatrix}), (B=\{\|x\|\le1\}), (F=K+N_B); BWY Example 3.5 `VERIFIED_SOURCE`, formulas `ALG`.  (S=\{0\}). |
| Graph geometry | Writing (u=Kx+\alpha x), (\alpha(1-\|x\|)=0), gives

\[
\langle x-y,u-v\rangle=\alpha(\|x\|^2-\langle x,y\rangle)
+\beta(\|y\|^2-\langle x,y\rangle)\ge0.
\]

Thus (m_*=c_*=0).  Maximal monotone and rectangular, but not paramonotone (interior skew pairs are a direct witness). |
| Inverse / (J/R), RL | The inverse is the explicit single-valued formula (58.3); (J) is the interior/exterior formula (58.4).  (R) is globally nonexpansive, sharp RL\(_1=1) on exterior rays; all global subunit exponents fail. |
| Reference ((0,0)) | Locally (F=K), (F^{-1}=-K).  Core, Inv and HREG/UHREG all exact 1.  Fixed-target MSR in fact holds globally with modulus 1. |
| Boundary warning / verdict | The inverse has a square-root radial turn at output norm 1 and is not Lipschitz there; the local zero statement cannot be exported.  B labels and source object pass. |

### GX-059 -- (F=D+B) on (\ell^2)

| Property row | Independent C result |
|---|---|
| Object / source | (D(x_n)=x_n/n), (B) the blockwise skew isometry, and **sum** (F=D+B); BWY Example 5.5 `VERIFIED_SOURCE`.  Full-domain linear bijection, (S=\{0\}). |
| Graph geometry | (\langle x,Fx\rangle=\sum x_n^2/n>0).  Strict/maximal monotone and paramonotone, (m_*=0,c_*=0).  Not rectangular; the positive-cocoercivity equivalence uses BWY Proposition 5.1, while the vanishing ratios are directly computed. |
| Inverse conditioning | Each block has singular values (1) and (1+a_kb_k), so (\|F^{-1}\|=1). |
| (J/R), RL | Block resolvents are (59.5).  Monotonicity gives (\|R\|\le1), and high blocks approach a skew Cayley isometry, so sharp global RL\(_1=1).  Nonzero linear homogeneity defeats global subunit RL. |
| Regularity | Core, Inv and HREG/UHREG all globally exact 1; largest power 1.  Isolated/nonvacuous. |
| Verdict | B object and labels pass.  Zero strong modulus does not reflect inverse conditioning. |

### GX-060 -- Volterra integration (V)

| Property row | Independent C result |
|---|---|
| Object / source | (Vx(t)=\int_0^t x(s)ds) on (L^2[0,1]); BWY Example 5.3.  Injective, full domain, dense nonclosed range (\{H^1:y(0)=0\}), (S=\{0\}). |
| Graph geometry | (\langle x,Vx\rangle=\tfrac12(\int x)^2\ge0), hence (m_*=c_*=0), maximal monotone.  A zero-mean (h) with (Vh\ne0) defeats paramonotonicity; the explicit rectangular expression tends to (-\infty). |
| (J/R), RL | (Jp=p-\lambda\int_0^t e^{-\lambda(t-s)}p(s)ds), (R=2J-I).  The cosine singular sequence makes sharp global RL\(_1=1); nonzero linear homogeneity defeats every global subunit exponent. |
| Regularity / gauge | Scaled cosine directions prove MR/MSR/SMR/SMSR, all Inv properties, HREG/UHREG, every power (q>0), and every vanishing-gauge MSR/SMSR fail.  Mechanism: isolated zero with `NONCLOSED-RANGE`, not vacuity. |
| Verdict | B labels pass; C supplies explicit singular, power and gauge countersequences. |

### GX-061 -- adjoint Volterra (V^*)

| Property row | Independent C result |
|---|---|
| Object / source | (V^*x(t)=\int_t^1x(s)ds), range (\{H^1:y(1)=0\}); BWY Example 5.3.  With the unitary (Uf)(t)=f(1-t), (V^*=UVU).  Thus GX-060/061 form one unitary-conjugacy phase point with two orientation observations.  Injective with isolated zero and nonclosed range. |
| Graph geometry | Same quadratic form (\tfrac12(\int x)^2), so (m_*=c_*=0), maximal monotone.  Orientation-specific zero-mean witnesses independently defeat paramonotonicity and rectangularity. |
| (J/R), RL | (Jp=p-\lambda\int_t^1e^{-\lambda(s-t)}p(s)ds), (R=2J-I).  Cosine sequence gives sharp global RL\(_1=1); all subunit global exponents fail. |
| Regularity / gauge | Same complete failure as GX-060: no Core/Inv/HREG/UHREG property, no positive power, no vanishing-gauge MSR/SMSR. |
| Verdict | B labels pass.  Endpoint orientation and witnesses were independently recomputed, but unitary-invariant graph/Cayley/regularity coordinates are counted once, not as independent phase evidence. |

### GX-062 -- rotation (Q_{\pi/3})

| Property row | Independent C result |
|---|---|
| Object / source | Isometric planar rotation by (\pi/3); Voisei Example 43 supplies the cyclic threshold, independently derived in C.  (S=\{0\}), inverse (Q_{-\pi/3}). |
| Graph / cyclic geometry | (\langle a,Qa\rangle=\tfrac12\|a\|^2=\tfrac12\|Qa\|^2).  (m_*=c_*=1/2); maximal 3-cyclic but not 4-cyclic, paramonotone and rectangular. |
| (J/R), RL | 

\[
L_1^*(\lambda)=\sqrt{\frac{1-\lambda+\lambda^2}{1+\lambda+\lambda^2}}<1.
\]

The nonnegative LT violation is 0; signed LT number is (-\lambda/[2(1+\lambda+\lambda^2)]).  Since (R\ne0) is linear on an unbounded space, every global subunit exponent fails; window bounds inherited. |
| Regularity | Core, Inv and HREG/UHREG all globally exact 1; largest power 1. |
| Verdict | B labels pass.  Cyclic level is an independent graph coordinate. |

### GX-063 -- rotation (Q_{\pi/4})

| Property row | Independent C result |
|---|---|
| Object / source | Isometric rotation by (\pi/4), (S=\{0\}), inverse (Q_{-\pi/4}). |
| Graph / cyclic geometry | (m_*=c_*=1/\sqrt2); maximal 4-cyclic but not 5-cyclic, paramonotone and rectangular. |
| (J/R), RL | 

\[
L_1^*(\lambda)=\sqrt{\frac{1-\sqrt2\lambda+\lambda^2}
{1+\sqrt2\lambda+\lambda^2}}<1,
\qquad
\tau_{\rm signed}=-\frac{\lambda}{\sqrt2(1+\sqrt2\lambda+\lambda^2)}.
\]

Nonnegative LT violation 0; global subunit RL fails by nonzero linear homogeneity. |
| Regularity | Core, Inv and HREG/UHREG all globally exact 1; largest power 1. |
| Verdict | B labels pass.  Same inverse conditioning as GX-062 but a different cyclic level/modulus. |

### GX-064 -- VI-positive oscillation (F(x)=2+\sin x)

| Property row | Independent C result |
|---|---|
| Object / VI class | Full-domain positive scalar map; no zero.  VI-pseudomonotone and quasimonotone, but not ordinary monotone on decreasing sine intervals.  Zero-target MSR statements are N/A. |
| Graph geometry | Secant slopes range through ([-1,1]), so (m_*=-1), (c_*=-\infty). |
| RL for (0<\lambda<1) | (g_\lambda(x)=x+\lambda(2+\sin x)) is bijective; sharp (L_1=(1+\lambda)/(1-\lambda)), (\tau=\lambda/(1-\lambda)^2).  Subunit global RL fails on the unbounded Minty domain. |
| Critical (\lambda=1) | At flat points (x_0=(2k+1)\pi), the maximal local all-pairs exponent is genuinely (1/3), exact modulus (4\sqrt[3]3).  The fixed-base anchored modulus is the smaller (2\sqrt[3]6).  No global subunit estimate. |
| (\lambda>1) | Minty folds create collisions, so every all-graph exponent fails. |
| Reference ((\pi/2,3)) | (d(x,F^{-1}(3))=|h|), residual (1-\cos h\sim h^2/2).  Fixed (q_*=1/2), MSR/SMSR and (1/2)-calm/isolated calm exact (\sqrt2); ordinary versions fail.  MR/Aubin, SMR and HREG/UHREG fail because targets above 3 are empty and lower targets branch.  At regular references (\cos\bar x\ne0), SMR modulus (1/|\cos\bar x|). |
| Verdict | `C-REFINE`: the critical exponent was correct; the exact all-pairs and anchored constants are distinct as printed above. |

### GX-065 -- VI square (F(x)=x^2) on ([-1,1])

| Property row | Independent C result |
|---|---|
| Object / source | Restricted scalar square, (S=\{0\}); VI-quasimonotone but not VI-pseudomonotone, as in Lei--He Definitions 2.2--2.3/example. |
| Graph geometry | (b=(x+y)a), (\langle a,b\rangle=(x+y)a^2\ge-2a^2).  Sharp (m_*=-2); (c_*=-\infty). |
| (0<\lambda<1/2) | Minty map injective; sharp RL\(_1=(1+2\lambda)/(1-2\lambda)), (\tau=2\lambda/(1-2\lambda)^2). |
| Critical (\lambda=1/2) | Maximal global-on-domain exponent (1/2), sharp (L=2\sqrt2).  For (0<\gamma<1/2), sharp (L_{1/2,\gamma}=2^{1-\gamma}(1-\gamma)^{-1}[(1-2\gamma)/(1-\gamma)]^{1-2\gamma}); every (\gamma>1/2) fails.  Subunit endpoint is a boundary cusp. |
| (\lambda>1/2) | Minty map folds and every exponent fails by collision. |
| Regularity at ((0,0)) | Exact (|x|=|F(x)|^{1/2}).  Fixed MSR/SMSR and (1/2)-calm/isolated calm endpoint modulus 1; ordinary versions fail.  MR/Aubin, SMR and HREG/UHREG fail by negative targets/two positive branches.  At nonzero interior graph points, SMR modulus (1/(2|\bar x|)). |
| Verdict | B labels pass; C adds the critical and subcritical sharp constants. |

## 6. VI control, algorithm residuals, anchored/all-pairs and source examples

### GX-066 -- VI negative identity on ([-1,1])

| Property row | Independent C result |
|---|---|
| Object / VI class | (F(x)=-x) on (|x|\le1), empty outside; (S=\{0\}), inverse (-y) on ([-1,1]).  Fails both VI-quasimonotonicity and VI-pseudomonotonicity. |
| Graph geometry | (b=-a), (\langle a,b\rangle=-a^2=-b^2).  (m_*=c_*=-1), (\Sigma=\{(\mu,\rho):\mu+\rho\le-1\}).  Nonmaximal restricted negative line. |
| (J/R), RL | If (\lambda\ne1), (D=(1-\lambda)[-1,1]), (J=p/(1-\lambda)), (R=(1+\lambda)p/(1-\lambda)).  Sharp (L_1=(1+\lambda)/|1-\lambda|); for (0<\gamma<1), exact bounded-domain inherited (L_\gamma=2^{1-\gamma}(1+\lambda)|1-\lambda|^{-\gamma}).  At (\lambda=1), every distinct pair collides and all exponents fail. |
| Regularity | Locally (F=F^{-1}=-I).  Core, Inv and HREG/UHREG all exact 1; exact residual (|x|=|F(x)|), largest power 1. |
| Verdict | Isolated/nonvacuous.  B labels pass; subunit RL is solely bounded-domain inheritance. |

### GX-067 -- normal cone to the closed unit ball

| Property row | Independent C result |
|---|---|
| Object | (F=N_B) for (B=\{\|x\|\le1\}\subset\mathbb R^m); maximally cyclically monotone and prox-regular.  (S=B), inverse is (B) at 0 and (y/\|y\|) for (y\ne0). |
| Graph geometry | Convex-normal monotonicity is exact: (\langle a,b\rangle\ge0), and interior horizontal plus boundary vertical pairs give (m_*=c_*=0), (\Sigma=(-\infty,0]^2). |
| (J/R), RL | (J=P_B, R=2P_B-I).  Sharp global RL\(_1=1), attained in the interior; large exterior rays defeat every global subunit exponent.  Window estimates inherited; no collision. |
| Regularity at every ((\bar x,0)) | MSR and every fixed power/gauge MSR, plus inverse calm, have exact 0 by `DOMAIN-VACUOUS + BIG-SOLUTION`; SMSR/isolated calm fail.  MR/Aubin, SMR, HREG and UHREG fail at both interior and boundary references by the explicit directional target sequences in C. |
| Verdict | B labels pass.  Prox-regular/maximal-monotone pedigree coexists only with a vacuous target-zero EB here. |

### GX-068 -- branch union (F(x)=\{x,x^2\})

| Property row | Independent C result |
|---|---|
| Object / reference | Germ at ((0,0)), (S=\{0\}).  Small target (y) always has identity preimage (y), and for (y\ge0) also (\pm\sqrt y).  RM-01/HREG seed. |
| Graph geometry | Same-branch products are (a^2) and ((x+y)a^2); cross product is ((x-y)(x-y^2)).  Explicit cross scales give (m_*=c_*=-\infty).  Exact (\Sigma=\{(\mu,\rho):\mu<0,\rho<0,\mu\rho\ge1/4\}), the universal negative-negative region. |
| (J/R), RL | Local branches (J_1=p/(1+\lambda)) and (J_2=(-1+\sqrt{1+4\lambda p})/(2\lambda)).  For every step, cross branches share accumulating Minty inputs; every full-graph exponent fails although each selection is Lipschitz. |
| Fixed-target regularity | (d(x,S)=|x|), (d(0,F(x))=x^2).  Fixed (q_*=1/2), MSR/SMSR and (1/2)-calm/isolated calm modulus 1; ordinary MSR/SMSR/calm/isolated calm fail. |
| Nearby-target regularity | (F^{-1}) is locally (1/2)-Aubin with exact modulus 1; equivalently (F) is (1/2)-metrically regular with exact modulus 1.  Ordinary MR/Aubin fail.  Every single-valued or Hölder-strong localization fails because every small positive target has three local inverse branches.  HREG/UHREG remain exact 1 because the identity branch is the nearest inverse point. |
| Selected identity residual | (d(p,\operatorname{Fix}J_1)=|p|), (\|p-J_1p\|=\lambda|p|/(1+\lambda)): exact linear EB modulus ((1+\lambda)/\lambda). |
| Full resolvent-relation residual | The square branch satisfies (|p-J_2p|=\lambda J_2(p)^2\sim\lambda p^2).  Fixed-point residual has sharp exponent (1/2), asymptotic modulus (1/\sqrt\lambda). |
| Verdict | `C-UPGRADE`: the corrected selected/full distinction passes, and C adds exact two-variable (q=1/2) MR/Aubin modulus 1.  HREG is a nearest-branch property, not strong regularity or full-graph RL. |

### GX-069 -- tangent line/parabola Douglas--Rachford residual

| Property row | Independent C result |
|---|---|
| Canonical residual | For (C=\mathbb Re_1,D=\{(s,s^2)\}), (T=I-P_C+P_DR_C), (G=I-T), with Euclidean input and output norms.  In the projection tube, (a=s+2s(s^2+b)) and

\[
T(a,b)=(s,b+s^2),\qquad G(a,b)=(2s(s^2+b),-s^2).
\]

Locally (S=\operatorname{zer}G=\{0\}\times\mathbb R). |
| Exact graph geometry | For parameters ((s,b),(t,c)), (H=s(s^2+b)), (K=s^2+st+t^2),

\[
\langle\Delta z,\Delta G\rangle=(2K+b+c)(s-t)^2+4(H(s,b)-H(t,c))^2.
\]

Not monotone in any two-sided zero tube.  On (|b|\le\varepsilon<1/2), sharp hypomonotonicity defect (2\varepsilon/(1-2\varepsilon)); (c_*=-\infty) locally. |
| (J_{\lambda G}/R_{\lambda G}), RL | (I+\lambda G) is a local diffeomorphism.  The reflected resolvent is locally Lipschitz with exact point modulus 1 at 0; local RL\(_1) holds, window subunit estimates are inherited, and no collision remains after shrinking. |
| DR-residual regularity | Exact maximal fixed exponent (q_*=1/2), MSR modulus 1, proved on the **full tube** by (69.3); ordinary MSR/calm fail.  SMSR/isolated calm fail for every exponent because the fixed set is a line.  MR/Aubin, SMR and HREG/UHREG fail; the inverse has sharp (1/2)-calmness relative to the full zero fiber. |
| Dynamics row | (a_{k+1}=s_k, b_{k+1}=b_k+s_k^2); on (b_0=0), one-step distance ratio tends to 1 and (DT(0)=I).  The slice does not yield a uniform contraction/rate theorem. |
| Distinct primal map (N_C+N_D) | Locally (F_{\rm pr}(0)=\{0\}\times\mathbb R), empty off 0.  MSR/SMSR and inverse isolated calm have exact 0 by `DOMAIN-VACUOUS`; MR/SMR/HREG/UHREG fail due missing horizontal targets. |
| Verdict | `VERIFIED-ALG; C-UPGRADE`: full-tube (1/2)-MSR is proved, sharp modulus 1.  Residual and primal rows are not interchangeable. |

### GX-070 -- transverse-line Douglas--Rachford residual

| Property row | Independent C result |
|---|---|
| Canonical residual | Lines meet at (0<\theta<\pi/2), (c=\cos\theta,s=\sin\theta); (T=cQ_\theta), (G=I-T), (S=\{0\}), with Euclidean input and output norms. |
| Graph geometry | (\|Ga\|=s\|a\|), (\langle a,Ga\rangle=s^2\|a\|^2=\|Ga\|^2).  (m_*=s^2,c_*=1), (\Sigma=\{(\mu,\rho):\mu+\rho s^2\le s^2\}). |
| (J/R), RL | (\|J_{\lambda G}\|=[1+2\lambda s^2+\lambda^2s^2]^{-1/2}), and

\[
L_1^*=\|R_{\lambda G}\|=
\sqrt{\frac{1-2\lambda s^2+\lambda^2s^2}
{1+2\lambda s^2+\lambda^2s^2}}<1.
\]

Nonzero linearity defeats global subunit RL; window estimates inherited. |
| Residual regularity | Exact (\|z\|=s^{-1}\|Gz\|) and the corresponding two-target identity.  Core, Inv and HREG/UHREG all exact (1/s), largest power 1. |
| Dynamics row | (\|T^kz\|=c^k\|z\|).  This is an actual global linear rate, not inferred from a slice. |
| Distinct primal (F_{\rm pr}=N_C+N_D=N_{\{0\}}) | This is a member of the dimension-parameterized canonical family represented by GX-040, not a literal same-space alias when dimensions differ.  Core, Inv and HREG/UHREG all have exact 0 through `DOMAIN-VACUOUS + BRANCH-PINNING`; (R=-I), RL\(_1=1). |
| Verdict | B's corrected card passes.  Tangent and transverse cases must be compared on the common residual (G), not by a shared binary primal label. |

### GX-071 -- triangular exact (\gamma q) composition model

| Property row | Independent C result |
|---|---|
| Global object | (0<\gamma<1, q>1/\gamma, \alpha=\gamma q>1).  (J(t,z)=(t+|z|^\gamma,P_\alpha z)), (R=2J-I) globally; (F=J^{-1}-I),

\[
F(s,w)=(-|w|^{1/q},P_{1/\alpha}w-w),\qquad S=\mathbb R\times\{0\}.
\]

The bounded tube is only the RL/orbit window. |
| Graph geometry | For (T=t-s,Z=z-w,G=|z|^\gamma-|w|^\gamma,P=P_\alpha z-P_\alpha w),

\[
\langle a,b\rangle=-TG-G^2+PZ-P^2.
\]

Output-coordinate scales prove (m_*=c_*=-\infty) locally.  Against a matched solution the leading defect is (-|z|^{2\gamma}). |
| Restricted all-pairs RL | On (D=(-M,M)\times(-\delta,\delta)), exponent (\gamma) holds with the safe certified upper constant (L_{071}) in (71.4); its optimal value is **UNKNOWN**.  The exponent is sharp since the anchored quotient tends to 2; every exponent above (\gamma) fails.  RL\(_1) fails locally, while global RL\(_\gamma) fails because of the unbounded tangential identity. |
| Global operator regularity | (E_F(s,w)^2=|w|^{2/q}+|P_{1/\alpha}w-w|^2), so exact global (d((s,w),S)\le E_F(s,w)^q), sharp modulus 1 and maximal exponent (q).  Ordinary MSR/calm have exact 0 by `SUPERLINEAR-GERM` (nonvacuous, residual (\to0)); SMSR/isolated calm fail by the zero line.  MR/Aubin, SMR and HREG/UHREG fail by small positive first targets. |
| PPA recurrence / invariance | (t_+=t+|z|^\gamma, z_+=P_\alpha z), hence exactly (r_+=r^{\alpha}=r^{\gamma q}).  Convergence inside the tube needs the explicit positive tangential margin (71.7); the whole rectangle is not a self-map. |
| Verdict | Reverse-calibrated attainability construction: (\alpha=\gamma q) was imposed by design.  The exponent identity and invariant subwindow are `VERIFIED-ALG`, but the optimal restricted RL constant is unknown.  This card has no evidentiary weight as an independently observed universal (\gamma q) law. |

### GX-072 -- triangular oscillatory model with actual order (q>\gamma q)

| Property row | Independent C result |
|---|---|
| Object | (q>1, 0<\gamma<1, \beta=q/\gamma-1); (h(x)=|x|^q\sin(|x|^{-\beta})), (J(x,y)=(P_qx,P_qy+h(x))), (R=2J-I), (F=J^{-1}-I).  Global triangular homeomorphism; locally (S=\{0\}). |
| Graph geometry | With (A=\Delta P_qx,B=\Delta P_qy,H=\Delta h,X=\Delta x,Y=\Delta y),

\[
\langle a,b\rangle=A(X-A)+(B+H)(Y-B-H).
\]

Oscillatory derivative matrices give (m_*=c_*=-\infty) locally. |
| All-pairs versus anchored RL | The two-scale lemma proves maximal local all-pairs exponent exactly (\gamma=q/(\beta+1)), with explicit certified (L_{072}) (72.3), not claimed sharp.  Every larger exponent fails on adjacent extrema.  Against the solution, (Rz=-z+O(\|z\|^q)), so the anchored maximal exponent is 1 with point modulus 1. |
| Full-map fixed-target regularity | (q)-MSR/SMSR is sharp.  Exact endpoint modulus

\[
K_q=\max_{A^2+B^2=1,A,B\ge0}
\sqrt{A^{2q}+(A^q+B^q)^2},
\]

and (K_q=\sqrt2) for (q\ge2).  Ordinary MSR/SMSR/calm/isolated calm have exact 0 by `SUPERLINEAR-GERM` (nonvacuous, residual (\to0)); zero is isolated. |
| Target-uniform inverse properties | HREG/UHREG, calm and isolated calm have ordinary exact 0 by `SUPERLINEAR-GERM` (nonvacuous, residual (\to0)) and sharp centered exponent (q).  Ordinary MR/SMR/Aubin fail.  The inverse localization is all-pairs (\gamma)-Hölder and no better; its exact endpoint modulus is **UNKNOWN**. |
| Actual iteration | Small balls are invariant and (\|Jz\|=\Theta(\|z\|^q)), so every nonzero local orbit has exact Q-order (q), strictly better than the all-pairs mechanical (\gamma q) order. |
| Verdict | `VERIFIED-ALG; C-UPGRADE`: endpoint all-pairs RL and full-map (q)-regularity are proved.  The construction is also reverse-calibrated through (\beta=q/\gamma-1). |

### GX-073 -- anchored but rougher all-pairs Cayley relation

| Property row | Independent C result |
|---|---|
| Object | On ([-\delta,\delta]), (R(x)=P_\alpha(x)[2+\sin(|x|^{-\beta})]), (0<\alpha<1), (J=(I+R)/2); graph (\{(Jx,x-Jx)\}), local (S=\{0\}).  (J) folds, so (F) is genuinely set-valued. |
| Graph geometry | (ab=(|x-y|^2-|R(x)-R(y)|^2)/4).  Derivative crossings yield (m_*=c_*=-\infty), with exact universal (\Sigma=\{(\mu,\rho):\mu<0,\rho<0,\mu\rho\ge1/4\}). |
| RL exponents | Anchored exponent is (\alpha), with exact local constant 3 and (|x|^\alpha\le|R(x)|\le3|x|^\alpha).  Maximal all-pairs exponent is the strictly smaller (\eta_*=\alpha/(\beta+1)), proved by the two-scale lemma; explicit (L_{073}) is valid but not claimed sharp. |
| Full multifunction regularity | Uniform branch ratio proves MSR/SMSR exact 1 and maximal fixed exponent 1.  Calm/isolated calm and HREG/UHREG exact 1.  MR/SMR/Aubin fail because (I-J) has accumulating critical points. |
| Selected iteration | (\tfrac12|x|^\alpha\le|Jx|\le2|x|^\alpha).  Since (\alpha<1), every small nonzero selected step expands and leaves the window; this is not a convergence order. |
| Verdict | `VERIFIED-ALG; C-UPGRADE`: both former B candidates are positively resolved--exact maximal all-pairs exponent (\eta_*), and full-map linear MSR/SMSR modulus 1--while the noninvariance warning remains. |

### GX-074 -- CDK discrete graph

| Property row | Independent C result |
|---|---|
| Object / source | (K=\{0\}\cup\{1/k:k\ge1\}), (\operatorname{gph}F=K\times\{0\}); `P3-DIRECT` from Cibulka--Dontchev--Kruger after Theorem 5.2.  (S=K). |
| Graph geometry | (b=0,\langle a,b\rangle=0); (m_*=0), positive coco coefficients graph-vacuous, (\Sigma=\{(\mu,\rho):\mu\le0,\rho\in\mathbb R\}).  Monotone but nonmaximal. |
| (J/R), RL | Natural (D_\lambda=K), (J=R=I).  Since (\operatorname{diam}K=1), every (0<\gamma\le1) has exact global-on-(K) constant 1; subunit estimates are bounded-discrete inheritance and local constants shrink with the local diameter. |
| Regularity | MSR and every power/gauge MSR, plus inverse calm, exact 0 by `DOMAIN-VACUOUS`.  SMSR/isolated calm fail because (1/k\to0) are zeros.  MR/Aubin, SMR and HREG/UHREG fail by empty nonzero-target fibers. |
| Derivative/coderivative row | (T_{\operatorname{gph}F}(0,0)=\mathbb R_+\times\{0\}), so (DF(0|0)^{-1}(0)=\mathbb R_+\ne\{0\}), correctly detecting non-SMSR.  The limiting normal is all of (\mathbb R^2), hence not informative here. |
| Verdict | B's corrected “MSR yes, SMSR no” label is verified; MSR is entirely vacuous. |

### GX-075 -- HREG but not UHREG scalar multifunction

| Property row | Independent C result |
|---|---|
| Object | (A=\{0\}\cup\{1/n:n\ge1\}), (F(0)=A), (F(x)=\{x\}) for (x\ne0).  Closed graph, (S=\{0\}); project `ALG`, no primary attribution. |
| Graph geometry | Diagonal, vertical and cross pairs yield (m_*=c_*=-\infty).  Cross slopes realize all reals, so (\Sigma=\{(\mu,\rho):\mu<0,\rho<0,\mu\rho\ge1/4\}). |
| (J/R), RL | Diagonal branch (J=p/(1+\lambda)); at (p=\lambda/n), the extra graph point gives (J=0).  Accumulating branch collisions defeat every local full-graph exponent. |
| Fixed-target regularity | For (x\ne0), (d(x,S)=d(0,F(x))=|x|).  MSR/SMSR and inverse calm/isolated calm exact 1, (q_*=1); isolated/nonvacuous. |
| HREG versus uniformity | HREG exact 1 via the diagonal inverse point.  UHREG, MR/Aubin and SMR fail for targets (1/n+o(1/n)) that are close to (F(0)) but whose only inverse is far relative to that residual. |
| Verdict | B labels and exact moduli pass; provenance remains project algebra. |

### GX-076 -- Uderzo HREG/non-MR map

| Property row | Independent C result |
|---|---|
| Object / source | (\Theta:\mathbb R^2\to\mathbb R), (\Theta(p)=p_1+p_2^2) for (p_1\ge0), (p_1-p_2^2) for (p_1<0); Uderzo Example 2.3 `P3-DIRECT`.  Continuous at the origin, but not globally continuous and its graph is not locally closed on a whole product neighborhood of the origin. |
| Graph / (J/R) | Same-Hilbert inner-product monotonicity, resolvents and RL are **N/A** because domain and codomain dimensions differ. |
| Residual law | (S=\{(0,0)\}) and exact (|\Theta(p)|=|p_1|+p_2^2).  Ordinary MSR/SMSR/calm/isolated calm fail; maximal fixed/centered exponent is (q=1/2), exact modulus 1. |
| HREG/UHREG | For (|y|<1/2), (d(0,\Theta^{-1}(y))=|y|), so HREG and (because (\Theta(0)=\{0\})) UHREG exact 1. |
| Nearby-target regularity | In addition, (\Theta) is (1/2)-metrically regular around (((0,0),0)) with exact modulus 1.  Ordinary MR/Aubin fail already along ((0,t)), where solution distance is (|t|) and residual (t^2).  Every Hölder-strong localization (hence ordinary SMR) fails because every nonzero small level has a nonsingleton local fiber. |
| Verdict | `C-DISAGREE`: only B's global continuity description is wrong; the source HREG/non-MR conclusion is verified and sharpened. |

### GX-077 -- convex subdifferential (\partial|x|)

| Property row | Independent C result |
|---|---|
| Canonical operator | (F(x)=-1) for (x<0), (F(0)=[-1,1]), (F(x)=1) for (x>0); maximally cyclically monotone, (S=\{0\}).  Not the single-valued GX-033. |
| Graph geometry | Monotonicity exact; horizontal and vertical pairs give (m_*=c_*=0), (\Sigma=(-\infty,0]^2). |
| (J/R), RL | (J(p)=\operatorname{sgn}(p)(|p|-\lambda)_+); (R=p+2\lambda) on the left tail, (-p) centrally, (p-2\lambda) on the right.  Sharp global RL\(_1=1); affine tails defeat global subunit exponents, window estimates inherited. |
| Full operator regularity at ((0,0)) | For (|y|<1), (F^{-1}(y)=\{0\}).  Core, Inv and HREG/UHREG all exact 0 by `BRANCH-PINNING + RESIDUAL-JUMP`; off zero (d(0,F(x))=1).  Every positive fixed power and every gauge positive at residual 1 has the same modulus-zero local behavior. |
| Prox fixed-point residual | On (|p|<\lambda), (Jp=0) and ((I-J)p=p).  Thus (d(p,\operatorname{Fix}J)=\|(I-J)p\|), exact linear EB modulus 1, and PPA terminates in one step. |
| Verdict | B's audit-corrected signature is verified.  Operator modulus 0 and algorithm-residual modulus 1 are different coordinates, not a contradiction. |

## 7. C-stage disagreement, upgrade and unknown ledger

### 7.1 Substantive disagreements and scope corrections

| ID | B-stage statement needing correction | C-stage resolution |
|---|---|---|
| GX-010 | “All four moduli are (1/\mu)” without fixing the graph reference. | (1/\mu) is exact at the zero/kink ((0,0)) and globally as an inverse Lipschitz bound; at ((0,\bar y<0)) all four local infima are 0.  `C-CLARIFY`. |
| GX-025/026 | Linear extension tails were said to defeat every global subunit RL estimate. | False at the tuned step (\lambda=1): the Cayley tail cancels, (R) is bounded nonexpansive, and all subunit exponents hold by inheritance.  Correct for (\lambda\ne1).  `C-DISAGREE`. |
| GX-046 | “Full graph has no finite local RL” read as every base-local restriction. | The untruncated relation has no global RL, but the two-branch base window (|x|\le\delta<\lambda) has the exact finite constants printed above; an output-attentive graph neighborhood is simpler still.  `C-DISAGREE-SCOPE`. |
| GX-056 | The graph was described without reference-local qualification as not locally closed. | It is locally closed at the isolated reference ((0,0)), though not at nonzero branch points.  `C-DISAGREE-SCOPE`. |
| GX-076 | The map was described as globally continuous. | It is continuous at the origin but not globally continuous, and its graph is not locally closed in a whole product neighborhood of the origin.  The source HREG/non-MR label survives.  `C-DISAGREE`. |

No other B yes/no label is reversed.  Clarifications about vacuity, reference,
local/global scope, exact versus safe constants, and branch/full-relation
quantifiers are part of the property data even when not called a substantive
disagreement.

### 7.2 C upgrades and sharpenings

| IDs | Upgrade supplied by independent calculation |
|---|---|
| GX-009, GX-060, GX-061 | Failure strengthened from ordinary/power subregularity to every vanishing-gauge bound, using explicit infinite-dimensional singular sequences. |
| GX-017 | `C-SHARPEN`: exact generating-step constant (L_\gamma^*=2^{-\gamma}(1+\gamma)^{(1+\gamma)/2}(1-\gamma)^{(1-\gamma)/2}) for (0<\gamma<1). |
| GX-025/026 | Same power spectrum but two explicitly incomparable exact gauges; pairwise endpoint exponent proved with quantitative bounds. |
| GX-030 | Critical local all-pairs RL\(_{1/3}) constant sharpened to (2^{5/3}). |
| GX-031 | Exact global constants (L_\gamma=2^{1-\gamma}) for every (0<\gamma\le\alpha). |
| GX-034 | HREG/UHREG exact modulus (1/3). |
| GX-037 | `C-SHARPEN`: exact two-target (1/2)-MR/Aubin modulus (K^*=\sqrt2\sin x_*/\sqrt{x_*}\approx1.20383666149), with (\tan x_*=2x_*); HREG yes/UHREG no. |
| GX-038 | Exact (1/2)-MR/Aubin/calm modulus 1 and HREG/UHREG modulus 0. |
| GX-049 | `VERIFIED-ALG; C-UPGRADE`: full-neighborhood (1/2)-MSR/SMSR proved, sharp modulus (\sqrt2). |
| GX-053 | Complete step phase and sharp critical/subcritical Hölder constants. |
| GX-056 | `C-SHARPEN`: sharp step-one RL\(_1\) constant ((1+\delta)/(1-\delta)); B's larger expression was explicitly only safe. |
| GX-057 | `VERIFIED-ALG; C-UPGRADE`: product candidate resolved, fixed (q_*=1/2), exact modulus 1. |
| GX-064 | `C-REFINE`: critical exponent (1/3), with distinct sharp all-pairs (4\sqrt[3]3) and anchored (2\sqrt[3]6) constants. |
| GX-065 | Critical (L_{1/2}=2\sqrt2) and exact subcritical constants. |
| GX-068 | `C-UPGRADE`: fixed and two-variable (q=1/2) moduli are both exactly 1; every strong Hölder localization fails. |
| GX-069 | `VERIFIED-ALG; C-UPGRADE`: full-tube (1/2)-MSR proved, exact modulus 1; slice-only evidence no longer used. |
| GX-071 | `VERIFIED-ALG`: global-ambient (F), exact (q)-MSR modulus 1, recurrence and invariant subwindow are proved; only a safe restricted-RL constant is known. |
| GX-072 | `VERIFIED-ALG; C-UPGRADE`: endpoint all-pairs exponent (\gamma), full-map fixed exponent (q), and actual order (q) are proved. |
| GX-073 | `VERIFIED-ALG; C-UPGRADE`: both B candidates are proved; anchored exponent (\alpha) has exact local constant 3, while selected-orbit noninvariance is retained. |
| GX-076 | `C-UPGRADE`: fixed and two-variable (q=1/2) moduli are both exactly 1; every strong Hölder localization fails. |
| GX-077 | Core regularity completed to include MR/SMR as exact-zero `BRANCH-PINNING` properties; operator and prox-residual moduli separated. |

Thus the formerly provisional property/exponent labels of GX-049, GX-057,
GX-069, GX-072 and GX-073 are `VERIFIED-ALG` after C.  Only the optimal
constants explicitly retained in the unknown table remain open.

### 7.3 Remaining unknowns and source boundaries

| Item | What is known | What remains unknown / pending |
|---|---|---|
| GX-025/026 tuned RL | Every exponent holds at (\lambda=1); exact constant is the displayed variational supremum. | Closed form of (L_\gamma^*). |
| GX-025/026 pairwise power | Maximal exponent (1-c), with (2^c\le K_\pm\le\max\{2^c,(1+c\sqrt2)/(1-c)\}). | Exact endpoint modulus (K_\pm). |
| GX-052 | Bounded LR is proved with (\kappa_R=\max\{1,4R^2\}). | Sharp bounded-set modulus was not optimized. |
| GX-071 | Exponent (\gamma) is sharp and (71.4) is a safe certified tube constant. | Optimal restricted-tube RL constant. |
| GX-072 | Maximal all-pairs exponent (\gamma), explicit finite constant; inverse localization is (\gamma)-Hölder and no better. | Sharp all-pairs RL and inverse Hölder constants. |
| GX-073 | Maximal exponent (\alpha/(\beta+1)), explicit finite constant. | Sharp endpoint RL constant. |
| Spingarn nomenclature | All displayed anchored/two-moving liminf formulae in GX-053, GX-055--057 were computed directly. | Historical mapping/maximality convention remains `PENDING_PRIMARY_FULLTEXT`; no mathematical property here depends on resolving the name. |

## 8. Phase table from calculated signatures

This table is descriptive bookkeeping only.  It does not order the rows or
infer a monotonicity--regularity seesaw.  Its 77 lines are observation
records, not 77 statistically independent operators.  In particular,
GX-060/061 are one unitary-conjugacy phase point; GX-028/GX-065 share the
zero germ (x^2), and GX-003 at (c=1)/GX-066 share the zero germ (-I), while
their domain, VI, reference and global-RL observations remain distinct.
`A4(k)` means all four ordinary core properties have exact modulus (k);
`P_q(k)` means sharp fixed-target residual exponent (q) and endpoint
modulus (k); `H_q(k)` means a two-target (q)-MR/Hölder-Aubin endpoint.
Zero entries retain the full mechanism tags defined in Section 0;
`NONCLOSED-RANGE` is a separate failure diagnostic.

### GX-001--GX-026

| ID | Calculated graph / Cayley signature | Calculated inverse-stability signature |
|---|---|---|
| 001 | maximal neutral, (R=I), global RL only (\gamma=1,L=1) | MSR 0 by `BIG-SOLUTION`; no MR/SMSR |
| 002 | (m=c, c_*=1/c); strict (R)-contraction, tuned (R=0) | `A4(1/c)`, isolated |
| 003 | (m_*=-c,c_*=-1/c); expansive/singular Cayley | `A4(1/c)`, isolated |
| 004 | skew (m_*=c_*=0); (J) contracts, (R) isometry | `A4(1/\omega)` |
| 005 | strong+coco; strict (R)-contraction | `A4(1/\sqrt{\mu^2+\omega^2})` |
| 006 | maximal+coco, kernel, RL\(_1=1) | MSR (1/c) only; nonisolated/no coverage |
| 007 | sharp hypo (1/2), no finite cohypo; shear (R) | MSR 1 only; nonisolated/no coverage |
| 008 | indefinite (m_*=-c,c_*=-1/c); (J) may contract | `A4(1/\min\{c,d\})` |
| 009 | strict/maximal+coco; Cayley tail norm 1 | no power/genuine gauge regularity; isolated `NONCLOSED-RANGE` |
| 010 | maximally strong, no coco; (J) contracts but RL\(_1=1) | at zero `A4(1/\mu)`; vertical targets `A4(0)` pinning |
| 011 | maximal+coco, fixed Cayley ray | MSR 1 only; nonisolated/no coverage |
| 012 | maximal cyclic neutral; (R=|\cdot|) | target 0: 0 by `DOMAIN-VACUOUS + BIG-SOLUTION`; target (-1): `A4(0)` by `BRANCH-PINNING + RESIDUAL-JUMP` |
| 013 | strong+coco, nonmaximal restricted graph | MSR/SMSR (1/\mu); no MR/SMR |
| 014 | neutral nonmaximal bounded graph; all subunit RL inherited | MSR 0 by `DOMAIN-VACUOUS + BIG-SOLUTION`; no MR/SMSR |
| 015 | hypo (1/\lambda_0), no cohypo; genuine RL\(_\alpha) | `A4(\lambda_0)` at 0, `A4(\lambda_0(1+\alpha)/(1-\alpha))` at (\pm1) |
| 016 | strict maximal+coco; all subunit RL inherited | `P_{1/3}((6\lambda_0)^{1/3})`, `H_{1/3}((24\lambda_0)^{1/3})` |
| 017 | strict maximal+coco (7/9); generating-step inherited RL with exact (L_\gamma^*) | `P_{1/3}(2^{1/3})`, `H_{1/3}(2)` |
| 018 | cohypo 1, no finite hypo; step-dependent relation | `P_{1/3}(2^{1/3})`, `H_{1/3}(2)` |
| 019 | bounded adverse line, hypo (1/3), cohypo 3 | `A4(3)` locally |
| 020 | maximal+coco 1; all subunit RL only at tuned step | MSR 0 interior by `BIG-SOLUTION` / 1 boundary; no MR/SMSR |
| 021 | strict maximal cyclic, zero quadratic moduli; RL\(_1=1) | `P_{1/3}(1)`, `H_{1/3}(2^{2/3})`; residual moduli depend on scaling |
| 022 | maximal monotone, global moduli 0; RL\(_1=1) | ordinary `A4(0)` by `SUPERLINEAR-GERM`; fixed `P_2(1)`, no pairwise (q>1) |
| 023 | maximal+coco (e^2/4); RL\(_1=1) | no power; log-gauge fixed 1 / pairwise 2 |
| 024 | maximal, local strong/unbounded slope; RL\(_1=1) | ordinary `A4(0)` by `SUPERLINEAR-GERM`; every fixed power, exact gauge 1; no pairwise (q>1) |
| 025 | maximal neutral; tuned all-subunit RL inherited | `P_{1-c}(1)`, `H_{1-c}(K_+)`; exact own gauge, cross gauge fails |
| 026 | same power/Cayley signature as 025 | `P_{1-c}(1)`, `H_{1-c}(K_-)`; opposite exact gauge |

### GX-027--GX-052

| ID | Calculated graph / Cayley signature | Calculated inverse-stability signature |
|---|---|---|
| 027 | maximal monotone, no positive local coco; RL\(_1=1) | `P_{1/2}(1)`, `H_{1/2}(1)` |
| 028 | locally hypo (2\delta), no cohypo; full Cayley collisions | `P_{1/2}(1)` only; no two-target MR |
| 029 | maximal monotone cylinder, RL\(_1=1) | `P_{1/3}(1)` MSR only; nonisolated/no coverage |
| 030 | hypo 1, no cohypo; critical genuine RL\(_{1/3}) | `A4(1)` at 0, `A4(1/2)` at (\pm1) |
| 031 | hypo (1/\lambda_0), no cohypo; genuine clipped RL\(_\alpha) | branch-local A4 at all three zeros |
| 032 | LT (\tau=2), RL\(_1=3), no finite hypo, cohypo (1/2) | fixed `P_2(1)`, ordinary MSR/SMSR 0 by `SUPERLINEAR-GERM`; no MR |
| 033 | hypo 1, no cohypo; Cayley collisions for (\lambda\ge1) | MSR/SMSR 1; no MR/SMR |
| 034 | no finite hypo/cohypo; anchored contraction but no all-pairs RL | MSR/SMSR 1, HREG/UHREG (1/3); no MR |
| 035 | no finite quadratic moduli; every Cayley step collides | MR/MSR/SMSR 1, no SMR |
| 036 | no finite moduli; fully multivalued Cayley | MR/MSR 0 by `FULL-VALUE + BIG-SOLUTION`; no strong properties |
| 037 | no finite moduli; every all-pairs Cayley step collides | MSR/SMSR 1, `H_{1/2}(K^*)`, (K^*\approx1.20383666149); HREG 1, no UHREG |
| 038 | no finite moduli; vertical-fiber collisions | `P_{1/2}(1)` and `H_{1/2}(1)`; nonisolated, HREG/UHREG 0 by `FULL-VALUE` |
| 039 | global coco 1/local identity; RL\(_1=1) | local `A4(1)`; no global EB |
| 040 | dimension-family vertical graph, vacuous strong, (R=-I) | `A4(0)`: `BRANCH-PINNING` inverse / `DOMAIN-VACUOUS` mapping |
| 041 | singleton graph, all graph/RL labels vacuous | MSR/SMSR 0 by `DOMAIN-VACUOUS`; no MR/SMR |
| 042 | (N_L): neutral reflection; (P_{L^\perp}): coco 1 | normal MSR 0 by `DOMAIN-VACUOUS + BIG-SOLUTION`; residual MSR 1; neither has full regularity |
| 043 | no finite moduli; Cayley relation collides | MR/MSR 1, no SMSR/SMR |
| 044 | no finite moduli; branch collision | MSR 0 by `BIG-SOLUTION`, HREG/UHREG 1; no MR |
| 045 | full normal no finite moduli/RL; truncation hypo (r_0) | MSR 0 by `DOMAIN-VACUOUS + BIG-SOLUTION`; no MR/SMSR |
| 046 | attentive neutral; full no hypo/global RL; small base-window RL | MSR 0 by `RESIDUAL-JUMP`; no MR/SMSR |
| 047 | set-map graph/RL N/A; transversal | `A4(\sqrt2)` |
| 048 | set-map N/A; identical lines, nontransversal | MSR 1 only; no coverage/isolation |
| 049 | set-map N/A; second-order tangency | `P_{1/2}(\sqrt2)` with SMSR; no MR |
| 050 | set-map N/A; zero angle/nonclosed sum | no positive power regularity |
| 051 | set-map N/A; isolated local / remote tangent | local MSR/SMSR 1; no MR; no bounded LR |
| 052 | set-map N/A; isolated local / asymptotic contact | local MSR/SMSR 1; bounded LR; no MR/global LR |

### GX-053--GX-077

| ID | Calculated graph / Cayley signature | Calculated inverse-stability signature |
|---|---|---|
| 053 | hypo 1/no cohypo; critical genuine RL\(_{1/2}) | `P_{1/2}(1)`; no nearby-target coverage |
| 054 | no global hypo/no local cohypo; global Minty collision | `P_{1/3}(1)`, `H_{1/3}(2^{2/3})` |
| 055 | no hypo, cohypo (\varepsilon^2); step-threshold RL | every fixed power 0 by `RESIDUAL-ESCAPE/GRAPH-ISOLATION`; no MR |
| 056 | no hypo, cohypo (\delta); sharp finite restricted RL | every fixed power 0 by `RESIDUAL-JUMP`; no MR |
| 057 | no finite hypo/cohypo; local genuine RL\(_{1/2}) in graph window | `P_{1/2}(1)`; no ordinary/target-uniform regularity |
| 058 | maximal monotone rectangular, not paramonotone; RL\(_1=1) | local `A4(1)` at zero |
| 059 | strict/maximal/paramonotone, not rectangular; RL\(_1=1) | global `A4(1)` |
| 060 | maximal neutral; neither para nor rectangular; RL\(_1=1) | no power/gauge regularity, isolated `NONCLOSED-RANGE`; unitary phase point shared with 061 |
| 061 | unitary-conjugate orientation of 060 | same invariant no-power/gauge signature; observation, not a second phase point |
| 062 | strong+coco (1/2), exactly 3-cyclic; strict Cayley contraction | global `A4(1)` |
| 063 | strong+coco (1/\sqrt2), exactly 4-cyclic; strict contraction | global `A4(1)` |
| 064 | VI pseudo/quasi, hypo 1; critical genuine RL\(_{1/3}) | at range endpoint `P_{1/2}(\sqrt2)`; no MR |
| 065 | VI quasi not pseudo, hypo 2; boundary RL\(_{1/2}) | `P_{1/2}(1)`; no MR |
| 066 | adverse slope (m_*=c_*=-1); bounded inherited subunit RL | local `A4(1)` |
| 067 | maximal cyclic/prox-regular neutral; RL\(_1=1) | MSR 0 by `DOMAIN-VACUOUS + BIG-SOLUTION`; no MR/SMSR |
| 068 | no finite moduli/full RL; selected branches regular | `P_{1/2}(1)`, `H_{1/2}(1)`, HREG/UHREG 1; no ordinary MR/no strong Hölder localization |
| 069 | vanishing local hypo defect/no cohypo; local RL\(_1) | `P_{1/2}(1)` MSR only; nonisolated/no MR |
| 070 | residual strong (s^2)+coco 1, strict Cayley contraction | residual `A4(1/s)`; dimension-family primal `A4(0)` by `DOMAIN-VACUOUS + BRANCH-PINNING` |
| 071 | no finite moduli; restricted sharp exponent (\gamma), safe (L_{071}) | global `P_q(1)`; ordinary MSR 0 by `SUPERLINEAR-GERM`, nonisolated; designed recurrence (\gamma q) |
| 072 | no finite moduli; sharp all-pairs exponent (\gamma), anchored exponent 1 | fixed `P_q(K_q)`; ordinary core 0 by `SUPERLINEAR-GERM`/no MR; actual order (q) |
| 073 | no finite moduli; anchored (\alpha,L^*=3), all-pairs (\alpha/(\beta+1)) | MSR/SMSR 1, HREG/UHREG 1; no MR; noninvariant step |
| 074 | neutral discrete graph; all bounded-domain RL inherited | MSR 0 by `DOMAIN-VACUOUS`, nonisolated; no MR/SMSR |
| 075 | no finite moduli; accumulating branch collisions | MSR/SMSR 1, HREG 1; no UHREG/MR |
| 076 | graph/RL N/A, different dimensions | `P_{1/2}(1)`, `H_{1/2}(1)`, HREG/UHREG 1; no ordinary MR/no strong Hölder localization |
| 077 | maximal cyclic neutral; RL\(_1=1) | operator `A4(0)` by `BRANCH-PINNING + RESIDUAL-JUMP`; prox-residual EB 1 |

## 9. Coverage and merge validation

- GX-001--GX-077 occur exactly once as canonical headings.  Alternate
  references and residuals have independent rows for GX-010, GX-012,
  GX-015, GX-020, GX-021, GX-030, GX-039, GX-042, GX-045, GX-046,
  GX-051--053, GX-058, GX-064, GX-068--070, and GX-077.
- Canonical-object counting has been separated from observation counting:
  GX-060/061 are unitary conjugates; the (N_{\{0\}}) records form a
  dimension-parameterized family; shared germs GX-028/GX-065 and
  GX-003((c=1))/GX-066 retain their distinct domain/VI/global observations.
- Every same-space card records an exact inner-product identity or sharp
  signed defect; every type-mismatched set map is marked N/A rather than
  assigned a fictitious monotonicity coordinate.
- Every card records (J/R) or explicitly says relation/N/A, checks Minty
  collisions, and classifies subunit RL as genuine or inherited whenever it
  exists.
- Every card records fixed-target and nearby-target regularity separately,
  including isolation, coverage and modulus-zero mechanisms.  Exact constants
  that C did not close are retained as `UNKNOWN` with proved bounds.
- GX-049, GX-057, GX-069, GX-072 and GX-073 carry `VERIFIED-ALG`
  property/exponent status.  GX-017 and GX-037 no longer appear in the
  unknown ledger; GX-071 retains only a sharp exponent plus a safe constant.
- This file intentionally stops at calculated signatures.  It makes no final
  claim that a one-dimensional, two-dimensional, partial-order, composite, or
  nonexistent monotonicity--regularity seesaw is the correct synthesis.
