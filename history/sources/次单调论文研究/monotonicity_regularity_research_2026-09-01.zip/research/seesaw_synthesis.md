# Generalized monotonicity–regularity “跷跷板”：证据综合与研究决策

> **文档状态。** 本文是 atlas → gap examples → independent recalculation 之后的最终综合。
> 它只使用 `theory_atlas.md`、`gap_examples.md`、`example_properties.md`、
> C-stage phase cloud / consistency audit、算法证据表以及用户 RL 初稿；没有重新搜索文献。
> `GX-001`--`GX-077` 是记录编号，不是 77 个统计独立样本。所有判断按 canonical
> object、reference、residual、scope 和 stepsize 去重；本文也不声称 atlas 已穷尽全部文献。

## 0. 先给结论

### 对问题 1 的回答

数据支持一种**算法机制内的局部补偿**，但不支持一种**算子类别之间的普遍负相关律**。

- 在固定算法、固定 residual、固定局部化和固定 rate object 后，graph / iteration
  geometry 提供 descent 或 almost-averaged estimate，metric regularity / error bound
  把 residual 转换为 solution distance；两者确实在同一个收缩条件中补偿。
  Luke–Tam PPA 的
  \(\tau(1+\bar\rho/\lambda)^2<1/2\) 和 almost-averaged fixed-point 模板的
  \(1+\varepsilon-(1-\alpha)/(\alpha\kappa^2)<1\) 是最清楚的 theorem-level 证据。
- 一旦离开同一算法 germ，现有样本便不再支持稳定负相关。phase cloud 中有“graph 强、regularity 强”、
  “graph 弱、regularity 强”、“graph 强、regularity 弱”和“两边都弱”的显式对象；
  还有同一 graph 因 target / residual / branch 改变而跨越多个 regularity 区域的对象。

因此，“跷跷板”若指普适的 intrinsic operator law，目前答案是否定的；若指固定迭代机制中的
sufficient compatibility boundary，答案是肯定的，但它通常不是必要、sharp 或一维的。

### 对问题 2 的回答

五个选项中，当前最合适的是：

\[
\boxed{\textbf{D 为主结论；数据结构是 B + C。}}
\]

- **D：若干不同机制拼在一起**，是实质判断。
- **B：二维 phase diagram** 可作可视化，但每个点必须附带多轴标签。
- **C：partial order** 才是理论关系的正确数学结构。
- **A：一维强弱轴** 被大量 coordinate crossings 否定。
- 若 **E** 指“完全不存在任何补偿机制”，则过强；若 E 只指“不存在统一的一维普遍律”，
  则现有数据强烈支持这个较窄版本。

这不是对所有可能标量化的抽象不可能性定理；它是对本项目已整理的自然 graph、Cayley、
regularity 和算法坐标所作的证据判断。

---

## 1. 证据如何计数：先排除假相关

### 1.1 观测单位

有效 phase observation 是

\[
\text{canonical object}
\times \text{graph reference}
\times \text{tested residual/target}
\times \text{scope/stepsize}.
\]

不同 target、restriction 或 residual 可以产生不同 observation，但不自动产生新的 canonical
object。反过来，同一组集合产生的 set-intersection map、primal normal sum 和
Douglas–Rachford residual 是不同映射，不能把一个 modulus 抄到另一个上。

以下去重规则对结论有实质影响：

- GX-060 与 GX-061 由 unitary conjugacy 联系，只算一个 invariant phase point；
- \(N_{\{0\}}\) 的不同维数记录是 dimension-parameterized family，不是 literal same-space alias；
- GX-049 的 tangent-set map 与 GX-069 的 DR residual 共享集合背景，却不是同一 mapping；
- GX-042 的 \(N_L\) 与 \(I-P_L\)、GX-077 的 \(\partial|x|\) 与 \(I-J\)
  分别保留为 operator/residual observations，不重复计作独立问题证据。

### 1.2 反向校准样本的权重

GX-071 先设 \(\alpha=\gamma q\)，GX-072 先设
\(\beta=q/\gamma-1\)。它们证明“某个 exponent 行为可构造”，不能证明这个行为在自然样本中
被发现。因此 phase cloud 对 GX-071/072 采用 \(w_{\rm emp}=0.25\)。GX-073 是工程化的
anchored/all-pairs probe，采用 \(w_{\rm emp}=0.5\)。综合结论不以这三条构造的数量作支持。

### 1.3 exact modulus \(0\) 不是一个强度等级

\(\operatorname{subreg}F=0\) 是可接受局部常数下确界为零；它可能来自完全不同的原因：

| 机制 | 代表记录 | 能否当作“regularity 极强” |
|---|---|---|
| `BIG-SOLUTION` / `DOMAIN-VACUOUS` | GX-012@0、GX-040、GX-042、GX-074 | 否；solution 大或域外 residual 为 \(+\infty\) |
| `FULL-VALUE` | GX-036、GX-038 的相应坐标 | 否；局部满值使不等式退化 |
| `BRANCH-PINNING` | GX-010 非零 target、GX-012@\(-1\)、GX-040 | 只说明该 inverse branch 局部常值；不等于 residual slope 强 |
| `RESIDUAL-JUMP` | GX-046、GX-056、GX-077 | 是非平凡逻辑现象，但 residual 不趋零，不能与渐近幂律混排 |
| `RESIDUAL-ESCAPE / GRAPH-ISOLATION` | GX-055 | 邻域隔离现象，不提供可比较的 conditioning slope |
| `SUPERLINEAR-GERM` | GX-022、GX-024、GX-071/072 | residual \(\to0\) 的非退化高阶关系；可保留为真正高阶 inverse rate |

尤其 GX-040 同时具有 input-side “任意 strong modulus”和四个 core regularity modulus \(0\)，
但前者由 \(a=0\) graph-vacuity、后者由 domain-vacuity / branch-pinning 产生。若把它画成
“两边无限强”，会人为制造最强的假相关。本文在相应轴上把这种 observation 的 empirical
weight 置零。

---

## 2. 问题 1–2：phase cloud 实际显示了什么

### 2.1 四个逻辑区域都有非退化对象

下表中的“强/弱”只在指定坐标上比较，不伪装成全序；“inverse 强”也只是操作性标签，
不等于名称中带有 `strong` 的 metric regularity / subregularity。

| 指定 phase 区域 | 非退化见证 | 实际含义 |
|---|---|---|
| graph 强 + inverse 强 | GX-002、GX-005、GX-062、GX-063；GX-070 的 DR residual | positive strong+coco / strict Cayley contraction 与 ordinary MR/SMR/SMSR/MSR 同时存在 |
| graph 较强 + inverse 某轴弱 | GX-013；GX-006/011；GX-009 | strong+coco restricted graph 仍可缺 MR/SMR；coco+maximal 可仅有 MSR；无限维 nonclosed range 可摧毁所有 power/genuine-gauge MSR |
| graph 弱/不利 + inverse 强 | GX-004、GX-008、GX-035、GX-043、GX-066 | pure skew、indefinite/adverse slope 或无 finite quadratic defect 仍可有 ordinary full/fixed-target stability |
| 两个 ordinary 坐标都弱 | GX-018、GX-054、GX-057、GX-068/069；GX-009、GX-060/061 | 前一簇仍有 fractional regularity；后一簇因 nonclosed range 连 power/gauge MSR 都失败 |

因此点云不是从左上到右下的带状云。它至少含同向移动、反向移动和相互独立移动三类。

### 2.2 最有力的反一维证据是“同签名分叉”

#### 近似相同 graph signature，regularity 分裂

- GX-006、GX-011 与 GX-009 都在 monotone/coco/nonexpansive Cayley 一侧；前两者有 exact
  linear MSR，GX-009 即使零点孤立，也因 infinite-dimensional nonclosed range 没有任何
  power 或 genuine vanishing-gauge MSR。
- GX-016/017/021 与 GX-023 都是 maximally monotone、Cayley nonexpansive 的显式标量模型；
  前三者有 sharp \(q=1/3\) power regularity，GX-023 只有 logarithmic gauge。
- GX-025 与 GX-026 的 scalar quadratic defect、Cayley 和完整 power envelope 相同，
  但各自的 exact gauge \(\phi_+\)、\(\phi_-\) 互不支配。
- GX-034、GX-035、GX-037、GX-075 都有 local unbounded quadratic defect / Cayley
  collision，却分别落在 SMSR、MR、fractional MR、HREG/UHREG 的不同组合中。

#### 近似相同 regularity signature，graph geometry 分裂

- ordinary 四个 core modulus 均为 1 的对象包括 pure skew GX-004（取 \(\omega=1\)）、不同
  paramonotone/rectangular cells 的 GX-058@0 / GX-059、positive finite-cyclic rotations
  GX-062/063、negative line GX-066 以及 local positive identity GX-039。
- fixed/two-target \(q=1/3\) 家族 GX-016/017/018/021/054 横跨
  monotone+coco、finite cohypo but no hypo、maximal cyclic 与 Minty-collision/no-finite-hypo。
- fixed \(q=1/2\) 且 ordinary failure 的对象横跨 scalar fold、set tangency、VI graph、
  branch relation、DR residual 和不同维数 mapping（GX-028/049/053/057/065/068/069/076）。

这些不是单个 counterexample；它们显示理论空隙里住着几种稳定的自然机制：kernel / range
closure、branch coverage、target uniformity、solution isolation、set tangency、residual choice 和
critical Cayley flatness。它们不能由一个“单调性强度”数字吸收。

### 2.3 natural sample clusters 的支持与反驳

| 样本簇 | 是否支持 universal seesaw | 它真正支持什么 |
|---|---|---|
| finite-dimensional linear / rotation / shear（GX-002--008、062--063） | 反驳；同一 inverse modulus 可配 skew、positive 或 adverse graph | graph symmetric part、singular values、range/ker 是相对独立坐标 |
| infinite-dimensional diagonal / Volterra（GX-009、059--061） | 强烈反驳 | nonclosed range 是 regularity 的独立破坏机制，maximal monotonicity 不补救它 |
| scalar power / gauge（GX-016--027） | 反驳固定 exponent law | regularity 的正确对象常是完整 gauge，而非一个 power label |
| normal cones / set feasibility（GX-040--052） | 反驳 operator-only 比较 | full/truncated graph、set map、normal sum、projection residual 必须分开 |
| tangent/transverse DR（GX-069/070） | 支持固定 residual 内的 geometry–rate 耦合 | 对 DR residual，tangency 给 fractional EB，transversality 给 linear conditioning；primal modulus不可代入 |
| LT/critical Cayley examples（GX-032、053、064/065） | 支持 scale/step-specific graph profile | GX-032 给 finite LT defect 但无 finite hypomonotonicity；GX-053/064/065 的 critical flatness 才给 genuine subunit Hölder Cayley；regularity常位于另一 reference，不能机械相乘 |
| reverse-calibrated GX-071/072 与 probe GX-073 | 只支持 attainable / obstruction | 必须降权；它们不构成自然经验定律 |

### 2.4 最终 phase topology

较安全的结构是两个多分量 signatures 的乘积，而非二维实数平面：

\[
\begin{aligned}
\mathcal G={}&(\text{input/output defect},\text{Cayley profile},
\text{cyclicity},\text{maximality/coverage},\text{scope},\text{step}),\\
\mathcal R={}&(\text{fixed/nearby target},\text{isolation},
\text{exponent/gauge},\text{modulus mechanism},\text{scope},\text{residual}).
\end{aligned}
\]

理论蕴含在各分量内部形成 partial order；算法定理只在选定坐标截面上给 compatibility region。
所谓二维图应是对 \(\mathcal G\times\mathcal R\) 的交互式投影，不能被解释为客观总排序。

---

## 3. 问题 3：算法理论中的补偿到底有多真实

### 3.1 代表性横向比较

下表选取能直接检验“补偿”解释的代表条目；完整 audited theorem index 见
`theory_atlas.md` 第 7 节。未收入本表的已核算法条目不构成反面证据。

| 算法族 | graph / model geometry | regularity 的对象 | 已核结论 | “跷跷板”判定 |
|---|---|---|---|---|
| PPA（maximal monotone） | firm resolvent / Fejér geometry | original \(F\) 的 MSR | local Q-linear distance；步长增大可使 distance factor趋零，[Leventhal, Thm. 3.1](https://arxiv.org/abs/0902.4200) | 两因素联合；尚无替代曲线 |
| local LT-PPA | local maximal submonotonicity，violation \(\tau\) | relevant zeros 上 uniform MSR bound \(\bar\rho\) | \(\tau(1+\bar\rho/\lambda)^2<1/2\) 下 local R-linear，[Luke–Tam, Thm. 2](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863) | **真正的连续 compatibility datum**；但只是 sufficient、restricted、有限维，未证 sharp/necessary |
| KM / almost-averaged fixed point | violation \(\varepsilon\)，averaging \(\alpha\) | \(I-T\) 或 \(T-I\) 的 MSR，modulus \(\kappa\) | \(c^2=1+\varepsilon-(1-\alpha)/(\alpha\kappa^2)<1\) 时 local linear，[Luke–Thao–Tam, Thm. 2.15](https://arxiv.org/abs/1605.05725) | **最通用的机制内补偿模板**；residual-specific，不是 original operator 定理 |
| nonconvex FB / DR | hypo/submonotone 或 almost-firm local geometry | FB/DR fixed-point residual 的 MSR | local linear，在同一 almost-averaged模板落地，[Luke–Thao–Tam](https://arxiv.org/abs/1605.05725) | 重复出现同一 proof architecture；不证明跨 residual 可互换 |
| FBF / extragradient | max-monotone + coco/Lipschitz pieces；conditioned metric | full inclusion 的 MSR | local Q/R-linear specializations，[Giselsson, Thms. 3--4](https://arxiv.org/abs/1908.07449) | 暴露第三个 metric-conditioning 轴；不能压成纯 monotonicity--regularity 两轴 |
| convex DR / ADMM | branch (i) strong convexity+cocoercivity | branch (ii) 改用 \(I-T\) residual EB | 同一问题框架中两条 local-linear sufficient branches，[Aspelmeier–Charitha–Luke, Thms. 1.6, 2.3](https://arxiv.org/abs/1508.04468) | **目前最干净的替代机制证据**；两 branch 未证互斥、必要或等常数 |
| PRS | 一项 strong convexity + smoothness | 无 EB 假设 | global contraction，含 pure PRS，[Davis–Yin, Thm. 4.1](https://arxiv.org/abs/1407.5210) | geometry-only 基准；不能与 local DR-EB 硬配，端点和 rate object不同 |
| cyclic / alternating projections | elemental set geometry \(\Rightarrow\) almost averaged | product-map subtransversality / residual MSR | technical invariance/bridge条件下 local linear，[Luke–Thao–Tam, Thm. 3.14](https://arxiv.org/abs/1605.05725) | 机制内补偿；这里“monotonicity side”其实是 set/projector geometry |
| generalized / semismooth Newton | derivative accuracy / semismoothness；无 monotonicity | original generalized equation或全部 linearizations 的 strong (power) subregularity | conditional superlinear / order，[Cibulka–Dontchev–Kruger, Thms. 6.1--6.4](https://arxiv.org/abs/1701.02078) | 强 inverse stability 可在另一机制中取代 Fejér geometry；不与 splitting 构成同结论 trade-off |
| Levenberg–Marquardt | **本轮 audited atlas 无 theorem-level 条目** | — | — | 不得外推 Newton 行；这是下一轮明确的证据缺口 |

表中的 local 结论都还依赖各原定理的 nonempty fixed/solution set、足够近初始化、
branch 存在与 neighborhood/affine invariance 等条件；Newton 行尤其只给保持在邻域内的合法
生成序列的 conditional rate。表格没有把这些条件吸收到“monotonicity”或“regularity”两轴。

用户初稿之外的 generalized PPA “无 monotonicity + MR/SMSR”条目在正式 atlas 中因 primary
theorem 全文量词尚未重新捕获而降为 pending，故本文不把它计作已证替代分支。

### 3.2 哪些可称为反复出现，哪些不能

可以说“反复出现”的是下列 proof architecture：

\[
\boxed{
\text{controlled one-step expansion/descent}
+
\text{residual-to-solution error bound}
\Longrightarrow
\text{local contraction}.}
\]

它出现在 PPA、abstract KM、nonconvex FB/DR 和 cyclic projections。graph violation 增大时，
允许的 error-bound modulus 必须变小，这就是固定截面上的局部跷跷板。

不能说已经反复证明了以下更强命题：

1. weaker operator monotonicity 必然伴随 stronger metric regularity；
2. 两者可在不同算法、不同 residual 和不同 rate object 间按一个数互换；
3. compatibility boundary 是 necessary 或 sharp；
4. Newton 的 strong subregularity 与 splitting 的 ordinary residual MSR 是同一种“补偿量”。

结论相似也必须保持量词：global contraction、local distance Q-linear、iterates R-linear、
objective Q-linear、存在一个 selection sequence、任意合法 branch convergence 都不是同一结论。

---

## 4. 问题 4：更基础的共同对象是什么

### 4.1 分裂 / fixed-point 家族中的最佳候选

目前最有解释力的共同对象不是 \(F\) 单独的 graph，也不是 \(F^{-1}\) 单独的稳定性，而是

\[
\boxed{\text{conditioned local iteration germ }
\mathfrak I=(T,S,W,G,\mathcal B).}
\]

这里 \(T\) 是 algorithm map，\(S\) 是目标 fixed/solution set，\(W\) 是有效且尽可能 invariant
的 window，\(\mathcal B\) 记录 branch/selection 量词。对每个 admissible update
\(x^+\in T_{\mathcal B}(x)\)，必须另行指定与该 branch 对齐的 residual
\(G_{\mathcal B}(x)\)；在标准 fixed-point 行中它通常是 \(x-x^+\)。两个核心 profiles 应写为：

\[
d(x^+,S)^2
\le (1+\varepsilon)d(x,S)^2-\nu\|G_{\mathcal B}(x)\|^2,
\tag{E}
\]

\[
d(x,S)\le \psi_G(\|G_{\mathcal B}(x)\|).
\tag{R}
\]

在线性 EB \(\psi_G(t)=\kappa t\) 下，二式给

\[
d(x^+,S)^2
\le\left(1+\varepsilon-\frac{\nu}{\kappa^2}\right)d(x,S)^2.
\tag{C}
\]

almost-averaged 模板正是 \(\nu=(1-\alpha)/\alpha\) 的实例。monotonicity、
hypomonotonicity、prox-regularity、set angle 或 RL 只是在不同问题中产生 (E) 或其 gauge
版本的路线；metric subregularity、subtransversality 和 EB 则在**完成 residual bridge 后**
产生 (R)。

例如 PPA 取 \(x^+=J_{\lambda F}x\)、\(Gx=x-x^+\)。original \(F\) 在 \(x^+\) 的
regularity 首先只给

\[
d(x^+,S)\le \psi_F\!\left(\frac{\|Gx\|}{\lambda}\right),
\]

再由三角不等式得到当前输入上的 bridge

\[
d(x,S)\le \|Gx\|+\psi_F\!\left(\frac{\|Gx\|}{\lambda}\right).
\]

若 \(\psi_F(t)=\bar\rho t\)，(R) 中的有效线性 modulus 是
\(\kappa=1+\bar\rho/\lambda\)，正是 Luke--Tam compatibility 式中的组合。对 DR/AP，
\(G_{\mathcal B}=I-T_{\mathcal B}\)；若改用 primal operator 或 set mapping，仍需另证 bridge。
这个 residual bridge 是 \(\mathfrak I\) 的一部分，不是可省略的记号替换。

这解释了为什么 theorem 中会出现“强弱补偿”：它是同一个 contraction proof 中 positive
defect 与 residual coercivity 的竞争，不是两个算子标签之间的守恒律。

### 4.2 为什么不能把这个候选升级为全域统一对象

1. **Residual 依赖。** GX-042、GX-069/070、GX-077 表明 original operator、primal sum、
   projection residual 和 \(I-T\) 的 moduli 可完全不同。
2. **Branch / invariance 依赖。** GX-073 有漂亮的一步 power scaling，却没有 invariant
   nonzero neighborhood；它不是 rate observation。
3. **Anchored / all-pairs 依赖。** GX-072 的 all-pairs exponent 是 \(\gamma\)，轨道看到的
   anchored exponent却是 1。
4. **Newton 机制不同。** Newton 的基本链是 model-error gauge 与 strong inverse stability
   的复合；derivative cancellation 取代 (E) 中的 Fejér decrease。
5. **Gauge 过于一般时会变成同义反复。** 任意算法都可事后定义一个 exact radial profile；
   只有当 profile 能由可验证 graph/derivative 条件预先估计，并在多算法上给 sharp prediction，
   才构成理论解释。

因此，当前事实只支持“conditioned iteration germ / gauge composition”作为**局部统一候选**。
它没有排除 derivative、coderivative、spectrum 或 Lyapunov quantity 在特定子类中提供更深表示，
但 phase cloud 尚未把其中任何一个选为唯一基础对象。

---

## 5. 问题 5：RL 在整个图中的精确位置

### 5.1 RL 是 Cayley 坐标，不是普通 monotonicity 轴上的一个新刻度

在 restricted graph \(\Gamma\) 上，RL

\[
\|a-\lambda b\|\le L\|a+\lambda b\|^\gamma
\]

精确等价于 restricted reflected resolvent / Cayley map

\[
\|R_\Gamma x-R_\Gamma y\|\le L\|x-y\|^\gamma,
\]

也等价于用户给出的 inner-product inequality。RL 本身强迫该 restricted Cayley relation
单值，但不提供 full-domain range、maximality、branch exclusion、self-map 或 invariance。

一个 RL datum 必须写成完整元组

\[
(\Gamma/W,\lambda,\gamma,L,
\text{local/global},\text{all-pairs/anchored},
\text{genuine/inherited},\text{map/relation}).
\]

压掉任一坐标，GX-015、020、025/026、030、045/046、053、064/065 的比较都会改变真假。

### 5.2 \(\gamma=1\)：与现有理论精确接轨

令

\[
\mu_L=\frac{1-L^2}{2\lambda(1+L^2)},\qquad
\rho_L=\frac{\lambda(1-L^2)}{2(1+L^2)}.
\]

则

\[
\mathrm{RL}(\lambda,L,1)
\iff
\langle a,b\rangle\ge \mu_L\|a\|^2+\rho_L\|b\|^2,
\qquad \rho_L=\lambda^2\mu_L.
\]

所以 \(\gamma=1\) 不是一个尚未命名的独立 generalized monotonicity class；它是
two-parameter semimonotonicity 平面上的 tied curve。对 \(\lambda F\)：

- \(L<1\)：equal positive semimonotonicity，Cayley contraction；
- \(L=1\)：ordinary monotonicity / nonexpansive Cayley；
- \(L>1\)：equal negative semimonotonicity；在 Luke–Tam convention 下
  \(\tau=(L^2-1)/4\)、\(L=\sqrt{1+4\tau}\)。

因此 RL\(_1\) 精确延伸的是这一条 symmetric/tied curve，而不是任意
\((\mu,\rho)\)-semimonotonicity 的全平面。引用 Luke–Tam 的 finite-dimensional restricted
theorem 时还必须保留其参数与局部 maximality 条件
([Luke–Tam 2025](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863))。
上述 algebraic 换参本身对所有 \(L\ge1\) 成立；论文中具体 resolvent/algorithm theorem 的
\(\tau<1/2\)、restriction 和 finite-dimensional 条件不能反向删到 algebraic equivalence 中。

### 5.3 \(0<\gamma<1\)：尺度反转导致全局不可比

令 \(t=\|a+\lambda b\|\)。RL inner-product form 可写为

\[
\lambda\langle a,b\rangle\ge-\tau_\gamma(t)t^2,
\qquad
\tau_\gamma(t)=\frac14\left(L^2t^{-2(1-\gamma)}-1\right).
\]

当 \(t\downarrow0\)，\(\tau_\gamma(t)\to+\infty\)：subunit RL 通常不推出一个固定 finite
hypomonotonicity / LT violation。反之，在 unbounded scale 上 \(t^\gamma\) 比 \(t\) 小，
global RL\(_\gamma\) 反而比 Lipschitz 更苛刻。故：

\[
\boxed{\text{global RL}_1\ \perp\ \text{global RL}_\gamma
\quad(0<\gamma<1)\quad\text{on unbounded domains}.}
\]

这里 \(\perp\) 只表示在 unbounded natural Cayley domain 的**类级 neither inclusion**，
不表示两个性质互斥，也不表示不存在同时满足二者的个别映射。

在 bounded window 上，任何 Lipschitz Cayley map 都继承所有较小 Hölder exponents；
GX-014、016/017、020、025/026、074 显示这种 `inherited` exponent 不携带新的 local
degeneracy 信息。只有 maximal/genuine、scope-fixed 的 exponent 才可能进入 trade-off 分析。

所以 \(\gamma<1\) RL 位于一个 scale-dependent Cayley-profile 坐标中，不能描述为“比
RL\(_1\) 更弱”或“更强”。这是 RL 无法压入传统一维 monotonicity 轴的根本原因。

### 5.4 \(\gamma q\)：一般的是 gauge composition，不是 product law

令 \(x^+=J_{\lambda F}x\)、\(S=F^{-1}(0)\)、\(r=d(x,S)\)。在同一 restricted graph /
regularity window 中，以 \(\varepsilon\)-nearest solution 处理一般 Hilbert 空间中可能不存在
最近点的问题，RL 给

\[
\|x-x^+\|\le\frac12(r+Lr^\gamma).
\]

若在 \(x^+\) 上有本项目 residual-exponent convention 的

\[
d(u,S)\le \rho\,d(0,F(u))^q,
\]

则

\[
\boxed{
d(x^+,S)
\le \frac{\rho}{(2\lambda)^q}(r+Lr^\gamma)^q
=O(r^{\gamma q})\quad(0<\gamma<1).}
\tag{5.1}
\]

若 regularity gauge \(\psi\) 在相关区间右连续，更本质的式子是

\[
d(x^+,S)
\le
\psi\!\left(\frac{r+Lr^\gamma}{2\lambda}\right),
\tag{5.2}
\]

其中 \(\psi\) 是 regularity gauge。若只假设 \(\psi\) 单调，则应把右端换为右包络
\(\psi^+(t):=\lim_{s\downarrow t}\psi(s)\)。为简化记号，以下仍把“原右连续 gauge 或其
右包络”统记为 \(\psi\)，threshold 也对这个有效 gauge 计算。\(\gamma q\) 只是
\(r\mapsto r^\gamma\) 与 \(t\mapsto t^q\) 的 regularly-varying 特例。
在其余 convergence / invariance 条件已经成立时，(5.1) 只给出以下 proof-level 分区：
\(\gamma q>1\) 时右端相对 \(r\) 为高阶，\(\gamma q=1\) 时还需 leading coefficient
小于 1，\(\gamma q<1\) 时这个 upper bound 本身不推出 contraction；它不排除真实轨道因
anchored profile 更好而收敛。

一般 gauge 的 sufficient contraction threshold 也必须分开：

\[
0<\gamma<1:\quad
\limsup_{t\downarrow0}\frac{\psi(t)}{t^{1/\gamma}}
<\left(\frac{2\lambda}{L}\right)^{1/\gamma},
\tag{5.3a}
\]

\[
\gamma=1:\quad
\limsup_{t\downarrow0}\frac{\psi(t)}{t}
<\frac{2\lambda}{1+L}.
\tag{5.3b}
\]

把 \(2\lambda/L\) 直接用于 \(\gamma=1\) 会漏掉式中的线性 \(r\) 项。

#### 三个关键例子的判决

| 例子 | 已复算事实 | 对 \(\gamma q\) 的意义 |
|---|---|---|
| GX-071 | restricted all-pairs sharp exponent \(\gamma\)，global fixed \(q\)-MSR exact 1；满足 drift margin 的子窗内 \(r_+=r^{\gamma q}\) | **可达性**；但 \(\alpha=\gamma q\) 是预先接线，optimal RL constant未知，权重 0.25 |
| GX-072 | all-pairs exponent \(\gamma\)，anchored exponent 1，sharp fixed \(q\)-regularity；真实 invariant orbit order \(q>\gamma q\) | 证明 (5.1) 可非 sharp；轨道服从 anchored profile，不服从 worst all-pairs exponent；同样反向校准，权重 0.25 |
| GX-073 | anchored exponent \(\alpha\)，all-pairs \(\alpha/(\beta+1)\)，linear MSR/SMSR | 一步有 power scaling，却没有 invariant nonzero neighborhood；不能称为 convergence order，权重 0.5 |

此外，bounded-range examples 可同时“满足任意 \(\gamma<1\)”而 dynamics 不变；若任意挑一个
非sharp inherited \(\gamma\) 与 \(q\) 相乘，会得到任意多个虚假的 predicted rates。GX-064
还显示 Cayley exponent 与 regularity exponent 可属于不同 graph reference，根本不能相乘。

因此当前结论是：

\[
\boxed{
\text{在上述同窗、branch 与 gauge 右包络条件下，gauge-composition upper bound 是一般代数结构；}
\gamma q\text{ 作为 exact rate 或 universal compensation law 不是。}}
\]

### 5.5 何时 \(\gamma q\) 才可能成为定理中的真实 order

至少需要同时加入：

1. resolvent branch 在指定 tube 上存在、单值并按所需 selection 量词闭合；
2. tube/self-map 或显式 orbit invariance，而不只是一步公式；
3. zero set closed；若不 proximinal，RL 与 regularity 对 \(\varepsilon\)-nearest solutions
   有统一 two-radius localization；
4. regularity 在所有 relevant zeros 与所有 \(x^+\) 上 uniform，且使用正确 residual；
5. 使用 orbit-relevant **anchored** Cayley gauge，而不是自动使用 worst all-pairs exponent；
6. 排除 inherited exponent、domain vacuity、residual jump 和不同 reference 的拼接；
7. 若要 exact order 而非 upper bound，geometry profile 与 regularity gauge 都需 two-sided
   asymptotic comparability，并证明 extremizing directions 与实际 branch 对齐；
8. finite-length / cluster membership 或其他机制保证迭代点本身收敛，而非只有
   distance-to-set 收敛；
9. fixed/variable stepsize 和每一步有效 window 明确。

用户 RL 初稿中的一步估计在这些限定下是有价值的；初稿的 full convergence statements 仍需按
上述清单重写，且 \(\gamma=1\) 的 gauge threshold 必须与 \(0<\gamma<1\) 分开。

---

## 6. 可证的下一步 conjecture / test program

以下全部是研究命题或检验程序，**不是 theorem**。

### P0：先建立最小的局部统一理论

#### Conjecture / Program C1 — anchored gauge-composition theorem

固定 conditioned iteration germ \((T,S,W,G,\mathcal B)\)。若：

- \(W\) 对所有 admissible branches invariant；
- 存在 sharp anchored geometry gauge \(g\)，使一步 residual / model error 与
  \(g(d(x,S))\) two-sided comparable；
- 存在 uniform inverse gauge \(\psi\)，且 extremizing branches 对齐；

则对每个指定的 admissible update \(x^+\in T_{\mathcal B}(x)\)，测试是否能证明 exact
radial order

\[
d(x^+,S)\asymp (\psi\circ g)(d(x,S)).
\]

power case 的 \(\gamma q\) 只是该命题的一个 corollary candidate。首先应用于 RL-PPA，
并用 GX-071 检验可达、GX-072 检验 anchored correction、GX-073 检验 invariance 必要性。

#### Program C2 — 修复并最小化 RL-PPA 假设

逐项证明哪些假设真的必要：range coverage、local maximality、branch exclusion、uniform
solution-tube MSR、two-radius window、zero-set closedness、finite length。优先尝试用 anchored RL
替代 all-pairs RL；若成功，这会解释 GX-072 而非把它当异常。

#### Program C3 — necessary/sharp compatibility

对 Luke–Tam 与 almost-averaged compatibility 式寻找：

- equality / boundary examples；
- 条件失败但算法仍收敛的反例；
- 条件失败且发散的匹配例；
- rate constant 的 lower bounds。

只有得到 necessity 或 sharpness，才能把 sufficient region 升级为真正 trade-off curve。

### P1：扩大非工程化样本，而非增加同类 alias

1. 以 prox-regular normal cones、degenerate smooth gradients、自然 DR tangent problems、
   compact/nonclosed-range operators 为主，计算 sharp anchored/all-pairs Cayley gauge 与
   fixed/two-target inverse gauge。
2. 对每一算法固定 residual 后再比较；专门研究何时
   \(F\)-MSR、\((I-J_{\lambda F})\)-MSR 和 \((I-T)\)-MSR 可通过可控 bridge 转换。
3. 用同一 canonical object 的 target/reference sweep 建立 within-object paired data；这比增加
   另一个术语相似的 operator 更能识别机制。
4. 完成 Levenberg–Marquardt theorem-level atlas；在此之前不把 Newton 结果外推到 LM。

### P2：检验更深表示，但设置否证标准

在 smooth finite-dimensional 子类测试 derivative/coderivative、symmetric/skew spectrum、
Cayley derivative 与 exact regularity modulus是否共同决定 local iteration profile。若两个对象
具有相同候选 invariant 却出现不同 anchored rate，则否决该候选。对 set-valued / nonsmooth
对象另测 graphical derivative和branch multiplicity，避免把 smooth 结论强行推广。

### 停止标准

若在固定 residual、固定 scope、sharp anchored gauge 后，自然样本仍持续出现不可由额外可观测
坐标解释的 crossings，且所有“统一定理”都退化为事后定义 exact radial profile，则停止追求统一
seesaw。反之，若一个预先可检验的 profile theorem 能在 PPA、DR/AP 和至少一个非 splitting
算法中给出 sharp、branch-stable prediction，再考虑提升为统一理论。

---

## 7. 最终研究决策

### 决策

\[
\boxed{\textbf{继续研究，但只继续“局部 / 机制级统一”；停止追求普遍一维跷跷板。}}
\]

优先级如下：

1. **最高：** 完成 anchored gauge-composition 与 RL-PPA 的严谨局部定理，补齐 invariance、
   branch 和 uniformity；把 \(\gamma q\) 降格为待证 corollary candidate。
2. **最高：** 对 Luke–Tam / almost-averaged compatibility 做 sharpness 与 necessity 压力测试。
3. **中等：** 扩充非工程化 canonical examples，并统一在 algorithm residual 上复算；不以
   GX 数量作统计支持。
4. **中等：** 补齐 Levenberg–Marquardt 及 pending primary-source 条目。
5. **较后：** 只有前四项显示稳定共同 profile 后，才投入 coderivative/spectral 统一表示。

当前 RL 的最可信定位是：\(\gamma=1\) 精确落在 tied semimonotonicity 曲线上，其中
\(L\ge1\) 的部分对应 Luke–Tam 参数化；
\(0<\gamma<1\) 提供一个真正有用但 scale-、scope-、step-、anchoring-dependent 的 Hölder
Cayley geometry。它可能延伸的是“conditioned iteration germ 的 gauge profile”，而不是传统
monotonicity 强弱轴。这个较窄方向值得继续；普遍负相关律目前不值得作为目标假设。

---

## 8. 综合自检

- 未把 77 个 GX 编号当作 77 个 independent canonical samples；GX-060/061 等按 alias
  规则去重。
- GX-071/072 按 reverse-calibrated 低权重处理，GX-073 未被当作 invariant convergence
  observation。
- 所有 modulus-zero 主张按 vacuity、pinning、jump、escape 或 superlinear germ 分机制。
- all-pairs/anchored、local/global、operator/residual、fixed/two-target、single/set-valued 与
  stepsize/restriction均分栏讨论。
- 算法结论没有跨 residual、rate object、selection 或 local/global 量词硬比较。
- \(\gamma=1\) 采用 exact semimonotonicity/Luke–Tam 换参；\(\gamma<1\) 保留尺度反转与
  global incomparability。
- \(\gamma q\) 只作为 gauge-composition proof path；可达、非sharp和noninvariant三类证据
  分别由 GX-071、GX-072、GX-073 承担。
- pending source 或 unknown sharp constant 未升级为 theorem；本文结论不声称文献穷尽性。
