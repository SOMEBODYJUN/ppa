# Generalized monotonicity–regularity gap example catalog

> 版本：2026-09-01（Subagent B 集成稿 + post-C audit overlay）。  
> 性质：保留 B 阶段的显式对象与构造公式，并回填 C 阶段已经解析核验的状态与 scope；它仍然**不是** `example_properties.md` 或 seesaw synthesis。  
> 规模：77 张独立可复算卡。它们不是 77 个可独立加权的 phase points：canonical operator/object 相同而只改变 reference、domain restriction、stepsize 或 algorithm residual 的卡，进入 phase cloud 时只计一个 canonical object，其余作为 observation 子记录。

## 0. 口径、证据与去重规则

除另注外，

\[
(x,u),(y,v)\in\operatorname{gph}F,\quad a=x-y,\quad b=u-v,
\quad d=a+\lambda b,\quad r=a-\lambda b,
\]

且 RL 比值为 \(Q_{\lambda,\gamma}=\|r\|/\|d\|^\gamma\)。若 \(d=0\) 而 \(r\ne0\)，则所有有限 RL 常数失败。Regularity 默认在条目打印的参考图点，power convention 为

\[
d(x,F^{-1}(\bar y))\le \kappa d(\bar y,F(x))^q.
\]

本文统一记 \(P_\alpha(t):=\operatorname{sgn}(t)|t|^\alpha\)。若 resolvent/reflection 只是 relation，则
\(A^{\mathrm{gph}}_\gamma(\bar u,\bar u^*)\) 专指：以固定 graph point
\((\bar u,\bar u^*)\) 为一端，对所有相关 graph points 验证 anchored RL graph inequality。
它不是某个 single-valued Cayley selection 的 map-pointwise \(P_\gamma\) 性质；没有打印 selection、window 与统一量词时，不使用两者的等价关系。

证据标签：

| 标签 | 本目录中的含义 |
|---|---|
| `P3-DIRECT` | 对象及所列文献性质已由 source verifier 在 primary full text 逐项核对 |
| `P2-DERIVED` | primary source 给对象/基础性质；显示常数或专门化是本项目代数推导 |
| `ALG-CHECKED` | B 稿已给显式代数核验，但未作 primary attribution；仍须 C 独立复算 |
| `VERIFIED-ALG` | C 阶段已从公式给出全量词解析证明；只升级所列数学性质，不改变其 primary-source provenance |
| `CANDIDATE` | 只有 branch/slice 或部分量词成立；不得升级为 full-map 性质 |
| `PENDING` | 历史定义、sharpness 或 theorem 假设尚未核实；只登记实际验证的公式 |

去重优先级：`b_source_verification.md` 的纠偏覆盖其他 B 稿。特别保留：Luke–Tam 例子的 \(U=[0,1/16],W=\mathbb R,\tau=2\)；BWY 对象中的 sum、closed ball 与无限维空间；rotation 阈值 \(|\theta|\le\pi/n\)；圆法锥为 \(N_{S^1}(x)=\mathbb Rx\)，且 prox-regular theorem 必须截断 normal norm。Phase-cloud 计数以 canonical operator/object 为单位；算法 map、primal operator 与 residual mapping 若公式不同可各自复算，但不得把同一 underlying operator 的别名当成独立样本权重。

每条以 14 字段压缩记录：1 space；2 mapping；3 single/set；4 graph；5 zero；6 inverse；7 resolvent；8 reflected resolvent；9 source；10 gap purpose；11 known yes；12 known no；13 proof sketch；14 parameter range。另列 local/global、vacuity/isolation 与 C audit。

## 1. Coverage matrix：理论 pair × 四逻辑区

表中 `L` 为 pair 左性质，`R` 为右性质；逻辑不可能的格不伪造例子。涉及 local/global 或固定 step 时在格内标明。

| Pair \((L,R)\) | \(L\wedge R\) | \(L\wedge\neg R\) | \(\neg L\wedge R\) | \(\neg L\wedge\neg R\) |
|---|---|---|---|---|
| global RL\(_1\), global RL\(_{\gamma<1}\) | GX-002 tuned；GX-016 | GX-001 | GX-015（仅 exponent \(\alpha\)） | GX-054 |
| global/local RL\(_\gamma\), SMSR | GX-015（local SMR） | GX-016, GX-017 | GX-003（subunit global RL fail） | GX-054 |
| strong monotone, cocoercive | GX-002, GX-005 | GX-010 | GX-006, GX-011 | GX-004, GX-007, GX-008 |
| finite hypomonotone, LT/RL\(_1\) | GX-003（nonsingular step） | GX-053（critical endpoint） | GX-032 | GX-054（global） |
| paramonotone, rectangular | GX-006 | GX-059 | GX-058 | GX-060, GX-061, GX-004 |
| 3-cyclic, 4-cyclic | GX-063 | GX-062 | impossible（4-cyclic \(\Rightarrow\) 3-cyclic） | GX-004 |
| maximally monotone, strong | GX-002, GX-010 | GX-001, GX-009 | GX-013 | GX-014, GX-019 |
| MR, SMSR | GX-002, GX-035 | GX-036, GX-043 | GX-013, GX-033 | GX-021, GX-028 |
| Aubin\((F^{-1})\), isolated calm\((F^{-1})\) | GX-002 | GX-036 | GX-033, GX-037 | GX-038 |
| MSR, HREG | GX-044, GX-075 | GX-033 | GX-068 | GX-028 |
| transversality, subtransversality | GX-047 | impossible | GX-048 | GX-049, GX-050 |
| VI pseudomonotone, VI quasimonotone | GX-064 | impossible | GX-065 | GX-066 |
| prox-regular set/function, full-graph finite hypo | GX-003（concave quadratic variant）, GX-067 | GX-045 | `PENDING`：GX-046 只有 attentive branch | GX-046 full graph |
| strict two-moving Spingarn formula, LT | GX-032 | GX-053 | GX-056 | GX-057；历史命名 `PENDING` |
| local LR, bounded LR | GX-047, GX-048, GX-052 | GX-051 | impossible | GX-049, GX-050 |
| bounded LR, global LR | GX-047, GX-048 | GX-052 | impossible | GX-049, GX-050, GX-051 |

Evidence coverage：P3/P2 anchors 为 GX-032、035、045、048、058–063、065、074、076；其余主要为 `ALG-CHECKED`。Post-C 后，GX-049、057、069、072、073 的下列卡内结论已升级为 `VERIFIED-ALG`。仍未知的是 GX-072/GX-073 的 optimal all-pairs endpoint RL constants，而不是 endpoint exponents 或 full-map regularity；未单列成 GX 卡的 AR-06 endpoint upper property 继续保持 `CANDIDATE`。

---

## 2. Linear、matrix 与 basic Cayley master records

### GX-001 — 零算子

- **Origin IDs / evidence：** LC-01 = EX-19 = SVG-05；`ALG-CHECKED`。
- **1–4：** \(H=\mathbb R\)，\(F(x)=0\)，single-valued；\(\operatorname{gph}F=\mathbb R\times\{0\}\)。
- **5–8：** \(S=\mathbb R\)；\(F^{-1}(0)=\mathbb R\)，其他 fiber 空；\(J_{\lambda F}=I\)，\(R_{\lambda F}=I\)。
- **9–12：** 用于 global RL\(_1\not\Rightarrow\)global RL\(_\gamma\)、maximal-not-strong、trivial MSR。已知 max monotone、RL\(_1\) sharp \(L=1\)、MSR modulus 0；非 strong、非 MR/SMSR/SMR，且无 global \(\gamma<1\) RL。
- **13–14：** \(b=0\)，\(Q_{\lambda,\gamma}=|a|^{1-\gamma}\)；任意 \(\lambda>0\)，\(0<\gamma<1\)。bounded Minty diameter \(\Delta\) 时 \(L_\gamma^*=\Delta^{1-\gamma}\)。
- **Scope / vacuity / C audit：** graph/RL global；MSR 因 \(S=H\) **BIG-SOLUTION TRIVIAL**。C 复核 inverse Aubin failure 的空 fiber 量词。

### GX-002 — 正标量族 \(F=cI\)

- **Origin IDs / evidence：** LC-02 = CP-03；MGB-16 是 \(c=1\)；`ALG-CHECKED`。
- **1–4：** Hilbert space \(H\ne\{0\}\)，\(F(x)=cx\), \(c>0\)，single-valued；graph \(\{(x,cx)\}\)。
- **5–8：** \(S=\{0\}\)，\(F^{-1}=c^{-1}I\)；\(J=(1+\lambda c)^{-1}I\)，\(R=((1-\lambda c)/(1+\lambda c))I\)。
- **9–12：** both strong+coco、all four core regularities、tuned subunit-RL control。Sharp strong \(c\)，coco \(1/c\)，MR/MSR/SMSR/SMR modulus \(1/c\)，RL\(_1\) constant \(|1-\lambda c|/(1+\lambda c)\)。
- **13–14：** \(\langle a,b\rangle=c\|a\|^2=c^{-1}\|b\|^2\)。若 \(\lambda c=1\)，\(R=0\) 且全部 \(0<\gamma\le1\) global RL；否则 global subunit exponents 失败。
- **Scope / vacuity / C audit：** 全局、孤立、非 vacuous。C 将此作为所有 modulus/exponent 的校准基线。

### GX-003 — 负标量族 \(F=-cI\)

- **Origin IDs / evidence：** LC-03 = MGB-03（非奇异范围）= MGB-22（\(c=1\) 的 concave quadratic）；`ALG-CHECKED`。
- **1–4：** \(H=\mathbb R\)，\(F(x)=-cx\), \(c>0\)，single-valued；graph negative line。
- **5–8：** \(S=\{0\}\)，\(F^{-1}(y)=-y/c\)。若 \(\lambda c\ne1\)，\(J=(1-\lambda c)^{-1}I\)，\(R=((1+\lambda c)/(1-\lambda c))I\)；若相等，Minty range \(\{0\}\) 且 \(J(0)=\mathbb R\)。
- **9–12：** negative graph + strongest inverse stability；也作 prox-regular concave quadratic control。Sharp hypo \(c\)、cohypo \(1/c\)，四种 regularity modulus \(1/c\)。非 monotone/coco；奇异 step 所有 RL 失败。
- **13–14：** \(\langle a,b\rangle=-c\|a\|^2=-c^{-1}\|b\|^2\)。非奇异 step RL\(_1\) sharp \(|1+\lambda c|/|1-\lambda c|\)，global \(\gamma<1\) 失败。
- **Scope / vacuity / C audit：** 全局、孤立、非 vacuous；C 区分 operator regularity 与 chosen-step resolvent collapse。

### GX-004 — 纯 skew rotation

- **Origin IDs / evidence：** LC-04 = MGB-13（\(\omega=1\)，orientation 可反转）；rotation threshold part `P3-DIRECT`，其余 `ALG-CHECKED`。
- **1–4：** \(H=\mathbb R^2\)，\(K=\bigl(\begin{smallmatrix}0&-1\\1&0\end{smallmatrix}\bigr)\)，\(F=\omega K\), \(\omega>0\)，linear single-valued。
- **5–8：** \(S=\{0\}\)，\(F^{-1}=-(1/\omega)K\)；令 \(t=\lambda\omega\)，\(J=(I-tK)/(1+t^2)\)，\(R=(I-tK)(I+tK)^{-1}\) 为 rotation。
- **9–12：** \(J\)-contraction without strongness；max monotone but neither paramonotone nor rectangular at quarter turn；all four regularities modulus \(1/\omega\)。非 strong/coco。
- **13–14：** \(\langle a,b\rangle=0\)，\(\|J\|=(1+t^2)^{-1/2}\)，\(\|R\|=1\)。Global RL\(_1\) sharp 1；所有 global subunit RL 失败。
- **Scope / vacuity / C audit：** 全局、孤立。C 复核 “rectangular iff positive cocoercivity” 所需 linear/maximal assumptions。

### GX-005 — shifted rotation \((\mu I+\omega K)\)

- **Origin IDs / evidence：** LC-05；`ALG-CHECKED`。
- **1–4：** \(H=\mathbb R^2\)，\(F=(\mu I+\omega K)\), \(\mu,\omega>0\)，linear single-valued；full graph。
- **5–8：** \(S=\{0\}\)，\(F^{-1}=(\mu I-\omega K)/(\mu^2+\omega^2)\)；\(J=[(1+\lambda\mu)I-\lambda\omega K]/D_+\)，\(D_+=(1+\lambda\mu)^2+(\lambda\omega)^2\)，\(R=(I-\lambda F)(I+\lambda F)^{-1}\)。
- **9–12：** both strong+coco、\(F,F^{-1}\) strong、contracting \(R\)，四 regularities。Sharp strong \(\mu\)，coco \(\mu/(\mu^2+\omega^2)\)，regularity modulus \((\mu^2+\omega^2)^{-1/2}\)。
- **13–14：** \(\langle a,b\rangle=\mu\|a\|^2=\mu\|b\|^2/(\mu^2+\omega^2)\)；\(\|R\|=\sqrt{((1-\lambda\mu)^2+(\lambda\omega)^2)/D_+}<1\)。Subunit global RL 仍因非零线性 \(R\) 失败。
- **Scope / vacuity / C audit：** 全局、孤立、非 vacuous；作为 GX-004 正曲率对照。

### GX-006 — singular PSD diagonal / projection residual

- **Origin IDs / evidence：** LC-06；SVG-11 与 MGB-12 是 \(c=1\)；`ALG-CHECKED`。
- **1–4：** \(H=\mathbb R^2\)，\(F(x_1,x_2)=(0,cx_2)\), \(c>0\)，single-valued；graph of \(\operatorname{diag}(0,c)\)。
- **5–8：** \(S=\mathbb R\times\{0\}\)；\(F^{-1}(0,y_2)=\mathbb R\times\{y_2/c\}\)，若 \(y_1\ne0\) 则空；\(J=\operatorname{diag}(1,(1+\lambda c)^{-1})\)，\(R=\operatorname{diag}(1,(1-\lambda c)/(1+\lambda c))\)。
- **9–12：** coco-not-strong；paramonotone+rectangular control；MSR not MR/SMSR。Sharp coco \(1/c\)，MSR \(1/c\)，global RL\(_1\) sharp 1。非 strong、MR、SMSR、SMR、global subunit RL。
- **13–14：** \(\langle a,b\rangle=ca_2^2=c^{-1}\|b\|^2\)，\(d(x,S)=|x_2|=c^{-1}\|F(x)\|\)。任意 \(\lambda>0\)。
- **Scope / vacuity / C audit：** 全局；非孤立但 EB 非 vacuous。C 复核 rectangularity只在 max monotone universe 内引用。

### GX-007 — nilpotent shear

- **Origin IDs / evidence：** LC-07；`ALG-CHECKED`。
- **1–4：** \(H=\mathbb R^2\)，\(N=\bigl(\begin{smallmatrix}0&1\\0&0\end{smallmatrix}\bigr)\)，\(F(x)=Nx\)，linear single-valued。
- **5–8：** \(S=\mathbb R\times\{0\}\)；\(F^{-1}(y_1,0)=\mathbb R\times\{y_1\}\)，else empty；\(J=I-\lambda N\)，\(R=I-2\lambda N\)。
- **9–12：** finite hypo but no finite signed comonotone lower modulus；MSR only。Sharp hypo \(1/2\)，MSR 1，RL\(_1\) constant \(\sqrt{1+\lambda^2}+\lambda\)。非 MR/SMSR/SMR/coco/cohypo。
- **13–14：** 对 \(a=(p,q)\)，\(b=(q,0)\)，\(\langle a,b\rangle=pq\ge-\|a\|^2/2\)，而 \(pq/q^2=p/q\) 无下界。任意 \(\lambda>0\)。
- **Scope / vacuity / C audit：** 全局，零集非孤立，EB 非 vacuous；C 检查 exact shear norm。

### GX-008 — indefinite diagonal bijection

- **Origin IDs / evidence：** LC-08；`ALG-CHECKED`。
- **1–4：** \(H=\mathbb R^2\)，\(F=\operatorname{diag}(-c,d)\), \(c,d>0\)，linear bijection。
- **5–8：** \(S=\{0\}\)，inverse \(\operatorname{diag}(-1/c,1/d)\)；当 \(\lambda\ne1/c\)，\(J=\operatorname{diag}((1-\lambda c)^{-1},(1+\lambda d)^{-1})\)，\(R\) 对角元为 \((1+\lambda c)/(1-\lambda c)\) 与 \((1-\lambda d)/(1+\lambda d)\)。
- **9–12：** nonmonotone + SMR/MR/SMSR/MSR；\(\lambda c>2\) 可有 \(J\) contraction。Sharp hypo \(c\)，signed comonotone \(-1/c\)，regularity modulus \(1/\min\{c,d\}\)。
- **13–14：** \(\langle a,b\rangle=-ca_1^2+da_2^2\)。非奇异 step 仅 global RL\(_1\)；奇异 step所有 RL 失败。
- **Scope / vacuity / C audit：** 全局、孤立、非 vacuous；C 比较 \(J\)-contraction 与 graph curvature。

### GX-009 — \(\ell^2\) compact positive diagonal

- **Origin IDs / evidence：** LC-09；`ALG-CHECKED`。
- **1–4：** \(H=\ell^2\)，\((Fx)_n=x_n/n\)，bounded single-valued；full graph。
- **5–8：** \(S=\{0\}\)；\(F^{-1}y=(ny_n)\) on nonclosed \(\operatorname{ran}F\)；\((Jx)_n=n x_n/(n+\lambda)\)，\((Rx)_n=(n-\lambda)x_n/(n+\lambda)\)。
- **9–12：** maximal+coco but no power MSR。Sharp coco 1，strong modulus 0，RL\(_1\) sharp 1。MR/MSR/SMSR/SMR 及所有 power-\(q\) SMSR 均失败。
- **13–14：** \(\langle a,b\rangle=\sum|a_n|^2/n\ge\sum|a_n|^2/n^2=\|b\|^2\)；用 \(x=t e_n\) 使任意 power ratio 发散。任意 \(\lambda>0\)。
- **Scope / vacuity / C audit：** 全局、isolated zero、非 vacuous；对每个有限 \(n\)，\(|(n-\lambda)/(n+\lambda)|<1\)，所以 \(\|R\|=1\) 只来自 \(n\to\infty\) 的 tail supremum。C 必须保留 infinite-dimensional/nonclosed-range 机制。

### GX-010 — shifted half-line normal \(\mu I+N_{[0,\infty)}\)

- **Origin IDs / evidence：** LC-10 = SVG-07；`ALG-CHECKED`。
- **1–4：** \(H=\mathbb R\)，\(F(x)=\mu x\) for \(x>0\)，\(F(0)=(-\infty,0]\)，off \([0,\infty)\) empty；set-valued。
- **5–8：** \(S=\{0\}\)，\(F^{-1}(y)=\mu^{-1}y_+\)；\(J(p)=p_+/(1+\lambda\mu)\)，\(R(p)=-p\) for \(p\le0\)，and \(((1-\lambda\mu)/(1+\lambda\mu))p\) for \(p\ge0\)。
- **9–12：** maximally strong but not coco；all four regularities exact \(1/\mu\)；\(J\) contracts but \(R\) does not. Sharp strong \(\mu\)，RL\(_1\) 1。
- **13–14：** normal monotonicity给 \(\langle a,b\rangle\ge\mu|a|^2\)；same-input distinct normals否定 positive coco。\(\lambda,\mu>0\)。
- **Scope / vacuity / C audit：** 全局 regularity；isolated zero。一侧 empty-domain，但 sharp modulus由 \(x\downarrow0^+\) 达到，非纯 vacuity。

### GX-011 — positive-part map

- **Origin IDs / evidence：** LC-11；`ALG-CHECKED`。
- **1–4：** \(H=\mathbb R\)，\(F(x)=x_+\)，single-valued；graph 为 negative horizontal ray 与 positive identity ray。
- **5–8：** \(S=(-\infty,0]\)；\(F^{-1}(y)=\{y\}\) for \(y>0\)，\(( -\infty,0]\) for \(y=0\)，negative targets empty；对任意 \(\lambda>0\)，
  \[
  J_{\lambda F}(p)=\begin{cases}p,&p\le0,\\p/(1+\lambda),&p\ge0,\end{cases}
  \qquad
  R_{\lambda F}(p)=\begin{cases}p,&p\le0,\\ \dfrac{1-\lambda}{1+\lambda}p,&p\ge0.\end{cases}
  \]
- **9–12：** coco-not-strong；MSR not MR/SMSR。Sharp coco 1，global MSR 1，RL\(_1\) 1。非 strong、MR/SMSR/SMR、global subunit RL。
- **13–14：** \((x-y)(x_+-y_+)\ge|x_+-y_+|^2\)，且 \(d(x,S)=x_+=|F(x)|\)。任意 \(\lambda>0\)。
- **Scope / vacuity / C audit：** 全局，boundary EB nonvacuous，zero nonisolated。

### GX-012 — half-line normal \(N_{[0,\infty)}\)

- **Origin IDs / evidence：** LC-12 = SVG-01/02；`ALG-CHECKED`。
- **1–4：** \(F(x)=0\) for \(x>0\)，\(F(0)=(-\infty,0]\)，else empty；set-valued convex normal graph。
- **5–8：** \(S=[0,\infty)\)；inverse：\(\{0\}\) for \(y<0\)，\([0,\infty)\) for \(y=0\)，empty for \(y>0\)；\(J=P_{[0,\infty)}\)，\(R=|\cdot|\)。
- **9–12：** max cyclic/max monotone, not strong/coco；RL\(_1\) sharp 1。At \((0,0)\)：MSR modulus 0 but no MR/SMSR/SMR；at \((0,-1)\)：SMR/MR/SMSR/MSR all with infimal modulus 0。
- **13–14：** \(\langle a,b\rangle\ge0\)，horizontal/vertical branches给 strictness failures；任意 \(\lambda>0\)。
- **Scope / vacuity / C audit：** operator global；regularity **reference-dependent**。At target 0: domain-vacuous + nonisolated；at target \(-1\): branch pinning. C 必须分开两参考点。

### GX-013 — restricted positive slope

- **Origin IDs / evidence：** LC-13 = SVG-08；`ALG-CHECKED`。
- **1–4：** \(F(x)=\mu x\) for \(x\ge0\)，else empty；single-valued on proper domain，graph ray。
- **5–8：** \(S=\{0\}\)；inverse \(y/\mu\) for \(y\ge0\), else empty；natural \(D_\lambda=[0,\infty)\)，\(J=p/(1+\lambda\mu)\)，\(R=((1-\lambda\mu)/(1+\lambda\mu))p\)。
- **9–12：** strong not maximal；SMSR/MSR but not MR/SMR。Sharp strong \(\mu\)，coco \(1/\mu\)，SMSR \(1/\mu\)，natural-domain RL\(_1\) as displayed。
- **13–14：** \(\langle a,b\rangle=\mu a^2\)；negative nearby targets prove coverage failure。\(\mu,\lambda>0\)，tuned step gives \(R=0\)。
- **Scope / vacuity / C audit：** local regularity at boundary，isolated; empty negative side does not determine sharp SMSR。

### GX-014 — restricted zero graph

- **Origin IDs / evidence：** LC-14；`ALG-CHECKED`。
- **1–4：** \(F(x)=0\) for \(|x|\le1\)，else empty；single-valued on bounded domain；graph \([-1,1]\times\{0\}\)。
- **5–8：** \(S=[-1,1]\)；inverse only nonempty at 0；\(D_\lambda=[-1,1]\)，\(J=R=I\) on \(D_\lambda\)。
- **9–12：** nonmax+nonstrong；bounded RL\(_1\)+RL\(_\gamma\) inherited；MSR exact 0, no MR/SMSR/SMR。
- **13–14：** \(\langle a,b\rangle=0\)，\(L_\gamma^*=2^{1-\gamma}\) by endpoint gap。Any \(\lambda>0,0<\gamma<1\)。
- **Scope / vacuity / C audit：** bounded natural domain；MSR **domain-vacuous + big solution set**，subunit exponent not genuine。

### GX-015 — pure power-Hölder Cayley graph

- **Origin IDs / evidence：** LC-15 = EX-11；AR-01 是 bounded restriction；`ALG-CHECKED`。
- **1–4：** \(H=\mathbb R\)，\(0<\alpha<1\)，\(P_\alpha(s)=\operatorname{sgn}(s)|s|^\alpha\)，\(u=(s+P_\alpha s)/2\)，\(v=(s-P_\alpha s)/(2\lambda_0)\)；\(u(s)\) homeomorphism，故生成 single-valued full-domain \(F\)；graph 为该曲线。
- **5–8：** \(S=\{-1,0,1\}\)；\(F^{-1}(y)=\{u(s):v(s)=y\}\)；\(J_{\lambda_0F}(s)=u(s)\)，\(R_{\lambda_0F}=P_\alpha\)。
- **9–12：** genuine global RL\(_\alpha\) not RL\(_1\)，但在每个 zero local SMR/MR/SMSR/MSR。RL sharp \(L=2^{1-\alpha}\)；at 0 exact regularity modulus \(\lambda_0\)，at \(\pm1\) 为 \(\lambda_0(1+\alpha)/(1-\alpha)\)。
- **13–14：** \(\langle a,b\rangle=(|\Delta s|^2-|\Delta P|^2)/(4\lambda_0)\)；larger exponent fails at 0, smaller at infinity。\(\lambda_0>0\)。
- **Scope / vacuity / post-C：** regularity local and branch-specific，zeros isolated locally。令 θ=η/λ₀：η<λ₀ 时只有 global RL\(_1\)，sharp \((1+θ)/(1-θ)\)；η=λ₀ 时唯一 global exponent 为 \(α\)，sharp \(2^{1-α}\)；η>λ₀ 时 Minty folds 使 all-pairs RL 全部失败（`VERIFIED-ALG`）。

### GX-016 — tanh-Cayley

- **Origin IDs / evidence：** LC-16 = EX-13；`ALG-CHECKED`。
- **1–4：** \(u(s)=(s+\tanh s)/2\)，\(v(s)=(s-\tanh s)/(2\lambda_0)\)，生成 full-domain single-valued \(F\)。
- **5–8：** \(S=\{0\}\)；inverse 由唯一方程 \(s-\tanh s=2\lambda_0y\)；\(J=u\)，\(R=\tanh\)。
- **9–12：** RL\(_1\) 与所有 subunit RL，但 ordinary MSR/MR/SMSR/SMR 全失败；max monotone，coco \(\lambda_0\)（按 scaling）。Sharp fixed-target \(q_*=1/3\)，modulus \((6\lambda_0)^{1/3}\)。
- **13–14：** \(u(s)=s-s^3/6+O(s^5)\)，\(v(s)=s^3/(6\lambda_0)+O(s^5)\)；\(|\tanh s-\tanh t|\le\min\{|s-t|,2\}\)。
- **Scope / vacuity / post-C：** isolated, nonvacuous。Generating step \(η=λ_0\) 有所有 subunit exponents，且仅由 bounded range + Lipschitz 继承；每个 \(η\neλ_0\) 只有 global RL\(_1\)，sharp constant 1。Fixed-target \(q=1/3\) modulus 为 \((6λ_0)^{1/3}\)，two-variable modulus 为 \((24λ_0)^{1/3}\)（`VERIFIED-ALG`）。

### GX-017 — rational bounded Cayley

- **Origin IDs / evidence：** LC-17；`ALG-CHECKED`。
- **1–4：** \(R(s)=s/(1+s^2)\)，\(u=(s+R(s))/2\)，\(v=(s-R(s))/2\)；\(u\) strictly increasing onto，故 \(F\) full-domain single-valued。
- **5–8：** \(S=\{0\}\)；inverse由 \(s^3/[2(1+s^2)]=y\) 唯一解；\(J=u,R_F=R\)。
- **9–12：** all RL exponents + no ordinary MSR；max monotone, sharp coco \(7/9\)。Power \(q_*=1/3\)，SMSR modulus \(2^{1/3}\)。
- **13–14：** \(R'\in[-1/8,1]\)，\(|R(s)-R(t)|\le\min\{|s-t|,1\}\)；\(u=s-s^3/2+O(s^5),v=s^3/2+O(s^5)\)。
- **Scope / vacuity / post-C：** global，isolated，nonvacuous；subunit exponents inherited。At step 1，two-variable \(q=1/3\) modulus 为 2，且
  \[
  L_\gamma^*=2^{-\gamma}(1+\gamma)^{(1+\gamma)/2}(1-\gamma)^{(1-\gamma)/2}
  \quad(0<\gamma<1).
  \]
  At every other step，nonzero linear tails 排除 global subunit exponents，而 RL\(_1\) sharp 1（`VERIFIED-ALG`）。

### GX-018 — cubic Cayley relation \(R(s)=s-s^3\)

- **Origin IDs / evidence：** LC-18；`ALG-CHECKED`。
- **1–4：** \(u=s-s^3/2\)，\(v=s^3/2\)；因 \(u\) 非 injective，\(F\) set-valued，domain \(\mathbb R\)，graph 为参数曲线。
- **5–8：** \(S=\{0\}\)；\(F^{-1}(y)=\sqrt[3]{2y}-y\) single-valued；\(J(s)=u(s)\)，\(R(s)=s-s^3\)。
- **9–12：** no global RL of any exponent；local RL\(_1\)；no ordinary MSR/MR/SMSR/SMR；sharp signed comonotone lower coefficient \(-1\)，无 finite hypo。Power \(q_*=1/3\)。
- **13–14：** 令 \(q=s^2+st+t^2\)，\(a=(1-q/2)(s-t),b=(q/2)(s-t)\)，所以 \(ab=q(2-q)(s-t)^2/4\)。On \(|s|\le\delta\le\sqrt{2/3}\)，local \(\operatorname{Lip}R=1\)。
- **Scope / vacuity / post-C：** isolated/nonvacuous。For \(η<1\) Minty folds/collisions 使 all-pairs RL 失败；\(η=1\) 无 global exponent，但 near zero 有 local RL\(_1\)；\(η>1\) 有 global RL\(_1\) sharp \((η+1)/(η-1)\)，且无 global subunit exponent。Fixed-target \(q=1/3\) modulus 为 \(2^{1/3}\)，two-variable modulus 为 2（`VERIFIED-ALG`）。

### GX-019 — bounded dilation \(R=2I\)

- **Origin IDs / evidence：** LC-19；`ALG-CHECKED`。
- **1–4：** Minty domain \([-1,1]\)，\(u=3s/2,v=-s/2\)，即 \(F(x)=-x/3\) on \(|x|\le3/2\)，else empty；single-valued on domain。
- **5–8：** \(S=\{0\}\)；inverse \(-3y\) for \(|y|\le1/2\)；\(J(s)=3s/2,R(s)=2s\)。
- **9–12：** nonmonotone but local SMR/MR/SMSR/MSR exact 3；bounded RL\(_1\) and every subunit exponent。Nonmaximal, sharp hypo \(1/3\)，cohypo 3。
- **13–14：** \(\langle a,b\rangle=-|a|^2/3=-3|b|^2\)；\(L_\gamma^*=2^{2-\gamma}\) on diameter 2。
- **Scope / vacuity / post-C：** RL only on bounded natural domain；regularity local at interior zero, nonvacuous。At step \(λ\ne3\)，bounded-domain sharp constant is \((3+λ)|3-λ|^{-\gamma}\)；at \(λ=3\) a Minty collision destroys every all-pairs RL estimate。Do not call the bounded-domain subunit exponent genuine（`VERIFIED-ALG`）。

### GX-020 — clipped Cayley residual \(I-P_{[-1,1]}\)

- **Origin IDs / evidence：** LC-20；`ALG-CHECKED`。
- **1–4：** \(F(x)=x-P_{[-1,1]}x\)，single-valued full-domain；three affine graph pieces。
- **5–8：** \(S=[-1,1]\)；inverse is \(-1+y\) for \(y<0\), interval at 0, \(1+y\) for \(y>0\)；at the generating step \(\lambda=1\), \(J=(I+P_{[-1,1]})/2\) and \(R=P_{[-1,1]}\)。
- **9–12：** all RL exponents + exact MSR but not MR/SMSR/SMR。Sharp coco 1；global MSR 1；RL\(_1\) 1 and \(L_\gamma^*=2^{1-\gamma}\)。
- **13–14：** \(\langle a,b\rangle\ge|b|^2\)，\(d(x,S)=|F(x)|\)，and max output gap of clip is \(\min\{d,2\}\)。
- **Scope / vacuity / post-C：** global nontrivial EB；zero nonisolated。At interior zero local MSR infimum 0，at boundary exact 1。Every step has RL\(_1\) sharp 1；global subunit exponents occur only at \(λ=1\)，with \(L_\gamma^*=2^{1-\gamma}\)（`VERIFIED-ALG`）。

---

## 3. Scalar nonlinear、power 与 gauge master records

### GX-021 — cubic power \(F(x)=x^3\)

- **Origin IDs / evidence：** LC-21 = EX-01 = SVG-04 = RM-02；CP-05 的 \(p=3\) instance；`ALG-CHECKED`。
- **1–4：** \(H=\mathbb R\)，continuous single-valued full-domain；graph \(\{(x,x^3)\}\)。
- **5–8：** \(S=\{0\}\)，\(F^{-1}(y)=\sqrt[3]y\)；\(J_{\lambda F}(p)\) 是 \(u+\lambda u^3=p\) 的唯一根，\(R=2J-I\)。
- **9–12：** maximal cyclic/strict monotone + RL\(_1\)，但 ordinary MR/MSR/SMSR/SMR 均失败。Sharp fixed-target \(q_*=1/3\)，modulus 1；global RL\(_1\) sharp 1；非 strong，非 global positive coco。
- **13–14：** \(ab=(x-y)^2(x^2+xy+y^2)\ge0\)，\(d(x,S)=|F(x)|^{1/3}\)，且 \(R'(p)=(1-3\lambda u^2)/(1+3\lambda u^2)\)。任意 \(\lambda>0\)。
- **Scope / vacuity / C audit：** global graph/RL，local regularity at isolated zero，nonvacuous。C 复核 inverse global \(1/3\)-Hölder sharp constant \(2^{2/3}\)。

### GX-022 — signed square-root power

- **Origin IDs / evidence：** EX-02；`ALG-CHECKED`。
- **1–4：** \(F(x)=\operatorname{sgn}(x)\sqrt{|x|}\) on \(\mathbb R\)，continuous single-valued。
- **5–8：** \(S=\{0\}\)，\(F^{-1}(y)=\operatorname{sgn}(y)|y|^2\)；若 \(s(p)=(\sqrt{\lambda^2+4|p|}-\lambda)/2\)，则 \(J(p)=\operatorname{sgn}(p)s(p)^2\)，\(R=2J-I\)。
- **9–12：** max monotone/RL\(_1\) + SMR/MR/SMSR/MSR，yet no local coco at 0。Fixed-target largest exponent \(q_*=2\)，endpoint modulus 1；linear exact regularity modulus 0。
- **13–14：** exact \(|x|=|F(x)|^2\)；monotonicity gives \(\operatorname{Lip}R=1\)，large scale excludes global subunit RL。\(\lambda>0\)。
- **Scope / vacuity / C audit：** isolated, nonvacuous；\(q>1\) is fixed-target only，not two-variable \(q\)-MR。C 复核 “modulus 0” convention。

### GX-023 — flat exponential

- **Origin IDs / evidence：** EX-03；`ALG-CHECKED`。
- **1–4：** \(F(0)=0\)，\(F(x)=\operatorname{sgn}(x)e^{-1/|x|}\) for \(x\ne0\)；continuous increasing single-valued，range \((-1,1)\)。
- **5–8：** \(S=\{0\}\)；\(F^{-1}(y)=\operatorname{sgn}(y)/\log(1/|y|)\) for \(0<|y|<1\)；\(J\) is the unique root \(u+\lambda F(u)=p\)，\(R=2J-I\)。
- **9–12：** max monotone, sharp coco \(e^2/4\), RL\(_1\) sharp 1；no positive power MSR/SMSR, MR or SMR。Exact logarithmic gauge \(\phi(r)=1/\log(1/r)\)。
- **13–14：** \(F'\) has global maximum \(4e^{-2}\)，but tends to 0 at zero；\(|x|=\phi(|F(x)|)\)。Any \(\lambda>0\)。
- **Scope / vacuity / C audit：** local gauge at isolated zero，nonvacuous；C 复核 gauge domain cutoff and inverse-side gauge calmness。

### GX-024 — inverse-log cusp

- **Origin IDs / evidence：** EX-04；`ALG-CHECKED`。
- **1–4：** \(F(0)=0\)，\(F(x)=\operatorname{sgn}(x)/\log(e+1/|x|)\)；continuous strictly increasing single-valued，range \((-1,1)\)。
- **5–8：** \(S=\{0\}\)；\(F^{-1}(y)=\operatorname{sgn}(y)/(e^{1/|y|}-e)\)；\(J\) implicit unique，\(R=2J-I\)。
- **9–12：** max monotone/RL\(_1\) and SMR/MR；fixed-target \(q\)-SMSR for every finite \(q>0\), exact point modulus 0。No local coco at zero；two-variable \(q>1\)-MR fails for nonconstant inverse localization。
- **13–14：** \(|x|=(e^{1/r}-e)^{-1}=o(r^q)\) for all finite \(q\)。Any \(\lambda>0\)。
- **Scope / vacuity / C audit：** isolated/nonvacuous；C separates fixed-target super-power flatness from pairwise inverse Hölder order。

### GX-025 — oscillating gauge \(F_+\)

- **Origin IDs / evidence：** EX-05；`ALG-CHECKED`。
- **1–4：** Fix \(0<c<1/\sqrt2\). For \(t\le e^{-1}\), \(s=\log(1/t)\), \(A(s)=cs\sin(\log s)\), \(\phi_+(t)=e^{-s-A(s)}\), extended increasingly; \(F_+(x)=\operatorname{sgn}(x)\phi_+^{-1}(|x|)\)。Odd single-valued homeomorphism。
- **5–8：** \(S=\{0\}\)，\(F_+^{-1}(y)=\operatorname{sgn}(y)\phi_+(|y|)\)；\(J\) implicit unique，\(R=2J-I\)。
- **9–12：** max monotone/RL\(_1\)；exact \(\phi_+\)-SMSR but not \(\phi_-\)-SMSR；ordinary MSR/SMSR/MR/SMR fail。Sharp largest power exponent \(q_*=1-c\)。
- **13–14：** exact \(|x|=\phi_+(|F_+(x)|)\)；ratio \(\phi_+/\phi_-\) has liminf 0 and limsup \(\infty\)。
- **Scope / vacuity / post-C：** isolated/nonvacuous；`C-DISAGREE/VERIFIED-ALG`。All steps have RL\(_1\) sharp 1。For \(λ\ne1\)，nonzero linear tails kill every global subunit exponent；at the tuned step \(λ=1\)，the tails cancel and all \(0<\gamma<1\) hold globally by Lipschitz-plus-bounded-range inheritance。The optimal tuned-step \(L_\gamma\) remains `UNKNOWN`。Fixed and two-variable maximal power exponent are both \(1-c\)；fixed modulus is 1，while the exact pairwise endpoint modulus \(K_+\) remains `UNKNOWN` within the proved C bounds。

### GX-026 — oscillating gauge \(F_-\)

- **Origin IDs / evidence：** EX-06；`ALG-CHECKED`。
- **1–4：** Same \(c,A\) as GX-025, but \(\phi_-(t)=e^{-s+A(s)}\) near zero and \(F_-(x)=\operatorname{sgn}(x)\phi_-^{-1}(|x|)\)；single-valued odd homeomorphism。
- **5–8：** \(S=\{0\}\)，inverse \(\operatorname{sgn}(y)\phi_-(|y|)\)；implicit \(J\), \(R=2J-I\)。
- **9–12：** exact \(\phi_-\)-SMSR but not \(\phi_+\)-SMSR；same max monotone/RL\(_1\) and same power signature \(q_*=1-c\) as GX-025；no ordinary linear regularity。
- **13–14：** \(|x|=\phi_-(|F_-(x)|)\) and oscillatory ratio gives gauge incomparability。
- **Scope / vacuity / post-C：** isolated/nonvacuous；`C-DISAGREE/VERIFIED-ALG`。All steps have RL\(_1\) sharp 1。For \(λ\ne1\)，nonzero linear tails kill every global subunit exponent；at \(λ=1\)，tail cancellation yields all \(0<\gamma<1\) globally by inheritance。The optimal tuned-step \(L_\gamma\) remains `UNKNOWN`。Fixed and two-variable maximal power exponent are both \(1-c\)；fixed modulus is 1，while the exact pairwise endpoint modulus \(K_-\) remains `UNKNOWN` within the proved C bounds。GX-025/026 remain two distinct cards。

### GX-027 — asymmetric mixed powers

- **Origin IDs / evidence：** EX-07；`ALG-CHECKED`。
- **1–4：** \(F(x)=x^2\) for \(x\ge0\), \(-\sqrt{-x}\) for \(x<0\)；continuous increasing single-valued homeomorphism。
- **5–8：** \(S=\{0\}\)，\(F^{-1}(y)=\sqrt y\) for \(y\ge0\), \(-y^2\) for \(y<0\)；\(J\) unique implicit root，\(R=2J-I\)。
- **9–12：** max monotone/global RL\(_1\)，but neither local strong nor local coco on a two-sided window；linear MR/MSR/SMSR/SMR fail。Sharp fixed-target \(q_*=1/2\)。
- **13–14：** positive side \(|x|=|F(x)|^{1/2}\)，negative side exponent 2；worst branch controls。
- **Scope / vacuity / C audit：** local at isolated zero，nonvacuous；C checks exact two-sided modulus 1 and no illegal averaging of one-sided orders。

### GX-028 — even polynomial \(F(x)=x^2\) on \(\mathbb R\)

- **Origin IDs / evidence：** EX-08；`ALG-CHECKED`。
- **1–4：** continuous single-valued full-domain; graph parabola。
- **5–8：** \(S=\{0\}\)，\(F^{-1}(y)=\{\pm\sqrt y\}\) for \(y\ge0\), else empty；full \(J_{\lambda F}\) is the root relation of \(\lambda u^2+u=p\)，and \(R=2J-I\)。
- **9–12：** local finite hypo/LT on \(|u|\le\delta<1/(2\lambda)\)，but globally no all-graph RL；sharp \(q_*=1/2\), no ordinary MR/MSR/SMSR/SMR/HREG。
- **13–14：** local sharp hypo \(2\delta\)，RL\(_1\) \((1+2\lambda\delta)/(1-2\lambda\delta)\)；exact \(|x|=|F(x)|^{1/2}\)。
- **Scope / vacuity / C audit：** local restricted branch versus global relation must remain separate；isolated/nonvacuous。

### GX-029 — nonisolated cubic cylinder

- **Origin IDs / evidence：** EX-09；`ALG-CHECKED`。
- **1–4：** \(F(x,z)=(x^3,0):\mathbb R^2\to\mathbb R^2\)，single-valued full-domain。
- **5–8：** \(S=\{0\}\times\mathbb R\)；inverse \(\{(\sqrt[3]{y_1},z):z\in\mathbb R\}\) if \(y_2=0\), else empty；\(J=(J_{\lambda x^3},I)\)，\(R=(R_{\lambda x^3},I)\)。
- **9–12：** max monotone/RL\(_1\)，nontrivial \(q=1/3\)-MSR but no SMSR/MR/SMR。No global subunit RL。
- **13–14：** \(d((x,z),S)=|x|=\|F(x,z)\|^{1/3}\) exactly。
- **Scope / vacuity / C audit：** global；zero nonisolated but MSR nonvacuous。C distinguishes lack of isolation from range noncoverage。

### GX-030 — critical Cayley cusp \(F(x)=x^3-x\)

- **Origin IDs / evidence：** EX-10；`ALG-CHECKED`。
- **1–4：** scalar continuous polynomial, single-valued full-domain；graph \((x,x^3-x)\)。
- **5–8：** \(S=\{-1,0,1\}\)，inverse is real-root set of \(x^3-x-y=0\)；Minty equation \(p=(1-\eta)u+\eta u^3\)，\(J\) its root relation，\(R=2J-I\)。
- **9–12：** sharp 1-hypomonotone. For \(0<\eta<1\), global RL\(_1\) constant \((1+\eta)/(1-\eta)\)；at \(\eta=1\), genuinely local RL\(_{1/3}\) but not Lipschitz；at \(\eta>1\), full RL fails。At each zero SMR/MR/SMSR/MSR with moduli 1 at 0 and \(1/2\) at \(\pm1\)。
- **13–14：** \(F'=3x^2-1\) and at critical step \(R(p)=2\sqrt[3]p-p\)，so exponent \(1/3\) is sharp at 0 but fails globally at infinity。
- **Scope / vacuity / post-C：** critical RL is bounded-window only；zeros locally isolated/nonvacuous。For \(η<1\)，global RL\(_1\) is \((1+η)/(1-η)\)；at \(η=1\)，the genuine local maximal exponent is \(1/3\) with sharp \(L=2^{5/3}\)，and no global exponent holds；for \(η>1\)，global collisions destroy RL, although a small zero branch still has local RL\(_1\)（`VERIFIED-ALG`）。

### GX-031 — clipped power Cayley

- **Origin IDs / evidence：** EX-12；`ALG-CHECKED`。
- **1–4：** \(C_\alpha(s)=\operatorname{sgn}(s)\min\{|s|^\alpha,1\}\), \(0<\alpha<1\)；\(u=(s+C_\alpha s)/2\)，\(v=(s-C_\alpha s)/(2\lambda_0)\) generate single-valued full-domain \(F_C\)。
- **5–8：** \(S=\{-1,0,1\}\)；inverse parameterized by \(v(s)=y\)；\(J=u,R=C_\alpha\)。
- **9–12：** global RL\(_\gamma\) for every \(0<\gamma\le\alpha\), no exponent \(>\alpha\)；sharp hypo \(1/\lambda_0\)；each zero locally SMR/SMSR, \(q_*=1\)。
- **13–14：** small gaps inherit the genuine \(\alpha\)-cusp, large gaps controlled by range diameter 2；at 0 regularity modulus \(\lambda_0\)，at \(\pm1\) \(\lambda_0(1+\alpha)/(1-\alpha)\)。
- **Scope / vacuity / C audit：** global RL, local regularity, isolated zeros。C separates genuinely maximal exponent \(\alpha\) from smaller exponents enabled by clipping。

### GX-032 — Luke–Tam restricted negative square root

- **Origin IDs / evidence：** MGB-01 = EX-14 after verifier correction；`P3-DIRECT` for object/\(U,W,\tau\), `P2-DERIVED` for sharpness and regularity calculations。Primary locator: Luke–Tam 2025, Example 2, (19)–(21)。
- **1–4：** \(F(x)=-\sqrt x\) for \(x\ge0\), catalog restriction \(U=[0,1/16]\), outputs restricted relative to \(W=\mathbb R\)；single-valued on domain；graph \((t^2,-t),0\le t\le1/4\)。
- **5–8：** \(S=\{0\}\)，inverse \(y^2\) for \(y\in[-1/4,0]\), else empty；at \(\lambda=1\), Minty \(p=t^2-t\in[-3/16,0]\)，\(J(p)=t^2\)，\(R(p)=t^2+t\)。
- **9–12：** LT-submonotone sharp \(\tau=2\), equivalently RL\(_1\) sharp \(L=3\), but no finite local hypo at 0；SMSR and every fixed-target \(q\le2\)，no MR/SMR due positive target noncoverage。
- **13–14：** \(ab=-(t-s)^2(t+s)=-a^2/(t+s)\) gives unbounded hypo quotient, while \(|\Delta R|/|\Delta p|=(1+t+s)/(1-t-s)\uparrow3\)。
- **Scope / vacuity / C audit：** restricted graph, isolated/nonvacuous；do not replace \(W\) by \(F(U)\), enlarge the domain, or cite Luke–Tam Proposition 4 at \(\tau=2\)。

### GX-033 — absolute-value map

- **Origin IDs / evidence：** EX-16 = SVG-14；also one ALG HREG separation seed；`ALG-CHECKED`。
- **1–4：** \(F(x)=|x|\) on \(\mathbb R\)，single-valued V-graph。
- **5–8：** \(S=\{0\}\)；inverse \(\{\pm y\}\) for \(y>0\), \(\{0\}\) at 0, empty for \(y<0\)；for \(0<\lambda<1\), \(J(p)=p/(1-\lambda)\) on \(p<0\), \(p/(1+\lambda)\) on \(p\ge0\)，and corresponding piecewise \(R\)。
- **9–12：** sharp 1-hypomonotone；SMSR/MSR exact 1 and inverse isolated calm；not MR/SMR/Aubin/HREG。For \(0<\lambda<1\), RL\(_1\) sharp \((1+\lambda)/(1-\lambda)\)；for \(\lambda\ge1\), Minty collisions kill all RL。
- **13–14：** residual identity \(d(x,S)=|F(x)|=|x|\)；negative branch attains hypo modulus。
- **Scope / vacuity / C audit：** global mapping/local regularity at isolated zero, nonvacuous；C checks the exact failure quantifier for HREG versus isolated calm。

### GX-034 — oscillatory coefficient \(x(2+\sin(1/x))\)

- **Origin IDs / evidence：** EX-17；`ALG-CHECKED`。
- **1–4：** \(F(0)=0\), \(F(x)=x(2+\sin(1/x))\) for \(x\ne0\)；continuous single-valued closed graph。
- **5–8：** \(S=\{0\}\)；inverse is the root set of the displayed oscillatory equation；\(J_{\eta F}\) parameterized by \(p=u[1+\eta(2+\sin(1/u))]\)，\(R=2J-I\) relation。
- **9–12：** graph-anchored \(A^{\mathrm{gph}}_1(0,0)\) + SMSR exact 1, but no local all-pairs RL of any exponent and no MR/SMR。No finite local hypo。由于 \(I+\eta F\) 在每个零邻域均非单射，这里不声称 map-pointwise \(P_1(0)\)。
- **13–14：** anchored ratio is bounded by \(\max\{|1-\eta|/(1+\eta),|1-3\eta|/(1+3\eta)\}<1\)；yet \(F'=2+\sin(1/x)-\cos(1/x)/x\) has alternating unbounded signs, so \(I+\eta F\) folds in every neighborhood。\(\eta>0\)。
- **Scope / vacuity / C audit：** anchored graph inequality only at the solution graph point；isolated/nonvacuous。除非另选 single-valued Cayley branch并打印量词，不套用 \(A_\gamma=P_\gamma\) 的 map-level 等价。C independently proves MR failure without assuming differentiability at 0。

### GX-035 — two-branch relation \(F(x)=\{-x,x\}\)

- **Origin IDs / evidence：** EX-18 = SVG-12；`P3-DIRECT` for CDK example and qualitative properties, `P2-DERIVED` for exact global identity/modulus。
- **1–4：** \(H=\mathbb R\)，set-valued union of the two lines \((x,\pm x)\)。
- **5–8：** \(S=\{0\}\)，\(F^{-1}=F\)；for \(\lambda\ne1\), \(J(p)=\{p/(1+\lambda),p/(1-\lambda)\}\)，\(R\) has two corresponding slopes；at \(\lambda=1\) negative branch collapses to input 0。
- **9–12：** MR + SMSR/MSR exact 1 but not SMR；no finite local hypo and no all-graph RL for any step。Inverse is both calm/Aubin as a multifunction but has no single-valued localization。
- **13–14：** exact identity \(d(x,F^{-1}(y))=\min\{|x-y|,|x+y|\}=d(y,F(x))\)；cross-branch \(x=t,y=t+t^2\) makes hypo quotient \(-\infty\)。
- **Scope / vacuity / C audit：** global MR identity, isolated/nonvacuous；C must not import the differentiable single-valued theorem MR+SMSR\(\Rightarrow\)SMR。

### GX-036 — vertical slab multifunction

- **Origin IDs / evidence：** EX-20；also inverse-side constant-interval seed；`ALG-CHECKED`。
- **1–4：** \(F(x)=\mathbb R\) for \(|x|\le1\), empty otherwise；set-valued，graph \([-1,1]\times\mathbb R\)。
- **5–8：** \(S=[-1,1]\)，\(F^{-1}(y)=[-1,1]\) for every \(y\)；\(J_{\lambda F}(p)=[-1,1]\)，\(R(p)=2[-1,1]-p\)。
- **9–12：** MR/MSR exact 0 and inverse Aubin/calm modulus 0, but no SMSR/SMR/isolated calm；no finite local hypo or RL。
- **13–14：** choose \(b=-a/\lambda\ne0\) for Minty collision; choose \(a=\varepsilon^2,b=-\varepsilon\) for hypo quotient divergence。
- **Scope / vacuity / C audit：** local reference \((0,0)\) inside slab；zero nonisolated，MSR is vacuous in the sense all local points are solutions, while MR is genuine target-uniform zero distance。

### GX-037 — inverse oscillation \(F=(y\sin(1/y))^{-1}\)

- **Origin IDs / evidence：** EX-21；`ALG-CHECKED` for the B object，`VERIFIED-ALG` for the post-C Hölder endpoint/modulus。
- **1–4：** \(G(0)=0,G(y)=y\sin(1/y)\), \(F=G^{-1}\) set-valued；graph parameterized by \((G(y),y)\)。
- **5–8：** \(S=\{0\}\)，\(F^{-1}=G\)；Minty parameter \(p=y(\lambda+\sin(1/y))\)，\(J(p)=y\sin(1/y)\)，\(R(p)=y(\sin(1/y)-\lambda)\) as relation。
- **9–12：** inverse isolated calm/calm exact 1 and F SMSR/MSR exact 1, but inverse not Aubin, so no MR/SMR；no local all-graph RL。
- **13–14：** \(|G(y)|\le|y|\) implies \(|x|\le d(0,F(x))\), equality along \(\sin(1/y)=\pm1\)；unbounded \(G'\) and Minty folds disprove Aubin/RL。
- **Scope / vacuity / post-C：** isolated/nonvacuous。Besides failure of ordinary Aubin/MR/SMR, the single-valued inverse localization \(G\) is locally \(1/2\)-Hölder, so \(F\) has \(q=1/2\) metric regularity and a Hölder strong-MR localization。Its exact Hölder-Aubin modulus is the \(K^*\) printed in the post-C overlay（`VERIFIED-ALG`）；HREG is exact 1 while UHREG fails。

### GX-038 — sparse vertical fibers plus square curve

- **Origin IDs / evidence：** EX-22；`ALG-CHECKED`。
- **1–4：** \(K=\{0\}\cup\{1/n:n\in\mathbb N_+\}\)，其中 \(\mathbb N_+=\{1,2,\ldots\}\)；\(F(x)=\mathbb R\) for \(x\in K\), else \(F(x)=\{\operatorname{sgn}(x)x^2\}\)；closed set-valued graph \((K\times\mathbb R)\cup\) square curve。
- **5–8：** \(S=K\)；\(F^{-1}(y)=K\cup\{\operatorname{sgn}(y)\sqrt{|y|}\}\)；every \(J(p)\) contains candidates in \(K\)，so \(J,R\) multivalued。
- **9–12：** neither Aubin nor isolated calm, no ordinary MSR/MR/SMSR/SMR, no finite hypo/RL；but sharp \(q=1/2\)-MSR modulus 1。
- **13–14：** \(d(x,K)\le|x|=d(0,F(x))^{1/2}\), equality for negative \(x\to0\)；vertical fibers give hypo quotient \(-\sqrt n\)。
- **Scope / vacuity / C audit：** nonisolated but fractional MSR nonvacuous；C checks graph closedness at all accumulation points。

### GX-039 — saturated identity

- **Origin IDs / evidence：** EX-23；`ALG-CHECKED`。
- **1–4：** \(F(x)=\operatorname{clip}(x,-1,1)\)，continuous single-valued full-domain。
- **5–8：** \(S=\{0\}\)；inverse is singleton for \(|y|<1\), half-lines at \(y=\pm1\), empty outside；\(J_{\lambda F}\) has slopes 1 on shifted tails and \((1+\lambda)^{-1}\) in center，\(R=2J-I\)。
- **9–12：** max monotone, sharp coco 1, global RL\(_1\) 1 but no global subunit RL；locally at 0 all four regularities exact 1。Global error bound fails due saturation。
- **13–14：** tail \(R(p)=p\mp2\lambda\) excludes subunit global estimates；near zero \(F=I\)。
- **Scope / vacuity / C audit：** local strong regularity versus weak global growth；isolated/nonvacuous。C keeps local/global labels separate。

---

## 4. Set-valued、normal-cone 与 set-regularity master records

### GX-040 — vertical normal \(N_{\{0\}}\)

- **Origin IDs / evidence：** SVG-06；RM-04 isolated variant；RM-07 primal map；`ALG-CHECKED`。
- **1–4：** \(H=\mathbb R\)，\(F(0)=\mathbb R\), \(F(x)=\varnothing\) for \(x\ne0\)；set-valued vertical graph \(\{0\}\times\mathbb R\)。
- **5–8：** \(S=\{0\}\)，\(F^{-1}(y)=\{0\}\) for all \(y\)；\(J\equiv0\)，\(R=-I\)。
- **9–12：** max cyclic/max monotone；formally \(\mu\)-strong for every \(\mu>0\), yet RL\(_1\) sharp 1；SMR/MR/SMSR/MSR all infimal modulus 0。
- **13–14：** every graph pair has \(a=0\), so primal strong inequality is vacuous；inverse is a constant singleton。Any \(\lambda>0\)。
- **Scope / vacuity / C audit：** inverse is the global constant singleton, hence MR/SMR/SMSR/MSR all have exact infimum 0；the fixed-target mapping-side inequalities are **GRAPH-VACUOUS + DOMAIN-VACUOUS** although the zero is isolated。C must exclude it from nonvacuous “both strong” phase counts and treat the three Origin IDs as one canonical operator。

### GX-041 — singleton graph

- **Origin IDs / evidence：** SVG-09；`ALG-CHECKED`。
- **1–4：** \(F(0)=\{0\}\), empty elsewhere；graph singleton，set-valued convention。
- **5–8：** \(S=\{0\}\)；inverse only nonempty at 0；natural Minty domain \(\{0\}\)，\(J(0)=R(0)=0\)，no full-domain resolvent。
- **9–12：** all pairwise monotonicity/strong/coco/RL labels hold vacuously; MSR/SMSR infimal modulus 0; not MR/SMR/maximal。
- **13–14：** there is only one graph pair; for \(x\ne0\), residual is \(+\infty\)。Any \(\lambda>0,\gamma\in(0,1]\)。
- **Scope / vacuity / C audit：** double stress test: **GRAPH-VACUOUS + DOMAIN-VACUOUS**；isolated solution。Never use as ordinary evidence for compensation。

### GX-042 — subspace normal \(N_L\)

- **Origin IDs / evidence：** SVG-10 = RM-04 (nonisolated projection instance)；`ALG-CHECKED`。
- **1–4：** \(H=\mathbb R^2\)，\(L=\mathbb R\times\{0\}\)，\(F=N_L\) with graph \(L\times L^\perp\)；set-valued。
- **5–8：** \(S=L\)；\(F^{-1}(y)=L\) for \(y\in L^\perp\), else empty；\(J=P_L\)，\(R=2P_L-I\) is orthogonal reflection。
- **9–12：** max cyclic/max monotone/RL\(_1\) exact 1，but no MR/SMSR/SMR；F-MSR exact 0。Algorithm residual \(I-P_L\) has the distinct nonvacuous identity \(d(x,L)=\|(I-P_L)x\|\)。
- **13–14：** for graph differences \(a\in L,b\in L^\perp\), \(\langle a,b\rangle=0\)。Any \(\lambda>0\)。
- **Scope / vacuity / C audit：** F-MSR is domain-vacuous + nonisolated; fixed-point residual EB is nonvacuous. C recomputes both residual coordinates separately。

### GX-043 — vertical-value multifunction

- **Origin IDs / evidence：** SVG-13；`ALG-CHECKED`。
- **1–4：** \(H=\mathbb R^2\)，\(F(x_1,x_2)=\{x_1\}\times\mathbb R\)；full-domain set-valued graph \(((x_1,x_2),(x_1,u_2))\)。
- **5–8：** \(S=\{0\}\times\mathbb R\)；\(F^{-1}(y_1,y_2)=\{y_1\}\times\mathbb R\)；\(J(p)=\{p_1/(1+\lambda)\}\times\mathbb R\)，\(R\) relation with an unrestricted second coordinate。
- **9–12：** global MR/MSR exact 1, but no SMSR/SMR；no finite local hypo and no all-pairs RL。
- **13–14：** exact \(d(x,F^{-1}(y))=|x_1-y_1|=d(y,F(x))\)；take \(a=(0,t^2),b=(0,-t)\) for hypo quotient \(-1/t\)。
- **Scope / vacuity / C audit：** target-uniform regularity genuine; zero nonisolated。C checks the product norm convention underlying exact modulus 1。

### GX-044 — zero/identity union \(F(x)=\{0,x\}\)

- **Origin IDs / evidence：** SVG-15；one verifier HREG seed；`ALG-CHECKED`。
- **1–4：** scalar set-valued graph \((\mathbb R\times\{0\})\cup\{(x,x)\}\)。
- **5–8：** \(S=\mathbb R\)；\(F^{-1}(0)=\mathbb R\)，\(F^{-1}(y)=\{y\}\) for \(y\ne0\)；\(J(p)=\{p,p/(1+\lambda)\}\)，\(R(p)=\{p,(1-\lambda)p/(1+\lambda)\}\)。
- **9–12：** MSR + HREG (both exact as in origins) but not MR/SMSR/SMR；no finite local hypo or RL。HREG exact 1，MSR exact 0。
- **13–14：** cross-branch \((t,t)\) versus \((t+t^2,0)\) yields hypo quotient \(-1/t\)；for MR, fix small \(x\ne0\) and let \(y\to0\) to make the metric ratio diverge。
- **Scope / vacuity / C audit：** MSR is big-solution-set triviality；HREG is nontrivial fixed-\(x\) coverage. C audits UHREG separately。

### GX-045 — unit-circle full normal

- **Origin IDs / evidence：** SVG-16 = MGB-20；`P3-DIRECT` for prox-regular truncation theorem, `P2-DERIVED` for circle formula/sharp constant。Primary: Poliquin–Rockafellar–Thibault 2000, Theorem 1.3(g), Corollary 2.2。
- **1–4：** \(H=\mathbb R^2\)，\(C=S^1\)，\(F=N_C\) with \(F(x)=\mathbb Rx\) for \(x\in C\), empty off C；set-valued full cone graph。
- **5–8：** \(S=C\)；\(F^{-1}(0)=C\)，\(F^{-1}(y)=\{\pm y/\|y\|\}\) for \(y\ne0\)；full \(J(p)\) has both antipodal points (and \(J(0)=C\))，so \(R\) relation is multivalued。
- **9–12：** C is prox-regular/reach 1, but full \(N_C\) has no finite local hypo and no RL；MSR exact 0, no MR/SMSR/SMR。Norm-truncated normal is locally hypo with infimal constant equal to truncation radius。
- **13–14：** for \(u=tx,v=sy\), \(\langle x-y,u-v\rangle=(t+s)\|x-y\|^2/2\)。Full graph: \(t=s=-M\to-\infty\). Open truncation \(|t|,|s|<r\): infimal modulus \(r\), approached; closed project truncation attains equality。
- **Scope / vacuity / post-C：** full versus localized/truncated graph is mandatory. At target 0: domain-vacuous/nonisolated MSR。For the norm-truncated graph \(|u^*|\le r_0\)，restricted RL\(_1\) is finite exactly when \(λ r_0<1\)，with sharp \((1+λ r_0)/(1-λ r_0)\)；the threshold/open-inner-radius blow-up must be retained。Optimal subunit constants on the truncated annulus remain `UNKNOWN`（`VERIFIED-ALG` for the RL\(_1\) statement）。

### GX-046 — limiting subgradient of \(-|x|\)（affine-shift family）

- **Origin IDs / evidence：** SVG-17；MGB-21 is the output-shifted map \(\partial(-|x|-x)\)，retained as a variant rather than a second count；`ALG-CHECKED` with prox-regular theorem boundary。
- **1–4：** Main representative \(f=-|x|\)，\(F=\partial f\): \(F(x)=\{1\}\) for \(x<0\), \(F(0)=\{-1,1\}\), \(F(x)=\{-1\}\) for \(x>0\)；set-valued closed graph。
- **5–8：** \(S=\varnothing\) for target 0；for target 1, \(F^{-1}(1)=(-\infty,0]\)。For \(-\lambda<p<\lambda\), full \(J_{\lambda F}\) has two affine-branch values, hence \(R\) multivalued。
- **9–12：** output-localized graph near \((0,1)\) is constant and monotone, but \(f\) is not prox-regular there; the untruncated full graph has no finite global RL and no finite hypo on any two-sided base neighborhood。At \((0,1)\), MSR infimal modulus 0 but no MR/SMSR/SMR。
- **13–14：** prox-support at \((0,1)\) would require \(-t\ge t-r t^2/2\), i.e. \(r\ge4/t\)。Affine-shift variant has outputs 0 and \(-2\), with pair \((\pm\varepsilon)\) giving hypo quotient \(-1/\varepsilon\)。
- **Scope / vacuity / post-C：** attentive graph neighborhood, two-sided base restriction, and untruncated full graph are different theorem objects。`C-DISAGREE-SCOPE/VERIFIED-ALG`：on the base window \(|x|\leδ<λ\)，the full two-branch graph has exact restricted RL\(_1\) constant \((λ+δ)/(λ-δ)\)；at \(δ\geλ\) a Minty collision appears。An output-attentive neighborhood of \((0,1)\) selects the constant branch。The untruncated graph still has no finite global RL。For target 1 the solution set is nonisolated and modulus 0 comes from a residual jump, not empty domain。The “hypo but not prox-regular” full-graph cell remains `PENDING` because only the attentive branch is hypo。

### GX-047 — transverse coordinate axes set mapping

- **Origin IDs / evidence：** SVG-18；`ALG-CHECKED`, set-mapping equivalence sourced to Kruger–Luke–Thao 2017。
- **1–4：** \(X=\mathbb R^2\)，\(A=\mathbb R e_1,B=\mathbb R e_2\)，\(\Phi(x)=(A-x)\times(B-x):X\rightrightarrows X^2\)，set-valued；graph by \(x+u\in A,x+v\in B\)。
- **5–8：** zero \(A\cap B=\{0\}\)；for \(u=(u_1,u_2),v=(v_1,v_2)\), \(\Phi^{-1}(u,v)=\{(-v_1,-u_2)\}\)。\(J,R\): N/A (domain/codomain type mismatch)。
- **9–12：** transversal + subtransversal；\(\Phi\) SMR/MR/SMSR/MSR all exact \(\sqrt2\) under output max norm。Individual normals are max cyclic。
- **13–14：** \(d(x,A\cap B)=\sqrt{x_1^2+x_2^2}\le\sqrt2\max\{|x_1|,|x_2|\}\)，equality on diagonal。
- **Scope / vacuity / C audit：** global, isolated, nonvacuous；C checks the norm-dependent modulus。

### GX-048 — identical lines set mapping

- **Origin IDs / evidence：** SVG-19；underlying strict witness `P3-DIRECT` from Kruger–Luke–Thao Examples 1–2, inverse/modulus `P2-DERIVED`。
- **1–4：** \(A=B=L=\mathbb R e_1\) in \(\mathbb R^2\)，\(\Phi(x)=(L-x)^2\)；set-valued。
- **5–8：** zero \(L\)；\(\Phi^{-1}(u,v)=\mathbb R\times\{-u_2\}\) when \(u_2=v_2\), else empty；\(J,R\) N/A。
- **9–12：** subtransversal/global linearly regular, not transversal；\(\Phi\) MSR exact 1, no MR/SMSR/SMR。
- **13–14：** \(d(x,L)=\max\{d(x,A),d(x,B)\}\)；small different vertical translations become disjoint parallel lines。
- **Scope / vacuity / C audit：** global, nonisolated, but MSR nonvacuous；C retains translation-uniformity quantifier for MR failure。

### GX-049 — tangent line and parabola

- **Origin IDs / evidence：** SVG-20；same sets underlie RM-06/GX-069 but \(\Phi\) and DR residual are distinct mappings；`VERIFIED-ALG` for the post-C full-neighborhood Hölder bound。
- **1–4：** \(A=\{(s,0)\}\)，\(B=\{(t,t^2)\}\) in \(\mathbb R^2\)，\(\Phi(x)=(A-x)\times(B-x)\)。Both sets smooth/prox-regular。
- **5–8：** zero \(\{0\}\)；if \(\Delta=v_2-u_2\), inverse has two, one or zero roots \((-v_1\pm\sqrt\Delta,-u_2)\) according as \(\Delta>0,=0,<0\)；\(J,R\) N/A。
- **9–12：** neither transversality nor ordinary subtransversality/MR/MSR；under the output max norm, full-neighborhood fixed-target \(q=1/2\) MSR/SMSR holds with sharp modulus \(\sqrt2\)，and the exponent is maximal。
- **13–14：** along \(x_\tau=(\tau,0)\), \(d(x_\tau,B)=\tau^2(1+O(\tau^2))\) while \(d(x_\tau,A\cap B)=|\tau|\)。
- **Scope / vacuity / post-C：** local, isolated/nonvacuous；the \(\sqrt2\) bound is proved on the full neighborhood, not extrapolated from the tangent slice。No optimal constant remains open for this property（`VERIFIED-ALG`）。

### GX-050 — infinite-dimensional zero-angle subspaces

- **Origin IDs / evidence：** SVG-21；`ALG-CHECKED`。
- **1–4：** \(K=\ell^2,H=K\oplus K\)，\(Te_n=e_n/n\)，\(A=K\oplus\{0\}\)，\(B=\operatorname{gra}T\)，\(\Phi(x)=(A-x)\times(B-x)\)。
- **5–8：** zero \(\{0\}\)；inverse is singleton through \(T^{-1}(v_2-u_2-Tv_1)\) when that vector lies in \(\operatorname{ran}T\), else empty；\(J,R\) N/A for \(\Phi\)。Individual \(N_A,N_B\) have projectors/reflections。
- **9–12：** closed smooth linear sets and trivial normal intersection, yet no local/bounded/global subtransversality and no power-\(q\) MSR for any \(q>0\)。
- **13–14：** \(z_n=(e_n,0)\) has distance 1 to intersection, 0 to A, and \(1/\sqrt{n^2+1}\) to B；scale \(t_nz_n\to0\) to defeat every \(q\)。
- **Scope / vacuity / C audit：** local infinite-dimensional, isolated/nonvacuous；C checks the \(0<q<1\) scaling choice and nonclosed-angle mechanism。

### GX-051 — isolated component plus tangent component

- **Origin IDs / evidence：** SVG-22；`ALG-CHECKED`。
- **1–4：** \(A=\mathbb R\times\{0\}\)，\(B=\{(0,0)\}\cup\{(2+t,t^2):t\in\mathbb R\}\)，\(\Phi(x)=(A-x)\times(B-x)\)。
- **5–8：** zero \(\{(0,0),(2,0)\}\)；\(\Phi^{-1}(u,v)=(A-u)\cap(B-v)\), a finite union of an isolated translate and quadratic-root set；\(J,R\) N/A。
- **9–12：** at reference 0, local MSR/SMSR exact 1 but no MR/SMR；family is not boundedly or globally linearly regular because of tangency at the second intersection。
- **13–14：** near 0, \(d(x,B)=\|x\|\)；near \((2,0)\), \(x_t=(2+t,0)\) has residual \(\asymp t^2\) and solution distance \(|t|\)。
- **Scope / vacuity / C audit：** pointwise local versus bounded/global; locally isolated and nonvacuous。C rechecks mapping-side MR failure at the isolated reference。

### GX-052 — isolated point plus asymptotic hyperbola

- **Origin IDs / evidence：** SVG-23；`ALG-CHECKED`。
- **1–4：** \(A=\mathbb R\times\{0\}\)，\(B=\{0\}\cup\{(t,1/t):t\ge1\}\)，\(\Phi(x)=(A-x)\times(B-x)\)。
- **5–8：** zero \(\{0\}\)；\(\Phi^{-1}(u,v)=(A-u)\cap(B-v)\)；\(J,R\) N/A。
- **9–12：** boundedly linearly regular and local SMSR/MSR at 0, but not globally linearly regular and not MR/SMR at 0。
- **13–14：** compact-annulus argument gives a finite modulus on each bounded ball；along \(x_t=(t,0)\), solution distance \(t\) while \(d(x_t,B)\le1/t\)，so global modulus \(\ge t^2\)。
- **Scope / vacuity / post-C：** bounded-versus-global gap; isolated/nonvacuous。C certifies the bounded-ball safe modulus \(\kappa_R=\max\{1,4R^2\}\)；its optimal value remains `UNKNOWN`。Local MSR/SMSR at 0 have exact modulus 1；no global LR or local MR/SMR。

---

## 5. Generalized-monotonicity separation records

### GX-053 — critical restricted negative square \(-x^2\)

- **Origin IDs / evidence：** MGB-02；source object/endpoint `P3-DIRECT`, sharp Hölder calculation `P2-DERIVED`。
- **1–4：** \(H=\mathbb R\)，\(F(x)=-x^2\) on \([0,1/2]\), empty off it；single-valued on proper domain，graph arc。
- **5–8：** \(S=\{0\}\)，\(F^{-1}(y)=\{\sqrt{-y}\}\) for \(y\in[-1/4,0]\)；at \(\lambda=1\), \(p=x-x^2\), \(J(p)=(1-\sqrt{1-4p})/2\), \(R=2J-I\) on \([0,1/4]\)。
- **9–12：** sharp 1-hypomonotone but no finite LT/RL\(_1\) at critical endpoint；sharp RL\(_{1/2}\) constant 2；fixed-target \(q_*=1/2\), no ordinary MSR/SMSR/MR/SMR。
- **13–14：** with \(s=x+y\), \(b=-sa,d=(1-s)a,r=(1+s)a\)；\(Q_{1,1}\to\infty\) as \(s\uparrow1\), while \(Q_{1,1/2}^2=|x-y|(1+s)^2/(1-s)\le4\)。
- **Scope / vacuity / post-C：** restricted/bounded graph, isolated/nonvacuous。For \(λ<1\)，global-on-domain RL\(_1\) has sharp \((1+λ)/(1-λ)\) and subunit estimates only by bounded-range inheritance；at \(λ=1\)，the maximal exponent is \(1/2\) with sharp \(L=2\)；for \(λ>1\)，folds destroy all-pairs RL（`VERIFIED-ALG`）。

### GX-054 — negative cubic

- **Origin IDs / evidence：** MGB-04；`ALG-CHECKED`。
- **1–4：** \(F(x)=-x^3\) on \(\mathbb R\)，single-valued full-domain，graph smooth cubic。
- **5–8：** \(S=\{0\}\)，\(F^{-1}(y)=-\sqrt[3]y\)；Minty map \(x-\lambda x^3\) is noninjective globally, so \(J,R\) are relations with collisions。
- **9–12：** neither finite global hypo nor any global RL；ordinary MR/MSR/SMSR/SMR fail；sharp fixed-target \(q_*=1/3\)。Locally on \([-M,M]\), hypo modulus \(3M^2\) and branch RL away from folds。
- **13–14：** \(ab=-(x^2+xy+y^2)a^2\) and coefficient is globally unbounded；exact residual \(|x|=|F(x)|^{1/3}\)。
- **Scope / vacuity / C audit：** global neither-cell, isolated/nonvacuous；C distinguishes local prox-regularity from global uniform hypo。

### GX-055 — isolated pole branch

- **Origin IDs / evidence：** MGB-05；`ALG-CHECKED`; Spingarn historical naming `PENDING`。
- **1–4：** Fix \(0<\varepsilon<1\), \(F(0)=0\), \(F(x)=-1/x\) for \(0<x\le\varepsilon\), empty otherwise；single-valued on disconnected domain, closed graph。
- **5–8：** \(S=\{0\}\)；inverse \(-1/y\) for \(y\le-1/\varepsilon\), plus \(F^{-1}(0)=\{0\}\)；Minty domain \(( -\infty,\varepsilon-1/\varepsilon]\cup\{0\}\)，branch \(J(p)=(p+\sqrt{p^2+4})/2\), \(R=2J-I\)。
- **9–12：** at step \(λ=1\), LT/RL\(_1\) is finite with sharp \((1+\varepsilon^2)/(1-\varepsilon^2)\), yet the displayed fixed-end Spingarn quotient fails; all fixed-target power SMSR have infimal modulus 0, while MR/SMR fail。
- **13–14：** against \((0,0)\), RL ratio \((1+x^2)/(1-x^2)\)；Spingarn formula gives \(-1/x\to-\infty\)。
- **Scope / vacuity / post-C：** local at an isolated graph point；finite RL\(_1\) holds exactly for \(λ>\varepsilon^2\)，with sharp \((λ+ε^2)/(λ-ε^2)\)；no global subunit exponent holds on the unbounded pole cluster（`VERIFIED-ALG`）。q-SMSR exact modulus 0 comes from **RESIDUAL-ESCAPE / GRAPH-ISOLATION** along genuine domain points, not domain vacuity。Inverse isolated calmness for nearby nonzero targets is separately vacuous because those fibers are empty。Spingarn historical naming remains `PENDING`。

### GX-056 — rational/irrational sign staircase

- **Origin IDs / evidence：** MGB-06；`ALG-CHECKED`; historical Spingarn label `PENDING`。
- **1–4：** On \(|x|<\delta<1/2\), \(F(0)=0\), \(F(x)=\operatorname{sgn}(x)c(x)\) with \(c=1\) on rationals and 2 on irrationals；single-valued, nonclosed graph。
- **5–8：** \(S=\{0\}\)；inverse fibers of \(\pm1,\pm2\) are rational/irrational half-intervals；\(J,R\) are defined relation-wise from finitely separated Minty clusters, no useful closed formula。
- **9–12：** displayed fixed-end pointwise formula holds, two-moving strict formula fails。Finite LT/RL\(_1\) holds exactly for \(λ>\delta\)，with sharp \((λ+δ)/(λ-δ)\)；in particular at step 1 the sharp constant is \((1+δ)/(1-δ)\)。All power SMSR have infimal modulus 0; no MR/SMR。
- **13–14：** fixed endpoint quotient \(c(x)\ge1\); rational \(x_n>y_n\) irrational gives strict quotient \(-1\)。
- **Scope / vacuity / post-C：** `C-SHARPEN/VERIFIED-ALG`：the former \((1+2δ)/(1-2δ)\) was only a safe triangle bound, not a false B sharp claim。Subunit estimates are bounded-domain inheritance。The graph is globally nonclosed but locally closed at the isolated reference \((0,0)\) after an output window excludes \(\pm1,±2\)；coderivative use still requires a genuinely closed localized graph。Historical Spingarn naming remains `PENDING`。

### GX-057 — product splice

- **Origin IDs / evidence：** MGB-07；`VERIFIED-ALG` for the post-C product power exponent/modulus；historical naming remains `PENDING`。
- **1–4：** \(F=F_1\times F_2\) on \(\mathbb R^2\), where \(F_1\) is GX-053 and \(F_2\) is GX-056；single-valued on product domain, nonclosed/nonmaximal。
- **5–8：** \(S=\{(0,0)\}\)；graph/inverse are Cartesian products；where defined, \(J=(J_1,J_2),R=(R_1,R_2)\)。
- **9–12：** neither strict two-moving formula nor LT/RL\(_1\) at base \((1/2,0)\)；the sharp fixed-target product exponent is \(1/2\)，with exact MSR/SMSR modulus 1。
- **13–14：** hold coordinate 2 fixed to reproduce GX-053’s unbounded \(Q_{1,1}\); hold coordinate 1 fixed to reproduce GX-056’s quotient \(-1\)。
- **Scope / vacuity / post-C：** with Euclidean product norms, the gap mechanisms are independent product coordinates；the full-map product residual proof gives maximal \(q=1/2\) and exact modulus 1（`VERIFIED-ALG`）。The former candidate is resolved; only the separate historical Spingarn nomenclature remains unresolved。

### GX-058 — BWY skew plus closed-ball normal

- **Origin IDs / evidence：** MGB-08；Bauschke–Wang–Yao Proposition 3.4 and Example 3.5 give the object and logical labels “maximally monotone + rectangular + not paramonotone” as `P3-DIRECT`；the displayed inverse/resolvent formulas and local exact regularity moduli are `P2-DERIVED/ALG-CHECKED`。
- **1–4：** \(H=\mathbb R^2\)，\(K=\bigl(\begin{smallmatrix}0&1\\-1&0\end{smallmatrix}\bigr)\)，\(B\) closed unit ball，\(F=K+N_B\)；set-valued on boundary, not a linear relation。
- **5–8：** \(S=\{0\}\)；inverse is \(-Ky\) for \(\|y\|<1\), and \(((tI-K)/\|y\|^2)y\) for \(\|y\|\ge1\), \(t=\sqrt{\|y\|^2-1}\)；\(J\) equals \((I+\lambda K)^{-1}p\) inside the threshold and radial boundary formula outside, \(R=2J-I\)。
- **9–12：** maximally monotone and rectangular, not paramonotone；global RL\(_1\) 1, no global subunit RL；near zero all four regularities exact 1。
- **13–14：** interior witness \(\langle x,Kx\rangle=0\) but crossed graph point absent; exterior \(R(p)=-p+O(1)\)。
- **Scope / vacuity / C audit：** global operator/local regularity, isolated/nonvacuous。Never replace \(K+N_B\) by bare \(K\) or the ball by its boundary。

### GX-059 — BWY diagonal plus block skew on \(\ell^2\)

- **Origin IDs / evidence：** MGB-09；BWY Proposition 5.4 and Example 5.5 give the object and paramonotone/not-rectangular gap as `P3-DIRECT`；the displayed block inverse/Cayley formulas and exact regularity modulus are `P2-DERIVED/ALG-CHECKED`。
- **1–4：** \(D(x_n)=(x_n/n)\)，\(B(x_1,x_2,\ldots)=(-x_2,x_1,-x_4,x_3,\ldots)\)，\(F=D+B\) on \(\ell^2\)；continuous linear single-valued。
- **5–8：** \(S=\{0\}\)；on block \(k\), inverse is \((1+a_kb_k)^{-1}\bigl(\begin{smallmatrix}b_k&1\\-1&a_k\end{smallmatrix}\bigr)\)；\(J,R\) are block-diagonal Cayley matrices。
- **9–12：** max monotone, strictly monotone/paramonotone, not rectangular；strong modulus 0, yet boundedly invertible with all four regularities exact 1；global RL\(_1\) exact 1。
- **13–14：** \(\langle x,Fx\rangle=\sum x_n^2/n>0\)；block singular values are \(1\) and \(1+a_kb_k\)。
- **Scope / vacuity / C audit：** infinite-dimensional structure is essential；finite truncations do not give the same separation。C recomputes singular values and BWY range-pathology assumptions。

### GX-060 — Volterra operator

- **Origin IDs / evidence：** MGB-10；BWY Example 5.3 gives the object and logical non-paramonotone/non-rectangular labels as `P3-DIRECT`；the displayed inverse/resolvent formulas, range argument and regularity signature are `P2-DERIVED/ALG-CHECKED`。
- **1–4：** \(H=L^2[0,1]\)，\((Vx)(t)=\int_0^t x(s)ds\)；continuous linear single-valued full-domain。
- **5–8：** \(S=\{0\}\)；\(V^{-1}y=y'\) on \(\{y\in H^1:y(0)=0\}\)；\((J_{\lambda V}p)(t)=p(t)-\lambda\int_0^t e^{-\lambda(t-s)}p(s)ds\)，\(R=2J-I\)。
- **9–12：** max monotone, neither paramonotone nor rectangular；global RL\(_1\) 1, no subunit global RL；MR/MSR/SMSR/SMR fail due nonclosed range。
- **13–14：** \(\langle x,Vx\rangle=\frac12(\int x)^2\)；\(x(t)=t-1/2\) gives zero inner product but \(Vx\ne0\)。
- **Scope / vacuity / C audit：** isolated zero, nonvacuous infinite-dimensional failure。C supplies explicit normalized singular sequence; claims for every general gauge remain pending that calculation。

### GX-061 — adjoint Volterra operator

- **Origin IDs / evidence：** MGB-11；BWY Example 5.3 gives the object and logical non-paramonotone/non-rectangular labels as `P3-DIRECT`；the displayed inverse/resolvent formulas, range argument and regularity signature are `P2-DERIVED/ALG-CHECKED`。
- **1–4：** \((V^*x)(t)=\int_t^1x(s)ds\) on \(L^2[0,1]\)，continuous linear single-valued。
- **5–8：** \(S=\{0\}\)；inverse \(-y'\) on \(\{y\in H^1:y(1)=0\}\)；\((J_{\lambda V^*}p)(t)=p(t)-\lambda\int_t^1e^{-\lambda(s-t)}p(s)ds\)，\(R=2J-I\)。
- **9–12：** same neither-paramonotone-nor-rectangular cell as GX-060, global RL\(_1\), and failure of all four ordinary regularities。
- **13–14：** same quadratic identity and witness \(t-1/2\)；range nonclosed by reflected singular sequence。
- **Scope / vacuity / C audit：** orientation-reversed independent object; C should not simply copy GX-060 labels without recomputing endpoint conditions。

### GX-062 — rotation \(Q_{\pi/3}\)

- **Origin IDs / evidence：** MGB-14；`P3-DIRECT` threshold from Voisei Example 43 and published boundary witness; Cayley/moduli `P2-DERIVED`。
- **1–4：** \(F=Q_{\pi/3}\) on \(\mathbb R^2\)，linear isometry, single-valued full-domain。
- **5–8：** \(S=\{0\}\)，\(F^{-1}=Q_{-\pi/3}\)；\(J=(I+\lambda Q)^{-1}\)，\(R=(I-\lambda Q)(I+\lambda Q)^{-1}\)。For the common rotation family these matrix formulas require \(\Delta=1+2\lambda\cos\theta+\lambda^2>0\)；here \(\Delta=1+\lambda+\lambda^2>0\) for every \(\lambda>0\)。
- **9–12：** maximal 3-cyclic but not 4-cyclic；strong modulus \(1/2\), paramonotone/rectangular；all four regularities exact 1；RL\(_1\) contraction \(\sqrt{(1-\lambda+\lambda^2)/(1+\lambda+\lambda^2)}\)。
- **13–14：** general threshold \(Q_\theta\) is \(n\)-cyclic iff \(|\theta|\le\pi/n\)；\(\langle a,Qa\rangle=\frac12\|a\|^2\)。
- **Scope / vacuity / C audit：** global/isolated/nonvacuous；left endpoint for strict adjacent gap is open in the general family。The singular common-family point \((\theta,\lambda)=(\pi,1)\) has \(Q=-I\), \(I+\lambda Q=0\), and is a Minty collapse rather than an admissible Cayley matrix formula。

### GX-063 — rotation \(Q_{\pi/4}\)

- **Origin IDs / evidence：** MGB-15；same `P3-DIRECT/P2-DERIVED` basis as GX-062。
- **1–4：** \(F=Q_{\pi/4}\) on \(\mathbb R^2\)，linear isometry。
- **5–8：** \(S=\{0\}\)，inverse \(Q_{-\pi/4}\)，standard linear \(J,R\) Cayley formulas；their denominator is \(\Delta=1+\sqrt2\lambda+\lambda^2>0\) for every \(\lambda>0\)。
- **9–12：** maximal 4-cyclic but not 5-cyclic；strong modulus \(1/\sqrt2\)，all regularity moduli 1；RL\(_1\) sharp \(\sqrt{(1-\sqrt2\lambda+\lambda^2)/(1+\sqrt2\lambda+\lambda^2)}\)。
- **13–14：** apply \(|\theta|\le\pi/n\) and \(\langle a,Qa\rangle=\cos(\pi/4)\|a\|^2\)。
- **Scope / vacuity / C audit：** global/isolated/nonvacuous；separate cyclic-order coordinate from scalar strong modulus。The common rotation formula is never extended through the singular point \((\theta,\lambda)=(\pi,1)\)；see GX-062。

### GX-064 — VI-positive oscillation \(2+\sin x\)

- **Origin IDs / evidence：** MGB-17；`ALG-CHECKED` under verified VI definitions。
- **1–4：** \(F(x)=2+\sin x>0\) on \(\mathbb R\)，single-valued full-domain。
- **5–8：** \(S=\varnothing\) for target 0；inverse is the two periodic arcs for \(y\in[1,3]\)；for \(0<\lambda<1\), \(J=(I+\lambda F)^{-1}\) single-valued, \(R=2J-I\)。
- **9–12：** VI-pseudomonotone/quasimonotone but not ordinary monotone；sharp global hypo 1。For \(\lambda<1\), RL\(_1\) sharp \((1+\lambda)/(1-\lambda)\)；at \(\lambda=1\), the local maximal exponent is \(1/3\)，with sharp all-pairs constant \(4\sqrt[3]{3}\) and distinct anchored constant \(2\sqrt[3]{6}\)；\(\lambda>1\) has Minty collisions and RL fails。
- **13–14：** positivity proves VI implication；mean value theorem gives \(ab\ge-a^2\)。At target 3, fixed-target exponent \(1/2\), asymptotic modulus \(\sqrt2\)。
- **Scope / vacuity / post-C：** zero-error-bound labels N/A; regularity is at specified nonzero target。`C-REFINE/VERIFIED-ALG`：C verified the critical exponent and separated the sharp all-pairs/anchored constants; B did not assert a false common sharp constant。

### GX-065 — VI square on \([-1,1]\)

- **Origin IDs / evidence：** MGB-18；VI separation `P3-DIRECT` from Lei–He following Definitions 2.2–2.3, other formulas `P2-DERIVED`。
- **1–4：** \(F(x)=x^2\) restricted to \([-1,1]\)，single-valued proper-domain graph。
- **5–8：** \(S=\{0\}\)，inverse \(\{\pm\sqrt y\}\) for \(0<y\le1\)；for \(0<\lambda<1/2\), local/global-on-domain branch \(J(p)=(-1+\sqrt{1+4\lambda p})/(2\lambda)\), \(R=2J-I\)。
- **9–12：** VI-quasimonotone but not pseudomonotone；sharp global-on-domain hypo 2；RL\(_1\) constant \((1+2\lambda)/(1-2\lambda)\) below threshold；fixed-target \(q_*=1/2\), no ordinary core regularities。
- **13–14：** pseudomono counterpair \(x=0,y=-1\)；\(ab=(x+y)a^2\ge-2a^2\)。
- **Scope / vacuity / post-C：** bounded restricted domain, isolated/nonvacuous；do not merge with GX-028’s full-domain object when recording VI properties。For \(λ<1/2\)，RL\(_1\) is \((1+2λ)/(1-2λ)\)；at \(λ=1/2\)，the maximal exponent is \(1/2\) with sharp \(L=2\sqrt2\)；for \(λ>1/2\)，Minty collisions destroy all-pairs RL（`VERIFIED-ALG`）。

### GX-066 — VI negative identity on \([-1,1]\)

- **Origin IDs / evidence：** MGB-19；`ALG-CHECKED`。
- **1–4：** \(F(x)=-x\) on \([-1,1]\), empty off it；single-valued on proper domain。
- **5–8：** \(S=\{0\}\)，inverse \(-y\) for \(|y|\le1\)；for \(\lambda\ne1\), \(J=p/(1-\lambda)\), \(R=((1+\lambda)/(1-\lambda))p\) on restricted Minty range；at 1 collapse。
- **9–12：** neither VI-quasi nor VI-pseudo；sharp hypo 1；all four local regularities exact 1；RL\(_1\) off singular step。
- **13–14：** pair \(x=-1/2,y=1/2\) violates quasi; \(ab=-a^2\)。
- **Scope / vacuity / C audit：** local regularity at interior zero, isolated/nonvacuous；restriction distinguishes it from GX-003 despite same local slope。

### GX-067 — convex closed-ball normal

- **Origin IDs / evidence：** MGB-23；`ALG-CHECKED` with standard convex-normal primary dictionary。
- **1–4：** \(B\subset\mathbb R^m\) closed unit ball, \(F=N_B\)；set-valued convex normal, max cyclic。
- **5–8：** \(S=B\)；\(F^{-1}(0)=B\), \(F^{-1}(y)=\{y/\|y\|\}\) for \(y\ne0\)；\(J=P_B\), \(R=2P_B-I\)。
- **9–12：** prox-regular + full monotone normal graph, paramonotone/rectangular, RL\(_1\) 1；MSR exact 0 but no MR/SMSR/SMR/global subunit RL。
- **13–14：** convex normal monotonicity; at infinity \(R=-I+O(1)\)。MR fails by small rotated outputs whose inverse remains on the boundary。
- **Scope / vacuity / C audit：** target-zero MSR is domain-vacuous + nonisolated；C checks interior versus boundary reference MR countersequences separately。

---

## 6. Algorithm-residual、anchored 与 regularity-source records

### GX-068 — identity/square branch union \(F(x)=\{x,x^2\}\)

- **Origin IDs / evidence：** RM-01；verifier HREG seed 3；`VERIFIED-ALG` for the post-C fractional regularity fields。
- **1–4：** \(H=\mathbb R\)，set-valued graph \(\{(x,x)\}\cup\{(x,x^2)\}\)（RM-01 localizes to \(|x|<\delta<1\)）。
- **5–8：** \(S=\{0\}\)；inverse contains \(y\), and for \(y\ge0\) also \(\pm\sqrt y\)；\(J_{\lambda F}\) contains identity-branch \(p/(1+\lambda)\) and roots of \(u+\lambda u^2=p\)，\(R=2J-I\) relation。
- **9–12：** HREG/UHREG exact 1 but no ordinary linear MSR/MR/SMSR/SMR；fixed-target \(q=1/2\) MSR/SMSR and two-variable \(q=1/2\) MR all have exact modulus 1。Every Hölder-strong localization fails because each small positive target has three local inverse branches。Full RL fails by multiple resolvent branches；selected identity branch has linear fixed-point EB, full residual does not。
- **13–14：** near zero \(d(0,F(x))=\min\{|x|,x^2\}=x^2\)，while branch \(T_1p=p/(1+\lambda)\) is linearly contractive。
- **Scope / vacuity / post-C：** local branch selection versus full multifunction; isolated/nonvacuous。The two-variable \(q=1/2\) upper bound uses the same square-root branch (and the identity branch across zero), while opposite-root fibers attain modulus 1。This `VERIFIED-ALG` fractional MR does not restore ordinary MR or any strong localization。

### GX-069 — tangent-set Douglas–Rachford residual

- **Origin IDs / evidence：** RM-06；same sets as GX-049 but a different mapping；`VERIFIED-ALG` for the post-C full-tube \(q=1/2\) bound。
- **1–4：** \(C=\mathbb Re_1,D=\{(s,s^2)\}\), local single-valued \(T=I-P_C+P_DR_C\) on \(\mathbb R^2\)；catalog mapping is \(G=I-T\), single-valued local graph \(\{(z,Gz)\}\)。
- **5–8：** \(\operatorname{zer}G=\operatorname{Fix}T\), locally the vertical axis；\(G^{-1}\) implicit through the parabola projection equation；\(J_{\lambda G}=(I+\lambda G)^{-1}\), \(R_{\lambda G}=2J-I\) have no simplified formula in the B record。
- **9–12：** ordinary MSR of \(G\) fails；on the full projection tube, \(q=1/2\)-MSR holds with exact modulus 1 and maximal exponent \(1/2\)。SMSR of every exponent fails because the zero set contains the vertical axis；ordinary MR/SMR fail。
- **13–14：** Write \(z=(a,b)\) and \(P_D(a,-b)=(s,s^2)\). Then \(T(a,b)=(s,b+s^2)\), so the fixed-point equations give \(a=s\) and \(s^2=0\), hence \(a=0\). Conversely, if \(|b|<1/2\), then \(P_D(0,-b)=(0,0)\), proving the local equality \(\operatorname{Fix}T=\{0\}\times\mathbb R\). On the slice \(z=(t,0)\), let \(t=s+2s^3\); then \(Tz=(s,s^2)\), \(Gz=(2s^3,-s^2)\), so \(d(z,\operatorname{Fix}T)=|t|\sim|s|\) while \(\|Gz\|\sim s^2\)。
- **Scope / vacuity / post-C：** local prox-regular projection tube；the full-tube estimate follows from the complete \((s,b)\) parameterization and has exact modulus 1, rather than being extrapolated from the slice。The zero set is nonisolated but the MSR residual law is nonvacuous。No optimal constant remains open for this property（`VERIFIED-ALG`）。

### GX-070 — transverse-line Douglas–Rachford residual

- **Origin IDs / evidence：** RM-07；`ALG-CHECKED`。
- **1–4：** Lines \(C,D\) meet at angle \(0<\theta<\pi/2\); \(T=(I+R_DR_C)/2=\cos\theta\,Q_\theta\) (orientation immaterial), and \(G=I-T\) is linear single-valued on \(\mathbb R^2\)。The same set pair's primal inclusion map is \(F_{\rm pr}=N_C+N_D=N_{\{0\}}\), hence is the canonical operator GX-040 rather than a new phase point。
- **5–8：** \(S=\operatorname{zer}G=\{0\}\)；\(G^{-1}=(I-\cos\theta Q_\theta)^{-1}\)；\(J_{\lambda G}=(I+\lambda G)^{-1}\)，\(R_{\lambda G}=(I-\lambda G)(I+\lambda G)^{-1}\)。
- **9–12：** For the residual \(G\), exact MSR/MR/SMSR/SMR modulus is \(1/\sin\theta\)；\(G\) is strongly monotone with modulus \(\sin^2\theta\) and 1-cocoercive。For the distinct primal map \(F_{\rm pr}\), \(F_{\rm pr}^{-1}(b)=\{0\}\) for every \(b\), so global MR/SMR/SMSR/MSR all have exact infimum 0。Iteration rate \(\|T^kz\|=(\cos\theta)^k\|z\|\)。
- **13–14：** \(\|Gz\|=\sin\theta\|z\|\), \(\langle z,Gz\rangle=\sin^2\theta\|z\|^2=\|Gz\|^2\)。
- **Scope / vacuity / C audit：** residual \(G\) is global/isolated/nonvacuous；primal \(F_{\rm pr}\) has inverse branch pinning plus domain-vacuous mapping-side inequalities。For the tangent RM-06 pair the primal normal sum has only vertical output coverage and fails MR/SMR, so the two primal maps share only the binary fixed-target SMSR=yes label。Compare GX-069 only after keeping the same residual coordinate \(G=I-T\)。

### GX-071 — triangular exact \(\gamma q\) composition model

- **Origin IDs / evidence：** CP-01；`VERIFIED-ALG` for the post-C exponent, fixed-target modulus and invariant-subwindow statements；the optimal restricted all-pairs RL constant remains `UNKNOWN`。
- **1–4：** \(H=\mathbb R^2\), \(0<\gamma<1,q>1/\gamma,\alpha=\gamma q>1\). First define on all of \(\mathbb R^2\) the triangular bijection \(J(t,z)=(t+|z|^\gamma,P_\alpha z)\) and \(R=2J-I=(t+2|z|^\gamma,2P_\alpha z-z)\). The global single-valued map is \(F=J^{-1}-I\), equivalently \(\operatorname{gph}F=\{(Jx,x-Jx):x\in\mathbb R^2\}\)。The bounded tube \(D=(-M,M)\times(-\delta,\delta)\) is only the Minty-input window for restricted all-pairs RL and later drift/invariance checks。
- **5–8：** For this global \(F\), \(S=\mathbb R\times\{0\}\), \(J^{-1}(s,w)=(s-|w|^{1/q},P_{1/\alpha}w)\), and \(F(s,w)=(-|w|^{1/q},P_{1/\alpha}w-w)\)。Moreover \(F^{-1}(b_1,b_2)=\mathbb R\times W(b_1,b_2)\), where \(W(b_1,b_2)=\{w:b_1=-|w|^{1/q},\ b_2=P_{1/\alpha}w-w\}\)；the displayed global \(J,R\) are the resolvent/reflection at \(\lambda=1\)。
- **9–12：** On each bounded tube \(D\), the all-pairs RL\(_\gamma\) exponent is genuinely sharp, but its optimal restricted constant is `UNKNOWN`。For the global operator, fixed-target \(q\)-MSR has exact modulus 1；the PPA normal recurrence is exactly \(r_+=r^{\gamma q}\)。Ordinary isolation fails by design, while its ordinary modulus-zero behavior is a nonvacuous **SUPERLINEAR-GERM** mechanism with residual tending to zero。
- **13–14：** against matched solution, \(\langle a,b\rangle=-|z|^{2\gamma}+|z|^{\alpha+1}-|z|^{2\alpha}\)；residual \(\asymp|w|^{1/q}\)，iteration \(z^+=P_\alpha z\)。
- **Scope / vacuity / post-C：** ambient \(J,F\) and zero set are global；only the RL claim is restricted to \(D\). The full rectangle is not invariant。A self-map/rate statement must use a smaller subwindow with positive upper tangential margin and the proved summable-drift estimate; that estimate is a sufficient invariant-subwindow condition, not a claim that the full tube is invariant。The q-error bound is nonvacuous despite the nonisolated zero line。This is a reverse-calibrated attainability construction: \(α=γq\) was imposed in the definition, so it receives reduced evidentiary weight and cannot by itself support a universal \(γq\) law。C proved the sharp exponent, not the optimal RL constant。

### GX-072 — triangular oscillatory model with order better than \(\gamma q\)

- **Origin IDs / evidence：** CP-02；`VERIFIED-ALG` for the post-C two-scale endpoint, full-map power regularity and actual order；the optimal all-pairs endpoint constant remains `UNKNOWN`。
- **1–4：** \(q>1,0<\gamma<1,\beta=q/\gamma-1\); \(h(x)=|x|^q\sin(|x|^{-\beta})\), \(J(x,y)=(P_qx,P_qy+h(x))\), \(R=2J-I\). Triangular bijection generates single-valued \(F=J^{-1}-I\)。
- **5–8：** local \(S=\{0\}\)；\(F^{-1}\) implicit, while \(J,R\) are explicit as above。
- **9–12：** a complete amplitude/derivative two-scale proof gives the local all-pairs endpoint \(\gamma\), and adjacent oscillatory extrema prove that every \(\eta>\gamma\) fails；thus \(\gamma\) is maximal。The solution-anchored maximal exponent is 1 with point modulus 1。The full-map fixed-target maximal exponent is \(q\), with exact endpoint modulus \(K_q\) from the C variational formula, and the invariant PPA orbit has actual Q-order \(q\)。Ordinary MSR/SMSR have infimal modulus 0 by **SUPERLINEAR-GERM (nonvacuous, residual \(\to0\))**，not a residual jump。
- **13–14：** the verified endpoint is \(q/(\beta+1)=\gamma\). The failure sequence uses oscillatory extrema, while the endpoint upper proof separately splits amplitude and derivative scales；\(Rz=-z+O(\|z\|^q)\) at the fixed point and \(\|Jz\|=\Theta(\|z\|^q)\) on sharp sequences。
- **Scope / vacuity / post-C：** local isolated/nonvacuous, invariant small ball。The endpoint exponent, full-map \(q\)-MSR/SMSR and Q-order are `VERIFIED-ALG`；only the optimal all-pairs endpoint RL constant remains `UNKNOWN`。Like GX-071, this exponent pairing is reverse-calibrated by \(\beta=q/\gamma-1\) and is an attainability construction rather than independent evidence of a universal law。

### GX-073 — anchored-but-not-all-pairs oscillatory Cayley relation

- **Origin IDs / evidence：** AR-02；`VERIFIED-ALG` for the post-C endpoint all-pairs exponent and full-map regularity；the optimal all-pairs endpoint constant remains `UNKNOWN`。
- **1–4：** On \([-\delta,\delta]\), \(R(0)=0\), \(R(x)=P_\alpha(x)[2+\sin(|x|^{-\beta})]\), \(J=(I+R)/2\); graph relation \((Jx,x-Jx)\). Because \(J\) folds, generated \(F\) is set-valued。
- **5–8：** local \(S=\{0\}\)；inverse relation \(F^{-1}(b)=\{Jx:x-Jx=b\}\)；\(J,R\) explicitly displayed on Minty domain。
- **9–12：** anchored/pointwise-at-zero maximal exponent \(\alpha\) holds with exact local constant 3, each nonzero base is locally Lipschitz, but uniform all-pairs exponent \(\alpha\) fails。The two-scale upper proof plus adjacent-extrema sharpness shows that \(\eta_*:=\alpha/(\beta+1)\) is the maximal all-pairs exponent。The full generated multifunction has linear MSR/SMSR with exact modulus 1。
- **13–14：** adjacent oscillatory extrema satisfy output gap \(\asymp x_n^\alpha\), input gap \(\asymp x_n^{\beta+1}\)；\(|R(x)|\le3|x|^\alpha\) at the anchor。
- **Scope / vacuity / post-C：** bounded local relation, isolated zero at parameter level, iteration not invariant。`C-UPGRADE/VERIFIED-ALG`：other preimages do not lower the residual enough to destroy the exact linear modulus 1。Only the optimal all-pairs endpoint RL constant remains `UNKNOWN`。AR-06 is not promoted to a separate card, was not covered by this GX-073 proof, and its analogous endpoint upper label remains `CANDIDATE`。

### GX-074 — CDK discrete graph

- **Origin IDs / evidence：** source verifier regularity seed 5.2；`P3-DIRECT` from Cibulka–Dontchev–Kruger after Theorem 5.2。
- **1–4：** \(H=\mathbb R\)，\(\operatorname{gph}F=\{(1/k,0):k\in\mathbb N_+\}\cup\{(0,0)\}\); set-valued mapping with singleton values on its discrete domain and empty elsewhere。
- **5–8：** \(S=\operatorname{dom}F\)；\(F^{-1}(0)=S\), other inverse fibers empty；natural \(D_\lambda=S\)，\(J=R=I\) on D。
- **9–12：** not SMSR at \((0,0)\), despite the cited coderivative behavior; ordinary MSR holds trivially with infimal modulus 0。No MR/SMR; bounded-domain RL estimates are only relative to the discrete D。
- **13–14：** points \(1/k\to0\) are distinct zeros, defeating isolation; fixed-target distance to S is identically 0 on domain and residual is \(+\infty\) off it。
- **Scope / vacuity / C audit：** **DOMAIN-VACUOUS MSR + NONISOLATED**。Use \(k\in\mathbb N_+=\{1,2,\ldots\}\), never an ambiguous \(\mathbb N\)。C recomputes the exact coderivative claim only if needed。

### GX-075 — hemiregular but not uniformly hemiregular scalar map

- **Origin IDs / evidence：** source verifier HREG seed 1；`ALG-CHECKED`, no primary attribution。
- **1–4：** \(F(0)=\{0\}\cup\{1/n:n\ge1\}\), \(F(x)=\{x\}\) for \(x\ne0\)；set-valued at 0, diagonal elsewhere。
- **5–8：** \(S=\{0\}\)；\(F^{-1}(0)=\{0\}\), \(F^{-1}(1/n)=\{0,1/n\}\), otherwise \(F^{-1}(y)=\{y\}\) for nonzero y；\(J\) contains the diagonal branch \(p/(1+\lambda)\) and, at \(p=\lambda/n\), the extra value 0; \(R\) correspondingly multivalued there。
- **9–12：** HREG exact 1 and SMSR/MSR exact 1, but not UHREG, MR or SMR；full RL fails at accumulating multibranch inputs。
- **13–14：** HREG uses the inverse point \(y\). For UHREG take \(y_n=1/n+1/n^3\) (or a nearby value not in \(F(0)\)): then \(d(0,F^{-1}(y_n))=|y_n|\asymp1/n\), while \(d(y_n,F(0))\le1/n^3\), so the ratio diverges。
- **Scope / vacuity / C audit：** local isolated zero, nonvacuous SMSR；C writes out the exact UHREG quantifiers and confirms whether graph closedness affects any derivative test。

### GX-076 — Uderzo hemiregular/non-MR map

- **Origin IDs / evidence：** source verifier §5.3；object and ordinary HREG/non-MR label `P3-DIRECT` from Uderzo, Example 2.3；fractional moduli and continuity correction `VERIFIED-ALG`。
- **1–4：** \(\Theta:\mathbb R^2\to\mathbb R\), \(\Theta(p_1,p_2)=p_1+p_2^2\) if \(p_1\ge0\), and \(p_1-p_2^2\) if \(p_1<0\)；single-valued piecewise-polynomial map, continuous at the reference origin but not globally continuous。
- **5–8：** \(\Theta^{-1}(0)=\{(0,0)\}\)；general inverse is the union of the two sign-constrained level curves \(p_1\pm p_2^2=y\)。\(J,R\): N/A because domain \(\mathbb R^2\) and codomain \(\mathbb R\) differ。
- **9–12：** HREG/UHREG at \(((0,0),0)\) have exact ordinary modulus 1, while ordinary MR/MSR/SMSR/SMR fail as stated at the linear scale。At exponent \(q=1/2\)，fixed-target MSR/SMSR and two-variable MR all hold with exact modulus 1；no Hölder-strong localization exists because nearby level fibers are non-singleton。
- **13–14：** the exact residual law is \(|\Theta(p_1,p_2)|=|p_1|+p_2^2\)。The ordinary MR countersequence is already the fixed target \((0,t)\), for which distance is \(|t|\) and residual is \(t^2\)；a direct level-set construction gives the full two-variable \(q=1/2\) upper bound, attained on the same sequence。
- **Scope / vacuity / post-C：** local, isolated/nonvacuous。`C-DISAGREE/VERIFIED-ALG`：the map is continuous at the origin but its graph is not locally closed in any whole product neighborhood of that point, because the two one-sided values disagree at fixed small \(p_2\ne0\)。The different domain/codomain dimensions make inner-product monotonicity, resolvent and RL N/A；the fractional MR conclusion does not change the primary ordinary non-MR label。

### GX-077 — convex subdifferential \(\partial|x|\)

- **Origin IDs / evidence：** SVG-03 = RM-03；`ALG-CHECKED` with Rockafellar maximal-cyclic dictionary。
- **1–4：** \(F(x)=\{-1\}\) for \(x<0\), \([-1,1]\) at 0, \(\{1\}\) for \(x>0\)；set-valued max cyclic graph。
- **5–8：** \(S=\{0\}\)；inverse is \(\{0\}\) for \(|y|<1\), half-lines at endpoints；\(J(p)=\operatorname{sgn}(p)(|p|-\lambda)_+\)，\(R=2J-I\)。
- **9–12：** max cyclic/RL\(_1\) but not strong；SMR/MR/SMSR/MSR all hold at \((0,0)\) with infimal modulus 0。Equivalently, the inverse has a single-valued constant localization and hence Aubin, calm and isolated calm properties with infimal modulus 0。Algorithm residual \(I-J\) on \(|p|<\lambda\) has exact EB modulus 1, so the same yes-label hides a different mechanism/modulus。
- **13–14：** inverse localization is constant 0; off zero, \(d(0,F(x))=1\) gives residual jump；\(R\) is nonexpansive piecewise affine。
- **Scope / vacuity / C audit：** isolated, not domain-vacuous; modulus 0 arises from inverse branch pinning/residual jump。This is not the single-valued absolute-value map GX-033 and must never be deduplicated with it。C separates operator residual from prox fixed-point residual。

---

## 7. B-stage recomputation queue and post-C disposition

本节保留 B 阶段的逐条复算队列以便追踪 provenance；它不再是当前状态账本。已经由六份 C ledger 解析闭合的项目，以各卡的 `post-C` 字段和第 8 节 overlay 为准；尚未闭合的历史命名或 optimal constant 仍显式保留。

### Tier H — historical high-risk queue

| IDs | 首要复算事项 |
|---|---|
| GX-032, 045, 053, 058–065, 074, 076 | 对照 primary locator，逐字保留 restriction、空间、sum、截断、阈值与 reference；再复算常数 |
| GX-009, 050, 059–061 | infinite-dimensional closed-range/singular-sequence、power/gauge 失败量词 |
| GX-015–018, 030–031 | Cayley 参数是否真生成 function；global/local exponent、inverse folds、exact regularity modulus |
| GX-022–026 | fixed-target \(q>1\)、modulus 0、gauge incomparability；严禁升级为 two-variable q-MR |
| GX-034–038, 055–057 | multibranch/nonclosed/oscillatory quantifiers，Minty collision，domain-vacuity 与 exact failure sequence |
| GX-040, 070 | 把 RM-07/RM-04 isolated primal map 统一复算为 \(N_{\{0\}}\)：四类 regularity exact infimum 0；与 tangent primal 只比较完整 signature |
| GX-046, 049, 069, 071–073, 075 | Post-C：GX-046 scope 已纠正；GX-049/GX-069 full-neighborhood/full-tube bounds 已验证；GX-071 的 global ambient/restricted window 已验证但 optimal RL constant 未知；GX-072/073 endpoint exponents 与 full-map regularity 已验证，仅 optimal all-pairs endpoint constants 未知。AR-06 未单列且继续 `CANDIDATE`。 |

### Tier R — 代表性 phase coordinates（先算 sharp 常数，再算 yes/no）

| IDs | 代表机制 |
|---|---|
| GX-001–008, 010–014 | linear calibration；strong/coco/maximality/J-contraction/full-range 的互相独立 |
| GX-019–021, 027–029, 033, 039 | bounded inheritance、saturation、power residual、nonisolated EB |
| GX-040–044, 047–048, 051–052 | graph/domain vacuity、reference dependence、set LR local/bounded/global |
| GX-054, 066–068, 070, 077 | both-weak controls、VI restriction、branch selection、DR exact angle、residual-jump modulus |

### Tier D — 去重组与 cross-reference 核验

C 每组只做一次 operator algebra，但必须为不同 reference/residual 另开 regularity calculation：

- GX-001：LC-01 / EX-19 / SVG-05；
- GX-003：LC-03 / MGB-03 / MGB-22；
- GX-006：LC-06 / SVG-11 / MGB-12；
- GX-012：LC-12 / SVG-01 / SVG-02，尤其 \((0,0)\) 与 \((0,-1)\)；
- GX-015：LC-15 / EX-11 / AR-01 的 global 与 bounded-window版本；
- GX-016：LC-16 / EX-13 的 \(\lambda_0\)-scaling；
- GX-021：LC-21 / EX-01 / SVG-04 / RM-02 / CP-05 的 operator、PG residual 与 PPA residual；
- GX-032：MGB-01 / EX-14，只接受 verifier 的 \(U,W,\tau\)；
- GX-033：EX-16 / SVG-14 / HREG seed；
- GX-035：EX-18 / SVG-12 / CDK source；
- GX-040：SVG-06 / RM-04 isolated / RM-07 primal，canonical operator 均为 \(N_{\{0\}}\)；
- GX-042：SVG-10 / RM-04，区分 \(N_L\)-residual 与 \(I-P_L\)-residual；
- GX-046：SVG-17 与 MGB-21 只差 affine output shift，但 reference target随之改变；
- GX-068：RM-01 与 HREG seed，区分 selected branch 与 full-map residual。

### C 的统一输出字段

六份 C ledger 已按此 schema 完成复算；本 catalog 只回填经一致性审计点名的 post-C 状态/scope，不代替后续 `example_properties.md`。数值网格只能作 sanity check，不能替代全称证明。

## 8. 审计修订记录

下表记录 `work/b_catalog_audit.md` 在 **B 阶段当时** 对本 catalog 的修订落点；其中曾标 `CANDIDATE` 的历史状态由后面的 post-C overlay 覆盖。它不作 trade-off synthesis。

| Audit item | Catalog action |
|---|---|
| BCA-B01 | GX-071 的 \(J,R,F\) 改为全 \(\mathbb R^2\) ambient 定义；\(D\) 仅作 restricted all-pairs RL 与带 margin 的 drift/invariance window。零集 \(\mathbb R\times\{0\}\) 及 q-MSR 均相对于 global \(F\)，消除 restricted tangential-boundary 反例。 |
| BCA-M02 | GX-040 纳入 RM-04 isolated 与 RM-07 primal aliases；GX-070 显式区分 DR residual \(G\) 与 primal \(F_{\rm pr}=N_{\{0\}}\)。后者 MR/SMR/SMSR/MSR exact infimum均为 0；tangent primal 只有 vertical output coverage，二者只共享 fixed-target SMSR=yes。 |
| BCA-M03 | 首页与 Tier D 规定 canonical operator 计数：不同 reference、restricted window、stepsize、selection 或 algorithm residual 只作 observation/cross-reference，不获得重复 phase weight。 |
| BCA-M04 | GX-032、035、045、058–063 的 primary logical labels 与 project-derived formulas 分层；BWY 的 inverse/resolvent/moduli不再冒充 P3。GX-075 等 exact HREG scalar seeds继续为 `ALG-CHECKED`。 |
| BCA-M05 | B 阶段曾将 GX-072/GX-073 endpoint upper bounds 降为 `CANDIDATE`；C 的 two-scale proof 现已将这两张卡升级为 `VERIFIED-ALG`。未单列、未被该证明自动覆盖的 AR-06 仍不得升级。 |
| BCA-M06 | GX-038 统一使用 \(\mathbb N_+=\{1,2,\ldots\}\)，排除 \(1/0\) ambiguity。 |
| BCA-M07 | EX-05 与 EX-06 已分别作为 GX-025、GX-026 两张 master card；共享 gauge lemma 只作 cross-reference，不合并对象。 |
| BCA-M08 | GX-055 的 modulus-zero 机制改为 **RESIDUAL-ESCAPE / GRAPH-ISOLATION**；近零 empty inverse fibers 的 isolated-calm inclusion另标 vacuous。 |
| BCA-M09 | GX-069 在 B 阶段补出 \(P_D(a,-b)=(s,s^2)\) 的 fixed-point 方程及反向 inclusion；C 随后已用完整 \((s,b)\) parameterization 验证 full-tube \(q=1/2\)-MSR，exact modulus 1。 |
| BCA-M10 | GX-011 的 positive-part resolvent/reflection 恢复任意 \(\lambda>0\) 的完整分段公式。 |
| BCA-M11 | GX-077 补齐 \(\partial\lvert\cdot\rvert\) 的 MR/SMR/SMSR/MSR 与 inverse Aubin/calm/isolated-calm infimum 0，并禁止与 single-valued GX-033 \(\lvert x\rvert\) 去重。 |
| BCA-M12 | 首页定义 graph-anchored \(A^{\mathrm{gph}}_\gamma\)；GX-034 改用 \(A^{\mathrm{gph}}_1(0,0)\)，不再把 relation 的性质叫 single-valued map-pointwise \(P_1\)。 |
| BCA-M14 | GX-062/063 标明 common rotation Cayley公式只在 \(\Delta=1+2\lambda\cos\theta+\lambda^2>0\) 使用；\((\theta,\lambda)=(\pi,1)\) 单列为 Minty collapse。 |
| Minor audit | GX-009 明确每个有限 diagonal coefficient严格小于 1、norm 1 仅来自 tail supremum；\(P_\alpha\) 已在首页定义；MGB-01 的 `\qquad` 渲染 typo 未带入本 catalog。 |

BCA-M01（Luke–Tam strict edge / Voisei attribution）与 BCA-M13（\(\varepsilon\)-nearest solution 量词）是 `theory_atlas.md` 的定理账本修订，不改变本文件的 example cards；这里不把它们伪装成 catalog 性质修复。

### Post-C audit overlay（authoritative for status and scope）

本 overlay 只覆盖性质状态、量词、window/stepsize scope 与 sharp/safe 标签；上文 B 阶段的对象、graph、inverse、resolvent 和反向构造公式保持不变。若历史 queue/BCA 行与本 overlay 冲突，以本 overlay 和卡内 `post-C` 字段为准。`VERIFIED-ALG` 表示解析复算通过，不把项目推导冒充 primary-source theorem，也不包含任何 seesaw 结论。

| Audit items | Post-C disposition |
|---|---|
| CCA-M04/M08 | GX-025/026 为 genuine `C-DISAGREE`（仅 tuned step \(\lambda=1\) tail cancellation）；GX-046 为 `C-DISAGREE-SCOPE`；GX-056 sharp constant 为 `C-SHARPEN`，其 local-closedness 另作 scope correction；GX-064 为 `C-REFINE`；GX-073 为 `C-UPGRADE`，不是 catalog-error disagreement；GX-076 continuity 为 genuine `C-DISAGREE`。 |
| CCA-M09 | GX-049 fixed \(q=1/2\) modulus \(\sqrt2\)、GX-057 fixed \(q=1/2\) modulus 1、GX-069 full-tube \(q=1/2\)-MSR modulus 1、GX-072 endpoint/full-map/order、GX-073 endpoint/full-map regularity 均为 `VERIFIED-ALG`。 |
| CCA-M11 | GX-071 uses global ambient \(J,F\), global \(S=\mathbb R\times\{0\}\), exact fixed-target \(q\)-MSR modulus 1, restricted sharp exponent \(\gamma\), and a smaller invariant subwindow with a sufficient drift-margin condition；optimal restricted \(L_\gamma\) unknown。 |
| CCA-M13 | GX-071/GX-072 ordinary modulus-zero behavior is `SUPERLINEAR-GERM (nonvacuous, residual \(\to0\))`, not `RESIDUAL-JUMP`。 |
| CCA-M14 | GX-068 has fixed and two-variable \(q=1/2\) modulus 1；ordinary MR and every strong Hölder localization still fail。 |
| CCA-M15 | GX-076 has fixed and two-variable \(q=1/2\) modulus 1；ordinary MR still fails, and non-singleton level fibers exclude strong Hölder localization。 |
| CCA-M17 | A stepsize conclusion is stored as `(mapping/window, lambda, exponent, constant, local/global, all-pairs/anchored, genuine/inherited, map/relation)`；the minimum authoritative ledger is printed below。 |

#### Authoritative high-risk stepsize ledger

| ID | Post-C RL statement |
|---|---|
| GX-015 | \(\eta<\lambda_0\): only global RL\(_1\), sharp \((1+\theta)/(1-\theta)\), \(\theta=\eta/\lambda_0\)；\(\eta=\lambda_0\): unique global exponent \(\alpha\), sharp \(2^{1-\alpha}\)；\(\eta>\lambda_0\): folds/all-pairs failure。 |
| GX-016 | At \(\lambda_0\), every subunit exponent holds by bounded range；at every other step only global RL\(_1\), sharp 1。 |
| GX-017 | At step 1 every subunit exponent holds；at every other step tails kill them, while RL\(_1\) remains sharp 1。 |
| GX-018 | \(\eta<1\): folds；\(\eta=1\): no global exponent but local RL\(_1\) near zero；\(\eta>1\): global RL\(_1\) \((\eta+1)/(\eta-1)\), no global subunit exponent。 |
| GX-019 | \(\lambda\ne3\): bounded-domain \(L^*=(3+\lambda)|3-\lambda|^{-\gamma}\)；\(\lambda=3\): collision/all RL failure。 |
| GX-020 | All steps have RL\(_1\) sharp 1；global subunit exponents only at \(\lambda=1\), with \(L_\gamma=2^{1-\gamma}\)。 |
| GX-025/026 | \(\lambda=1\): all subunit exponents by exact tail cancellation and bounded-range inheritance；\(\lambda\ne1\): tails kill them。 |
| GX-030 | \(\eta<1\): RL\(_1\) \((1+\eta)/(1-\eta)\)；\(\eta=1\): local exponent \(1/3\), sharp \(2^{5/3}\), no global exponent；\(\eta>1\): global collisions。 |
| GX-045 truncation | Restricted RL\(_1\) is finite iff \(\lambda r_0<1\), sharp \((1+\lambda r_0)/(1-\lambda r_0)\)。 |
| GX-053 | \(\lambda<1\): bounded-domain RL\(_1\) \((1+\lambda)/(1-\lambda)\) plus inherited subunit bounds；\(\lambda=1\): sharp exponent \(1/2\), \(L=2\)；\(\lambda>1\): folds。 |
| GX-055 | Finite RL\(_1\) iff \(\lambda>\varepsilon^2\), sharp \((\lambda+\varepsilon^2)/(\lambda-\varepsilon^2)\)；no global subunit exponent。 |
| GX-056 | Finite RL\(_1\) iff \(\lambda>\delta\), sharp \((\lambda+\delta)/(\lambda-\delta)\)；subunit bounds are bounded-domain inheritance。 |
| GX-064 | \(\lambda<1\): RL\(_1\) \((1+\lambda)/(1-\lambda)\)；\(\lambda=1\): local \(1/3\), all-pairs \(4\sqrt[3]{3}\), anchored \(2\sqrt[3]{6}\)；\(\lambda>1\): collisions。 |
| GX-065 | \(\lambda<1/2\): RL\(_1\) \((1+2\lambda)/(1-2\lambda)\)；\(\lambda=1/2\): exponent \(1/2\), \(L=2\sqrt2\)；\(\lambda>1/2\): collisions。 |

#### Remaining `UNKNOWN` / `PENDING` after this overlay

| Item | Exact remaining uncertainty |
|---|---|
| GX-025/GX-026 | optimal tuned-step subunit RL constants and exact pairwise endpoint \((1-c)\)-MR moduli \(K_\pm\) within the proved bounds |
| GX-045 | optimal subunit RL constants on the truncated annulus; RL\(_1\) is already sharp |
| GX-052 | optimal bounded-ball linear-regularity modulus; \(\kappa_R=\max\{1,4R^2\}\) is certified safe |
| GX-071 | optimal restricted-tube RL\(_\gamma\) constant; the exponent is sharp and (71.4) is only safe |
| GX-072/GX-073 | optimal all-pairs endpoint RL constants; endpoint exponents and stated regularity properties are verified |
| Spingarn-related GX-053--057 | historical nomenclature/maximality convention pending primary full-text verification; this is not a mathematical-constant candidate |
| uncarded AR-06 | analogous endpoint upper property remains `CANDIDATE`; no GX status is inferred from GX-073 |

Former constant placeholders for GX-017 and GX-037 are closed analytically, not `UNKNOWN`: GX-017 has the exact \(L_\gamma^*\) printed in its card；for GX-037 the exact local \(1/2\)-Hölder-Aubin modulus is
\[
K^*=\sup_{\Delta>0}\frac{2|\sin(\Delta/2)|}{\sqrt\Delta}
=\frac{\sqrt2\sin x_*}{\sqrt{x_*}}\approx1.20383666149,
\qquad \tan x_*=2x_*,\quad x_*\in(0,\pi/2).
\]

### CP-01 / CP-02 反向校准警告

CP-01 先定义 \(\alpha:=\gamma q\)，再把 normal update 直接设置为 \(P_\alpha\)，并把 residual 设计成 \(|w|^{1/q}\)；CP-02 则定义 \(\beta:=q/\gamma-1\)，使候选 oscillatory exponent 被校准为 \(q/(\beta+1)=\gamma\)。因此二者是按目标 exponents 反向设计的 existence constructions，而不是独立采样后出现的配对。

它们可用于检查 attainability、nonsharpness、anchored/all-pairs 量词差异与 window 机制；在任何后续 universal compensation 判断中必须降低证据权重，不得把 \(\alpha=\gamma q\) 或 \(\beta=q/\gamma-1\) 的定义恒等式重新包装成发现的规律。

## 9. Catalog boundary

本目录没有从这些落点推出任何 monotonicity–regularity trade-off，也没有把 \(\gamma q\) 写成普遍规律。CP-06 是 obstruction lemma 而非显式对象，故未计入 77 条；RM-05/CP-03 等仅改变已收录 scalar operator 的 split/stepsize，保留在 origin cross-reference 而不重复计数。所有 synthesis 留给 C 完成独立复算之后的 integrator。
