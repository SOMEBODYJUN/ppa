# Root mathematical audit notes (provisional)

These notes are algebraic deductions from the uploaded RL draft, not literature claims.

## RL/Minty parameterization

Let (z=u+\lambda u^*), (w=v+\lambda v^*), (a=u-v), (b=u^*-v^*). Then

\[
R_{\lambda F}z-R_{\lambda F}w=a-\lambda b,\qquad z-w=a+\lambda b.
\]

Thus RL is exactly a selection-wise Hölder bound for (R_{\lambda F}) on
\(\operatorname{ran}(I+\lambda F)\).  Moreover, if two graph points have the
same Minty input, then RL gives both (a+\lambda b=0) and (a-\lambda b=0),
hence (a=b=0).  Consequently RL itself makes the resolvent single-valued on
its range.  Any statement on all of (H) still needs surjectivity of
\(I+\lambda F\).

## The \(\gamma=1\) parameter curve

For \(\gamma=1\), squaring and rearranging gives

\[
\langle a,b\rangle\ge
\frac{1-L^2}{2\lambda(1+L^2)}\|a\|^2+
\frac{\lambda(1-L^2)}{2(1+L^2)}\|b\|^2.
\]

Hence, under the convention
\(\langle a,b\rangle\ge\mu\|a\|^2+\rho\|b\|^2\), the exact curve is

\[
\mu=\frac{1-L^2}{2\lambda(1+L^2)},\qquad
\rho=\lambda^2\mu.
\]

In particular, (L=1) is monotonicity, (L<1) gives positive coefficients,
and (L>1) gives negative coefficients.  Source/convention matching is still
required before naming this semimonotonicity or cohypomonotonicity.

## Inversion symmetry

Applying RL to (F^{-1}), swapping (a,b), and using parameter (1/\lambda)
shows

\[
F\in RL(\lambda,L,\gamma)
\iff
F^{-1}\in RL(\lambda^{-1},L\lambda^{\gamma-1},\gamma).
\]

## Scale dependence for \(0<\gamma<1\)

At Minty separation (t=\|a+\lambda b\|), RL-IP has defect

\[
-\frac{L^2}{4}t^{2\gamma}+\frac14t^2.
\]

For (t\downarrow0), (t^{2\gamma}\) dominates (t^2), so the relative
quadratic defect diverges.  For (t\to\infty), the positive quadratic term
dominates.  Thus \(\gamma<1\) cannot be assigned a scale-free position on a
single monotonicity-strength axis.

On a domain of diameter (D), a Lipschitz reflected resolvent with constant
(K) is \(\gamma\)-Hölder with constant (KD^{1-\gamma}).  The analogous
global implication fails on unbounded domains in general.

## Immediate geometric restrictions

For two zeros (p,q\), RL gives
\(\|p-q\|\le L\|p-q\|^\gamma\).  If \(\gamma<1\) and (p\ne q\), then

\[
\|p-q\|\le L^{1/(1-\gamma)}.
\]

Thus a global RL mapping cannot have an unbounded zero set.  Local RL has no
such global consequence.

## Power-subregularity convention check

For (F(x)\asymp \operatorname{sgn}(x)|x|^\alpha\) near zero,

\[
|x|\le \rho |F(x)|^q
\]

holds locally exactly for (\alpha q\le1) (with equality giving the sharp
largest exponent (q_*=1/\alpha)).  Thus (q>1) describes a very sharp
inverse/error bound and naturally arises only when (0<\alpha<1) in this
model.  This convention must not be confused with papers that put the power
on the distance-to-solution side or use order (1/q).

## Draft theorem checks to preserve

- The gauge sufficient constant is dimensionally consistent: if
  \(\psi(t)\sim c t^{1/\gamma}\), then
  \(\psi((r+Lr^\gamma)/(2\lambda))/r\to
  c(L/(2\lambda))^{1/\gamma}\).
- Point convergence from the distance recurrence still needs branch
  well-definedness, localization, closedness of the zero set, and summability
  of steps.  Superlinear or contractive distance recursion plus
  \(\|x^{k+1}-x^k\|=O(r_k^\gamma)\) gives the summability.
- The equivalence with AFNE should state the common domain and all-selection
  quantifier before single-valuedness is deduced.

## High-value explicit model families for later stages

1. (F_c(x)=cx): exact RL ratio, exact regularity, anti/strong/zero slopes.
2. (F_\alpha(x)=\operatorname{sgn}(x)|x|^\alpha): sharp power exponent
   (q_*=1/\alpha).
3. (F(x)=x^3): monotone but only Hölder subregular of order at most (1/3).
4. Skew rotation on \(\mathbb R^2\): monotone and invertible, but neither
   strongly monotone nor cocoercive with positive constant.
5. Positive semidefinite singular linear maps: maximal monotone with nonisolated
   zeros and ordinary subregularity but not strong subregularity/regularity.
6. (\partial|x|\): maximal monotone, no positive strong monotonicity, but a
   locally constant inverse branch around (0).
7. Normal cones and the zero operator: examples where subregularity is vacuous
   because the solution set is large, exposing the need for isolated/quotient
   coordinates.

