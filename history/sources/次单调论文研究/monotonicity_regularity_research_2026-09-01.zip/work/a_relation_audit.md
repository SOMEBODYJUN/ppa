# Generalized monotonicity / regularity atlas：关系与 strictness 审计

> 范围：只审计最容易被 atlas 写错的蕴含、等价和 converse；不重写百科，也不作 seesaw synthesis。  
> 记号：$H$ 为实 Hilbert 空间，$A:H\rightrightarrows H$，
> $J_{\lambda A}=(I+\lambda A)^{-1}$，$R_{\lambda A}=2J_{\lambda A}-I$。
> Regularity 性质均在给定图点 $(\bar x,\bar y)\in\operatorname{gph}F$ 讨论。

## 0. 一页式结论

| 易错简写 | atlas 中可安全写成 |
|---|---|
| “$A$ maximal monotone iff $J_A$ firmly nonexpansive” | 必须加 $J_A:H\to H$ 处处定义；partial FNE resolvent 只对应 monotonicity。 |
| “strong monotone iff resolvent contractive” | 错。精确条件是 $(1+\lambda\alpha)J_{\lambda A}$ firmly nonexpansive；单纯 $\operatorname{Lip}J<1$ 不够。 |
| “strong monotone iff inverse Lipschitz” | 错。精确 inverse 条件是 $A^{-1}$ cocoercive；Lipschitz 只是推论。 |
| “monotone + Lipschitz iff cocoercive” | 一般错；在凸梯度的 Baillon--Haddad 结构下恢复 converse。 |
| “prox-regular iff $\partial f$ hypomonotone” | 必须保留 proximal-subgradient 条件和 $f$-attentive、值域截断的 localization。 |
| “metric regular iff open at the point” | 等价的是在邻近图点上统一的 linear openness around，不是 center-only covering。 |
| “strong regular = regular + isolated solution” | 错。需要 $F^{-1}$ 对所有邻近右端都有 single-valued graphical localization。 |
| “一个 coderivative nonsingularity 判据包打所有 regularity” | 错。有限维 metric regularity 有基本 limiting-coderivative iff；subregularity 与 strong subregularity 的边界不同。 |

---

## 1. Maximal monotonicity 与 resolvent / reflected resolvent

### 结论

对任意 $\lambda>0$：

1. $A$ monotone 时，$J_{\lambda A}$ 在
   \[
   \operatorname{dom}J_{\lambda A}=\operatorname{ran}(I+\lambda A)
   \]
   上单值且 firmly nonexpansive。
2. $A$ maximal monotone 当且仅当
   $J_{\lambda A}:H\to H$ 处处定义且 firmly nonexpansive。
3. 在 full-domain 情形，以上又等价于
   $R_{\lambda A}=2J_{\lambda A}-I$ nonexpansive。
4. 每个 full-domain firmly nonexpansive $T:H\to H$ 唯一对应
   \[
   A=\lambda^{-1}(T^{-1}-I),\qquad T=J_{\lambda A},
   \]
   且该 $A$ maximal monotone。

### 完整假设

- 实 Hilbert 空间；$A$ 可 set-valued。
- Full domain 是 maximality 的组成部分，不是技术性补充。
- 对 partial $T$，firm nonexpansiveness 仍给 monotone relation，但不给 maximal extension。

### 原始定理来源

- G. J. Minty, *Monotone (nonlinear) operators in Hilbert space*, Duke Math. J. 29
  (1962), 341--346，[Project Euclid / DOI](https://projecteuclid.org/journals/duke-mathematical-journal/volume-29/issue-3/Monotone-nonlinear-operators-in-Hilbert-space/10.1215/S0012-7094-62-02933-2.short)：
  原始 maximality/surjectivity 机制。
- H. H. Bauschke, S. M. Moffat, X. Wang,
  *Firmly nonexpansive mappings and maximally monotone operators: correspondence and duality*，
  [author PDF](https://arxiv.org/pdf/1101.4688)，Fact 1.1--1.2，pp. 2--3：
  $T\leftrightarrow A$ 与 $2T-I$ nonexpansive 的精确对应。
- H. H. Bauschke, X. Wang, L. Yao,
  *General Resolvents for Monotone Operators: Characterization and Extension*，
  [author PDF](https://arxiv.org/pdf/0810.3905)，Proposition 5.1 与 Corollary 5.4，
  pp. 8--9：full domain iff maximality。

### Converse / strict witness

- Converse 在 full-domain FNE 条件下成立。
- Full-domain 假设严格：在 $\mathbb R$ 取
  \[
  \operatorname{gph}A=\{(0,0)\}.
  \]
  $A$ monotone 但不 maximal；$J_A$ 只在 $\{0\}$ 上定义且 FNE。
  因而 partial FNE resolvent 不推出 maximal monotonicity。

---

## 2. Strong monotonicity、Lipschitz inverse 与 resolvent contraction

### 结论

设 $A$ 为 $\alpha$-strongly monotone，$\alpha>0$：
\[
\langle x-y,u-v\rangle\ge\alpha\|x-y\|^2
\quad((x,u),(y,v)\in\operatorname{gph}A).
\]

则：

1. $A^{-1}$ 在 $\operatorname{ran}A$ 上单值且 $1/\alpha$-Lipschitz。
   精确 inverse characterization 是
   \[
   A\text{ is }\alpha\text{-strongly monotone}
   \iff A^{-1}\text{ is }\alpha\text{-cocoercive on }\operatorname{ran}A.
   \]
2. 若 $A$ 还 maximal monotone，则 $\operatorname{ran}A=H$，故
   $A^{-1}:H\to H$ 全局单值且 $1/\alpha$-Lipschitz。
3. 精确 resolvent 条件为
   \[
   \langle J_{\lambda A}x-J_{\lambda A}y,x-y\rangle
   \ge(1+\lambda\alpha)\|J_{\lambda A}x-J_{\lambda A}y\|^2.
   \]
   即 $(1+\lambda\alpha)J_{\lambda A}$ firmly nonexpansive。因此
   \[
   \operatorname{Lip}J_{\lambda A}\le(1+\lambda\alpha)^{-1}.
   \]

### 完整假设

- 前两项在 $\operatorname{ran}A$ 上不需 maximality。
- 要把 inverse 声称为 $H\to H$，必须另加 maximality 或 surjectivity。
- Resolvent 等价在自然定义域上成立；maximality 才使其成为全空间映射。

### 原始定理来源

- Bauschke--Moffat--Wang，
  [author PDF](https://arxiv.org/pdf/1101.4688)，Theorem 2.1(xi),(xiii)，
  pp. 5, 7：$(1+\varepsilon)J_A$ FNE iff $\varepsilon$-strong monotonicity；
  单纯 Banach contraction 对应另一个含交叉项的 graph inequality。
- W. M. Moursi, L. Vandenberghe，
  *Douglas--Rachford splitting for a Lipschitz continuous and a strongly monotone operator*，
  [author PDF](https://arxiv.org/pdf/1805.09396)，Proposition 2.1(i),(iii)--(v)，
  pp. 3--4。

### Converse / strict witness

“inverse Lipschitz $\Rightarrow$ strong monotone”与
“resolvent contraction $\Rightarrow$ strong monotone”均失败。取九十度旋转
\[
K(x_1,x_2)=(-x_2,x_1)\quad\text{on }\mathbb R^2.
\]
$K$ 是 continuous full-domain maximal monotone，且
$\langle z,Kz\rangle=0$，故不对任何 $\alpha>0$ strongly monotone；但
\[
\|(I+\lambda K)^{-1}\|=(1+\lambda^2)^{-1/2}<1,
\qquad K^{-1}=-K\ \text{is 1-Lipschitz}.
\]
正确 converse 要把 inverse Lipschitz 加强为 inverse cocoercivity，或把 resolvent
contraction 加强为上面的 scaled-FNE inequality。

---

## 3. Cocoercivity 与 monotone + Lipschitz

### 结论

若单值 $T:H\to H$ 是 $\beta$-cocoercive：
\[
\langle x-y,Tx-Ty\rangle\ge\beta\|Tx-Ty\|^2,
\]
则 $T$ monotone 且 $1/\beta$-Lipschitz。一般 converse 失败。

两个可安全使用的附加结构：

1. $\mu$-strongly monotone 且 $L$-Lipschitz
   $\Rightarrow\mu/L^2$-cocoercive。
2. 若 $f:H\to\mathbb R$ 凸、Fréchet differentiable，且 $\nabla f$ 为
   $L$-Lipschitz，则 $\nabla f$ 为 $1/L$-cocoercive（Baillon--Haddad）。

### 完整假设

Baillon--Haddad 中“凸势的梯度”是实质假设；不能替换为任意 monotone
Lipschitz operator。

### 原始定理来源

- H. H. Bauschke, P. L. Combettes，
  *The Baillon--Haddad theorem revisited*，
  [journal PDF](https://www.heldermann-verlag.de/jca/jca17/jca0932_b.pdf)，
  Theorem 2.1，pp. 782--783；开放凸域 $C^2$ 版本见 Theorem 3.3。
- Moursi--Vandenberghe，
  [author PDF](https://arxiv.org/pdf/1805.09396)，Proposition 2.1(i)。

### Converse / strict witness

同一旋转 $K$ 是 1-Lipschitz 且 monotone，但
\[
\langle z,Kz\rangle=0<\beta\|Kz\|^2\quad(z\ne0)
\]
对每个 $\beta>0$ 均失败。因此 cocoercive 是 monotone $\cap$ Lipschitz
的严格子类；$K$ 也准确显示 Baillon--Haddad 缺少势结构时的失败机制。

---

## 4. Hypomonotonicity 与 prox-regularity：localization 不能省

### 结论

在 $\mathbb R^n$，proper l.s.c. $f$ 在 $\bar x$ relative to
$\bar v\in\partial f(\bar x)$ prox-regular 的精确刻画是：

1. $\bar v$ 是 $f$ 在 $\bar x$ 的 proximal subgradient；且
2. 存在 $\varepsilon,r>0$，使 limiting subdifferential 的
   $f$-attentive $\varepsilon$-localization $T$ 满足
   \[
   T+rI\text{ monotone},\qquad
   \langle v_1-v_0,x_1-x_0\rangle\ge-r\|x_1-x_0\|^2.
   \]

该 localization 同时限制
\[
\|x-\bar x\|<\varepsilon,\quad
|f(x)-f(\bar x)|<\varepsilon,\quad
\|v-\bar v\|<\varepsilon.
\]
所以不能缩写为“整个 $\partial f$ 局部 hypomonotone”，更不能写成 global
hypomonotonicity。

### 完整假设

- 上述 iff 是有限维、limiting proximal subdifferential 版本。
- Hilbert/Banach 扩展依赖所选 normal/subdifferential 与紧性、弱闭条件，不能无说明搬运。

### 原始定理来源

- R. A. Poliquin, R. T. Rockafellar，
  *Prox-regular functions in variational analysis*，Trans. AMS 348 (1996),
  1805--1838，[DOI](https://doi.org/10.1090/S0002-9947-96-01544-9)，
  Theorem 3.2。
- 同作者 *A calculus of prox-regularity*，
  [journal PDF](https://www.heldermann-verlag.de/jca/jca17/jca0849_b.pdf)，
  Definition 1.1 与 Theorem 2.1，pp. 203--205；局部 proximal map 的
  $1/(1-\lambda r)$ Lipschitz 界见 Theorem 2.2。
- R. A. Poliquin, R. T. Rockafellar, L. Thibault，
  *Local differentiability of distance functions*，
  [AMS official page](https://www.ams.org/journals/tran/2000-352-11/S0002-9947-00-02550-2/)：
  prox-regular set / local projection 刻画。

### Converse / strict witnesses

**值域截断不可省。** 令 $C=S^1\subset\mathbb R^2$。$C$ prox-regular，但完整
$N_C(x)=\operatorname{span}\{x\}$ 不满足任何有限常数的局部 hypomonotonicity。
取邻近 $x\ne y$、$v=-tx\in N_C(x)$、$w=0\in N_C(y)$，则
\[
\langle v-w,x-y\rangle=-\frac t2\|x-y\|^2.
\]
令 $t\to\infty$ 即破坏任意固定 $r$。

**Proximal-subgradient 条件不可省。** 取 $f(x)=-|x|$ 于
$(\bar x,\bar v)=(0,1)$。$\bar v=1$ 附近的 limiting-subgradient 分支局部为常值，
因而 monotone；但 $1$ 不是 proximal subgradient，$f$ 不在该图点 prox-regular。

---

## 5. Metric regularity、inverse Aubin 与 linear openness

### 结论

对 metric spaces 中任意 $F:X\rightrightarrows Y$，采用标准局部定义时：
\[
\boxed{
F\text{ metrically regular at }(\bar x,\bar y)
\iff F^{-1}\text{ has the Aubin property at }(\bar y,\bar x)
\iff F\text{ is linearly open around }(\bar x,\bar y).
}
\]
精确模数满足
\[
\operatorname{reg}F(\bar x|\bar y)
=\operatorname{lip}F^{-1}(\bar y|\bar x),\qquad
\operatorname{sur}F(\bar x|\bar y)\operatorname{reg}F(\bar x|\bar y)=1
\]
（含 $0\leftrightarrow+\infty$ 约定）。

### 完整假设

- 这是距离不等式的定义级等价，不需 Banach、凸性或闭图。
- Linear openness 必须对所有邻近 $(x,y)\in\operatorname{gph}F$ 使用统一 rate。
- 只要求 $B(\bar y,ct)\subset F(B(\bar x,t))$ 的 center-only covering 是另一性质。
- 闭图、完整性、Asplund 等条件出现在判据中，不出现在上述等价本身。

### 原始/权威来源

- A. L. Dontchev, M. Quincampoix, N. Zlateva，
  *Aubin Criterion for Metric Regularity*，
  [journal PDF](https://www.heldermann-verlag.de/jca/jca13/jca0526_b.pdf)，
  Definition 1.1 与式 (6)，pp. 281--284：inverse Aubin 等价及模数相等。
- A. D. Ioffe，*Metric regularity—a survey*，
  [author PDF](https://arxiv.org/pdf/1505.07920)，Definition 2.1 与 Proposition 2.2，
  pp. 9--10：一般 metric spaces 中的三重等价与精确模数（用于交叉核对）。

### Converse / strict witness

标准三者之间 converse 全部成立，没有 strict inclusion。

Center-only $\not\Rightarrow$ around-linear openness 的最简文献 witness 尚待 B 固化。
可从
\[
f(0)=0,\qquad f(x)=x+x^2\sin(1/x^2)
\]
出发：端点估计给 0 中心的线性覆盖，而趋近 0 的临界点破坏统一 around-rate；
进入正式 catalog 前仍需补全所有邻域量词。

---

## 6. Subregularity / strong subregularity 与 inverse calmness

### 结论

定义级精确等价：
\[
F\text{ metrically subregular at }(\bar x,\bar y)
\iff F^{-1}\text{ calm at }(\bar y,\bar x),
\]
\[
\operatorname{subreg}F(\bar x|\bar y)
=\operatorname{calm}F^{-1}(\bar y|\bar x).
\]

强版本：
\[
F\text{ strongly metrically subregular at }(\bar x,\bar y)
\iff F^{-1}\text{ isolated calm at }(\bar y,\bar x).
\]
即存在邻域 $U,V$ 与 $\kappa\ge0$ 使
\[
F^{-1}(y)\cap U\subset \bar x+\kappa d(y,\bar y)\mathbb B
\quad(y\in V),
\]
且两个 exact moduli 相等。

### 完整假设

- 一般 metric spaces 即可；平移球写法只需右侧为平移不变 metric linear space。
- 普通 subregularity 左端是 $d(x,F^{-1}(\bar y))$；
  strong subregularity 左端是 $d(x,\bar x)$，后者强制参考解局部孤立。

### 原始/primary 来源

- R. Cibulka, A. L. Dontchev, A. Y. Kruger，
  *Strong metric subregularity of mappings in variational analysis and optimization*，
  [author PDF](https://arxiv.org/pdf/1701.02078)，pp. 1--3，尤其式 (2)--(4)：
  strong subregularity $\leftrightarrow$ isolated calmness 及模数相等。
- Ioffe，[author PDF](https://arxiv.org/pdf/1505.07920)，
  Definition 3.16--3.17 与 Proposition 3.18，p. 20：
  ordinary subregularity $\leftrightarrow$ inverse calmness。

### Strictness / incomparability witnesses

| 目的 | 映射与图点 | 精确性质 |
|---|---|---|
| subregular 非 strong | $F(x)\equiv0$ on $\mathbb R$，$(0,0)$ | $F^{-1}(0)=\mathbb R$；普通 subregularity 左端恒 0，解不孤立。 |
| strong subregular 非 metric regular | $F(x)=|x|$，$(0,0)$ | strong modulus 1；负的邻近 $y$ 无原像，metric regularity 失败。 |
| metric regular 非 strong subregular | $F(x_1,x_2)=x_1$，$(0,0)$ | regularity modulus 1；kernel 非平凡，参考解不孤立。 |

因此 metric regularity 与 strong metric subregularity 互不包含。

---

## 7. Strong metric regularity 不是 regularity + reference-fiber singleton

### 结论

\[
F\text{ strongly metrically regular at }(\bar x,\bar y)
\iff
\begin{cases}
F\text{ metrically regular at }(\bar x,\bar y),\\
F^{-1}\text{ has a single-valued graphical localization }V\to U.
\end{cases}
\]
Localization 要对每个 $y\in V$ 给出唯一邻近解；metric regularity 随后给 Lipschitz，
且 localization 的 Lipschitz modulus 等于 $\operatorname{reg}F$。

只知道
\[
F^{-1}(\bar y)\cap U=\{\bar x\}
\]
不够。

### 完整假设

这里的 single-valued localization 包含邻近右端的局部 existence 与 uniqueness，
不是只在参考右端的 isolated solution。

### 原始定理来源

- S. M. Robinson，*Strongly Regular Generalized Equations*，
  Math. Oper. Res. 5 (1980), 43--62，
  [official PDF / DOI](https://pubsonline.informs.org/doi/pdf/10.1287/moor.5.1.43)。
- Ioffe，[author PDF](https://arxiv.org/pdf/1505.07920)，
  Definition 4.9 与 Proposition 4.10，pp. 25--26。
- Cibulka--Dontchev--Kruger，
  [author PDF](https://arxiv.org/pdf/1701.02078)，Proposition 1.2，p. 3。

### Converse / strict witness

取
\[
F(x)=\{-x,x\}\quad(x\in\mathbb R)
\]
于 $(0,0)$。有
\[
d(x,F^{-1}(y))=\min\{|x-y|,|x+y|\}=d(y,F(x)),
\]
故 metric regularity modulus 为 1；又 $d(0,F(x))=|x|$，故 strong-subregularity
modulus 为 1，参考 fiber 也局部单点。但 $y\ne0$ 时
$F^{-1}(y)=\{-y,y\}$，无 single-valued inverse localization，故不 strongly regular。
该反例由 Cibulka--Dontchev--Kruger 在 Proposition 1.2 后明确给出。

结构化 converse：若 $f:X\to Y$ strictly differentiable，且
$\operatorname{rge}Df(\bar x)$ closed，则 Proposition 1.2 给出
metric regularity $\iff Df(\bar x)$ surjective，
strong subregularity $\iff Df(\bar x)$ injective。
二者合取使导数可逆，从而 $f$ strongly regular。此 converse 不能推广到一般 multifunction。

---

## 8. Hölder / higher-order / gauge：exponent convention 审计

### 结论与完整 convention

本项目采用
\[
d(x,F^{-1}(\bar y))\le\rho\,d(\bar y,F(x))^q. \tag{P}
\]
Kruger 等常写
\[
\tau\,d(x,F^{-1}(\bar y))\le d(\bar y,F(x))^q. \tag{K}
\]
同一性质下 $\tau=1/\rho$；P-modulus 取 infimum，K-modulus 取 supremum。

在残差小于 1 的局部邻域内，若 $0<q_1<q_2$，则
\[
r^{q_2}\le r^{q_1},
\]
故 $q_2$-subregularity $\Rightarrow q_1$-subregularity：
较大 exponent 是较强估计。

- $0<q<1$ 通常称 Hölder；
- $q=1$ 是 linear；
- $q>1$ 是 higher-order subregularity，仍可非平凡；
- 对 uniform metric regularity，$q>1$ 会使 inverse 受到超一阶 Hölder 约束，
  在通常连通的单值局部化上高度退化；不能把 higher-order subregularity 结论自动搬过去。

Gauge 还可能放在另一边。Kruger 使用
\[
\tau d(x,S)\le\varphi(d(\bar y,F(x))).
\]
若另一文献写 $\psi(d(x,S))\le d(\bar y,F(x))$，只有在 $\psi$ 严格递增可逆时，
才能转换，且 residual-side gauge 是 $\psi^{-1}$；幂函数 exponent 会取倒数。

### 原始/primary 来源

- B. S. Mordukhovich, W. Ouyang，
  *Higher-order metric subregularity and its applications*，
  [author PDF](https://optimization-online.org/wp-content/uploads/2014/07/4440.pdf)，
  Definition 3.1 与 Example 3.2，pp. 2--3。
- A. Y. Kruger，*Nonlinear Metric Subregularity*，
  [author PDF](https://arxiv.org/pdf/1502.06159)，式 (1)--(2)，pp. 2--3，
  以及式 (45)--(47)，pp. 15--16。

### Sharp exponent witness

取
\[
F_p(x)=\operatorname{sgn}(x)|x|^p,\qquad p>0,\quad(\bar x,\bar y)=(0,0).
\]
则 (P) 化为 $|x|\le\rho|x|^{pq}$，故 sharp largest exponent
\[
q_*=1/p.
\]
$q=q_*$ 时 exact P-modulus 为 1；$q<q_*$ 时性质成立且 exact local modulus 可为 0；
$q>q_*$ 失败。$p>1$ 给 genuine Hölder，$p<1$ 给 genuine higher-order。

---

## 9. Coderivative / derivative criteria：充分、必要、等价边界

### 9.1 Metric regularity：有限维 limiting coderivative 是 iff

设 $X,Y$ finite-dimensional，$\operatorname{gph}F$ 在参考点 locally closed，
$D^*F$ 由 limiting normal cone 定义。Mordukhovich criterion 为
\[
F\text{ metrically regular}
\iff (D^*F(\bar x|\bar y))^{-1}(0)=\{0\}, \tag{MC}
\]
即
\[
0\in D^*F(\bar x|\bar y)(y^*)\Longrightarrow y^*=0.
\]

特别注意：这是 coderivative relation 的 inverse 在 0 的值。
$D^*F(\bar x|\bar y)(0)=\{0\}$ 则是 $F$ 自身 Aubin property 的判据，
不是 $F$ metric regularity 的同一句话。

**原始来源：**
B. S. Mordukhovich，
*Complete characterization of openness, metric regularity, and Lipschitzian properties of multifunctions*，
Trans. AMS 340 (1993), 1--35，
[AMS official page](https://www.ams.org/journals/tran/1993-340-01/S0002-9947-1993-1156300-4/)。
Dontchev--Quincampoix--Zlateva
[journal PDF](https://www.heldermann-verlag.de/jca/jca13/jca0526_b.pdf)，pp. 2--3，
明确重述 finite-dimensional criterion。

### 9.2 无限维：不能无条件搬运 point criterion

Banach-space 中，邻近图点的 graphical derivative / Fréchet coderivative 下界通常先给
sufficient condition；单点 limiting-coderivative iff 需要 Asplund 结构及适当
compactness/normal-compactness 假设，或改用 mixed coderivative。

- Primary boundary source：B. S. Mordukhovich, Y. Shao，
  *Stability of set-valued mappings in infinite dimensions: point criteria and applications*，
  [SIAM official DOI page](https://epubs.siam.org/doi/10.1137/S0363012994278171)。
- Dontchev--Quincampoix--Zlateva Theorem 1.2：Banach 情形给上界/充分性；
  $\dim X<\infty$ 时得 necessity/equality；$X,Y$ 均有限维时还可用 convexified derivative。

### 9.3 Metric subregularity：基本 MR test 不是必要条件

(MC) 推出 metric regularity，故当然充分于 subregularity，但过强。
$F(x)=|x|$ 在 $(0,0)$ strong subregular 而不 metric regular，故不满足 (MC)。
普通 subregularity 没有可无条件复制 (MC) 形状的 basic limiting-coderivative iff；
现有判据要用 outer/directional coderivatives、斜率或邻域条件，并保留各自假设。

### 9.4 Strong subregularity：graphical derivative 与 coderivative 不对称

Primary source：Cibulka--Dontchev--Kruger，
[author PDF](https://arxiv.org/pdf/1701.02078)。

1. Theorem 5.1，pp. 13--14：若 $\dim X<\infty$，
   \[
   F\text{ strongly subregular}
   \iff DF(\bar x|\bar y)^{-1}(0)=\{0\}.
   \]
   若 $X,Y$ 均有限维，还得到 exact-modulus equality；一般 Banach 情形只保留单向界。
2. Theorem 5.2，pp. 14--15：若 $\dim X<\infty$，Fréchet coderivative inner norm
   给 sufficient upper bound；仅在 graph locally convex 时 equality。
3. 同文 p. 15 的 strict witness：$F(x)=\{x,-x\}$ 的 strong-subregularity modulus
   为 1，但 Fréchet-coderivative bound 为 $+\infty$。
4. 同文 pp. 15--16：
   \[
   \operatorname{gph}F=\{(1/k,0):k\in\mathbb N\}\cup\{(0,0)\}
   \]
   在 $(0,0)$ 不 strongly subregular，但 limiting normal 为 $\mathbb R^2$，
   使相应 limiting-coderivative inner-norm 条件呈有限值。
   因而 limiting coderivative “surjectivity”一般甚至不是 strong subregularity 的充分条件。

### 9.5 Strong metric regularity：coderivative 还缺局部唯一性

有限维 (MC) 只检测 metric regularity / inverse Aubin 稳定性，不检测 inverse localization
是否单值。要得到 strong metric regularity，必须另加局部单值化。
$F(x)=\{x,-x\}$ 是 metric regular、却不 strongly regular 的同一 witness。

---

## 10. 供 B 使用的 strictness witness 索引（非正式 catalog）

| ID | 对象 | 首要用途 |
|---|---|---|
| W-M1 | $\operatorname{gph}A=\{(0,0)\}$ | partial FNE resolvent 不推出 maximal monotone |
| W-M2 | 九十度旋转 $K$ on $\mathbb R^2$ | contraction / inverse Lipschitz 不推出 strong monotone；monotone+Lipschitz 不推出 cocoercive |
| W-P1 | $C=S^1$ 与完整 $N_C$ | prox-regular 不推出未截断 normal hypomonotonicity |
| W-P2 | $f=-|x|$ at $(0,1)$ | hypomonotone localization 不能替代 proximal-subgradient 条件 |
| W-R1 | $F\equiv0$ | subregular 非 strong subregular |
| W-R2 | $F=|x|$ | strong subregular 非 metric regular；MR coderivative test 非必要于 subregularity |
| W-R3 | $F(x_1,x_2)=x_1$ | metric regular 非 strong subregular |
| W-R4 | $F(x)=\{x,-x\}$ | MR + strong subregular + isolated reference fiber 不推出 strong regular；Fréchet bound strict |
| W-Q1 | $F_p(x)=\operatorname{sgn}(x)|x|^p$ | sharp Hölder / higher-order exponent 与 modulus convention |
| W-C1 | $\{(1/k,0)\}\cup\{(0,0)\}$ | limiting coderivative condition 不充分于 strong subregularity |

## 11. 尚缺但不阻塞核心 atlas

1. Center-only linear openness 与 around-linear openness 的最简、量词完全展开的文献反例。
2. Mordukhovich--Shao 无限维 point criteria 中各 PSNC/SNC/mixed-coderivative 版本，
   应由主 atlas 按最终选定的 Banach/Asplund 范围逐条摘录，不能压成无条件箭头。
3. Hilbert-space prox-regular set 的 proximal/limiting normal 及截断 convention
   需要主 atlas 统一符号；本审计只确认截断不可省。

