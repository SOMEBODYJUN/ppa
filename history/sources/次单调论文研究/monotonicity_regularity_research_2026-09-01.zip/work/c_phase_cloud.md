# C-stage phase cloud：canonical object × reference/residual observations

> 状态：C 阶段数据抽取稿；输入仅为 `research/theory_atlas.md`、
> `research/gap_examples.md` 与六份 `work/c_gx*.md` 独立复算账本。
> 本文件不重新证明各卡，不把 implication 当数据点，也不回答
> monotonicity–regularity “跷跷板”是否存在。

## 0. 观测单位、签名编码与比较边界

Phase-cloud 的最小单位不是一个术语，也不是一个 `GX` 编号，而是

\[
  \textbf{canonical mapping/object}
  \times \textbf{reference graph point}
  \times \textbf{tested residual/target}
  \times \textbf{scope/step}.
\]

因此，同一算子在不同 target、不同 residual 或不同 graph restriction 下可以有多条
observation，但不增加 canonical-object 权重。反过来，即使来自同一组集合，
set-intersection mapping、primal normal sum 与 Douglas–Rachford residual 公式不同，
仍是不同 observation mappings，不能合并性质。

### 0.1 Compact signature legend

| 字段 | 代码 | 精确含义 |
|---|---|---|
| input-scaled graph defect | `M+μ`, `M0`, `Hσ`, `H∞` | sharp strong modulus \(\mu>0\)；monotone且 \(m_*=0\)；sharp hypo violation \(\sigma\)；在打印 scope 内无 finite hypo modulus |
| output-scaled graph defect | `C+β`, `C0`, `CHη`, `CH∞` | sharp coco modulus \(\beta>0\)；best comonotone coefficient 0；sharp cohypo violation \(\eta\)；无 finite cohypo modulus |
| degenerate / type | `GV`, `N/A` | graph inequality 由零差分而 vacuous；domain/codomain 不同，Hilbert endomorphism graph/RL 坐标不适用 |
| Cayley | `C(L)`, `Hγ(L)`, `Iγ`, `COLL`, `REL` | reflected resolvent Lipschitz exponent 1、exact \(L\)；genuine maximal Hölder exponent \(\gamma<1\)；subunit exponent仅由 bounded window/range继承；Minty zero-denominator collision；只有 relation、未形成单值 Cayley map |
| coverage / multi-point | `MM`, `MCyc`, `nCyc`, `NM`, `Para`, `Rect`, `VI-P/Q` | maximally monotone；maximal cyclic；exact finite cyclic level；nonmaximal；paramonotone；rectangular；VI pseudo/quasi 标签 |
| regularity | `MRq`, `MSRq`, `SMRq`, `SMSRq` | residual-exponent convention 下的 two-target / fixed-target / single-valued-localization / isolated fixed-target性质；省略 \(q\) 时 \(q=1\) |
| centered | `HREG`, `UHREG` | fixed-input centered coverage；不等同于 MSR/MR |
| vacuity | `DV`, `BST`, `IBP`, `RJ`, `RE`, `FV` | domain-vacuous；big-solution trivial；inverse-branch pinning；residual jump；residual escape/graph isolation；local full-value triviality |
| residual | `OP`, `SUM`, `FP`, `SET`, `NZT`, `PPA` | canonical operator residual \(d(\bar y,F(x))\)；primal inclusion/normal-sum residual；fixed-point residual \(I-T\) 或 \(I-J\)；set-feasibility max-distance residual；nonzero target；PPA state/distance recurrence |

`H∞/CH∞` 总是带 `loc/glob` scope；`Iγ` 不作为 genuine Hölder Cayley
observation。Modulus 0 必须和机制一起读，不能与正 displacement rate 混为一类。

## 1. Canonical weighting 与 anti-duplication

这里的 weight 只用于后续去重与敏感性分析，不是“理论强度分数”，也不是概率。

| weight | 使用规则 | 对象 / observation |
|---:|---|---|
| `w_can=1` | 一个独立 canonical mapping/object 的总质量；不同 reference/residual rows 共享这一质量 | 每个无 alias 的 GX 默认如此；同对象多行不得逐行各算 1 |
| `w_can=0` | alias、stepsize、restriction、reference 或 derived residual observation；保留性质但不新增 object count | 下表 alias groups 与所有 `↳` rows |
| `w_emp=1` | 非 vacuous、非反向校准的显式 observation；用于普通 anomaly 查询 | 默认，仅表示可作为独立落点读取 |
| `w_emp=0` | 该轴只由 graph/domain vacuity、big solution 或 locally full value 支撑；只作逻辑/量词压力测试 | 标有 `GV`，或 regularity 仅 `DV/BST/FV` 的相应轴；不抹掉该对象其他非vacuous坐标 |
| `w_emp=0.25` | 按目标 exponent 反向设计的 coupled construction；只作 attainable/obstruction 见证 | **GX-071 / CP-01** 与 **GX-072 / CP-02** |
| `w_emp=0.5` | 明确工程化、但未把 regularity exponent 反向接线到目标 \(\gamma q\) 的 mechanism probe | GX-073 的 anchored/all-pairs probe；必要时可在敏感性分析中单列 |

`w_can=0` 只禁止把一条 `↳` row 当作第二个独立对象，并不删除该 row 的性质。
做 reference-specific 查询时，应把 canonical object 的单位质量放到所选 reference row；
做 within-object reference 对比时，应作为 paired observation 使用；只有在直接对所有 rows
求和时才把 `↳` 的增量质量置零。一个 canonical object 在同一查询中贡献的总 object mass
至多为 1。`w_emp` 还是 axis-specific：例如一个对象的 regularity 观察可能因 `DV` 取 0，
同时其 nonvacuous graph observation 仍可取 1。

### 1.1 Canonical alias / observation groups

| canonical key | aliases / derived observations | counting rule |
|---|---|---|
| GX-001 | LC-01 / EX-19 / SVG-05 | one operator |
| GX-003 | LC-03 / MGB-03 / MGB-22 | one operator；concave-quadratic interpretation不加权 |
| GX-006 | LC-06 / SVG-11 / MGB-12 | one operator |
| GX-012 | LC-12 / SVG-01 / SVG-02；targets \((0,0)\), \((0,-1)\) | one operator, two reference observations |
| GX-015 | LC-15 / EX-11 / AR-01；global / bounded windows | one operator；window row `w_can=0` |
| GX-016 | LC-16 / EX-13 | one \(\lambda _0\)-scaled family |
| GX-021 | LC-21 / EX-01 / SVG-04 / RM-02 / CP-05；operator / PPA / scaled-gradient residuals | one operator；derived residual rows `w_can=0` |
| GX-032 | MGB-01 / EX-14 | one restricted graph；只接受 \(U=[0,1/16],W=\mathbb R\) |
| GX-033 | EX-16 / SVG-14 / HREG seed | one operator |
| GX-035 | EX-18 / SVG-12 / CDK seed | one relation |
| GX-040 | SVG-06 / RM-04 isolated primal / RM-07 transverse primal | one canonical \(N_{\{0\}}\) operator across ambient observations |
| GX-042 | SVG-10 / RM-04 | \(N_L\) is canonical；\(I-P_L\) is a distinct residual observation, not a new underlying problem |
| GX-046 | SVG-17 / MGB-21 affine output shift | one graph-difference family；target shifts with the output |
| GX-049 / GX-069 | same tangent sets, but \(\Phi\) and DR residual \(G\) are different mappings | keep both formula-level observations；do not treat as replication |
| GX-068 | RM-01 / HREG seed；selected identity branch / full relation | one multifunction；selection rows `w_can=0` |
| GX-070 | DR residual \(G\)；primal \(N_{\{0\}}\) is GX-040 | residual row is distinct；primal alias gets `w_can=0` |
| GX-077 | operator residual / prox fixed-point residual | one operator；FP row `w_can=0` |

CP-01 first sets \(\alpha:=\gamma q\) and then builds the normal update
\(P_\alpha\). CP-02 first sets \(\beta:=q/\gamma-1\), forcing
\(q/(\beta+1)=\gamma\). Their `w_emp=0.25` is mandatory in every later
aggregate; the defining identities cannot be reported as independently discovered coupling.

## 2. Phase table

The table is intentionally signature-dense. Exact derivations remain in the six C ledgers.

### 2.1 GX-001--GX-020: linear/basic Cayley calibrations

| observation | graph defect family / scale | Cayley signature | max / multi-point tags | inverse-stability signature | vacuity | residual |
|---|---|---|---|---|---|---|
| GX-001@\((\bar x,0)\), global | `M0`; output term degenerate \(b=0\) | `C(1)`; global \(\gamma<1\) fail; `Iγ` only bounded | `MM` | `MSRq` all \(q\), \(\kappa=0\); no MR/SMSR | `BST` | OP |
| GX-002@0 | `M+c`, `C+1/c`, global | `C(L)<1`, \(L=\lvert1-\lambda c\rvert/(1+\lambda c)\); tuned \(R=0\) | `MM Para Rect` | SMR/MR/SMSR/MSR, \(q_*=1,\kappa=1/c\) | none | OP |
| GX-003@0 | `Hc`, `CH1/c`, global | expansive `C(L)`, \(L=(1+\lambda c)/\lvert1-\lambda c\rvert\); `COLL` at \(\lambda c=1\) | maximal signed class | all four ordinary, \(\kappa=1/c\) | none | OP |
| GX-004@0 | `M0`, `C0`, pure skew | `C(1)` isometry; \(J\) contracts | `MM`, \(\neg\)Para, \(\neg\)Rect | all four ordinary, \(\kappa=1/\omega\) | none | OP |
| GX-005@0 | `M+μ`, `C+μ/(μ²+ω²)` | strict contraction `C(\sqrt{D_-/D_+})` | `MM Para Rect` | all four ordinary, \(\kappa=(\mu^2+\omega^2)^{-1/2}\) | none | OP |
| GX-006@0 | `M0`, `C+1/c`; kernel | `C(1)` fixed kernel direction | `MM Para Rect` | MSR \(\kappa=1/c\); no MR/SMSR | none; zero nonisolated | OP |
| GX-007@0 | `H1/2`, `CH∞`, global | expansive `C(\sqrt{1+\lambda^2}+\lambda)` | maximal signed class | MSR \(\kappa=1\); no MR/SMSR | none; zero nonisolated | OP |
| GX-008@0 | `Hc`, `CH1/c`, indefinite | expansive `C(L)`, \(L=(1+\lambda c)/\lvert1-\lambda c\rvert\); \(J\) may contract; critical `COLL` | maximal signed class | all four ordinary, \(\kappa=1/\min\{c,d\}\) | none | OP |
| GX-009@0 | strict `M0`, `C+1`, global | `C(1)` only as tail supremum | `MM Para Rect` | no power/genuine-gauge MSR; no MR/SMR despite isolated zero | none; nonclosed range | OP |
| GX-010@\((0,0)\) | `M+μ`, `C0`; vertical values | `C(1)` although \(J\) contracts | maximal strongly monotone | all four ordinary, \(\kappa=1/\mu\) | finite positive-side witness | OP |
| ↳ GX-010@\((0,\bar y<0)\) | same canonical graph | same | same | all four local moduli \(0\) | `IBP` | NZT |
| GX-011@0 | `M0`, `C+1` | `C(1)` fixed ray | `MM Para Rect` | MSR \(\kappa=1\); no MR/SMSR | none; zero nonisolated | OP |
| GX-012@\((0,0)\) | `M0`, `C0` | `C(1)`, \(R=\lvert\cdot\rvert\) | `MCyc` | MSR/gauge-MSR \(\kappa=0\); no MR/SMSR | `DV+BST` | OP |
| ↳ GX-012@\((0,-1)\) | same canonical graph | same | same | all four and every finite gauge have infimum \(0\) | `IBP+RJ` | NZT |
| GX-013@0, natural domain | `M+μ`, `C+1/μ` | contraction `C(L)`, \(L=\lvert1-\lambda\mu\rvert/(1+\lambda\mu)\); tuned \(R=0\) | `NM` | SMSR/MSR \(\kappa=1/\mu\); no MR/SMR | none; target coverage missing | OP |
| GX-014@0, bounded domain | `M0`; output term degenerate | `C(1)` and all subunit `Iγ`, \(L_\gamma=2^{1-\gamma}\) | `NM` | MSR/gauge-MSR \(0\); no MR/SMSR | `DV+BST` | OP |
| GX-015@central zero, step \(\lambda _0\) | `H(1/λ₀)`, `CH∞`; scale tied to \(\lambda _0\) | genuine `Hα(2^{1-α})`; unique global exponent \(\alpha\) | maximal signed class | all four ordinary locally, \(\kappa=\lambda _0\) | none; local branch | OP |
| ↳ GX-015@zeros \(\pm1\) | same global graph | same | same | all four ordinary, \(\kappa=\lambda _0(1+\alpha)/(1-\alpha)\) | none; separate branch | OP |
| GX-016@0 | strict `M0`, `C+λ₀` | `C(1)` plus all subunit `Iγ` from bounded range | `MM` | `MR_{1/3}` \((24\lambda _0)^{1/3}\); `MSR_{1/3}/SMSR_{1/3}` \((6\lambda _0)^{1/3}\); no ordinary | none | OP |
| GX-017@0 | strict `M0`, `C+7/9` | `C(1)` plus all subunit `Iγ`; exact subunit \(L\) optimization open | `MM` | `MR_{1/3}` \(2\); fixed-target \(2^{1/3}\); no ordinary | none | OP |
| GX-018@0 | `H∞`, `CH1` | step 1: no global exponent, local `C(1)`; other steps fold/Lipschitz by regime | set-valued relation | `MR_{1/3}` \(2\); fixed-target \(2^{1/3}\); no ordinary | none | OP |
| GX-019@0, bounded graph | `H1/3`, `CH3` | all exponents `Iγ`; `COLL` at \(\lambda=3\) | `NM` | all four ordinary, \(\kappa=3\) | none | OP |
| GX-020@zero set, global law | `M0`, `C+1` | `C(1)`; at \(\lambda=1\) all subunit `Iγ` | `MM` | global MSR \(1\); no MR/SMSR | zero nonisolated | OP |
| ↳ GX-020@interior zero | same | same | same | local MSR infimum \(0\) | `BST` | OP |
| ↳ GX-020@boundary zero | same | same | same | local MSR \(1\), nonvacuous; no MR/SMSR | none | OP |

### 2.2 GX-021--GX-039: power, gauge, branch and oscillation observations

| observation | graph defect family / scale | Cayley signature | max / multi-point tags | inverse-stability signature | vacuity | residual |
|---|---|---|---|---|---|---|
| GX-021@0, operator | strict `M0`; global `C0`, local `C+1/(3δ²)` | global `C(1)`; subunit global fail | `MCyc` | `MR_{1/3}` \(2^{2/3}\); fixed-target \(1\); no ordinary | none | OP |
| ↳ GX-021@0, \(G_\lambda=I-J_{\lambda F}\) | same underlying operator | derived residual | same | fixed-point `MSR_{1/3}` modulus \(\lambda^{-1/3}\) | none | FP |
| GX-022@0 | global `M0,C0`; local strong, no local positive coco | global `C(1)`; subunit fail | `MM` | all four ordinary infimum \(0\); fixed-target \(q_*=2,\kappa=1\); no two-target \(q>1\) | none; higher-order flattening | OP |
| GX-023@0 | strict `M0`, `C+e²/4` | global `C(1)` only | `MM` | no positive power; exact log-gauge fixed \(1\), pairwise \(2\); no ordinary | none | OP |
| GX-024@0 | global `M0,C0`; local strong, no local coco | global `C(1)` only | `MM` | all four ordinary infimum \(0\); every finite fixed-target \(q\) with infimum \(0\); exact super-power gauge \(1\), but no pairwise \(q>1\)/same gauge | none | OP |
| GX-025@0 | `M0,C0`; neither local strong nor local coco | `C(1)`; tuned \(\lambda=1\): all subunit `Iγ` | `MM` | fixed/pairwise \(q_*=1-c\); fixed \(\kappa=1\), pair exact constant unresolved; no ordinary | none | OP, exact gauge \(\phi_+\) |
| GX-026@0 | same scalar defect/Cayley signature as GX-025 | same | `MM` | same complete power signature; exact gauge \(\phi_-\), cross-gauge failure | none | OP, exact gauge \(\phi_-\) |
| GX-027@0 | `M0,C0` on every two-sided zero window | global `C(1)` only | `MM` | `SMR_{1/2}/MR_{1/2}/SMSR_{1/2}/MSR_{1/2}`, all \(\kappa=1\); no ordinary; centered \(q=1/2\) only | none | OP |
| GX-028@0 | local `H(2δ)`, `CH∞` | full graph `COLL`; small branch `C((1+2λδ)/(1-2λδ))` | nonmonotone relation | fixed `MSR_{1/2}/SMSR_{1/2}` \(1\); no MR at any exponent | none | OP |
| GX-029@\(((0,\bar z),(0,0))\) | `M0`; global `C0`, local coco | global `C(1)` from free coordinate | maximal monotone | `MSR_{1/3}` \(1\); no SMSR/MR | none; zero nonisolated | OP |
| GX-030@central zero, critical step \(\lambda=1\) | global `H1`, `CH∞` | genuine local `H_{1/3}(2^{5/3})`; no global exponent | nonmonotone full-domain | all four ordinary locally, \(\kappa=1\) | none | OP |
| ↳ GX-030@zeros \(\pm1\) | same global graph; local positive slope 2 | step-dependent as above | same | all four ordinary locally, \(\kappa=1/2\) | none | OP |
| GX-031@central zero | `H(1/λ₀)`, `CH∞` | genuine maximal `Hα`; \(L_\gamma=2^{1-\gamma}\) for \(\gamma\le\alpha\) | maximal signed class | all four ordinary, \(\kappa=\lambda _0\) | none | OP |
| ↳ GX-031@zeros \(\pm1\) | same | same | same | all four ordinary, \(\kappa=\lambda _0(1+\alpha)/(1-\alpha)\) | none | OP |
| GX-032@whole exact LT restriction | `H∞`, `CH1/2` on \(U=[0,1/16]\) | `C(3)`; subunit only `Iγ`; sharpness driven by \(t+s\uparrow1/2\) | restricted LT graph | reference-specific regularity deferred to next row | none on graph axis | restricted Cayley graph |
| ↳ GX-032@\((0,0)\) | same restricted canonical graph | local-at-zero Cayley is Lipschitz | same | fixed \(q_*=2,\kappa=1\); ordinary MSR/SMSR infimum \(0\); no MR/HREG | finite one-sided branch; not pure vacuity | OP |
| GX-033@0 | `H1`, `CH∞` | \(\lambda<1\): expansive `C((1+λ)/(1-λ))`; \(\lambda\ge1\): `COLL` | nonmonotone | SMSR/MSR \(1\); no MR/SMR/HREG | none | OP |
| GX-034@0 | local `H∞,CH∞` | anchored `C(L_{anc}<1)` but every all-pairs exponent `COLL` | single-valued oscillatory graph; Cayley relation folds | SMSR/MSR \(1\); no MR/SMR; HREG=UHREG \(1/3\) | none | OP + centered |
| GX-035@0 | local `H∞,CH∞` | every step `COLL` | two-branch relation | MR/MSR/SMSR \(1\), no SMR; HREG=UHREG \(1\) | none | OP |
| GX-036@\((0,0)\) | local `H∞,CH∞` | `REL+COLL` | vertical slab | MR/MSR all exponents, modulus \(0\); no SMSR/SMR | `FV+BST` | OP |
| GX-037@0 | local `H∞,CH∞` | every step all-pairs `COLL`; anchored depends on \(\lambda\) | set-valued inverse oscillation | SMSR/MSR \(1\); `MR_{1/2}` yes (endpoint constant unresolved), no ordinary MR; HREG \(1\), no UHREG | none | OP + centered |
| GX-038@0 | local `H∞,CH∞` | `REL+COLL` | closed vertical-fiber relation | `MR_{1/2}=MSR_{1/2}=1`; no SMSR/SMR; HREG=UHREG \(0\) | centered vertical-fiber triviality; zero nonisolated | OP |
| GX-039@0, local | local `M+1,C+1`; global `M0,C+1` | global `C(1)` only | `MM` | all four ordinary locally, \(\kappa=1\) | none | OP |
| ↳ GX-039@global growth | same operator | same | same | every fixed global power EB fails by saturation | none | OP |

### 2.3 GX-040--GX-052: multifunction, normal and set-feasibility observations

| observation | graph defect family / scale | Cayley signature | max / multi-point tags | inverse-stability signature | vacuity | residual |
|---|---|---|---|---|---|---|
| GX-040@\((0,\bar y)\) | input-side arbitrary strong is `GV`; `C0` | global `C(1)`, \(R=-I\) | `MCyc` | all four ordinary exact infimum \(0\) | graph `GV`; mapping `DV`; inverse `IBP` | OP |
| GX-041@\((0,0)\) | all pairwise labels `GV` | singleton Minty domain; RL vacuous | `NM` | MSR/SMSR \(0\); no MR/SMR | `GV+DV` | OP |
| GX-042@\((\bar x,0)\), \(N_L\) | `M0,C0` | `C(1)` orthogonal reflection | `MCyc` | MSR \(0\); no MR/SMSR | `DV+BST` | OP |
| ↳ GX-042, \(G=I-P_L\) | `M0,C+1` | `C(1)` fixed \(L\)-direction | residual observation | MSR \(1\); no MR/SMSR | none; zero nonisolated | FP |
| GX-043@any graph point | local/global `H∞,CH∞` | `REL+COLL` | full-domain multifunction | MR/MSR \(1\); no SMSR/SMR | none; genuine target uniformity | OP |
| GX-044@\((0,0)\) | local `H∞,CH∞` | `REL+COLL` | branch union | MSR \(0\), no MR/SMSR; HREG=UHREG \(1\) | `BST` only on MSR axis | OP + centered |
| GX-045@\((\bar x,0)\), full \(N_{S^1}\) | full cone `H∞,CH∞` | `REL+COLL` | nonconvex full normal | MSR \(0\); no MR/SMSR | `DV+BST` | OP |
| ↳ GX-045, \(\lvert t\rvert\le r_0\) | sharp `Hr₀`, still `CH∞` | if \(\lambda r_0<1\), `C((1+λr₀)/(1-λr₀))`; threshold collision | prox-regular truncated branch | reference regularity belongs to full operator row | none on graph axis | restricted OP graph |
| GX-046@\((0,1)\), attentive branch | `M0`; output term degenerate | bounded `C(1)` / `Iγ` | non-prox-regular function at reference | MSR \(0\); no MR/SMSR | `RJ` | NZT |
| ↳ GX-046, two-branch base window \(\lvert x\rvert\le\delta<\lambda\) | `H∞`; local `CHδ` | exact local `C((λ+δ)/(λ-δ))`; global/full graph `COLL` | same canonical graph | same target signature | none on graph axis | restricted NZT |
| GX-047@0, transverse axes \(\Phi\) | `N/A` | `N/A` | transversal set pair | all four ordinary \(\sqrt2\) under max output norm | none | SET |
| GX-048@0, identical lines \(\Phi\) | `N/A` | `N/A` | subtransversal, not transversal | MSR \(1\); no MR/SMSR | none; zero nonisolated | SET |
| GX-049@0, tangent line/parabola \(\Phi\) | `N/A`; zero tangent angle | `N/A` | smooth/prox-regular sets, no subtransversality | fixed `MSR_{1/2}/SMSR_{1/2}` \(\sqrt2\); no ordinary/MR | none | SET |
| GX-050@0, zero-angle subspaces \(\Phi\) | `N/A`; Friedrichs angle 0 | `N/A` | trivial normal intersection but nonclosed sum | no power MSR/SMSR for any \(q>0\); no MR | none; infinite-dimensional nonclosed angle | SET |
| GX-051@0, isolated component | `N/A` | `N/A` | local isolated intersection, not transversal | local MSR/SMSR \(1\); no MR/SMR | none | SET |
| ↳ GX-051@bounded set containing second intersection | `N/A`; remote quadratic tangency | `N/A` | same set pair | bounded/global linear regularity fails | none | SET |
| GX-052@0, isolated point | `N/A` | `N/A` | local isolated intersection | local MSR/SMSR \(1\); no MR/SMR | none | SET |
| ↳ GX-052@bounded/global | `N/A`; asymptotic contact | `N/A` | same set pair | bounded LR with safe \(\kappa_R\); global LR fails | none | SET |

### 2.4 GX-053--GX-077: generalized classes, algorithm residuals and calibrated constructions

| observation | graph defect family / scale | Cayley signature | max / multi-point tags | inverse-stability signature | vacuity | residual |
|---|---|---|---|---|---|---|
| GX-053@whole restricted graph, critical step | global-on-domain `H1`, `CH∞` | genuine endpoint `H_{1/2}(2)` driven by \(x,y\uparrow1/2\); subcritical `C`; supercritical `COLL` | proper-domain scalar graph; displayed Spingarn formula only | at endpoint \((1/2,-1/4)\): ordinary MSR/SMSR \(1\), no two-sided MR | none | restricted Cayley/NZT |
| ↳ GX-053@\((0,0)\) | same canonical graph | local zero branch is ordinary Lipschitz at the critical step | same | fixed `MSR_{1/2}/SMSR_{1/2}` \(1\); no MR | none | OP |
| GX-054@0 | global `H∞`; local `CH∞` | every global step `COLL`; small branch `C` | nonmonotone | `MR_{1/3}` \(2^{2/3}\); fixed \(1\); no ordinary | none | OP |
| GX-055@0 | local `H∞`, global `CHε²` | if \(\lambda>\varepsilon^2\), `C((λ+ε²)/(λ-ε²))`; otherwise collision/blow-up | disconnected proper-domain graph | every fixed-target power MSR/SMSR infimum \(0\); no MR | `RE` | OP |
| GX-056@0 | `H∞`, `CHδ` on restricted graph | \(\lambda>\delta\): `C((λ+δ)/(λ-δ))`; all subunit `Iγ` on bounded clusters | nonclosed away from isolated reference | every fixed-target power MSR/SMSR \(0\); no MR | `RJ` | OP |
| GX-057@\((0,0)\), product residual | local `H∞,CH∞` | all-graph RL1 fails | engineered product | fixed `MSR_{1/2}/SMSR_{1/2}` \(1\); no ordinary/MR | none | OP |
| ↳ GX-057@graph endpoint \(((1/2,0),(-1/4,0))\) | same canonical product | output-localized genuine maximal `H_{1/2}(2)` | same | zero-target regularity not attached to this graph reference | none | restricted Cayley graph |
| GX-058@0 | `M0,C0` | global `C(1)` | `MM Rect`, \(\neg\)Para | all four ordinary locally, \(\kappa=1\) | none | OP |
| GX-059@0 | strict `M0,C0` | global `C(1)` (tail block limit) | `MM Para`, \(\neg\)Rect | all four ordinary globally, \(\kappa=1\) | none | OP |
| GX-060@0 | `M0,C0` | global `C(1)` | `MM`, \(\neg\)Para, \(\neg\)Rect | no power/genuine-gauge MSR; no MR/SMR | none; nonclosed range | OP |
| GX-061@0 | `M0,C0` | global `C(1)` | same neither-cell, independently oriented | no power/genuine-gauge MSR; no MR/SMR | none; nonclosed range | OP |
| GX-062@0 | `M+1/2,C+1/2` | strict contraction `C(L_{62}<1)` | maximal `3Cyc`, not `4Cyc`; Para/Rect | all four ordinary \(1\) | none | OP |
| GX-063@0 | `M+1/√2,C+1/√2` | strict contraction `C(L_{63}<1)` | maximal `4Cyc`, not `5Cyc`; Para/Rect | all four ordinary \(1\) | none | OP |
| GX-064@flat Cayley point, \(\lambda=1\) | `H1,CH∞`; `VI-P/Q` | genuine local all-pairs `H_{1/3}(4\sqrt[3]3)`; anchored constant \(2\sqrt[3]6\); no global subunit | nonmonotone VI map | no regularity coordinate attached to this Cayley germ | N/A | Cayley germ |
| ↳ GX-064@\((\pi/2,3)\) | same canonical graph | same step family | same | fixed `MSR_{1/2}/SMSR_{1/2}` \(\sqrt2\); no MR/SMR | none; local branch at range endpoint | NZT |
| GX-065@left graph endpoint, critical \(\lambda=1/2\) | global-on-domain `H2,CH∞`; `VI-Q`, not `VI-P` | genuine endpoint `H_{1/2}(2\sqrt2)`; supercritical `COLL` | restricted VI graph | no zero-target regularity attached to this Cayley germ | none | Cayley germ |
| ↳ GX-065@\((0,0)\) | same canonical graph | subcritical/local zero branch is Lipschitz | same | fixed `MSR_{1/2}/SMSR_{1/2}` \(1\); no MR/SMR | none | OP |
| GX-066@0 | `H1,CH1`, bounded line | expansive `C(L)`, \(L=(1+λ)/\lvert1-λ\rvert\); subunit `Iγ`; `COLL` at \(\lambda=1\) | `NM`; neither VI-P nor VI-Q | all four ordinary \(1\) | none | OP |
| GX-067@\((\bar x,0)\) | `M0,C0` | global `C(1)` | `MCyc Para Rect`; prox-regular convex set | MSR/gauge-MSR \(0\); no MR/SMSR/HREG | `DV+BST` | OP |
| GX-068@0, full multifunction | local `H∞,CH∞` | full graph `COLL`; each selection Lipschitz | branch union | fixed `MSR_{1/2}/SMSR_{1/2}` \(1\); no MR; HREG=UHREG \(1\) | none | OP |
| ↳ GX-068, selected identity \(J_1\) | selection only | linear branch | same underlying object | FP-EB \((1+λ)/λ\) | none | FP |
| ↳ GX-068, full resolvent residual | full relation | square branch controls | same | fixed `MSR_{1/2}` asymptotic \(1/\sqrtλ\) | none | FP |
| GX-069@0, DR residual \(G\) | strip `H(2ε/(1-2ε))\to0`; local `CH∞` | local `C(1)` point modulus; no genuine subunit | tangent DR mapping | fixed `MSR_{1/2}` \(1\); no ordinary MR/MSR; no SMSR/HREG | none; fixed set nonisolated | FP |
| ↳ GX-069, tangent primal normal sum | vertical-output graph at \(x=0\) | relation | primal mapping | MSR/SMSR \(0\); no MR/HREG | `DV` | SUM |
| GX-070@0, transverse DR residual \(G\) | `M+sin²θ,C+1` | strict contraction `C(L_{70}<1)` | linear residual | all four + HREG/UHREG, \(\kappa=1/\sin\theta\) | none | FP |
| ↳ GX-070, primal normal sum | alias of GX-040 \(N_{\{0\}}\); input-strong `GV`, `C0` | `C(1)`, \(R=-I\) | `MCyc` | all four + HREG/UHREG infimum \(0\) | `GV+DV+IBP` | SUM |
| GX-071/CP-01, global F + restricted tube | local `H∞,CH∞`; scale defect carried only by RL | genuine restricted `Hγ`; no global RL\(_\gamma\) from tangential identity | reverse-calibrated triangular bijection | global fixed `MSR_q` \(1\); ordinary MSR \(0\); no SMSR/MR/HREG | zero nonisolated; EB nonvacuous | OP, `w_emp=.25` |
| ↳ GX-071, invariant-margin orbit | same | same | same | exact \(r_+=r^{\gamma q}\) after explicit drift margin | none | PPA, `w_can=0` |
| GX-072/CP-02@0 | local `H∞,CH∞` | genuine maximal all-pairs `Hγ`; anchored exponent 1 | reverse-calibrated triangular homeomorphism | fixed `MSR_q/SMSR_q` exact \(K_q\); ordinary modulus \(0\); `MR_γ` but no ordinary MR; HREG/UHREG ordinary \(0\), centered sharp \(q\) | none | OP, `w_emp=.25` |
| ↳ GX-072, invariant orbit | anchored exponent 1 is the orbit-relevant graph observation | same full map | same | actual Q-order \(q\), strictly above mechanical exponent \(\gamma q\) | none | PPA, `w_can=0` |
| GX-073@0 | local `H∞,CH∞`; only universal negative-negative semimonotone region | maximal all-pairs `H_{α/(β+1)}`; anchored exponent \(\alpha\) | engineered set-valued relation | MSR/SMSR \(1\); no MR/SMR; HREG=UHREG \(1\) | none | OP, `w_emp=.5` |
| ↳ GX-073, selected orbit | same | one-step \(\lvert Jx\rvert=\Theta(\lvert x\rvert^\alpha)\) | same | no invariant zero-neighborhood; not a convergence-order observation | none | PPA, `w_can=0` |
| GX-074@0 | `M0`; output term degenerate | identity on bounded discrete domain; all subunit `Iγ` | `NM` | MSR/gauge-MSR \(0\); no SMSR/MR/HREG | `DV+BST`; zero nonisolated | OP |
| GX-075@0 | local `H∞,CH∞` | accumulating `COLL` | closed branch union | MSR/SMSR \(1\); HREG \(1\); no UHREG/MR/SMR | none | OP + centered |
| GX-076@0 | `N/A` (\(\mathbb R^2\to\mathbb R\)) | `N/A` | pure regularity map; graph not locally closed in full product neighborhood | fixed `MSR_{1/2}/SMSR_{1/2}` \(1\); HREG=UHREG \(1\); no ordinary MR/MSR | none | OP/SET-like scalar target |
| GX-077@\((0,0)\), operator | `M0,C0` | global `C(1)` | `MCyc` | all four + HREG/UHREG infimum \(0\) | `IBP+RJ` | OP |
| ↳ GX-077, prox fixed-point residual | same underlying operator | \(J=0\) locally | same | FP-EB exact \(1\); one-step termination | none | FP |

## 3. Anomaly index

本节只列“压缩签名发生分叉”的数据现象。这里的“same graph”均指表中指定的
compressed coordinate 相同；除明确写“同一 canonical operator”外，不声称两图同构。

### 3.1 同一 canonical graph，reference / residual 改变 regularity

| canonical object | observation A | observation B | 数据异常 |
|---|---|---|---|
| GX-010 | target \(0\)：四 core modulus \(1/\mu\) | vertical target \(\bar y<0\)：四 core infimum \(0\) | graph、Cayley 与 maximality不变；inverse 从 kink-Lipschitz 变为 locally constant |
| GX-012 | \((0,0)\)：MSR 0 only，nonisolated | \((0,-1)\)：SMR/MR/SMSR/MSR 皆 0 | 同一 max-cyclic graph 从 `DV+BST` 转为 `IBP+RJ` |
| GX-015 | zero 0：modulus \(\lambda _0\) | zeros \(\pm1\)：\(\lambda _0(1+\alpha)/(1-\alpha)\) | global inverse有三支，但三个 graphical localizations 各自 SMR；binary label不区分条件数 |
| GX-020 | interior zero：MSR infimum 0 | boundary zero：MSR 1 | 同一 global identity \(d(x,S)=\lvert F(x)\rvert\)，local modulus由 solution-set interior/boundary决定 |
| GX-021 | operator residual：endpoint \(q=1/3\), modulus 1 | PPA residual \(I-J\)：same exponent, modulus \(\lambda^{-1/3}\) | 同一 operator 的 residual scaling 改变 modulus，不能当两点 |
| GX-030 | zero 0：ordinary modulus 1 | zeros \(\pm1\)：ordinary modulus \(1/2\) | 同一 critical Cayley graph的 local derivative分支不同 |
| GX-039 | local at zero：四 core modulus 1 | global EB：所有固定 power 失败 | saturation 把 local conditioning 与 global growth分离 |
| GX-042 | operator \(N_L\)：MSR 0, vacuous | residual \(I-P_L\)：MSR 1, nonvacuous | normal-cone residual和projection/fixed-point residual不是同一 mapping |
| GX-045 | full normal cone：no finite hypo/RL | norm-truncated cone：sharp hypo \(r_0\), finite RL iff \(\lambda r_0<1\) | prox-regularity的信息只存在于 output-norm truncated branch |
| GX-046 | attentive output branch：monotone constant | full two-branch graph：no finite hypo，global RL collision；small base-window却有 finite RL | attentive/output localization、base restriction与full graph三种 scope 不可合并 |
| GX-051 | at isolated component：MSR/SMSR 1 | bounded set containing remote tangency：linear regularity fails | pointwise local与bounded-uniform量词分离 |
| GX-052 | local/bounded LR yes | global LR no | remote asymptotic branch只在无界尺度出现 |
| GX-064 | critical Cayley flat point：all-pairs exponent \(1/3\) | target-3 regularity point：fixed-target exponent \(1/2\) | 两个 exponent来自不同 reference/object-side tests，不能配成一个乘积 |
| GX-068 | full operator residual：\(q_*=1/2\) | selected identity FP residual：linear；full FP residual：\(q_*=1/2\) with \(\lambda\)-scaled modulus | branch selection改变 residual order，full relation的最差 branch仍保留平方阶 |
| GX-069/070 | DR residuals：tangent \(q=1/2\) vs transverse linear | associated primal maps：vertical-only vs \(N_{\{0\}}\) | 同一算法名下 residual/primal coordinate都随 geometry 改变；不可只比 binary SMSR |
| GX-077 | operator residual：四 core infimum 0 | prox FP residual：EB 1、一阶终止 | `IBP+RJ` 的 operator modulus 0 与 nonvacuous FP modulus 1 同时存在 |

### 3.2 相同 compressed graph signature，regularity 完全不同

| shared graph/Cayley signature | objects | regularity split |
|---|---|---|
| `M+μ,C+1/μ` 的正直线几何 | GX-002 vs GX-013 | full line SMR/MR/SMSR/MSR \(1/\mu\)；proper ray只有 SMSR/MSR，negative-target coverage destroys MR/SMR |
| `M0,C+1,C(1)`（按 sharp scalar moduli） | GX-006, GX-011, GX-009 | GX-006/011 有 exact linear MSR；GX-009 isolated zero 却连任何 power/vanishing-gauge MSR 都没有，差异来自 infinite-dimensional nonclosed range |
| `M0,C0,C(1)` | GX-004, GX-042 normal, GX-060/061, GX-067, GX-077 | 分别为 full regularity；vacuous MSR only；no power regularity；vacuous MSR only；四 core infimum 0 by branch pinning/residual jump |
| maximally monotone、strong modulus 0、Cayley nonexpansive | GX-016/017/021 vs GX-023 | 前三者有 sharp \(q=1/3\) power regularity；GX-023 没有任何 positive power，只剩 logarithmic gauge |
| same complete scalar defect/power envelope | GX-025 vs GX-026 | ordinary与power签名完全相同，但 exact fixed-target gauges \(\phi_+,\phi_-\) 互不支配 |
| local `H∞,CH∞` + all-pairs collision | GX-034, GX-035, GX-037, GX-075 | SMSR/MR/HREG组合各不相同：GX-034 SMSR+HREG但无MR；GX-035 MR+SMSR但无SMR；GX-037 only fractional MR plus HREG-not-UHREG；GX-075 linear SMSR+HREG但无UHREG/MR |

### 3.3 相同 regularity signature，graph geometry 完全不同

| shared regularity observation | objects | graph-side spread |
|---|---|---|
| all four ordinary, modulus 1 | GX-004 with \(\omega=1\), GX-058, GX-059, GX-062, GX-063, GX-066, GX-039(local) | pure skew `M0,C0`; rectangular-not-Para; Para-not-Rect; positive 3/4-cyclic strong maps; negative line `H1,CH1`; local positive identity |
| all four ordinary, infimum 0 | GX-040, GX-012@\(-1\), GX-077 | graph/domain-vacuous constant inverse；pinned normal branch；nonvacuous residual jump + constant inverse |
| MSR 1 but no MR/SMSR | GX-007, GX-011, GX-042 residual, GX-048 | sharp hypo with no cohypo；cocoercive max map；projection residual；type-inapplicable identical-set mapping |
| fixed/two-target \(q=1/3\) family | GX-016, GX-017, GX-018, GX-021, GX-054 | monotone+coco；monotone+coco；no finite hypo but finite cohypo；max cyclic cubic；globally no finite hypo and Minty collisions |
| fixed \(q=1/2\), ordinary failure | GX-028, GX-049, GX-053, GX-057, GX-065, GX-068, GX-069, GX-076 | nonmonotone scalar fold；set tangency (`N/A`)；critical hypo endpoint；product `H∞/CH∞`；VI-quasi graph；branch relation；DR residual；different-dimensional map |
| exact ordinary modulus 1 with MR+SMSR but no SMR | GX-035 | 说明 MR+SMSR 的 conjunction本身仍不能检测 inverse branch uniqueness |

### 3.4 “both strong” observations（只按指定坐标）

这里把“graph strong”操作化为：正 input/output quadratic modulus或 strict Cayley
contraction；把“regularity strong”操作化为非vacuous ordinary isolated + target-uniform
stability。它不是全序定义。

| observation | graph coordinate | regularity coordinate | exclusion / qualifier |
|---|---|---|---|
| GX-002, GX-005 | positive primal+dual moduli；strict \(R\)-contraction | nonvacuous SMR/MR/SMSR/MSR | full-domain linear controls |
| GX-062, GX-063 | positive strong+coco；strict Cayley contraction；finite cyclic levels | all four modulus 1 | cyclic order仍是额外标签，未被“both strong”吸收 |
| GX-070 residual | strong \(\sin^2\theta\), coco 1, strict Cayley contraction | all four + HREG/UHREG \(1/\sin\theta\) | residual mapping，不是 primal normal sum |
| GX-039 local | local strong+coco 1 | all four local 1 | global saturation observation另列 |
| GX-010 | positive input strong modulus \(\mu\), but `C0` and \(R\)-Lip 1 | all four \(1/\mu\) | only one graph coordinate is strong；vertical branch blocks reflected contraction |
| GX-013 | positive strong+coco | SMSR/MSR only | missing target coverage prevents promotion to target-uniform strong cell |

GX-040 is deliberately excluded: its arbitrary input-side “strong modulus” is `GV`, and its
mapping inequalities are `DV`; it is a logic control, not a nonvacuous both-strong point.

### 3.5 “both weak” observations（ordinary-coordinate screen）

这里的“weak”只表示 ordinary quadratic graph moduli或 ordinary inverse stability退化；
表内同时打印仍然存活的 fractional/gauge性质。

| observation | weak graph coordinate | weak ordinary regularity | surviving lower-order / other coordinate |
|---|---|---|---|
| GX-018, GX-054 | no finite input-scaled hypo globally / locally relevant | no ordinary core properties | both retain exact \(q=1/3\) MR/MSR |
| GX-057 | `H∞,CH∞` | no ordinary core properties | fixed \(q=1/2\) MSR/SMSR |
| GX-068 | `H∞,CH∞`, full RL collision | no ordinary MR/MSR | fixed \(q=1/2\) MSR/SMSR and linear HREG |
| GX-069 residual | local monotonicity defect tends to 0 but no finite cohypo | no ordinary MR/MSR; nonisolated | fixed \(q=1/2\) MSR |
| GX-038 | `H∞,CH∞`, collisions | no ordinary core properties | exact \(q=1/2\) MR/MSR; centered modulus 0 is fiber-trivial |
| GX-009, GX-060, GX-061 | nonnegative graph but zero coercive modulus / tail Cayley norm 1 | no power or genuine-gauge MSR | maximal monotonicity survives; failure is nonclosed range |
| GX-050 | graph/RL `N/A` | no power MSR/SMSR at all | infinite-dimensional zero-angle mechanism |

### 3.6 明确无法压到一维顺序的 coordinate crossings

| crossing | witness observations | independent coordinates exposed |
|---|---|---|
| strong vs coco | GX-010 vs GX-006 | positive input modulus / vertical multivaluedness vs positive output modulus / kernel |
| paramonotone vs rectangular | GX-058, GX-059, GX-060/061 | Rect-not-Para；Para-not-Rect；neither，在相同 max-monotone universe 内 |
| cyclic level vs scalar coercivity | GX-062 vs GX-063 | 3-cyclic/4-cyclic level、strong modulus与inverse modulus是三个数 |
| maximality / coverage | GX-002 vs GX-013 | graph line inequality相同，full-domain Minty coverage不同 |
| target uniformity vs isolation | GX-043 vs GX-013/033 | MR-without-SMSR vs SMSR-without-MR |
| conjunction vs branch uniqueness | GX-035 | MR+SMSR仍不推出SMR |
| MSR vs centered coverage | GX-033, GX-068, GX-075, GX-076 | MSR/HREG/UHREG在四种组合与不同exponent下分叉 |
| exponent vs gauge | GX-023, GX-024, GX-025/026 | no power + log gauge；all powers fixed + super-gauge；same power envelope + incomparable gauges |
| anchored vs all-pairs | GX-034, GX-064, GX-072, GX-073 | anchored Lipschitz/Hölder exponent与uniform pairwise exponent/constant不同 |
| local vs bounded vs global | GX-051, GX-052, GX-039 | remote tangency/asymptotic branch/saturation不被local signature检测 |
| same-space applicability | GX-047--GX-052, GX-076 | regularity可定义但 Hilbert endomorphism inner-product/Cayley坐标是 `N/A` |
| step / restriction dependence | GX-020, GX-025/026, GX-030, GX-045/046, GX-053, GX-064/065 | tuned cancellation、critical flatness、truncation threshold与Minty collision是额外参数轴 |

## 4. Coupled-construction ledger

| object | parameters wired in construction | independently recomputed output | evidentiary use | weight |
|---|---|---|---|---:|
| GX-071 / CP-01 | \(\alpha:=\gamma q\); update set to \(P_\alpha\); residual designed as \(\lvert w\rvert^{1/q}\) | restricted all-pairs exponent \(\gamma\); fixed \(q\)-MSR; exact orbit \(r_+=r^{\gamma q}\) after drift margin | attainability and window/invariance audit only；不可把定义恒等式当 empirical law | `0.25` |
| GX-072 / CP-02 | \(\beta:=q/\gamma-1\), so oscillatory endpoint is \(q/(\beta+1)=\gamma\) | all-pairs exponent \(\gamma\); anchored exponent 1；fixed \(q\)-MSR；actual invariant order \(q\), not \(\gamma q\) | nonsharpness、anchored/all-pairs separation与obstruction test | `0.25` |
| GX-073 / AR probe | \(\alpha,\beta\) tune all-pairs endpoint \(\eta_*=\alpha/(\beta+1)\), but regularity exponent is not wired to \(\eta_*\) | anchored \(\alpha\), all-pairs \(\eta_*\), linear MSR/SMSR, no invariant nonzero orbit | relation/branch/invariance mechanism probe；不进入CP式独立支持 | `0.5` |

Non-coupled controls that should remain visible beside this ledger include: GX-015/031
(genuine Cayley exponent but ordinary local regularity), GX-016/017 (all subunit Cayley
exponents inherited while inverse exponent is \(1/3\)), and GX-053/065 (critical boundary
flatness produces genuine Hölder Cayley, while their zero-reference rows have fractional
fixed-target regularity; these are explicitly different reference observations and have no
declared \(\gamma q\) wiring). This is a provenance distinction, not an inference about a
general relation.

## 5. Algorithm-residual type matrix

| underlying object/problem | OP / primal observation | algorithm residual observation | non-duplicable change |
|---|---|---|---|
| GX-021, \(F=x^3\) | OP: \(q_*=1/3,\kappa=1\) | PPA \(I-J_{\lambda F}\): \(q_*=1/3,\kappa=\lambda^{-1/3}\) | same exponent, different scale/modulus |
| GX-042, subspace | \(N_L\): MSR 0 by `DV+BST` | \(I-P_L\): nonvacuous linear MSR 1 | binary “MSR=yes” hides opposite mechanisms |
| GX-068, branch union | OP: fixed \(q=1/2\) | selected identity FP: linear；full FP: \(q=1/2\) | selection can improve order; full branch set restores worst order |
| GX-069, tangent sets | primal normal sum: modulus-0 `DV`, no MR/HREG | DR \(G=I-T\): sharp \(q=1/2\)-MSR, no linear contraction | primal and DR residual are not exchangeable |
| GX-070, transverse lines | primal \(N_{\{0\}}\): all core 0 by pinning/vacuity | DR residual: all core \(1/\sin\theta\), iteration rate \(\cos\theta\) | same feasibility problem supplies two wholly different phase coordinates |
| GX-071 | OP: \(q\)-MSR on zero line | PPA state recurrence: exact \(\gamma q\) after margin | recurrence was wired; low evidence weight |
| GX-072 | OP: \(q\)-SMSR and fractional two-target MR | PPA: invariant Q-order \(q\) | orbit follows anchored exponent 1 rather than worst all-pairs \(\gamma\) |
| GX-073 | OP: linear MSR/SMSR | selected step scales as \(r^\alpha\) but leaves every small invariant window | one-step scaling is not a convergence order |
| GX-077, \(\partial\lvert x\rvert\) | OP: all four infimum 0 by `IBP+RJ` | prox residual \(I-J\): EB 1, one-step termination | operator modulus 0 and residual modulus 1 are consistent because residuals differ |

## 6. Data-quality flags inherited from C

| flag | affected observation | phase-cloud action |
|---|---|---|
| exact constant unresolved | GX-017 subunit Cayley; GX-025/026 pairwise endpoint; GX-037 \(1/2\)-Aubin | property/exponent retained；constant cell remains interval/unknown |
| B sharpness corrected | GX-056 | use \((1+\delta)/(1-\delta)\) at \(\lambda=1\), not the earlier safe bound |
| anchored/all-pairs ambiguity repaired | GX-064 | store \(4\sqrt[3]3\) all-pairs and \(2\sqrt[3]6\) anchored as separate observations |
| scope correction | GX-046 | full graph global RL fails, but base-local \(\delta<\lambda\) RL is finite; attentive branch is different again |
| tuned-step correction | GX-025/026 | at \(\lambda=1\) subunit global RL survives by tail cancellation, but is inherited |
| C upgrades | GX-037/038, GX-049/069, GX-072/073 | endpoint Hölder MR/MSR or all-pairs upper bounds are now proved, not candidates |
| source-description correction | GX-076 | retain HREG/non-MR source label; mark non-global continuity and failure of full product-neighborhood local closedness |

## 7. Boundary of this extractor

- Tables above expose coordinates, duplicates, reference effects, residual mismatch and unusual
  phase locations. They do not rank observations on a common scalar axis.
- `w_emp` is only a robustness-control knob. No weighted regression, phase slope or trade-off
  conclusion has been computed here.
- Vacuous modulus-zero statements remain in the logical atlas but have zero empirical weight on
  the affected regularity coordinate.
- Algorithm rates are recorded only when C verified the recurrence/invariance statement; an
  error bound or one-step asymptotic alone is not labeled a rate.
- Any final statement about existence, failure or mechanism of a monotonicity–regularity
  compensation pattern belongs to the later integrator, not this file.
