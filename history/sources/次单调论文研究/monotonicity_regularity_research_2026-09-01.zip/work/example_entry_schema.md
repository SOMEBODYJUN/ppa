# Example entry schema for stages B/C

Every final example must carry the following fields so that theory labels can be
discarded and recomputed independently.

## Identity and formulas

- `ID`, purpose/gap cells, source status.
- Space, mapping (F), domain, graph, single/set-valued status.
- (F^{-1}), (\operatorname{zer}F), (J_{\lambda F}),
  (R_{\lambda F}), with parameter exclusions.

## Graph-side recomputation

- Exact (\langle a,b\rangle).
- Sharp/local lower bound and its dependence on (\|a\|,\|b\|,
  \|a+\lambda b\|\).
- Best constants/exponents for strong, hypo-, co-hypo-, cocoercive,
  semimonotone, and other atlas-relevant inequalities.
- Local/global, scale dependence, and failed quantifier when a class fails.

## RL-side recomputation

- Ratio
  \[
  Q_{\lambda,\gamma}(a,b)=
  \frac{\|a-\lambda b\|}{\|a+\lambda b\|^\gamma}
  \]
  with the zero-denominator case handled explicitly.
- Admissible (\lambda,L,\gamma\), domain diameter, local/global, sharp maximal
  exponent, and whether (\gamma<1) is genuine rather than inherited from a
  Lipschitz estimate on a bounded set.

## Regularity-side recomputation

- At every specified ((\bar x,\bar y)): MR, MSR, SMR, SMSR, calmness,
  isolated calmness, Aubin, Hölder/power/gauge variants.
- Exact or asymptotic modulus.
- Exact residual law
  (d(x,S)\) versus (d(0,F(x))\).
- Isolated/nonisolated solution flag, domain-vacuity flag, and whether the
  apparent error bound is trivial.

## Validation record

- Symbolic derivation.
- Numerical grid check when useful (never a proof of a universal statement).
- Source locator for sourced examples.
- Final phase coordinates and any disagreement with the original B label.

