# Subagent B(MAX): anchored RL、algorithmic residual 与幂次复合的显式 gap models

> 状态：**B-stage construction catalog**。本文件不作 literature atlas，也不作 seesaw synthesis。
> 所有 `CANDIDATE` 均须由 C 独立重算；没有把一步上界写成 sharp rate。

## 0. 统一记号与不可伪造的量词边

除非另说，空间为有限维 Euclidean 空间，\(\lambda=1\)。给定 Cayley map
\(R:D\to H\)，令

\[
J=\frac{I+R}{2},\qquad
\Gamma_R=\left\{\left(Jx,x-Jx\right):x\in D\right\}.
\tag{0.1}
\]

于是 \(J=(I+F)^{-1}\) 在 Minty domain \(D\) 上单值，而 \(F\) 本身是函数当且仅当
\(J\) 对参数 \(x\) 单射；否则 \(F\) 是多函数。零点与 fixed points 对应：

\[
u\in\operatorname{zer}F\iff (u,0)\in\Gamma_R
\iff u\in D,\ Ru=u.
\tag{0.2}
\]

本文件区分三种量词：

* `A_γ(p)`（solution-anchored）：\(p\in\operatorname{Fix}R\)，且对 \(x\) 在 \(p\)
  的指定窗口内，\(\|Rx-p\|\le L\|x-p\|^\gamma\)；
* `P_γ(\bar x)`（pointwise）：固定任意 base \(\bar x\)，
  \(\|Rx-R\bar x\|\le L_{\bar x}\|x-\bar x\|^\gamma\)；
* `G_γ(U)`（all-pairs）：同一个 \(L\) 对所有 \(x,y\in U\) 成立。

由平行四边形恒等式，`P_γ(p)` 恰等价于 \(J\) 在 base \(p\) 的 pointwise
additive-FNE inequality。因此，当 \(p\) 是同一个 fixed point 且窗口、selection、常数完全对齐时，

\[
\boxed{A_\gamma(p)\iff P_\gamma(p).}
\tag{0.3}
\]

所以不存在合法的 `A_γ(p) ∧ ¬P_γ(p)` 或反向反例。可分离的是：单一解点与所有 base、
pointwise 非统一常数与统一 all-pairs、local 与 global、以及不同 exponent。

对算法 residual 统一写

\[
E_F(u)=d(0,F(u)),\qquad E_T(x)=d(0,(T-I)(x)),
\tag{0.4}
\]

且每个条目明确 residual 所在坐标。对 single-valued full branch \(T=J_F\)，图点
\(x=u+b\)、\(u=Tx\) 给出

\[
\|u-p\|\le \|x-p\|+\|b\|,
\qquad
\|x-p\|\le \|u-p\|+\|b\|.
\tag{0.5}
\]

因此在同一 branch、同一邻域和同一 fixed/zero set 下，linear \(F\)-MSR 与
\(J_F-I\)-MSR 不能随意分离；下面的分离例必须打印 selection、domain-vacuity 或不同 residual
encoding。

---

## Residual block — \(F\)-MSR、\(T-I\)-MSR、prox-gradient / DR residual 的可分离性

### RM-01 — 两条 resolvent branches：selected residual 可强于 full-map residual

**Purpose.** 显式打印 selection 造成的“表观分离”；full graph 上不能把 selected branch 的 EB
冒充 \(F\)-MSR。

* **空间/mapping：** \(H=\mathbb R\)，在 \(|u|<\delta<1\) 令
  \[
  F(u)=\{u,u^2\},\qquad
  \operatorname{gph}F=\{(u,u)\}\cup\{(u,u^2)\},\qquad S=\{0\}.
  \tag{3.1}
  \]
  \(F^{-1}(b)\) 包含 \(u=b\)；当 \(b\ge0\) 还包含 \(u=\pm\sqrt b\)
  （按局部 domain 截断）。
* **resolvent/reflection：** 对小的 \(x\ge0\)，
  \[
  J_F(x)=\left\{T_1x,T_2x\right\},\quad
  T_1x=\frac x2,\quad
  T_2x=\psi(x):=\frac{-1+\sqrt{1+4x}}2,
  \tag{3.2}
  \]
  \[
  R_1x=0,\qquad R_2x=2\psi(x)-x=\psi(x)-\psi(x)^2.
  \tag{3.3}
  \]
  同一个 Minty input 有两个不同 outputs，故 full graph 不可能满足任何 finite-L RL；
  branch 1 的 \(R_1=0\)，branch 2 则 local Lipschitz。
* **\(F\)-residual：**
  \[
  E_F(u)=\min\{|u|,u^2\}=u^2,\qquad |u|=E_F(u)^{1/2}.
  \tag{3.4}
  \]
  linear MSR 失败，q=1/2 exact。
* **fixed-point residuals：**
  \[
  E_{T_1}(x)=x/2 \quad\Rightarrow\quad \text{linear EB};
  \qquad
  E_{T_2}(x)=x-\psi(x)=\psi(x)^2\sim x^2.
  \tag{3.5}
  \]
  full multifunction residual取 inf，故
  \(E_{J_F-I}(x)=\min(E_{T_1},E_{T_2})\sim x^2\)：linear EB失败，q=1/2。
* **实际迭代/branch：** 固定 branch 1 得 \(x_{k+1}=x_k/2\)；固定 branch 2 得
  \(x_{k+1}=\psi(x_k)=x_k-x_k^2+O(x_k^3)\)，正半轴 invariant 且次线性。
  任意 switching 的 rate 不由任一单 branch label决定。

### RM-02 — quartic smooth problem：canonical \(F\) 与 prox-gradient residual 完全同阶

**Purpose.** 作为“标准假设下不可伪造分离”的负对照。

* **problem/mapping：** \(f(x)=x^4/4\)，\(g=0\)，
  \[
  F=\nabla f,\quad F(x)=x^3,\quad S=\{0\},\quad F^{-1}(b)=P_{1/3}(b).
  \tag{3.6}
  \]
* **PPA resolvent：** \(J_{\lambda F}(x)=u\) 为 \(x=u+\lambda u^3\) 的唯一根；
  \(R=2J-I\) nonexpansive。PPA 满足
  \(x^+=x-\lambda x^3+O(x^5)\)。
* **regularity：** \(|x|=|F(x)|^{1/3}\)，sharp q=1/3；linear MSR失败。
* **prox-gradient：** 对 \(0<\tau\delta^2<1\)，
  \[
  T_{PG}(x)=x-\tau x^3,\qquad
  G_\tau(x)=\tau^{-1}(x-T_{PG}x)=x^3.
  \tag{3.7}
  \]
  所以 \(F\)-residual 与 PG residual **逐点相等**；二者都只有 q=1/3 EB。
* **实际迭代：** 正负小区间 invariant，
  \(|x_k|\sim(2\tau k)^{-1/2}\)。任何声称此例把 \(F\)-MSR 与 PG-EB
  yes/no 分离的标签都是错误的。

### RM-03 — nonsmooth sharp minimum：\(F\)-subregularity modulus 0，而 PG residual modulus非零

* **problem：** \(f=0\)，\(g(x)=|x|\)，
  \[
  F=\partial|\cdot|,\quad
  F(x)=\begin{cases}
  \{1\},&x>0,\\
  [-1,1],&x=0,\\
  \{-1\},&x<0,
  \end{cases}\qquad S=\{0\}.
  \tag{3.8}
  \]
  \(F^{-1}(b)=\{0\}\) for \(|b|<1\)，端点另含半轴。
* **resolvent/reflection：**
  \[
  J_{\lambda F}(x)=\operatorname{sgn}(x)(|x|-\lambda)_+,\qquad R=2J-I,
  \tag{3.9}
  \]
  且 \(R\) nonexpansive（all-pairs RL-1）。
* **\(F\)-MSR：** 对 \(0<|u|<\delta\)，\(E_F(u)=1\)，故
  \(|u|\le\delta E_F(u)\)。随着 localization radius趋零，exact subregularity
  modulus为 0；SMSR成立但这个强度来自 residual jump。
* **prox/PPA residual：** 在 \(|x|<\lambda\)，\(T=J=0\)，
  \(E_{T-I}(x)=|x|\)，fixed-point EB exact modulus 1。
* **实际迭代：** 小邻域一步终止。两个 regularity labels 都是 yes，但 moduli 与机制完全不同；
  不能沿单一数值“regularity strength”轴等同。

### RM-04 — projection：\(N_C\)-MSR 是 domain-vacuous，而 PG residual EB 是非平凡距离恒等式

* **空间/problem：** \(H=\mathbb R^2\)，\(C=\mathbb R\times\{0\}\)，
  \(f=0,g=\delta_C\)，\(F=N_C\)。
  \[
  F(s,0)=\{0\}\times\mathbb R,\quad F(s,z)=\varnothing\ (z\ne0),\quad
  S=C.
  \tag{3.10}
  \]
  \(F^{-1}(b)=C\) if \(b\in C^\perp\)，否则 empty。
* **resolvent/RL：**
  \[
  J_F=P_C(s,z)=(s,0),\qquad R_F(s,z)=(s,-z),
  \tag{3.11}
  \]
  an isometry，all-pairs RL-1 exact \(L=1\)。
* **\(F\)-MSR：** 在 \(\operatorname{dom}F=C\) 上左边 \(d(u,S)=0\)；dom 外
  \(E_F=+\infty\)。因此任何 modulus 都形式成立，exact modulus 0，但完全
  **domain-vacuous**。
* **PG residual：** \(T_{PG}=P_C\)，
  \[
  E_{T-I}(s,z)=|z|=d((s,z),C),
  \tag{3.12}
  \]
  是 full-neighborhood 的 nonvacuous exact EB，modulus 1。迭代一步投影到非孤立
  fixed set。
* **isolated variant：** 取 \(C=\{0\}\)，则 \(F=N_{\{0\}}\)、\(J=0\)、\(R=-I\)、
  \(S=\{0\}\)；相同 vacuity/nonvacuity gap，且迭代一步到 isolated zero。

### RM-05 — convex quadratic split：standard prox-gradient 下 yes/no 对齐但 modulus 可调

* **参数/problem：** \(a,b\ge0\)，\(a+b>0\)，\(\tau>0\)，
  \(f(x)=ax^2/2\)，\(g(x)=bx^2/2\)。
  \[
  F=\partial(f+g)=(a+b)I,\qquad S=\{0\}.
  \tag{3.13}
  \]
* **\(F\) resolvent：**
  \(J_{\lambda F}=(1+\lambda(a+b))^{-1}I\)，
  \(R_{\lambda F}=(1-\lambda(a+b))/(1+\lambda(a+b))I\)。
  \(F\)-MSR exact modulus \((a+b)^{-1}\)。
* **prox-gradient：**
  \[
  T_{PG}x=\frac{1-\tau a}{1+\tau b}x,\qquad
  G_\tau(x)=\frac{a+b}{1+\tau b}x.
  \tag{3.14}
  \]
  PG-residual EB exact modulus \((1+\tau b)/(a+b)\)，而
  \(T-I\) residual modulus为 \((1+\tau b)/(\tau(a+b))\)。
* **迭代/invariance：** 若 \(|1-\tau a|<1+\tau b\)，全局线性；若 \(a>0\) 且
  \(\tau=1/a\)，一步到 0。此例说明 split/stepsize 可改变算法 residual modulus 和 rate，
  但在合法凸二次类中不能产生 \(F\)-MSR yes / PG-EB no。

### RM-06 — tangent line/parabola：primal sum-MSR vacuous，DR residual 无 linear EB

**Purpose.** 在同一 feasibility problem 里显式分离 primal inclusion residual 与 DR fixed-point
residual，并打印 tangency law。

* **空间/sets/operators：** \(H=\mathbb R^2\)，
  \[
  C=\{(s,0):s\in\mathbb R\},\qquad
  D=\{(s,s^2):s\in\mathbb R\},\qquad
  A=N_C, B=N_D.
  \tag{3.15}
  \]
  在原点小 tube 内 \(P_D\) 单值。primal map \(F=A+B\) 只在
  \(C\cap D=\{0\}\) 有定义，且 \(F(0)=\{0\}\times\mathbb R\)。因此
  \(\operatorname{zer}F=\{0\}\)，但 MSR/SMSR 是 dom-vacuous。
* **\(F\) resolvent：** \(I+F\) 的 local range 是 vertical axis；对 \(x=(0,v)\)，
  \(J_Fx=0\)、\(R_Fx=-x\)。它不是 full-neighborhood resolvent。
* **DR map：** 采用
  \[
  T_{DR}=I-P_C+P_D R_C.
  \tag{3.16}
  \]
  对 test slice \(z=(t,0)\)，令 \(s\) 由 nearest-point 方程
  \(t=s+2s^3\) 唯一确定，则
  \[
  T_{DR}(t,0)=(s,s^2),\qquad
  (I-T_{DR})(t,0)=(2s^3,-s^2).
  \tag{3.17}
  \]
* **fixed set / EB failure：** local \(\operatorname{Fix}T_{DR}\) 包含且事实上等于
  vertical axis（对 \(|v|\) 小，\(P_D(0,-v)=0\)）。故
  \[
  d((t,0),\operatorname{Fix}T)=|t|\sim|s|,\qquad
  \|(I-T)(t,0)\|\sim s^2.
  \tag{3.18}
  \]
  linear MSR of \(T-I\) 必然失败；slice 上最大可能 power exponent至多 1/2。
  full-tube q=1/2 EB 标 `CANDIDATE`，未把 slice asymptotic 冒充 full theorem。
* **actual iteration/branch：** projections 在选定 prox-regular tube 内单值；实际迭代为
  \(z_{k+1}=z_k-P_Cz_k+P_D R_Cz_k\)。slice 一步后不保持在 slice，故 (3.17)
  只用于 residual law，不能直接迭代成 rate；local invariance/rate 留给 C。

### RM-07 — transverse lines：同样 vacuous primal label，DR residual却有 exact linear EB

* **sets：** \(C=\operatorname{span}(e_1)\)，
  \(D=\operatorname{span}(\cos\theta,\sin\theta)\)，\(0<\theta<\pi/2\)，
  \(A=N_C,B=N_D\)。primal \(F=A+B\) 的 domain 是 \(\{0\}\)，
  \(F(0)=\mathbb R^2\)，故 \(S=\{0\}\) 且 \(F\)-SMSR仍 domain-vacuous。
* **\(F\) resolvent：** 因 \(F(0)=\mathbb R^2\)，
  \(J_F\equiv0\)、\(R_F=-I\)；PPA 一步终止。
  且 \(F^{-1}(b)=\{0\}\) 对每个 \(b\in\mathbb R^2\) 成立。
* **DR map/reflection：**
  \[
  T_{DR}=\frac{I+R_D R_C}{2}
  =\cos\theta\,\operatorname{Rot}(\theta),\qquad
  \operatorname{Fix}T=\{0\}.
  \tag{3.19}
  \]
  （角度符号取决于 lines 顺序，不影响 norms。）
* **exact residual/rate：**
  \[
  \|(I-T)z\|=\sin\theta\,\|z\|,\qquad
  \|T^kz\|=(\cos\theta)^k\|z\|.
  \tag{3.20}
  \]
  所以 \(T-I\)-MSR exact modulus \(1/\sin\theta\)。RM-06 与 RM-07 的
  primal \(F\)-MSR 标签同为 vacuous yes，但 DR residual 分别为 non-linear/linear；
  差异来自 set angle/tangency，而非该 primal label。

### RM-08 — DR 的 PPA-degenerate branch：\(A=0\) 时 residual mismatch 消失

**Purpose.** 防止把 RM-06 的分离误推广为所有 DR。

* **mapping：** 取任意 single-valued resolvent 的 \(B\)，令 \(A=0\)。则
  \(J_A=I,R_A=I\)，且
  \[
  T_{DR}=I-J_A+J_BR_A=J_B.
  \tag{3.21}
  \]
  因而 DR residual 与 \(B\) 的 PPA residual完全相同。
* **显式 instance：** 令 \(B(u)=P_{1/q}(u)\)，\(q>1\)（CP-04）。则
  \(\operatorname{zer}(A+B)=\{0\}\)，\(B\) q-MSR exact，
  \(J_Bx=u\) 由 \(x=u+P_{1/q}(u)\) 唯一确定，
  \(R_B=2J_B-I\)，\(T_{DR}=J_B\) 且实际 order q。没有任何 residual yes/no gap。
* **branch/invariance：** \(J_B\) 全局单值；小区间 invariant。该例说明 residual separation
  需要 genuine splitting geometry、domain/selection 或坐标退化，不能只看算法名称。

---

## Composition block — RL–power MSR：达到、严格优于与不提供收敛

### CP-01 — 非孤立零集上 genuinely \(\gamma<1\) 且 exact \(\gamma q\)

**Purpose.** 构造一个所有量都显式、branch/invariance 可核的 exact composition model。

* **参数/空间：** \(H=\mathbb R^2\)，\(0<\gamma<1\)，\(q>1/\gamma\)，
  \(\alpha:=\gamma q>1\)。固定 \(M>0\)，在 bounded tube
  \(D=(-M,M)\times(-\delta,\delta)\)、\(0<\delta<1\) 上定义
  \[
  J(t,z)=\bigl(t+|z|^\gamma,P_\alpha(z)\bigr),
  \qquad
  R(t,z)=\bigl(t+2|z|^\gamma,2P_\alpha(z)-z\bigr).
  \tag{2.1}
  \]
* **function audit / explicit \(F\)：** \(J\) 是 triangular injection。给 output
  \(u=(s,w)\)，令 \(z=P_{1/\alpha}(w)\)、
  \(t=s-|w|^{1/q}\)，则
  \[
  F(s,w)=\left(-|w|^{1/q},
  P_{1/\alpha}(w)-w\right).
  \tag{2.2}
  \]
  所以 \(F\) 为单值函数，inverse 由解 (2.2) 给出的两个分量方程获得。
* **zeros：** 第一 residual 分量强迫 \(w=0\)，故
  \(S=\mathbb R\times\{0\}\)，非孤立。
* **graph inner product：** 对 matched solution \(p=(t,0)\) 与 graph point
  \(u=J(t,z), b=(t,z)-u\)，
  \[
  a=(|z|^\gamma,P_\alpha z),\quad
  b=(-|z|^\gamma,z-P_\alpha z),
  \tag{2.3}
  \]
  \[
  \langle a,b\rangle
  =-|z|^{2\gamma}+|z|^{\alpha+1}-|z|^{2\alpha}
  \sim-|z|^{2\gamma}.
  \tag{2.4}
  \]
* **RL：**
  \(R(t,z)-p=(2|z|^\gamma,2P_\alpha z-z)\)，其 norm
  \(\sim2|z|^\gamma\)。在 bounded tube 上 \(|z|^\gamma\) 的 standard Hölder
  estimate 给 local all-pairs `G_γ`；任何 \(\eta>\gamma\) 在 \(z\to0\) 失败。
  所以这里的 \(\gamma\) genuinely sharp，不是 bounded-window 继承。
* **power MSR：**
  \[
  d((s,w),S)=|w|,\qquad
  E_F(s,w)=\sqrt{|w|^{2/q}+|P_{1/\alpha}w-w|^2}
  \sim |w|^{1/q}.
  \tag{2.5}
  \]
  因 \(1/\alpha>1/q\)，第一项 dominant；q-MSR sharp，asymptotic modulus 1。
* **实际 PPA：**
  \[
  t_{k+1}=t_k+|z_k|^\gamma,\qquad
  z_{k+1}=P_\alpha(z_k),\qquad
  r_{k+1}=r_k^\alpha=r_k^{\gamma q}.
  \tag{2.6}
  \]
  normal tube invariant。且 \(\sum r_k^\gamma<\infty\)，故 tangential drift有限；若起点
  tangentially 留有该总 drift 的 margin，则留在指定 rectangle 并收敛到 \(S\) 中一点。
  **这是 exact 达到，不只是上界。**

### CP-02 — isolated zero、single-valued \(F\)：all-pairs sharp \(\gamma\)，实际 order \(q>\gamma q\)

**Purpose.** 把 all-pairs irregularity 与 solution-anchored geometry 分开；给出严格优于
\(\gamma q\) 的 invariant model。

* **参数：** \(q>1\)，\(0<\gamma<1\)，\(\beta=q/\gamma-1>0\)。令
  \(\phi_q(s)=P_q(s)\) 且
  \[
  h(0)=0,\qquad h(s)=|s|^q\sin(|s|^{-\beta})\ (s\ne0).
  \tag{2.7}
  \]
  在 \(H=\mathbb R^2\) 设
  \[
  J(x,y)=\bigl(\phi_q(x),\phi_q(y)+h(x)\bigr),\qquad R=2J-I.
  \tag{2.8}
  \]
* **function/inverse audit：** triangular map \(J\) 全局单射且满射：先由
  \(u_1=\phi_q(x)\) 恢复 \(x=P_{1/q}(u_1)\)，再由
  \(u_2-h(x)=\phi_q(y)\) 恢复 \(y\)。因此
  \[
  F(u)=J^{-1}u-u
  \tag{2.9}
  \]
  是单值函数，\(J_F=J\)、\(R_F=R\)。
* **zeros：** \(\|Jz\|\le C\|z\|^q\) near 0；取小球使
  \(C\|z\|^{q-1}<1\)，则唯一 fixed point / zero 为 0（isolated）。
* **all-pairs RL：** oscillatory cusp \(h\) 的 maximal local Hölder exponent为
  \(q/(\beta+1)=\gamma\)。\(\phi_q\) 与 \(-I\) local Lipschitz，所以 \(R\)
  local `G_γ`，且在振荡极值点对上任何 \(\eta>\gamma\) 失败。
* **anchored upgrade：**
  \[
  Rz=-z+O(\|z\|^q),
  \tag{2.10}
  \]
  故 `A_1(0)=P_1(0)` 成立并 sharp。也就是说 all-pairs 的 sharp exponent 是
  \(\gamma\)，solution-anchored sharp exponent却是 1。
* **power MSR：** 对 input \(z\) 与 output \(u=Jz\)，residual
  \(b=z-Jz\) 满足 \(\|b\|\asymp\|z\|\)，而
  \(\|u\|\le C\|z\|^q\)。所以
  \[
  d(u,S)\le C' E_F(u)^q.
  \tag{2.11}
  \]
  沿 \(z=(x,0)\)，\(\|u\|\ge|x|^q\)、\(\|b\|\sim|x|\)，故 q sharp。
* **迭代/invariance：** \(z^+=Jz\)，小球 invariant，
  \[
  E_{J-I}(z)=\|z-Jz\|\asymp\|z\|,\qquad
  \|z^+\|\le C\|z\|^q,
  \tag{2.12a}
  \]
  且沿适当序列达到 \(\Theta(\|z\|^q)\)。
  若机械代入 all-pairs exponent 只得 \(O(r^{\gamma q})\)，严格较差；用可得的
  solution-anchored exponent 1 则恢复 order q。

### CP-03 — 线性基准：\(\gamma q=1\) 的 exact order 与 exact moduli

* **空间/data：** \(H=\mathbb R\)，\(F(u)=cu\)，\(c>0\)，任意 \(\lambda>0\)。
  \[
  J_{\lambda F}x=\frac{x}{1+\lambda c},\qquad
  R_{\lambda F}x=\frac{1-\lambda c}{1+\lambda c}x.
  \tag{2.12}
  \]
* **graph/zero/inverse：** graph \(b=cu\)，\(S=\{0\}\)，\(F^{-1}(b)=b/c\)。
  \(\langle a,b\rangle=c|a|^2\)。
* **RL：** all-pairs RL-1 exact constant
  \(L=|1-\lambda c|/(1+\lambda c)\)（\(\lambda c=1\) 时 \(R=0\)）。
* **MSR：** \(|u|=c^{-1}|F(u)|\)，所以 q=1 sharp，modulus \(1/c\)。
* **迭代/residual：**
  \[
  r_{k+1}=\frac1{1+\lambda c}r_k,\qquad
  E_T(x)=\frac{\lambda c}{1+\lambda c}|x|.
  \tag{2.13}
  \]
  exponent \(\gamma q=1\) exact；coefficient 不是从 exponent alone 得到。

### CP-04 — steep power：isolated zero 上 \(\gamma=1\)、q-MSR 与 order q 全部 sharp

* **参数/data：** \(q>1\)，\(H=\mathbb R\)，
  \[
  F(u)=P_{1/q}(u),\quad S=\{0\},\quad F^{-1}(b)=P_q(b).
  \tag{2.14}
  \]
  \(Jx=u\) 是方程 \(x=u+\lambda P_{1/q}(u)\) 的唯一解，
  \(R=2J-I\)。
* **graph geometry/RL：** \(F\) maximal monotone，故 \(R\) nonexpansive；
  all-pairs RL-1 with \(L=1\)。沿 0，
  \(R(x)=-x+2\lambda^{-q}P_q(x)+o(|x|^q)\)，所以 anchored maximal exponent
  确为 1。
* **regularity：** \(|u|=|F(u)|^q\)，q-MSR exact modulus 1，且任何
  \(q'>q\) 失败。
* **迭代：** 令 \(t=P_{1/q}(u)\)，则 \(x=P_q(t)+\lambda t\)，从而
  \[
  x^+=Jx=P_q(t)=\lambda^{-q}P_q(x)+o(|x|^q),\qquad
  r_{k+1}\sim\lambda^{-q}r_k^q.
  \tag{2.15}
  \]
  小邻域 invariant，actual order \(q=\gamma q\) sharp。

### CP-05 — flat power：power EB 有效但 \(\gamma q<1\) 上界不描述实际 order

* **参数/data：** \(p>1\)，\(F(u)=P_p(u)\)，\(S=\{0\}\)。
  \(F^{-1}(b)=P_{1/p}(b)\)。
  \(Jx=u\) 唯一解 \(x=u+\lambda P_p(u)\)，\(R=2J-I\)。
* **RL：** maximal monotonicity 给 all-pairs RL-1，\(L=1\)。
* **regularity：**
  \[
  |u|=|F(u)|^{1/p};
  \tag{2.16}
  \]
  sharp residual exponent \(q=1/p<1\)，linear MSR失败。
* **迭代/residual：**
  \[
  x^+=x-\lambda P_p(x)+o(|x|^p),\quad
  \frac{r_{k+1}}{r_k}\to1,\quad
  E_T(x)=\lambda|x|^p+o(|x|^p).
  \tag{2.17}
  \]
  actual one-step order是 1（带高阶下降项），而 generic
  \(O(r^{\gamma q})=O(r^{1/p})\) 虽真却极松且不给 contraction。
  对正初值，迭代 invariant 并次线性趋零；不能把 exponent \(1/p\) 称为 actual rate order。

### CP-06 — isolated q>1 对 genuine anchored \(\gamma<1\) 的构造障碍（可复核 lemma）

**Purpose.** 记录一个会约束后续 candidate search 的代数事实，而非统一结论。

设 \(S=\{0\}\)，取任何趋于 \((0,0)\) 的 graph branch \((u,b)\)，并假设在该 branch
\(|u|\le\rho|b|^q\)，\(q>1\)。令 \(x=u+\lambda b\)、\(Rx=u-\lambda b\)。当
\(|b|\le\delta\) 且 \(\rho\delta^{q-1}<\lambda/2\) 时，

\[
|x|\ge(\lambda-\rho\delta^{q-1})|b|\ge\frac\lambda2|b|,
\qquad
|Rx|\le(\lambda+\rho\delta^{q-1})|b|\le3|x|.
\tag{2.18}
\]

所以 **solution-anchored RL-1 自动成立于该 branch**。这不推出 all-pairs Lipschitz；CP-02
正是 all-pairs 只有 \(\gamma<1\) 的例子。结论仅是：在 isolated zero、q>1 MSR 与 residual
趋零的对齐 branch 上，不能把 subunit \(\gamma\) 当作 sharp anchored exponent。

* **candidate consequence：** isolated、q>1、genuinely anchored \(\gamma<1\) 且 actual
  \(\gamma q\) 的 scalar/full-branch 模型可能被 (2.18) 排除；要绕开它必须使用
  nonisolated \(S\)、非最近解 anchor、selection/domain mismatch 或不同 residual。
  这是 `OBSTRUCTION`, 不是关于 all-pairs RL 的 theorem。

---

## Anchored block — solution-relative / pointwise / all-pairs gaps

### AR-01 — genuine Hölder Cayley cusp：三种量词全成立，但更大 exponent 失败

**Purpose.** 给出 genuine \(\gamma<1\) 的基准点，并检验 exact one-step
\(r_+=\Theta(r^\gamma)\) 不等于 convergence。

* **参数/空间：** \(H=\mathbb R\)，\(0<\gamma<1\)，\(D=[-\delta,\delta]\)，
  \(0<\delta<1\)。记 \(P_\alpha(x)=\operatorname{sgn}(x)|x|^\alpha\)。
* **Cayley data：**
  \[
  R(x)=P_\gamma(x),\qquad
  J(x)=\frac{x+P_\gamma(x)}2,\qquad
  F(Jx)=x-Jx=\frac{x-P_\gamma(x)}2.
  \tag{1.1}
  \]
  \(J\) 严格递增，故 \(F\) 是定义在 \(J(D)\) 上的单值函数；逆可用
  \(\chi_\gamma=(I+P_\gamma)^{-1}(2\cdot)\) 写为
  \(F(u)=\chi_\gamma(u)-u\)。
* **graph / zeros / inverse：** graph 正是 (1.1) 的参数曲线；局部
  \(\operatorname{zer}F=\{0\}\)，且 \(F^{-1}(b)=J(x)\) 其中
  \(b=(x-P_\gamma x)/2\)。
* **RL facts：** \(P_\gamma\) 全局 \(\gamma\)-Hölder，常数可取
  \(2^{1-\gamma}\)。所以 `G_γ(D)`、`P_γ(0)`、`A_γ(0)` 均成立。
  对任何 \(\eta>\gamma\)，
  \(|R(x)|/|x|^\eta=|x|^{\gamma-\eta}\to\infty\)，故 base 0 已失败；
  exponent \(\gamma\) sharp。
  同一例若改问 exponent 1，则每个非零 base 都有 \(P_1(\bar x)\)，
  但 \(A_1(0)\) 与 \(G_1(D)\) 失败；这填入“非解 base pointwise 不推出解点 anchored”
  的反向量词格。
* **inner product：** 对 graph pair 对应 \(x,y\)，
  \(a=(h+k)/2,b=(h-k)/2\)，其中 \(h=x-y,k=Rx-Ry\)，故
  \(ab=(h^2-k^2)/4\)；沿 \(y=0\) 为
  \((x^2-|x|^{2\gamma})/4\sim-|x|^{2\gamma}/4\)。
* **regularity：** 由 \(u\sim P_\gamma(x)/2\) 与
  \(F(u)=x-u\sim-u\)，有 \(|u|\asymp |F(u)|\)：linear SMSR，sharp
  residual exponent \(q=1\)。
* **实际迭代/residual：**
  \[
  x^+=Jx=\tfrac12(x+P_\gamma x),\quad
  E_T(x)=|x-Jx|=\tfrac12|x-P_\gamma x|\asymp |x|^\gamma.
  \tag{1.2}
  \]
  一步 \(r_+=\Theta(r^{\gamma q})=\Theta(r^\gamma)\) sharp，但
  \(r_+/r\to\infty\)：除 0 外迭代离开任意充分小的 0-neighborhood。
  **Branch 单值但 invariance/convergence 失败。**

### AR-02 — anchored exponent \(\alpha\) 成立而同 exponent all-pairs 失败

**Purpose.** 填 `A_α(0) ∧ P_α(0) ∧ ¬G_α`，并展示 Cayley 反推可生成多函数。

* **参数/空间：** \(H=\mathbb R\)，\(0<\alpha<1\)，\(\beta>0\)，
  \(D=[-\delta,\delta]\)，\(\delta\) 小。令
  \[
  R(0)=0,\qquad
  R(x)=P_\alpha(x)\,[2+\sin(|x|^{-\beta})]\quad(x\ne0).
  \tag{1.3}
  \]
  \(J=(I+R)/2\)，\(F(Jx)=x-Jx\)。
* **zeros：** 因 \(|R(x)|\ge |x|^\alpha>|x|\)（\(0<|x|<1\)），
  local fixed/zero set 为 \(\{0\}\)。
* **anchored：** \(|R(x)|\le3|x|^\alpha\)，故 `A_α(0)=P_α(0)`。
  每个非零 base 处 \(R\) 光滑，故也有 local \(P_1(\bar x)\)，从而有
  \(P_\alpha(\bar x)\)。所以该例实际上满足“每个 base pointwise-\(\alpha\)，常数/半径不统一”，
  但仍不满足邻域上的统一 all-pairs-\(\alpha\)。
* **all-pairs failure：** 在相邻振荡极值点 \(x_n,y_n\asymp n^{-1/\beta}\) 上，
  \(|R(x_n)-R(y_n)|\asymp x_n^\alpha\)，而
  \(|x_n-y_n|\asymp x_n^{\beta+1}\)。所以 quotient 的临界 exponent 是
  \[
  \eta_*:=\frac{\alpha}{\beta+1}<\alpha;
  \tag{1.4}
  \]
  特别 `G_α` 失败；标准 two-scale estimate 给 local `G_η*`。
* **function/multifunction audit：** \(R'\) 的 oscillatory 项量级
  \(|x|^{\alpha-\beta-1}\)，正负无界；\(J'=(1+R')/2\) 在 0 附近反复换号。
  因而 \(J\) 非单射，生成的 \(F\) **确为多函数**，但 resolvent relation 在 Minty input
  \(x\) 上仍由构造给出单值 \(Jx\)。
* **实际迭代：** \(x^+=Jx\)，且
  \(|x^+|\asymp |x|^\alpha\)；和 AR-01 一样局部 0 不 invariant。
  \(E_T=|x-Jx|\asymp|x|^\alpha\)。
* **regularity label：** graph output \(u=Jx\asymp|x|^\alpha\)，
  \(b=x-u\asymp-u\)，故沿每个构造 branch 有 q=1 residual law；对多函数
  \(d(0,F(u))\) 是否被不同参数 branch 降低，留给 C（`CANDIDATE`，不可仅凭参数 branch
  宣称 full-map MSR）。

### AR-03 — 每个 base 局部 Lipschitz，但没有 global all-pairs 常数

**Purpose.** 填 `∀x̄ P_1(x̄)`（nonuniform）与 `¬G_1(D)` 的 local/global gap。

* **空间/data：** \(H=\mathbb R\)，\(D=[0,\infty)\)，
  \[
  R(x)=x^2,\quad J(x)=\frac{x+x^2}{2},\quad
  u=Jx,\quad F(u)=x-u=\frac{x-x^2}{2}.
  \tag{1.5}
  \]
  \(J\) 在 \(D\) 严格递增，故 \(F\) 单值；
  \(x(u)=(-1+\sqrt{1+8u})/2\)。
* **zeros：** \(\operatorname{Fix}R=\{0,1\}\)，故
  \(\operatorname{zer}F=\{0,1\}\)。
* **RL facts：** 每个有限 base 的邻域上 \(R\) Lipschitz；在 0、1 都有 anchored RL-1。
  但 \(|R(x+1)-R(x)|=2x+1\)，所以没有 global `G_1(D)`；同样因二次增长，
  没有任何 global `G_γ(D)`，\(0<\gamma\le1\)。
* **实际迭代：** \(x^+=(x+x^2)/2\)。0 附近线性 factor \(1/2\)；1 附近
  derivative \(3/2\)，故 1 是不稳定 fixed point。\(D\) invariant。
* **residual laws：** \(E_T(x)=|x-x^2|/2\)。0 附近
  \(d(x,S)\sim2E_T(x)\)，1 附近亦 \(d(x,S)\sim2E_T(x)\)。
  在 output 坐标，0 附近 \(E_F(u)\sim u\)；1 附近
  \(|u-1|\sim3|F(u)|\)。两点均 linear MSR/SMSR，但 moduli 不同。

### AR-04 — 解点 anchored-Lipschitz，但一个非解 base 只有 Hölder

**Purpose.** 合法地填“solution-anchored RL-1 不推出 pointwise-at-every-base RL-1”。

* **参数/data：** \(H=\mathbb R\)，\(0<\alpha<1\)，\(D=[-\varepsilon,2]\)，
  \[
  R(x)=|1-x|^\alpha-1,\qquad J=(I+R)/2,\qquad F(Jx)=x-Jx.
  \tag{1.6}
  \]
* **zeros：** \(R(0)=0\)，且在该 \(D\) 上方程 \(R(x)=x\) 只有 \(x=0\)；
  因而 local/global-on-\(D\) zero set 是 \(\{0\}\)。
* **quantifier gap：** 0 附近 \(R(x)=-\alpha x+O(x^2)\)，所以 `A_1(0)` 与
  `P_1(0)` 成立。base \(\bar x=1\) 处
  \(|R(x)-R(1)|=|x-1|^\alpha\)，所以 `P_1(1)` 和 `G_1(D)` 失败，
  但 `P_α(1)` sharp。
* **function audit：** \(J'\to-\infty\)（从左）而 \(J'\to+\infty\)（从右）；
  \(J\) 在 1 附近非单射，所以 \(F\) 为多函数。
* **实际迭代/residual：** 0 附近
  \(x^+=((1-\alpha)/2)x+O(x^2)\)，局部 invariant 且线性收敛；
  \(E_T(x)=|x-Jx|\sim(1+\alpha)|x|/2\)。
  full-map \(F\)-MSR 仍需排除由 cusp 的第二参数 preimage 回到 0-output 邻域；标
  `CANDIDATE`，branch-wise 则 linear。

### AR-05 — 非孤立零集：每个解点 pointwise，但沿整个零集无统一 modulus

**Purpose.** 区分 pointwise-in-\(p\) 与 uniform solution-tube assumption。

* **空间/data：** \(H=\mathbb R^2\)，输入写 \((t,z)\)，
  \[
  R(t,z)=(t,(2+t^2)z),\qquad
  J(t,z)=\left(t,\frac{3+t^2}{2}z\right).
  \tag{1.7}
  \]
  \(J\) 是全局单射。对 output \(u=(s,w)\)，
  \[
  F(s,w)=\left(0,-\frac{1+s^2}{3+s^2}w\right).
  \tag{1.8}
  \]
* **zeros：** \(S=\mathbb R\times\{0\}\)，非孤立。
* **RL facts：** 每个 \(p=(t_0,0)\) 的小球上 `A_1(p)=P_1(p)` 且 all-pairs
  Lipschitz；所需常数随 \(|t_0|^2\) 增长。沿整个无界 \(S\) 不存在统一 radius/modulus，
  \(R\) 也不 global Lipschitz（cross derivative \(2tz\) 与 coefficient \(t^2\)）。
* **regularity：**
  \[
  d(u,S)=|w|,\quad E_F(u)=\frac{1+s^2}{3+s^2}|w|,\quad
  |w|\le3E_F(u).
  \tag{1.9}
  \]
  因而全局 linear MSR relative to \(S\)（modulus 3）。
* **迭代/residual：** \(t^+=t\)，\(z^+=(3+t^2)z/2\)，故 normal direction
  扩张；\(E_T(t,z)=(1+t^2)|z|/2\)，且
  \(d((t,z),\operatorname{Fix}J)=|z|\le2E_T\)。
  这是“两种 MSR 都强但 fixed-point iteration 发散”的 branch-invariance 反面基准。

### AR-06 — 对整个非孤立解集 uniformly anchored-\(\alpha\)，仍不 all-pairs-\(\alpha\)

**Purpose.** 排除“AR-02 只是 isolated anchor 的偶然”解释。

* **参数/data：** \(H=\mathbb R^2\)，在 bounded tube
  \(D=[-1,1]\times[-\delta,\delta]\) 上，令 AR-02 的 oscillatory scalar map 为
  \(r(z)\)，并设
  \[
  R(t,z)=(t,r(z)),\qquad J(t,z)=\left(t,\frac{z+r(z)}2\right).
  \tag{1.10}
  \]
  Cayley relation 明确为
  \[
  F\!\left(t,\frac{z+r(z)}2\right)
  \ni \left(0,\frac{z-r(z)}2\right).
  \tag{1.11}
  \]
* **zeros：** 对 \(\delta\) 小，\(S=[-1,1]\times\{0\}\)。
* **uniform anchored：** 对匹配解点 \(p=(t,0)\)，
  \(\|R(t,z)-p\|=|r(z)|\le3|z|^\alpha\)。允许 \(t'\ne t\) 时，bounded
  tube 上 identity component 也由 \(C\|(t'-t,z)\|^\alpha\) 控制，所以可取统一常数。
* **all-pairs failure：** 固定同一个 \(t\)，AR-02 的振荡点对直接证明 `G_α(D)` 失败；
  maximal pairwise exponent至多 \(\eta_*=\alpha/(\beta+1)\)。
* **function audit：** normal component \((z+r(z))/2\) 非单射，故 \(F\) 是多函数；
  tangential coordinate不消除该 noninjectivity。
* **iteration/residual/invariance：** \(t^+=t\)，
  \(z^+=(z+r(z))/2=\Theta(|z|^\alpha)\) 且 normal tube 不 invariant；
  \(E_T\asymp|z|^\alpha\)。full-map MSR 仍标 `CANDIDATE`，不能由单 branch 推出。

---

## Handoff matrix

### A. Anchored / pointwise / all-pairs 逻辑格

| Cell（量词必须照列理解） | Witness | 状态/机制 |
|---|---|---|
| \(G_\gamma\wedge P_\gamma(0)\wedge A_\gamma(0)\) | AR-01 | VERIFIED-ALG；\(\gamma\) sharp |
| \((\forall\bar x)\,P_\alpha(\bar x)\wedge\neg G_\alpha(U)\) | AR-02 | VERIFIED-ALG；pointwise constants/radii不统一 |
| local \(P_1\) at every base \(\wedge\neg\) global \(G_1\) | AR-03 | VERIFIED-ALG；unbounded-domain growth |
| \(A_1(0)\wedge\neg P_1(1)\wedge\neg G_1\) | AR-04 | VERIFIED-ALG；非解 base cusp |
| \(P_1(\bar x\ne0)\wedge\neg A_1(0)\) | AR-01 按 exponent 1 读取 | VERIFIED-ALG；base 未对齐 |
| 每个 solution base local \(P_1\)，但 solution-tube 无统一常数 | AR-05 | VERIFIED-ALG；unbounded nonisolated \(S\) |
| uniform solution-anchored \(A_\alpha\wedge\neg G_\alpha\) | AR-06 | anchored 已证；full-map MSR 为 CANDIDATE |
| \(A_\gamma(p)\wedge\neg P_\gamma(p)\)（同一 fixed base/window） | 不可能 | 由 (0.3) exact equivalence 排除 |
| \(G_\gamma(U)\wedge\neg P_\gamma(\bar x)\)，\(\bar x\in U\) | 不可能 | all-pairs 直接代入 \(y=\bar x\) |

### B. RL–power composition 落点

| Behavior | Witness | Isolated? | sharp exponent audit | invariance/rate |
|---|---|---:|---|---|
| genuine \(\gamma<1\)，exact \(r_+=r^{\gamma q}\) | CP-01 | 否 | all-pairs/anchored \(\gamma\) 与 MSR q 均 sharp | normal invariant，完整迭代可收敛 |
| exact \(r_+=\Theta(r^{\gamma q})\) 但不收敛 | AR-01 | 是 | \(\gamma\) sharp，q=1 | 小 neighborhood 不 invariant |
| isolated exact order q | CP-04 | 是 | sharp anchored \(\gamma=1\)，q sharp | invariant，order q |
| all-pairs sharp \(\gamma<1\)，实际严格优于 \(\gamma q\) | CP-02 | 是 | anchored exponent 可升级到 1 | invariant，order q |
| generic power upper bound极松且不给 contraction | CP-05 | 是 | \(\gamma=1,q=1/p<1\) | actual ratio趋 1 |
| isolated q>1 的 subunit anchored-sharp candidate | CP-06 | 是 | 被 branch lemma (2.18) 阻碍 | 非显式例；OBSTRUCTION |

### C. Algorithmic residual mismatch

| Same problem / encoding | \(F\)-side | algorithm residual side | separation type |
|---|---|---|---|
| RM-01 full multifunction | q=1/2 exact，linear no | selected branch 1 linear；full residual q=1/2 | selection |
| RM-02 quartic PG | q=1/3 exact | PG residual逐点等于 \(F\) | no gap baseline |
| RM-03 \(|x|\) | SMSR modulus 0 | prox residual EB modulus 1 | modulus/mechanism，不是 yes/no |
| RM-04 \(N_C\) projection | MSR vacuous | projection residual exact distance | domain-vacuity |
| RM-05 quadratic PG | linear MSR | linear EB，stepsize-dependent modulus | no yes/no gap；conditioning |
| RM-06 tangent DR | primal sum-SMSR vacuous | \(T-I\) linear MSR no | residual coordinate + tangency |
| RM-07 transverse DR | 同样 primal vacuous | \(T-I\) exact linear EB | same primal label, different angle |
| RM-08 \(A=0\) DR | q-MSR | DR=PPA，same order q | no gap baseline |

## Validation record and C-stage warnings

1. **显式对象数：** AR-01–06、CP-01–05、RM-01–08 共 19 个低维映射/问题；
   CP-06 是额外 obstruction lemma，不计入 19。RM-04 另含 isolated normal-cone variant。
2. **symbolic identities：** 每个 Cayley-built 例都使用
   \(u=Jx,\ b=x-Jx,\ R=2J-I\) 逐式核对；标为 multifunction 的条目均检查了
   \(J\) 非单射，标为 function 的 triangular/monotone \(J\) 均检查了单射。
3. **numerical spot check（非证明）：** CP-01 取
   \((\gamma,q,\alpha)=(1/2,3,3/2)\)，\(r=10^{-2},\ldots,10^{-8}\) 时
   \(r_+/r^{\gamma q}=1\)，且 \(d(u,S)/E_F(u)^q\) 从 \(0.988\) 趋于 1。
   RM-06 取 \(s=10^{-1},\ldots,10^{-4}\)，
   \(d/\|I-T\|\) 从约 \(10\) 增至 \(10^4\)，而
   \(d/\|I-T\|^{1/2}\to1\)，与 slice asymptotic 一致。
4. **不得升级的 candidate：**
   AR-02/04/06 的 full multifunction MSR、RM-06 的 full-tube q=1/2 DR EB、
   以及 CP-06 所述 isolated genuine-\(\gamma\) 不存在性都未作为 theorem。
5. **C 应优先攻击：**
   (i) AR-02/06 不同参数 preimages 是否降低 \(d(0,F(u))\)；
   (ii) CP-02 oscillatory \(h\) 的 maximal Hölder exponent完整 two-scale proof；
   (iii) RM-06 在 full tube 的 fixed-set equality 与 q=1/2 upper EB；
   (iv) 对 CP-01 的 all-pairs RL 常数和 q-MSR exact modulus做 sharp constant audit。
