# Generalized monotonicity / regularity 术语与 primary-source 溯源审计

> 版本：2026-09-01。本文是供 theory atlas 合并前使用的命名防错层，不是 atlas、example catalog 或最终综合。  
> 原则：先抄公式，再命名。定义只采用原论文、作者公开稿、出版社全文页或官方书目页。未直接看到原始公式者标为 PENDING_VERIFICATION。

## 0. 记号与证据标签

设 \(H\) 为实 Hilbert 空间，\((x,u),(y,v)\in\operatorname{gph}A\)，并记

\[
a:=x-y,\qquad b:=u-v.
\]

讨论项目中的尺度 \(\lambda>0\) 时，令

\[
c:=\lambda b,\qquad r:=\|a+c\|=\|a+\lambda b\|.
\]

- VERIFIED_SOURCE：已在 primary/official 页面或作者稿中看到所述公式或命题。
- AI_INFERENCE：由已核验公式直接代数推出，不冒充文献原句。
- PENDING_VERIFICATION：只核验到书目信息、摘要或后续转述，未直接看到原始全文相应公式。

## 1. 一页式名称交叉表

| 实际公式 | 建议的无歧义名称 | 真正的别名/关系 | 必须保留的限定 |
|---|---|---|---|
| \(\langle a,b\rangle\ge\mu\|a\|^2\) | \(\mu\)-monotone | \(\mu>0\)：strongly monotone；\(\mu=-\sigma<0\)：\(\sigma\)-hypomonotone；现代优化常称 \(\sigma\)-weakly monotone | global/local、graph localization、参数符号 |
| \(\langle a,b\rangle\ge\rho\|b\|^2\) | \(\rho\)-comonotone | \(\rho>0\)：cocoercive / inverse strongly monotone；\(\rho=-\sigma<0\)：pairwise cohypomonotone | 原始 local cohypomonotonicity 还含全局 extension |
| \(\langle a,b\rangle\ge\mu\|a\|^2+\rho\|b\|^2\) | Evens–Pas–Latafat–Patrinos \((\mu,\rho)\)-semimonotone | 同时容纳前两行；取逆交换参数 | pointwise 或 all-pairs；scalar 或 matrix 参数 |
| \(\langle a,b\rangle\ge-\frac{\theta}{2}(\|a\|^2+\|b\|^2)\) | Otero–Iusem \(\theta\)-semimonotone | 是前一行的 \((-\theta/2,-\theta/2)\) 切片 | \(0<\theta<1\)；不是一般二参数类的同义词 |
| \(\langle a,b\rangle\ge-\tau\|a+b\|^2\) | Luke–Tam 2025 submonotone（尺度 1） | inversion symmetric；对应 restricted reflected resolvent Lipschitz | \(U,W,D\) 与 restricted graph/range |
| \(\langle a,b\rangle\ge-o(\|a\|)\) 的精确局部式 | Spingarn strictly submonotone | 后期作者常删去 strictly | 两端点趋同；一次距离尺度，不是固定二次 violation |
| \(\|a-\lambda b\|\le L\|a+\lambda b\|^\gamma\) | 当前项目内部代号 RL-\((\lambda,L,\gamma)\) | \(\gamma=1,L\ge1\) 精确换参到 \(\lambda F\) 的 Luke–Tam 条件 | \(\lambda\) 改变算子；\(\gamma<1\) 不是固定 violation 类 |
| \(d(x,F^{-1}(\bar y))\le\kappa d(\bar y,F(x))^q\) | residual-exponent convention 的 metric \(q\)-subregularity | \(0<q<1\)：Hölder；\(q=1\)：ordinary；\(q>1\)：higher-order | 有文献使用倒数 growth exponent \(p=1/q\) |

## 2. Submonotonicity：至少四个不能合并的对象

### 2.1 Spingarn 1981：pointwise submonotone

对 \(T:\mathbb R^n\rightrightarrows\mathbb R^n\)，Spingarn 在 \(\bar x\) 的 pointwise 定义可写为

\[
\liminf_{\substack{x'\to\bar x,\ x'\ne\bar x\\
                    y\in T(\bar x),\ y'\in T(x')}}
\frac{\langle y-y',\bar x-x'\rangle}{\|x'-\bar x\|}
\ge0.
\tag{S-pw}
\]

等价的 \(\varepsilon\)-语言是：对每个 \(\varepsilon>0\)，足够靠近 \(\bar x\) 时，一端固定在 \(\bar x\)，有

\[
\langle y-y',\bar x-x'\rangle\ge-\varepsilon\|x'-\bar x\|.
\]

VERIFIED_SOURCE：

- Jonathan E. Spingarn, Submonotone Subdifferentials of Lipschitz Functions, Trans. AMS 264 (1981), 77–89。JSTOR primary 页面可检索原始 liminf 公式：  
  https://www.jstor.org/stable/1998411
- AMS 官方书目页：  
  https://www.ams.org/tran/1981-264-01/S0002-9947-1981-0597868-8/

### 2.2 Spingarn 1981：strictly submonotone

strictly 版本把两端点都允许趋于 \(\bar x\)：

\[
\liminf_{\substack{x_1,x_2\to\bar x,\ x_1\ne x_2\\
                    y_i\in T(x_i)}}
\frac{\langle y_1-y_2,x_1-x_2\rangle}{\|x_1-x_2\|}
\ge0.
\tag{S-strict}
\]

即对每个 \(\varepsilon>0\)，足够靠近 \(\bar x\) 的两图点满足

\[
\langle y_1-y_2,x_1-x_2\rangle
\ge-\varepsilon\|x_1-x_2\|.
\]

VERIFIED_SOURCE：Spingarn primary 页面可检索 strictly submonotone 定义；Zajíček 的 primary research article 明确记录后期 convention：他把上述两端点条件简称为 submonotone，并注明 Spingarn 原称 strictly submonotone。

- Luděk Zajíček, Differentiability of Approximately Convex, Semiconcave and Strongly Paraconvex Functions, J. Convex Anal. 15 (2008)：  
  https://www.heldermann-verlag.de/jca/jca15/jca0651_b.pdf

结论：后期论文只写 submonotone 时，必须检查它是一端点式 (S-pw)，还是两端点式 (S-strict)。

### 2.3 Rockafellar 与 Rockafellar–Wets

Rockafellar 1981 的 primary working paper在 Spingarn 语境下同时讨论 submonotone / strictly submonotone，并明确给出

\[
\text{hypomonotone}\Rightarrow\text{submonotone},\qquad
\text{strictly hypomonotone}\Rightarrow\text{strictly submonotone}.
\]

- R. T. Rockafellar, Favorable Classes of Lipschitz Continuous Functions in Subgradient Optimization, IIASA WP-81-001：  
  https://pure.iiasa.ac.at/id/eprint/1760/7/WP-81-001.pdf

PENDING_VERIFICATION：该 official PDF 在本轮环境中被访问保护拦截，本文不从中誊录细部定义，只采用 official 检索文本中的上述 implication。

Rockafellar–Wets, Variational Analysis, Example 12.28 被后续 primary papers反复引用为 hypomonotonicity：

\[
\langle a,b\rangle\ge-\sigma\|a\|^2.
\tag{H}
\]

官方书页：  
https://link.springer.com/book/10.1007/978-3-642-02431-3

审计结论：本轮没有找到 Rockafellar–Wets 另行定义一个能与 Luke–Tam 同名合并的 submonotonicity。atlas 应写 RW Example 12.28 hypomonotonicity，不应写未经核实的 RW-submonotonicity。

### 2.4 Luke–Thao–Tam 2017/2018：base-point quadratic

在有限维 Euclidean 空间，Luke–Thao–Tam 定义 \(F\) 在 \(\bar v\) pointwise submonotone：存在 \(\tau\) 与邻域 \(U\)，使

\[
-\tau\|(u+z)-(\bar v+w)\|^2
\le\langle z-w,u-\bar v\rangle
\tag{LTT-pw}
\]

对所有 \(u\in U,z\in F(u),w\in F(\bar v)\) 成立。若对 \(U\) 中每个基点以同一常数成立，则称 on \(U\)。

VERIFIED_SOURCE：Definition 2.9、Proposition 2.8。

- D. Russell Luke, Nguyen H. Thao, Matthew K. Tam, Quantitative convergence analysis of iterated expansive, set-valued mappings：  
  https://arxiv.org/html/1605.05725v2  
  https://pubsonline.informs.org/doi/pdf/10.1287/moor.2017.0898

它与 (S-pw) 的核心差异：负误差按 \(\|(u+z)-(\bar v+w)\|^2\) 计量；Spingarn 按 domain 距离的一次小量计量。名称相同不构成等价。

### 2.5 Luke–Tam 2025：two-point, range-relative quadratic

在有限维 Euclidean 空间 \(\mathbb E\)，给定 \(U,W\subset\mathbb E\)、\(\tau\ge0\)，Luke–Tam 定义

\[
-\tau\|(u+u^+)-(v+v^+)\|^2
\le\langle u-v,u^+-v^+\rangle
\tag{LT}
\]

对所有 \(u,v\in U\)、\(u^+\in F(u)\cap W\)、\(v^+\in F(v)\cap W\) 成立。其 maximality 是固定 \((U,W,\tau)\) 下 restricted graph

\[
\operatorname{gph}F\cap(U\times W)
\]

不能被保持 (LT) 的更大图严格扩张。论文自己明确说它 repurpose 了 Spingarn 已使用的名称。

VERIFIED_SOURCE：Definition 2、Propositions 3–5。

- D. Russell Luke, Matthew K. Tam, Generalized Monotonicity and the Proximal Point Algorithm, Mathematics of Operations Research (2025)：  
  https://pubsonline.informs.org/doi/10.1287/moor.2025.0863

令 \(a=u-v,b=u^+-v^+\)，其等价式包括

\[
\|a\|^2+\|b\|^2\le(1+2\tau)\|a+b\|^2
\tag{LT-energy}
\]

与

\[
-\tau(\|a\|^2+\|b\|^2)
\le(1+2\tau)\langle a,b\rangle.
\]

AI_INFERENCE：Spingarn 与 Luke–Tam 之间没有无条件等价。固定 \(\sigma\)-hypomonotonicity 局部蕴含 Spingarn 渐近条件，因为 \(-\sigma\|a\|^2/\|a\|\to0\)；但 Luke–Tam 的负项含 \(b\) 与 \(a+b\)，没有 \(b\) 对 \(a\) 的 calm/Lipschitz 控制时不能化成 domain-only 界。

## 3. Weak monotonicity 与 hypomonotonicity

\(\sigma\)-hypomonotonicity的标准图不等式是

\[
\langle a,b\rangle\ge-\sigma\|a\|^2,\qquad\sigma\ge0,
\tag{H}
\]

等价于 \(A+\sigma I\) monotone。局部版本可能只是 restricted graph pairwise inequality，也可能要求存在全局 hypomonotone extension；两者不能默认相同。

VERIFIED_SOURCE：

- Luke–Tam 2025, Definition 3：  
  https://pubsonline.informs.org/doi/10.1287/moor.2025.0863
- Poliquin–Rockafellar 传统的可读 primary 回顾：  
  https://www.heldermann-verlag.de/jca/jca17/jca0849_b.pdf

Liu–Rafique–Lin–Yang 对 set-valued \(F:Z\rightrightarrows\mathbb R^d\) 定义 \(\rho\)-weakly monotone 为

\[
\langle\xi-\xi',z-z'\rangle
\ge-\rho\|z-z'\|^2
\quad
(z,z'\in Z,\ \xi\in F(z),\xi'\in F(z')).
\tag{WM}
\]

VERIFIED_SOURCE：Definition 1。

- Q. Lin, M. Liu, H. Rafique, T. Yang, Solving weakly-convex–weakly-concave saddle-point problems as weakly-monotone variational inequality：  
  https://arxiv.org/pdf/1810.10207

严格结论：相同空间、相同 graph/domain quantifiers 下，\(\rho\)-weakly monotone 与 \(\rho\)-hypomonotone 是逐字同一个不等式，只是社区名称不同。

但以下概念不能并入：

- weak Minty / star condition只固定一个解端点，通常形如 \(\langle u,x-x^\star\rangle\ge\rho\|u\|^2\)；
- weakly convex function 是函数性质；只有在明确 subdifferential convention 与假设后才对应 hypomonotonicity；
- equilibrium bifunction、序理论或聚合函数中的 weak monotonicity 使用不同对象与公式。

## 4. Cohypomonotonicity 与 comonotonicity

### 4.1 Combettes–Pennanen 2004 的 local extension convention

对 \(U\subset H^2\)，Combettes–Pennanen 定义 \(A\) 在 \(U\) 上 [maximal] \(\rho\)-hypomonotone，若存在 \(\bar A\) 使

\[
\bar A+\rho I\quad\text{[maximal] monotone},
\qquad
\bar A|_U=A|_U.
\]

并定义 \(A\) 在 \(U\) 上 [maximal] \(\rho\)-cohypomonotone，当且仅当 \(A^{-1}\) 在交换坐标后的相应局部图上 [maximal] \(\rho\)-hypomonotone。

VERIFIED_SOURCE：Definition 2.2。

- P. L. Combettes, T. Pennanen, Proximal Methods for Cohypomonotone Operators：  
  https://pcombet.math.ncsu.edu/sicon3.pdf  
  https://epubs.siam.org/doi/10.1137/S0363012903427336

全局且不讨论 extension/maximality 时，取逆给出 pairwise 式

\[
\langle a,b\rangle\ge-\rho\|b\|^2.
\tag{CH}
\]

在 local maximal 语境，(CH) 不能替代“存在全局 maximal hypomonotone extension”这一部分。

### 4.2 现代 \(\rho\)-comonotonicity

\[
\langle a,b\rangle\ge\rho\|b\|^2.
\tag{C}
\]

VERIFIED_SOURCE：

- H. H. Bauschke, W. M. Moursi, X. Wang, Generalized monotone operators and their averaged resolvents：  
  https://arxiv.org/pdf/1902.09827  
  https://link.springer.com/article/10.1007/s10107-020-01500-6

精确关系：

\[
A\text{ is }\rho\text{-comonotone}
\iff
A^{-1}\text{ is }\rho\text{-monotone}.
\]

- \(\rho>0\)：\(\rho\)-cocoercive；
- \(\rho=0\)：monotone；
- \(\rho=-\sigma<0\)：与全局 pairwise \(\sigma\)-cohypomonotone 同式。

这不自动包含 Combettes–Pennanen 的 local extension/maximality convention。概率论、经济学中的 comonotone random variables 也是完全不同的概念。

## 5. Semimonotonicity：两个 operator traditions

### 5.1 Otero–Iusem 2011

在 Hilbert 空间，对 \(0<\theta<1\)，\(T:H\rightrightarrows H\) 为 \(\theta\)-semimonotone 若

\[
\langle a,b\rangle
\ge-\frac{\theta}{2}\big(\|a\|^2+\|b\|^2\big).
\tag{OI}
\]

maximality 是固定 \(\theta\) 的 graph-inclusion maximality。该式 inversion invariant。作者限制 \(0<\theta<1\)，因为 \(\theta\ge1\) 时 Cauchy–Schwarz 使所有图自动满足。

VERIFIED_SOURCE：Definition 2。

- R. Gárciga Otero, A. Iusem, Regularity results for semimonotone operators：  
  https://www.scielo.br/j/cam/a/TDWFt7WPXgSTwXPnCt8rYdy/?format=pdf&lang=en  
  https://webdoc.sub.gwdg.de/ebook/serien/e/IMPA_A/672.pdf

### 5.2 Evens–Pas–Latafat–Patrinos 2023/2025

对 \((x',y')\in\operatorname{gph}A\)，pointwise \((\mu,\rho)\)-semimonotonicity 是

\[
\langle x-x',y-y'\rangle
\ge\mu\|x-x'\|^2+\rho\|y-y'\|^2
\quad\forall(x,y)\in\operatorname{gph}A.
\tag{EPLP-pw}
\]

若在每个图点成立，即为 all-pairs \((\mu,\rho)\)-semimonotonicity。

VERIFIED_SOURCE：Definition 4.1、Remark 4.2。

- B. Evens, P. Pas, P. Latafat, P. Patrinos, Convergence of the Preconditioned Proximal Point Method and Douglas–Rachford Splitting in the Absence of Monotonicity：  
  https://arxiv.org/pdf/2305.03605  
  https://link.springer.com/article/10.1007/s10107-024-02182-0

精确子类：

\[
(\mu,0)=\mu\text{-monotone},\qquad
(0,\rho)=\rho\text{-comonotone},\qquad
A^{-1}:(\mu,\rho)\mapsto(\rho,\mu).
\]

Otero–Iusem 参数必须按公式换算：

\[
\text{OI-}\theta
\iff
\text{EPLP-}(\mu,\rho)
\quad\text{with}\quad
\mu=\rho=-\theta/2.
\]

所以 bare \(\rho\)-semimonotone 不能跨两个传统复制同一个数值参数。后续矩阵版本

\[
\langle a,b\rangle\ge\langle a,Ma\rangle+\langle b,Rb\rangle
\]

又不能与 complementarity theory 的 semimonotone matrices 或 PDE 中的 semimonotone structures 合并。

## 6. Accretivity 与 inverse strong monotonicity

### 6.1 Accretivity

对实 Banach 空间 \(X\) 的 set-valued \(A:X\rightrightarrows X\)，标准 accretivity 为

\[
\|x-y+\lambda(u-v)\|\ge\|x-y\|
\quad
\forall\lambda>0,\ (x,u),(y,v)\in\operatorname{gph}A.
\tag{Acc}
\]

以 normalized duality mapping

\[
J(z):=\{j\in X^*:\langle z,j\rangle=\|z\|^2=\|j\|^2\}
\]

可等价写成：对每对图点，存在 \(j\in J(x-y)\) 使

\[
\langle u-v,j\rangle\ge0.
\]

量词“存在 \(j\)”不可误写成“对所有 \(j\)”。\(m\)-accretive 通常再要求 \(\operatorname{ran}(I+\gamma A)=X\) 对所有 \(\gamma>0\)；一些来源在 accretive 前提下用“某个 \(\gamma\)”的等价 range convention，必须打印版本。

VERIFIED_SOURCE（精确现代公式）：

- N. Pischke, Logical metatheorems for accretive and (generalized) monotone set-valued operators, Definition 2.2：  
  https://nicholaspischke.github.io/papers/metatheorems_accretive_monotone.pdf

早期 primary official provenance（不声称绝对最早）：

- F. E. Browder, Nonlinear accretive operators in Banach spaces (1967)：  
  https://projecteuclid.org/journals/bulletin-of-the-american-mathematical-society/volume-73/issue-3/Nonlinear-accretive-operators-in-Banach-spaces/bams/1183528868.full
- F. E. Browder, Nonlinear monotone and accretive operators in Banach spaces (1968)：  
  https://www.pnas.org/doi/10.1073/pnas.61.2.388

在 Hilbert 空间 \(J=I\)，故 accretive 与 monotone 精确等价；配合 Minty range condition，\(m\)-accretive 与 maximally monotone 等价。离开 Hilbert 空间后不能按内积式合并。复 Hilbert/semigroup 文献还常取 \(\operatorname{Re}\langle Ax,x\rangle\) 并有 dissipative 的相反号 convention。

### 6.2 Inverse strong monotonicity / cocoercivity

对 single-valued \(T:C\to H\)，

\[
\langle x-y,Tx-Ty\rangle
\ge\alpha\|Tx-Ty\|^2
\tag{ISM}
\]

称 \(\alpha\)-cocoercive，也常称 \(\alpha\)-inverse strongly monotone / Dunn property。公式上等价于 \(T^{-1}\) 的 \(\alpha\)-strong monotonicity，也是 set-valued \(\alpha\)-comonotonicity的正参数情形。

参数倒数是高风险点：Bauschke–Combettes 写 \(1/\beta\)-cocoercive 时，条件是

\[
\beta\langle x-y,Tx-Ty\rangle\ge\|Tx-Ty\|^2,
\]

即 (ISM) 中 \(\alpha=1/\beta\)。另一些论文直接把 RHS 系数命名为 \(\beta\)。atlas 必须抄公式。

VERIFIED_SOURCE：

- H. H. Bauschke, P. L. Combettes, The Baillon–Haddad Theorem Revisited：  
  https://arxiv.org/html/0906.0807v2
- J. C. Dunn, Convexity, monotonicity, and gradient processes in Hilbert space (1976)：  
  https://doi.org/10.1016/0022-247X(76)90152-9

## 7. Hölder / higher-order / gauge metric subregularity

### 7.1 residual-exponent \(q\) convention

对 \(F:X\rightrightarrows Y\) 与 \((\bar x,\bar y)\in\operatorname{gph}F\)，metric \(q\)-subregularity为：存在 \(\kappa,\delta>0\)，

\[
d(x,F^{-1}(\bar y))
\le\kappa\,d(\bar y,F(x))^q
\quad\forall x\in B_\delta(\bar x).
\tag{qSR}
\]

strong metric \(q\)-subregularity将左侧换成

\[
\|x-\bar x\|
\le\kappa\,d(\bar y,F(x))^q.
\tag{sqSR}
\]

VERIFIED_SOURCE：

- G. Li, B. S. Mordukhovich, Hölder Metric Subregularity with Applications to Proximal Point Method, Definition 3.1：  
  https://optimization-online.org/wp-content/uploads/2012/02/3340.pdf  
  https://epubs.siam.org/doi/pdf/10.1137/120864660
- B. S. Mordukhovich, W. Ouyang, Higher-Order Metric Subregularity and Its Applications, Definition 3.1：  
  https://arxiv.org/pdf/1507.04825  
  https://doi.org/10.1007/s10898-015-0271-x

在此 convention 下：

- \(0<q<1\)：Hölder metric subregularity；
- \(q=1\)：ordinary metric subregularity；
- \(q>1\)：Mordukhovich–Ouyang 的 higher-order metric subregularity。

固定足够小的 residual \(0<r<1\) 后，\(q\) 越大，estimate 越强；\(q_2>q_1\) 时，\(q_2\)-subregularity局部蕴含 \(q_1\)-subregularity。比较依赖局部 residual 已缩到 1 以下。

Mordukhovich–Ouyang 还指出：metric regularity 中 \(q>1\) 基本退化，只有常值型映射满足；但 metric subregularity 中 \(q>1\) 有非平凡对象。不可误写成“higher-order subregularity 不存在”。

普通 metric subregularity对应 inverse calmness，strong metric subregularity对应 isolated calmness；加 \(q\) 后常称 Hölder calmness / isolated Hölder calmness of order \(q\)。必须同步局部集合和同一 exponent convention。

### 7.2 reciprocal growth-exponent convention

另一类 error bound 把 order \(p\) 放在 solution distance：

\[
d(\bar y,F(x))
\ge c\,d(x,F^{-1}(\bar y))^p.
\tag{growth-p}
\]

当 \(c,p>0\) 时等价于

\[
d(x,F^{-1}(\bar y))
\le c^{-1/p}d(\bar y,F(x))^{1/p}.
\]

因此 residual exponent \(q=1/p\)。凡出现 power / higher-order exponent，必须先判断幂落在哪个距离上。

### 7.3 gauge convention

Luke–Thao–Tam 定义 gauge \(\mu:[0,\infty)\to[0,\infty)\) 连续、严格递增、\(\mu(0)=0\)、趋于无穷，并要求

\[
d(x,\Phi^{-1}(y)\cap\Lambda)
\le\mu(d(y,\Phi(x))).
\tag{gauge-R}
\]

当 \(y=\bar y\) 固定时称 gauge metric subregularity；\(\mu(t)=\kappa t^q\) 恢复 power case。

VERIFIED_SOURCE：Definition 2.17：  
https://arxiv.org/html/1605.05725v2

另一些 generalized error-bound 文献写

\[
\varphi(d(x,S))\le d(\bar y,F(x)).
\tag{gauge-L}
\]

只有 \(\varphi\) 可严格反演或明确给出 generalized inverse 时，(gauge-L) 才能无损转成 (gauge-R)。当前 RL 底稿

\[
d(x,S)\le\rho\,d(0,F(x))^q
\]

正是 residual-exponent convention。建议正式文本称 metric \(q\)-subregularity in the residual-exponent convention，不只写尚未稳定的 power metric subregularity。

## 8. Luke–Tam reflected resolvent 与 RL 的精确审计

### 8.1 原始精确命题

Luke–Tam 2025 Proposition 4 不是无条件全空间 resolvent 命题。其设定为：

- 有限维 Euclidean \(\mathbb E\)；
- \(F:U'\rightrightarrows\mathbb E\)，\(U\subset U'\)、\(W\subset\mathbb E\)；
- restricted operator

\[
F_W(u):=
\begin{cases}
F(u)\cap W,&u\in U,\\
\varnothing,&u\notin U;
\end{cases}
\]

- 比较域

\[
D:=(I+F_W)(U).
\]

在论文命题的 \(\tau<1/2\) 假设下，以下等价：

1. \(F\) 在 \(U\) in \(W\) Luke–Tam submonotone，violation \(\tau\)；
2. \(J_{F_W}\) 在 \(D\) 上 almost firmly nonexpansive，averaging constant \(1/2\)、violation \(\varepsilon=2\tau<1\)；
3. restricted reflected resolvent \(\widetilde T:=2J_{F_W}-I\) 在 \(D\) 上满足

\[
\|\widetilde T x-\widetilde T y\|
\le\sqrt{1+4\tau}\,\|x-y\|.
\tag{LT-RR}
\]

VERIFIED_SOURCE：

- Luke–Tam 2025, Proposition 4：  
  https://pubsonline.informs.org/doi/10.1287/moor.2025.0863

论文 proof 中的 \(\tau<1/2\) 来自 almost-firm violation 区间约定。即使从 (LT) 直接平方展开可在更宽参数范围得到形式上的 Lipschitz inequality，引用 Proposition 4 的“等价”时也不能删掉 published 参数与域假设。

### 8.2 尺度 \(\lambda\) 与 RL 的 \(\gamma=1\)

把 Luke–Tam 条件应用于 \(\lambda F\)，令 \(c=\lambda b\)，得到

\[
\lambda\langle a,b\rangle
\ge-\tau\|a+\lambda b\|^2.
\tag{LT-\(\lambda\)}
\]

由

\[
\|a-\lambda b\|^2
=\|a+\lambda b\|^2-4\lambda\langle a,b\rangle
\]

得

\[
\|a-\lambda b\|
\le\sqrt{1+4\tau}\,\|a+\lambda b\|.
\]

RL 在 \(\gamma=1\) 时等价于

\[
\lambda\langle a,b\rangle
\ge\frac{1-L^2}{4}\|a+\lambda b\|^2.
\]

因此 AI_INFERENCE 的精确换参为

\[
\boxed{
L\ge1:\qquad
\tau=\frac{L^2-1}{4},\qquad
L=\sqrt{1+4\tau}.}
\]

所以 RL-\(\gamma=1,L\ge1\) 与“\(\lambda F\) 的 Luke–Tam submonotonicity / restricted reflected-resolvent Lipschitz”是同一公式。若调用 Proposition 4 的 \(\tau<1/2\)，相应为

\[
1\le L<\sqrt3.
\]

若 \(0<L<1\)，RL 给出正下界

\[
\lambda\langle a,b\rangle
\ge\frac{1-L^2}{4}\|a+\lambda b\|^2,
\]

比 \(\tau\ge0\) 的 violation 类更强，不能用非负 \(\tau\) 原样编码。

还须注意：Luke–Tam 条件对正比例缩放一般不保持同一个 \(\tau\)。应用于 \(\lambda F\) 不是说 \(F\) 在 scale 1 的参数自动沿用；原输出限制为 \(W\) 时，缩放后还应追踪 \(\lambda W\)。

### 8.3 \(\gamma<1\) 不是固定-\(\tau\) Luke–Tam 类

RL 内积式是

\[
\lambda\langle a,b\rangle
\ge\frac14\big(r^2-L^2r^{2\gamma}\big),
\qquad r=\|a+\lambda b\|.
\]

对 \(r>0\)，可形式化成 scale-dependent signed violation

\[
\lambda\langle a,b\rangle
\ge-\tau_{\mathrm{eff}}(r)r^2,\qquad
\tau_{\mathrm{eff}}(r)
=\frac{L^2r^{2\gamma-2}-1}{4}.
\]

若 \(0<\gamma<1\)，则 \(r\downarrow0\) 时 \(\tau_{\mathrm{eff}}(r)\to+\infty\)。因此它不是固定 violation 的 Luke–Tam 局部类；在大尺度区又可能给正内积下界。其强弱是 scale-dependent，不能沿传统单一 monotonicity 轴排序。

### 8.4 是否已有 \(\gamma<1\) reflected-resolvent Hölder 先例？

本轮交叉检索了：

- “reflected resolvent” + “Hölder continuous” + operator；
- “\(2J_A-I\)” + Hölder resolvent；
- almost firmly nonexpansive + Hölder；
- “a-lambda b” + “a+lambda b” + monotone operator；
- Luke / Tam 2017/2018 与 2025 primary papers及其 resolvent characterization。

结果：

- VERIFIED_SOURCE：找到了 \(\gamma=1\) 的 Luke–Tam 精确先例 (LT-RR)；
- VERIFIED_SOURCE：找到了 Hölder metric regularity/subregularity 与集合 Hölder regularity；
- 没有找到 primary source 将 graph property 精确等价定义为

\[
\|R_{\lambda F}x-R_{\lambda F}y\|
\le L\|x-y\|^\gamma,\qquad0<\gamma<1,
\]

或

\[
\|a-\lambda b\|\le L\|a+\lambda b\|^\gamma.
\]

PENDING_VERIFICATION：本次有界 primary-source 审计未发现精确 \(\gamma<1\) predecessor；这不是“文献中不存在”的证明，也不能单独支持 novelty claim。下一轮应做 forward/backward citation chaining，并继续检索 Hölder nonexpansive、Hölder averaged、metric-transform resolvent、nonlinear modulus/gauge nonexpansiveness 等异名公式。

## 9. 合并到 atlas 时的命名规则

1. 每个条目先打印公式，再写名称。
2. local 至少拆成：一端点固定、两端点同邻域、graph \(U\times W\) localization、存在全局 extension、relative-to-set。
3. maximal 总要绑定具体 inequality、参数和局部图。
4. \(\lambda F\) 的参数不能无说明地记成 \(F\) 的参数。
5. Hölder / higher-order 必须注明幂在 residual 还是 solution distance 上。
6. weak Minty、star-monotone/star-cocoercive 与 all-pairs weak monotonicity/comonotonicity 分节点。
7. RL 正式命名前继续保留内部代号。目前可安全陈述：\(\gamma=1,L\ge1\) 精确回到 scaled Luke–Tam 公式；\(\gamma<1\) prior-art 仍为 pending。

## 禁止直接合并的同名概念

- Spingarn submonotone (S-pw) 与 Spingarn strictly submonotone (S-strict)：一端点固定 vs 两端点移动。
- 后期作者简称的 submonotone = Spingarn strictly submonotone，与 Spingarn 原文 bare submonotone。
- Spingarn 渐近一次距离 submonotonicity 与 Luke–Thao–Tam 2017 base-point quadratic submonotonicity。
- Luke–Thao–Tam 2017 pointwise submonotonicity 与 Luke–Tam 2025 two-point \(U,W\)-relative submonotonicity。
- Luke–Tam 2025 submonotonicity 与未经公式核验的所谓 Rockafellar/Wets submonotonicity；RW Example 12.28 应标为 hypomonotonicity。
- hypomonotonicity / modern weak monotonicity 与 weak Minty condition；前者 all-pairs，后者 solution-star/base-point。
- global pairwise cohypomonotonicity 与 Combettes–Pennanen local maximal cohypomonotonicity；后者含 extension/maximality。
- operator \(\rho\)-comonotonicity 与概率论/经济学的 comonotonicity。
- Otero–Iusem \(\theta\)-semimonotonicity 与 Evens et al. \((\mu,\rho)\)-semimonotonicity；只有 \((\mu,\rho)=(-\theta/2,-\theta/2)\) 这一切片相同。
- 上述 operator semimonotonicity 与 complementarity semimonotone matrices、PDE semimonotone structures。
- Banach-space accretivity 与 Hilbert-space monotonicity；仅在 Hilbert 几何下精确等价。
- inverse strong monotonicity 的系数 \(\alpha\) 与以 Lipschitz 常数 \(\beta=1/\alpha\) 命名的 convention。
- residual-exponent metric \(q\)-subregularity 与 growth-exponent order \(p\)；通常 \(p=1/q\)。
- Hölder metric subregularity（通常 \(0<q<1\)）与 higher-order metric subregularity（Mordukhovich–Ouyang residual convention 中 \(q>1\)）。
- gauge metric subregularity \(d(x,S)\le\mu(\mathrm{residual})\) 与反向 gauge error bound \(\varphi(d(x,S))\le\mathrm{residual}\)；无可逆 gauge 时不能互换。
- RL 的 \(\gamma<1\) reflected-resolvent Hölder 条件与 Luke–Tam 固定-\(\tau\) Lipschitz 条件；前者有效 violation 随尺度发散。
