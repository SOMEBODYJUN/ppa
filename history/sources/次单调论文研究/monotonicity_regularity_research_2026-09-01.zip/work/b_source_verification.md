# Gap-example primary-source verification

Status: source audit for Subagent B. This file verifies provenance and transcription only; it does not enlarge the atlas or draw a synthesis conclusion.

## 0. Evidence-depth labels

| Label | Meaning |
|---|---|
| P3-DIRECT | The formula/object and stated property were checked in accessible full text of the primary source, at the locator given below. |
| P2-DERIVED | The primary source supplies the object or base formula, while the sharper constant or specialization below is an explicit derivation made in this project. |
| ALG-CHECKED | An explicit algebraic construction has been checked directly, but no matching primary-source occurrence was located in the targeted search. It must not be attributed to a paper. |
| PENDING | Not checked deeply enough for safe attribution. |

Throughout, “safe to claim” means safe with the locator and evidence label shown. A P2-DERIVED or ALG-CHECKED statement must be identified as a project calculation, not as a verbatim theorem of the linked source.

## 1. Luke–Tam Example 2: the \(-\sqrt{x}\) map

### Primary source and locator

D. Russell Luke and Matthew K. Tam, “Generalized Monotonicity and the Proximal Point Algorithm,” Mathematics of Operations Research, published online 21 November 2025.

- [Official full text and DOI landing page](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863)
- Locator: Definition 2, Definition 3, Example 2, equations (19)–(21).
- Evidence depth for the example as printed: P3-DIRECT.

### Exact object and restricted sets

The example is

\[
F(x)=-\sqrt{x}\qquad (x\ge 0).
\]

When represented as a multifunction \(F:\mathbb R\rightrightarrows\mathbb R\), this means

\[
F(x)=
\begin{cases}
\{-\sqrt{x}\},&x\ge0,\\
\varnothing,&x<0.
\end{cases}
\]

The exact restricted sets and violation in Example 2 are

\[
U=[0,1/16],\qquad W=\mathbb R,\qquad \tau=2.
\]

Thus the directly sourced statement is: \(F\) is Luke–Tam submonotone on \(U\) in \(W\) with violation \(2\), while it is not hypomonotone at the origin.

### Sharp calculation

For distinct \(u,v\in U\), let

\[
s=\sqrt u+\sqrt v.
\]

Then \(0<s<1/2\) and

\[
(u-v)(F(u)-F(v))
=-\frac{1}{s}|u-v|^2,
\]

whereas

\[
\big|(u+F(u))-(v+F(v))\big|^2
=\frac{(1-s)^2}{s^2}|u-v|^2.
\]

Consequently the exact ratio required by the Luke–Tam inequality is

\[
\frac{- (u-v)(F(u)-F(v))}
{\big|(u+F(u))-(v+F(v))\big|^2}
=\frac{s}{(1-s)^2}.
\]

This increases to \(2\) as two distinct \(u,v\) approach \(1/16\). Hence \(\tau=2\) is the infimal valid violation on the printed \(U,W\). This sharpness statement is P2-DERIVED.

Hypomonotonicity would require a finite \(\sigma\) satisfying

\[
(u-v)(F(u)-F(v))\ge-\sigma|u-v|^2.
\]

The required ratio is \(1/(\sqrt u+\sqrt v)\), which is unbounded as \(u,v\downarrow0\). Thus no finite hypomonotonicity constant works on any right-neighborhood of \(0\) containing positive points. This is P2-DERIVED and agrees with the source’s qualitative conclusion.

### Safe and unsafe claims

Safe:

- The exact printed restriction is \(U=[0,1/16]\), \(W=\mathbb R\), \(\tau=2\).
- The output set over \(U\) happens to be \(F(U)=[-1/4,0]\), but this is not the \(W\) printed in the example.
- The map has no finite local hypomonotonicity constant at \(0\).
- The constant \(2\) is sharp on this \(U\), by the displayed project calculation.

Unsafe:

- Calling \(F\) an everywhere-defined real-valued map on \(\mathbb R\).
- Replacing \(U\) by an unspecified “small interval” while still presenting \(\tau=2\) as a direct quotation.
- Replacing \(W=\mathbb R\) by \(F(U)\) and calling that the exact source statement.
- Confusing Example 2’s direct violation with a conversion formula elsewhere in the paper, such as the parameter transformation in Proposition 6.

Main transcription risk: three pieces must travel together—\(U=[0,1/16]\), \(W=\mathbb R\), and \(\tau=2\).

## 2. Bauschke–Wang–Yao: paramonotone versus rectangular

### Primary source and structural warning

Heinz H. Bauschke, Xianfu Wang, and Liangjin Yao, “Rectangularity and paramonotonicity of maximally monotone operators.”

- [Primary arXiv record](https://arxiv.org/abs/1201.4220)
- [Primary full manuscript](https://arxiv.org/pdf/1201.4220)

The paper gives explicit inhabitants of the three nontrivial logical regions. All three entries below are P3-DIRECT.

### Region R1: rectangular and not paramonotone

Let \(X=\mathbb R^2\), let \(B_X\) be the closed unit ball, and define the skew rotation

\[
K=
\begin{pmatrix}
0&1\\
-1&0
\end{pmatrix}.
\]

The object is

\[
T=K+N_{B_X}.
\]

Locator: Proposition 3.4 and Example 3.5.

The source establishes that \(T\) is maximally monotone and rectangular, but not paramonotone. A quick witness for the latter is also transparent: for nonzero \(x\in\operatorname{int}B_X\), \(T(x)=Kx\) and \(T(0)=0\), while

\[
\langle x,Kx\rangle=0
\]

but \(Kx\notin T(0)\).

Safe:

- “\(K+N_{B_X}\) is rectangular but not paramonotone.”

Unsafe:

- Replacing the sum by \(K\) alone.
- Replacing the closed ball by its boundary circle.
- Calling \(T\) a linear relation: the normal-cone term makes the displayed \(T\) set-valued and nonlinear.

Main transcription risk: the gap object is the sum \(K+N_{B_X}\), not the bare skew map.

### Region R2: paramonotone and not rectangular

Let \(X=\ell^2\). Define

\[
A(x_1,x_2,\ldots)
=\left(x_1,\frac{x_2}{2},\frac{x_3}{3},\ldots\right)
\]

and

\[
B(x_1,x_2,x_3,x_4,\ldots)
=(-x_2,x_1,-x_4,x_3,\ldots).
\]

The gap object is

\[
T=A+B.
\]

Locator: Proposition 5.4 and Example 5.5.

The source establishes that \(T\) is a continuous linear maximally monotone operator that is strictly monotone, hence paramonotone, but is not rectangular.

Safe:

- Attribute the gap to \(A+B\) on \(\ell^2\).
- Note that \(B\) is skew and that

\[
\langle x,(A+B)x\rangle
=\sum_{n\ge1}\frac{x_n^2}{n}>0
\quad(x\ne0).
\]

Unsafe:

- Assigning “paramonotone but not rectangular” to \(A\) alone or \(B\) alone.
- Truncating to a finite-dimensional block and claiming the same separation. The infinite-dimensional range pathology is essential; the same paper’s Corollary 4.9 gives equivalence for maximally monotone linear relations in finite dimensions.

Main transcription risk: both the sum and the infinite-dimensional space are essential.

### Region R3: neither paramonotone nor rectangular

Let \(X=L^2[0,1]\) and let the Volterra operator and its adjoint be

\[
(Vx)(t)=\int_0^t x(s)\,ds,\qquad
(V^*x)(t)=\int_t^1 x(s)\,ds.
\]

Locator: Example 5.3.

The source establishes that \(V\) and \(V^*\) are continuous linear maximally monotone operators, and that each is neither paramonotone nor rectangular.

The key identity is

\[
\langle x,Vx\rangle
=\frac12\left(\int_0^1x(t)\,dt\right)^2.
\]

For \(e(t)\equiv1\), the symmetric part is

\[
V_+x=\frac12\langle x,e\rangle e.
\]

Taking \(x(t)=t-\tfrac12\) gives \(x\in e^\perp\setminus\{0\}\), so

\[
\langle x,Vx\rangle=0
\quad\text{but}\quad
Vx(t)=\frac{t^2-t}{2}\ne0.
\]

This violates paramonotonicity. Proposition 4.5 supplies the implication from rectangularity to paramonotonicity for the relevant linear setting, hence \(V\) is not rectangular. Example 5.3 also records the adjoint conclusion for \(V^*\).

Main transcription risks:

- Do not infer “not rectangular” merely from injectivity; use the paper’s linear-operator implication.
- Do not omit \(V^*\): it is a second explicit object in the same neither/neither region.
- In this paper, rectangularity is also called \(3^*\)-monotonicity. It is not the same as 3-cyclic monotonicity.

### The fourth logical region

For “paramonotone and rectangular,” the same paper records convex subdifferentials as a standard family; see Facts 1.3 and 1.4. This is P3-DIRECT. It is a baseline rather than a separation example.

## 3. Planar rotations: exact \(n\)-cyclic threshold

### Primary sources and locators

Full iff threshold:

- M. D. Voisei, “General monotonicity,” [primary arXiv v2 full text](https://arxiv.org/html/2411.04212v2), Example 43.
- [Primary arXiv record](https://arxiv.org/abs/2411.04212).

Published boundary witness:

- Simon Bartz, Heinz H. Bauschke, Jonathan M. Borwein, Simeon Reich, and Xianfu Wang, “Fitzpatrick functions, cyclic monotonicity and Rockafellar’s antiderivative,” Nonlinear Analysis 66 (2007), Example 4.6.
- [Institutional primary manuscript](https://openresearch.newcastle.edu.au/ndownloader/files/54384149)
- [Publisher DOI](https://doi.org/10.1016/j.na.2006.01.013)

The full iff is P3-DIRECT from the Voisei preprint. The older published paper directly verifies the boundary separation \(R_{\pi/n}\): \(n\)-cyclic but not \((n+1)\)-cyclic; it should not alone be cited for the entire iff range.

### Exact statement

For \(\theta\in[-\pi,\pi]\), let \(R_\theta\) be counterclockwise rotation of \(\mathbb R^2\) through angle \(\theta\). For every integer \(n\ge2\),

\[
R_\theta\text{ is maximal \(n\)-cyclic monotone}
\quad\Longleftrightarrow\quad
|\theta|\le\frac{\pi}{n}.
\]

Therefore

\[
R_\theta\text{ is \(n\)-cyclic but not \((n+1)\)-cyclic}
\quad\Longleftrightarrow\quad
\frac{\pi}{n+1}<|\theta|\le\frac{\pi}{n}.
\]

It is cyclically monotone of every finite order iff \(\theta=0\).

### Safe and unsafe claims

Safe:

- \(R_{\pi/n}\) is an explicit boundary example: \(n\)-cyclic and not \((n+1)\)-cyclic.
- The lower boundary of the strict gap is open, because \(|\theta|=\pi/(n+1)\) already satisfies \((n+1)\)-cyclic monotonicity.
- The source’s term “\(n\)-monotone” is being translated here to “\(n\)-cyclic monotone” because its defining cyclic-sum inequality is the latter convention.

Unsafe:

- Writing \(\pi/(n-1)\) or \(\pi/(n+1)\) as the operator’s \(n\)-cyclic threshold.
- Closing the left endpoint in the strict-gap interval.
- Treating \(n\)-monotonicity in this source as rectangular or \(3^*\)-monotonicity.
- Treating maximality at one fixed cyclic order as maximal cyclic monotonicity. For a nonzero angle, the rotation eventually fails at a higher order.

Main transcription risk: auxiliary angle formulas in proofs can contain shifted indices; the operator threshold itself is \(\pi/n\).

## 4. Prox-regular circle and norm-truncated normals

### Primary theorem

R. A. Poliquin, R. T. Rockafellar, and L. Thibault, “Local Differentiability of Distance Functions,” Transactions of the American Mathematical Society 352 (2000), 5231–5249.

- [Author-hosted copy of the published paper](https://sites.math.washington.edu/~rtr/papers/rtr170-LocalDiffDistance.pdf)
- Locator: Proposition 1.2; Theorem 1.3(g); Corollary 2.2; Proposition 2.3.
- Evidence depth: P3-DIRECT for the general theorem; P2-DERIVED for the circle specialization and sharp constant below.

For \(r>0\), the paper defines

\[
N_C^r(x)=
\begin{cases}
N_C(x)\cap\operatorname{int}B(0,r),&x\in C,\\
\varnothing,&x\notin C.
\end{cases}
\]

Theorem 1.3(g) and Corollary 2.2 state locally that \(C\) is prox-regular at \(\bar x\) iff, for some \(r>0\) and a neighborhood \(O\) of \(\bar x\), the norm-truncated map \(N_C^r\) is hypomonotone on \(O\).

Thus “truncated” means truncation in normal-vector norm. Omitting it materially changes the claim.

### Circle calculation

Let \(C=S^1\subset\mathbb R^2\). Then

\[
N_C(x)=\mathbb R x\qquad(x\in S^1),
\]

not merely the outward ray. For \(x,y\in S^1\), \(v=tx\), and \(w=sy\),

\[
\langle x-y,v-w\rangle
=\frac{t+s}{2}\|x-y\|^2.
\]

For the full normal cone, choosing \(t=s=-M\) with arbitrarily large \(M\) proves that no finite hypomonotonicity constant works, even after localizing \(x,y\) near one point of the circle.

For the open norm truncation \(|t|,|s|<r\),

\[
\langle x-y,v-w\rangle\ge-r\|x-y\|^2.
\]

The infimal constant is \(r\), approached as \(t,s\downarrow-r\). If a closed truncation \(|t|,|s|\le r\) is used in a separate project convention, equality is attained.

The circle has reach \(1\): \(P_C(z)=z/\|z\|\) for \(z\ne0\), while the center \(0\), at distance \(1\), has all of \(S^1\) as nearest points.

### Transcription risks

- Do not substitute the closed unit disk. Its convex normal cone is outward-pointing and globally monotone.
- Do not write \(N_{S^1}(x)=\mathbb R_+x\); for the equality manifold it is the full line \(\mathbb Rx\).
- Do not attribute the circle’s sharp constant \(r\) to the general paper. It is the project’s explicit specialization.
- Do not say prox-regularity makes the full normal map hypomonotone. The theorem requires a local norm truncation.

## 5. Regularity seeds: provenance status

This section is intentionally concise. It records which catalog seeds have primary provenance and which should remain algebraic constructions.

### 5.1 \(F(x)=\{-x,x\}\): primary

Primary source:

- R. Cibulka, A. L. Dontchev, and A. Y. Kruger, “Strong Metric Subregularity of Mappings in Variational Analysis and Optimization,” [primary arXiv full text](https://arxiv.org/html/1701.02078v1).
- [Publisher DOI](https://doi.org/10.1016/j.jmaa.2016.11.045)
- Locator: Introduction immediately after Proposition 1.2; discussion following Theorem 5.2.
- Evidence: P3-DIRECT for the stated properties; P2-DERIVED for the global exact metric-regularity identity.

At \((0,0)\) the source states that this map is metrically regular and strongly metrically subregular, but not strongly metrically regular. It also records strong-subregularity modulus \(1\).

Indeed,

\[
F^{-1}(y)=\{-y,y\},
\]

and

\[
d(x,F^{-1}(y))
=\min\{|x-y|,|x+y|\}
=d(y,F(x)).
\]

Thus its global exact metric-regularity modulus is \(1\). Strong metric regularity fails because \(F^{-1}(y)\) contains both signs for every sufficiently small \(y\ne0\).

Safe source label: PRIMARY + project calculation for the exact global identity.

### 5.2 Discrete graph: primary, with an indexing warning

The same Cibulka–Dontchev–Kruger paper, immediately after Theorem 5.2, uses

\[
\operatorname{gph}F
=\{(1/k,0):k\in\mathbb N_+\}\cup\{(0,0)\}.
\]

It is not strongly metrically subregular at \((0,0)\), while its limiting-normal/coderivative behavior shows that the cited coderivative condition is not sufficient. Evidence: P3-DIRECT.

Catalog warning: write \(k\in\mathbb N_+=\{1,2,\ldots\}\). The paper elsewhere uses a convention in which \(\mathbb N\) may contain \(0\), so copying \(1/k\) with an unqualified \(\mathbb N\) creates a division-by-zero transcription defect.

Do not label this map “not metrically subregular.” Since \(F^{-1}(0)=\operatorname{dom}F\), ordinary metric subregularity at \((0,0)\) is trivial, with infimal modulus \(0\). The intended failure is strong metric subregularity.

### 5.3 Hemiregularity constructions

Primary background and a primary nonregular example:

- A. Uderzo, “An implicit multifunction theorem for the hemiregularity of mappings with application to constrained optimization,” [primary arXiv full text](https://arxiv.org/html/1703.10552v2).
- Locator: Definition 2.1, Remark 2.2, Example 2.3.

Example 2.3 defines

\[
\Theta(p_1,p_2)=
\begin{cases}
p_1+p_2^2,&p_1\ge0,\\
p_1-p_2^2,&p_1<0,
\end{cases}
\]

and gives a primary example that is hemiregular but not metrically regular at \(((0,0),0)\). Because \(\Theta(0,0)=\{0\}\), it does not separate uniform hemiregularity from pointwise hemiregularity.

The following exact scalar seeds used in the working atlas were not located in the targeted primary full texts or exact-formula searches. They should be labeled ALG-CHECKED, not attributed to Uderzo or Cibulka–Dontchev–Kruger:

1. \(F(0)=\{0\}\cup\{1/n:n\ge1\}\), \(F(x)=\{x\}\) for \(x\ne0\): hemiregular with exact modulus \(1\), but not uniformly hemiregular.
2. \(F(x)=|x|\): strongly metrically subregular at \((0,0)\) with exact modulus \(1\), but not hemiregular because nearby negative target values have empty inverse.
3. \(F(x)=\{x,x^2\}\): hemiregular with exact modulus \(1\), but not metrically subregular at \((0,0)\), since the residual can be \(x^2\) while the zero-set distance is \(|x|\).
4. \(F(x)=\{x,0\}\): hemiregular with exact modulus \(1\); metric subregularity is trivial because \(F^{-1}(0)=\mathbb R\), but metric regularity fails.

These formulas are valid explicit project constructions after direct algebraic checking. No-hit provenance is not a novelty claim; it only means that no primary attribution is currently justified.

## 6. Compact handoff matrix

| Object | Intended logical role | Exact locator | Evidence | Catalog instruction |
|---|---|---|---|---|
| \(-\sqrt{x}\) | LT-submonotone, not hypomonotone | Luke–Tam Example 2, (19)–(21) | P3 + P2 sharpness | Preserve \(U=[0,1/16]\), \(W=\mathbb R\), \(\tau=2\). |
| \(K+N_{B_X}\) | rectangular, not paramonotone | BWY Prop. 3.4, Ex. 3.5 | P3 | Preserve the sum and closed ball. |
| \(A+B\) on \(\ell^2\) | paramonotone, not rectangular | BWY Prop. 5.4, Ex. 5.5 | P3 | Preserve the sum and infinite dimension. |
| \(V,V^*\) | neither rectangular nor paramonotone | BWY Ex. 5.3 | P3 | Use the exact integral formulas. |
| \(R_\theta\) | strict finite cyclic hierarchy | Voisei Ex. 43; 2007 Ex. 4.6 at boundary | P3 | Threshold \(|\theta|\le\pi/n\); strict-gap left endpoint open. |
| \(N_{S^1}\) | prox-regular set but untruncated normal not hypomonotone | PRT Thm. 1.3(g), Cor. 2.2 + calculation | P3 + P2 | Normal is \(\mathbb Rx\); theorem needs norm truncation. |
| \(\{\pm x\}\) | MR + SMSR, not SMR | CDK after Prop. 1.2 and after Thm. 5.2 | P3 + P2 modulus | Primary example. |
| discrete graph | coderivative pitfall; not SMSR | CDK after Thm. 5.2 | P3 | Use \(k\ge1\); do not call it non-MSR. |
| four scalar HREG seeds | several HREG separation regions | no exact primary locator found | ALG-CHECKED | Cite as project constructions only. |

## 7. Audit conclusion

The four highest-risk example families are now safe to use with exact locators:

1. Luke–Tam’s domain/output restriction and violation are exact, not schematic.
2. The BWY three-region objects are identified without dropping the sum, changing the ball, or finite-dimensionalizing the \(\ell^2\) example.
3. The rotation threshold and endpoint convention are fixed.
4. The Volterra conclusion is tied to Example 5.3 and the paper’s linear paramonotone/rectangular implication.

The circle is a derived specialization of a primary truncation theorem, not a printed example with the displayed sharp constant. The two CDK regularity seeds are primary. The four exact HREG scalar constructions should remain ALG-CHECKED until a matching primary locator is found.
