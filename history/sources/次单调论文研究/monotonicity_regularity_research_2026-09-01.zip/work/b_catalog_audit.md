# Subagent B catalog 独立审计

> 审计对象：`research/theory_atlas.md` 与全部 `work/b_*.md`。  
> 审计日期：2026-09-01。  
> 性质：只做 catalog 一致性、公式、量词、证据等级与去重审计；**不合并原文件，不作 seesaw synthesis**。  
> 优先规则：涉及 primary-source 对象时，以 `work/b_source_verification.md` 的 P3/P2 记录为准。

## 0. 结论摘要

- **BLOCKER：1 组。** `CP-01` 没有说明 Cayley 公式究竟是全空间定义、还是只在 bounded tube 上定义；按本文件 §0 的默认规则读取时，其零集和全 tube 的 q-MSR 结论不成立。这个问题必须在把 `exact \gamma q` 当作 verified example 前修复。
- **MAJOR：14 组。** 除 atlas source ledger、`RM-07`、去重、source label、oscillatory proof、索引与 vacuity 问题外，还包括 `LC-11` 漏掉 stepsize、`RM-03` 漏记 MR/SMR、EX-17 的 graph-anchored / map-pointwise 混型、atlas 的最近解存在量词，以及 rotation Cayley 公式的奇异参数例外。
- **公式复核总体结果：** 除上述 scope/signature 问题外，没有发现另一个会改变对象本身的 BLOCKER 级 `F/gph F/zer F/F^{-1}/J/R` 代数错误。跨文件重复对象的公式大多一致。
- **数值证据纪律：** 各文件的 grid/SVD/spot checks 均明确写成“非证明”；未发现把纯数值采样直接冒充 universal proof 的条目。真正需要降级的是若干只写“standard two-scale estimate”却没有给 upper-bound lemma 的 sharp Hölder 结论。

---

## 1. BLOCKER

### BCA-B01 — `CP-01` 的 ambient mapping / restricted window 混用，导致零集与 q-MSR 量词不确定

**Origin：** `b_algorithm_anchored.md`, CP-01，尤其 (2.1)–(2.6)。

文件 §0 规定：给定 `R:D\to H` 时，生成的 graph 是 `\Gamma_R`，因而自然 mapping 只定义在 `J(D)`。CP-01 又取

\[
D=(-M,M)\times(-\delta,\delta),
\]

但随后写

\[
S=\mathbb R\times\{0\},\qquad
d((s,w),S)=|w|.
\]

若严格按 §0 读取，则实际零集只是

\[
S_D=(-M,M)\times\{0\},
\]

而且全 `J(D)` 上的 q-MSR 会在 tangential boundary 失效。具体地，令

\[
t_n=M-\tfrac12|z_n|^\gamma,
\qquad z_n\to0,
\qquad \alpha=\gamma q>1.
\]

则

\[
J(t_n,z_n)=
\left(M+\tfrac12|z_n|^\gamma,\ P_\alpha(z_n)\right).
\]

到 `S_D` 的距离为 `\Theta(|z_n|^\gamma)`，而 residual 的 q 次方为

\[
E_F(J(t_n,z_n))^q
=\Theta(|z_n|^{\gamma q})
=\Theta(|z_n|^\alpha).
\]

因为 `\alpha>\gamma`，两者之比发散。因此当前文字不能同时按“restricted graph”解释并保留全 tube 的 sharp q-MSR。

**推荐的直接修正句（保留原构造的最简方案）：**

> 公式 (2.1)–(2.2) 先在整个 \(\mathbb R^2\) 上定义全局三角双射 \(J\) 及单值映射 \(F\)；集合 \(D=(-M,M)\times(-\delta,\delta)\) 仅是检验 restricted all-pairs RL、self-map 与迭代漂移的窗口。于是 \(S=\mathbb R\times\{0\}\) 及 \(d((s,w),S)=|w|\) 均按全局 \(F\) 理解，而 RL\(_\gamma\) 只声称在 \(D\) 上成立。

若不愿作全局延伸，则必须改写为：

> 对由 \(D\) 生成的 restricted mapping，零集为 \((-M,M)\times\{0\}\)；q-MSR 与距离恒等式只在某个 interior zero \((t_0,0)\)、且邻域与 \(t=\pm M\) 保持正 margin 时成立，不声称在整个 \(J(D)\) 上 uniform 成立。

在二者中任选一种并统一全文前，`CP-01 = exact \gamma q` 不能进入 verified phase cloud。

---

## 2. MAJOR

### BCA-M01 — atlas 的 Luke–Tam strictness ledger 已被 `b_source_verification` 推翻

**Origin：** `theory_atlas.md` §1.3、§3.4、§4.1、§8.1；对照 `b_source_verification.md` §1 与 `MGB-01`。

Atlas 仍把 `hypomonotone \Rightarrow LT` 的 strict witness 写成 pending；但 source verification 已核实：

\[
F(x)=-\sqrt{x},\quad
U=[0,1/16],\quad W=\mathbb R,
\quad \tau_*=2,
\]

且在 0 的任何右邻域都不存在 finite hypomonotonicity modulus。`MGB-01` 的独立计算同时给出 sharp reflected constant `L=3`。因此 pending 状态已过期。

**可直接修正句：**

> 反向一般失败：Luke–Tam Example 2 的 \(F(x)=-\sqrt{x}\)，在 \(U=[0,1/16]\)、\(W=\mathbb R\) 上以 sharp violation \(\tau=2\) 满足 LT-submonotonicity，但在 0 的任何右邻域均无 finite hypomonotonicity modulus（P3-DIRECT + P2-DERIVED；见 `b_source_verification` §1 / `MGB-01`）。故该 implication 是 strict。

同时应从 atlas pending ledger 删除这一个 strictness 待办。另，atlas 将 arXiv:2411.04212v2 标成 “Bauschke et al. 2024”；source verification 给出的作者是 **M. D. Voisei**，应改为：

> Voisei, *General monotonicity*, Example 43；Bartz et al. 2007 只作为 boundary witness。

### BCA-M02 — `RM-07` 漏掉同一 primal map 的 MR/SMR，和 `RM-06` 的“同标签”比较过粗

**Origin：** `b_algorithm_anchored.md`, RM-07 与 handoff matrix C。

对两条 transverse lines，

\[
F=N_C+N_D,qquad
\operatorname{dom}F=\{0\},qquad F(0)=\mathbb R^2.
\]

所以 `F` **恰是** `N_{\{0\}}`，并且

\[
F^{-1}(b)=\{0\}\quad\forall b\in\mathbb R^2.
\]

因此它不只是“domain-vacuous SMSR”：它还 global SMR/MR，且 MR/SMR/SMSR/MSR 的 exact infimum 全为 0。`RM-06` 的 tangent pair 则只有 vertical output coverage，MR/SMR 失败。二者只在“fixed-target SMSR 的 binary yes 标签”上相同，完整 regularity signature 并不相同。

**可直接修正句：**

> 此处 \(F=N_{\{0\}}\)。故 \(F^{-1}\equiv0\)，F 在 \((0,0)\) global SMR/MR，exact modulus 0；其 SMSR/MSR 也成立且因 domain-vacuity 具有 exact modulus 0。RM-06 与 RM-07 只共享“fixed-target F-SMSR = yes”这一退化标签，不共享完整 inverse-stability signature。

同理，`RM-04` 的 isolated variant `C={0}` 也应补记：`N_{\{0\}}` 的 inverse 是 global constant singleton，故 MR/SMR exact 0。

### BCA-M03 — exact aliases 若作为独立 phase points，会人为重复加权

**Origin：** 全部 B catalogs。

下面 §5 给出安全 canonical map。最严重的重复包括 `x^3` 被四次登记、zero operator 被三次登记、`{\pm x}` 被两次登记、normal-cone / Cayley families 又在算法文件中以不同 residual encoding 重复出现。公式本身通常不冲突；风险在于 synthesis 若把每个 ID 当独立数学对象，会伪造样本权重。

**可直接修正句：**

> Phase-cloud 计数以 canonical operator/object 为单位；同一对象的不同 reference、domain restriction、stepsize 或 algorithm residual 只作为该 canonical object 的 observation 子记录，不作为新的独立 operator 点。

### BCA-M04 — primary 对象 `F(x)={-x,x}` 被错标为 SELF-CONSTRUCTED / ALG

**Origin：** `EX-18`、`SVG-12`；对照 `b_source_verification.md` §5.1。

Cibulka–Dontchev–Kruger 已直接给出这个对象在 `(0,0)` 的 MR + SMSR、非 SMR 结论及 strong-subregularity modulus 1。Global exact identity

\[
d(x,F^{-1}(y))=d(y,F(x))
\]

是本项目 P2 推导。故两个 catalog 的 source label 与 source-verification 冲突。

**可直接修正句（两条都使用）：**

> 来源：PRIMARY—Cibulka–Dontchev–Kruger（Proposition 1.2 后及 Theorem 5.2 后）；MR + SMSR + non-SMR 与 strong-subregularity modulus 1 为 P3-DIRECT，global exact MR identity 为 P2-DERIVED。

同一 source-priority 规则还应统一为：

- `MGB-01`：printed object/restriction/`\tau=2` 是 P3；sharpness 是 P2；
- `MGB-08`–`MGB-11`：BWY logical labels 是 P3，额外 inverse/resolvent/moduli 是 ALG/P2；
- `MGB-13`–`MGB-15`：Voisei threshold 是 P3；
- `MGB-20` / `SVG-16`：prox-regular truncation theorem 是 P3，circle sharp constant是 P2；
- exact HREG scalar seeds仍为 ALG-CHECKED，不得反向归因给 Uderzo/CDK。

### BCA-M05 — `CP-02`、`AR-02`、`AR-06` 的 sharp all-pairs Hölder upper bound 证明等级过高

**Origin：** `b_algorithm_anchored.md`, CP-02 (2.7)–(2.12a)，AR-02 (1.3)–(1.4)，AR-06。

这些条目用 oscillatory cusp

\[
h(x)=|x|^a\sin(|x|^{-b})
\]

并正确给出了相邻极值点上的 failure sequence，因而“任何 exponent 大于 `a/(b+1)` 失败”已有依据。但 upper implication

\[
|h(x)-h(y)|\le C|x-y|^{a/(b+1)}
\]

只以 “standard two-scale estimate” 一句带过，handoff 却把 `G_{a/(b+1)}` 和 maximal exponent 标成 VERIFIED-ALG。这个 upper bound 是 CP-02/AR-02/AR-06 的核心 all-pairs label，不能只由 failure sequence推出。

**可直接修正句（在补 lemma 前）：**

> 相邻振荡极值点已证明任何 \(\eta>a/(b+1)\) 失败；\(G_{a/(b+1)}\) 的 upper bound 暂标 CANDIDATE，待 C 补出完整 two-scale proof 后再写 “maximal Hölder exponent”。

一个足够的 proof patch 是明确分两区：

1. `|x-y|` 大于同尺度的 `c\max(|x|,|y|)^{b+1}` 时用 amplitude bound；
2. 更小时用 derivative bound `|h'(t)|\lesssim |t|^{a-b-1}`；

两界在尺度 `|t|\asymp|x-y|^{1/(b+1)}` 处给出 exponent `a/(b+1)`。CP-02 再代 `a=q,b=q/\gamma-1` 得 `\gamma`；AR-02/06 代 `a=\alpha` 得 `\eta_*=\alpha/(\beta+1)`。

### BCA-M06 — `EX-22` 的 `1/n` 索引未定义

**Origin：** `b_scalar_nonlinear.md`, EX-22 (4.5)。

当前写

\[
K=\{0\}\cup\{1/n:n\in\mathbb N\}.
\]

若本项目采用 `0\in\mathbb N`，则出现 division by zero；`b_source_verification` 已专门警告这一转录风险。

**可直接修正句：**

> \(K=\{0\}\cup\{1/n:n\in\mathbb N_+\}\)，其中 \(\mathbb N_+=\{1,2,\ldots\}\)。

### BCA-M07 — `EX-05/EX-06` 没有按“一例一卡”拆分

**Origin：** `b_scalar_nonlinear.md`, `### EX-05/EX-06`。

`F_+` 与 `F_-` 是两个不同 homeomorphisms，满足/失败的 gauge 方向相反。把它们放在一个 heading 下会使 origin ID、source/status、去重和 C-stage property row 都不稳定，也违反用户要求的独立 example entry。

**可直接修正句：**

> 以下先保留 shared family lemma；随后分别建立 EX-05 与 EX-06 两张独立卡，各自打印 mapping、inverse、满足的 gauge、失败的 gauge、sharp power exponent、参数与 source/status。

### BCA-M08 — `MGB-05` 的 exact-modulus-0 机制误叫 `domain-vacuity`

**Origin：** `b_monotonicity_gaps.md`, MGB-05 regularity seed 与 C queue。

在 `x\downarrow0` 的有效 domain 上仍有真实非零点，且 residual `|A(x)|=1/x\to\infty`；MSR 不等式并不是因为 domain 外取 `+\infty` 才成立。正确机制是：

- graph 在 product neighborhood of `(0,0)` 中 isolated；
- mapping-side fixed-target residual 沿 domain branch 逃向 infinity；
- inverse isolated calmness 因近零非零 targets 的 fibers empty 而单边/vacuous。

**可直接修正句：**

> 该条的 q-SMSR exact modulus 0 来自 **RESIDUAL-ESCAPE / GRAPH-ISOLATION**，不是纯 DOMAIN-VACUITY；inverse isolated calmness 对近零 empty fibers 的 inclusion 则是 vacuous。两种量词机制分开标记。

### BCA-M09 — `RM-06` 的 local fixed-set equality 被直接使用，但显示证明缺了一步

**Origin：** `b_algorithm_anchored.md`, RM-06 (3.16)–(3.18)。

文件正确地把 full-tube `q=1/2` EB 标为 CANDIDATE；但在 slice linear-EB failure 中使用了“local Fix 恰为 vertical axis”，只验证了 vertical axis 的 inclusion。这个 equality 实际成立，宜补出两行证明，避免 slice distance 依赖未经显示的 claim。

**可直接补丁句：**

> 写 \(z=(a,b)\) 且 \(P_D(a,-b)=(s,s^2)\)，则 \(T_{DR}(a,b)=(s,b+s^2)\)。fixed-point 方程给 \(a=s\) 且 \(s^2=0\)，故 \(a=0\)。反之当 \(|b|<1/2\) 时 \(P_D(0,-b)=0\)，所以 local \(\operatorname{Fix}T_{DR}=\{0\}\times\mathbb R\)。

补完后，slice 上 `d((t,0),Fix T)=|t|` 与 linear MSR failure 才是 self-contained proof；full-tube `q=1/2` upper EB 仍保持 CANDIDATE。

### BCA-M10 — `LC-11` 的 `J/R` 漏掉 `\lambda`

**Origin：** `b_linear_cayley.md`, LC-11 Cayley formulas。

文件总口径是任意 `\lambda>0`，但当前正半轴写成 `J(s)=s/2,R(s)=0`，这只对 `\lambda=1` 正确。对 `F(x)=x_+`，正确公式是

\[
J_{\lambda F}(s)=
\begin{cases}s,&s\le0,\\ s/(1+\lambda),&s\ge0,
\end{cases}
\qquad
R_{\lambda F}(s)=
\begin{cases}s,&s\le0,\\ \dfrac{1-\lambda}{1+\lambda}s,&s\ge0.
\end{cases}
\]

后续 `Lip J=Lip R=1`、global RL-1 sharp `L=1` 与 subunit global failure仍正确。

**可直接修正句：** 用上述分段公式替换 LC-11 当前 `s/2,0` 公式；若坚持原公式，则必须把整个条目显式固定为 `\lambda=1`。

### BCA-M11 — `RM-03` 漏记 `\partial|\cdot|` 的 MR/SMR

**Origin：** `b_algorithm_anchored.md`, RM-03 与 handoff matrix C。

`RM-03` 的 operator 是 `F=\partial|\cdot|`，不是 single-valued `F(x)=|x|`。对 `|b|<1`，

\[
F^{-1}(b)=\{0\},
\]

所以 inverse localization 是常值：F 在 `(0,0)` 实际具有 SMR/MR/SMSR/MSR，四个 exact infimum均为 0。条目只登记了 fixed-target modulus 0，导致完整 regularity signature缺失。

**可直接修正句：**

> 由于 \(F^{-1}(b)=\{0\}\) 对所有 \(|b|<1\) 成立，\(F=\partial|\cdot|\) 在 \((0,0)\) SMR/MR，且其与 SMSR/MSR 的 exact infimum均为 0；modulus-zero机制是 inverse branch pinning / residual jump。

禁止把它与 `EX-16/SVG-14` 的 single-valued absolute-value map去重；后者是 SMSR 但非 MR。

### BCA-M12 — EX-17 的 anchored graph inequality 不能直接叫已定义的 map-pointwise `P_\gamma`

**Origin：** `b_algorithm_anchored.md` §0 的 A/P/G 定义；`b_scalar_nonlinear.md`, EX-17 (3.7)–(3.8)。

`A_\gamma(p)\iff P_\gamma(p)` 只对同一个 single-valued Cayley map `R:D\to H`、同一 selection/window成立。EX-17 的 `I+\eta F` 在 0 的每个邻域都非单射，故其 `J,R` 是 relations；(3.8) 实际控制的是“以 solution graph point 为一端、对每个 graph point”的 anchored graph inequality，而不是 §0 定义的 single-valued `P_\gamma`。

**可直接修正句：**

> EX-17 记为 \(A^{\mathrm{gph}}_1(0)\)：对所有相关 graph points、以 \((0,0)\) 为锚的 graph inequality成立。除非另行指定 single-valued selection及其量词，不把它称为 map-pointwise \(P_1(0)\)，也不套用 (0.3)。

### BCA-M13 — atlas 的 `\gamma q` 推导默认最近解存在

**Origin：** `theory_atlas.md` §3.5, (3.10)–(3.12)。

Atlas 在一般 Hilbert 空间令 `r=d(x,S)` 后使用 solution pair。若 `S` 非凸、仅闭，最近点未必存在；不能默认有 `p\in S` 满足 `\|x-p\|=r`。此外，近似最近解与 `x^+` 必须统一落入 restricted graph 和 MSR windows。

**可直接修正句：**

> 对每个 \(\varepsilon>0\) 取 \(p_\varepsilon\in S\) 使 \(\|x-p_\varepsilon\|\le d(x,S)+\varepsilon\)，并要求这些 graph pairs 与 \(x^+\) 统一位于有效 graph/MSR window；先以 \(r+\varepsilon\) 推导 (3.10)–(3.12)，再令 \(\varepsilon\downarrow0\)。若假设 S proximinal，则可直接选最近解，但必须打印该假设。

### BCA-M14 — rotation 的公共 Cayley 公式漏掉奇异参数

**Origin：** `b_monotonicity_gaps.md` §4 的 common rotation formulas。

该段写“对所有 `\theta`”，但当

\[
(\theta,\lambda)=(\pi,1)
\]

时 `Q_\theta=-I`、`I+\lambda Q_\theta=0`，显示分母 `\Delta=0`，resolvent多值且 Cayley矩阵公式不可用。MGB-13–15 的角度不触发该例外，但公共公式范围仍需修正。

**可直接修正句：**

> 下列 Cayley公式只在 \(\Delta=1+2\lambda\cos\theta+\lambda^2>0\)（等价 \(I+\lambda Q_\theta\) 可逆）时使用；奇异点 \((\theta,\lambda)=(\pi,1)\) 单列为 Minty collapse。

---

## 3. 压缩后的 MINOR

1. `MGB-01` 的 resolvent 公式出现 `)^2,qquad`，应为 `)^2,\qquad`；这是渲染错误，不改变公式。
2. `LC-09` 写 `R` 的绝对对角元“可能在特殊小 n 取 1”。对 `\lambda>0,n\ge1`，
   \[
   \left|\frac{n-\lambda}{n+\lambda}\right|<1
   \]
   对每个有限 n 都严格成立；`\|R\|=1` 只由 tail supremum 给出。删去该 parenthetical 即可。
3. `P_\alpha` 在 `b_algorithm_anchored.md` 的 RM/CP block 先使用、到 AR block 才显式定义；建议在 §0 一次性定义 `P_\alpha(t)=\operatorname{sgn}(t)|t|^\alpha`。

---

## 4. 公式、local/global、vacuity 与 proof-status 核查结果

### 4.1 已通过的高风险公式簇

以下跨文件公式相互一致，C 仍应独立复算 sharpness，但 B 阶段没有发现标签冲突：

- zero operator：`J=R=I`，MSR exact 0 但为 big-solution triviality；
- `x^3`：`R` nonexpansive、sharp fixed-target exponent `q=1/3`；
- `\mu I+N_{[0,\infty)}`：inverse `y_+/\mu`，SMR/MR/SMSR/MSR modulus `1/\mu`，`R` 的负支斜率 `-1`；
- diagonal projection：cocoercivity与 MSR modulus一致，MR/SMSR失败机制分别是 cokernel/kernel；
- `F(x)={-x,x}`：global MR identity、SMSR modulus 1、SMR 因 branch multiplicity失败；
- circle full normal：`N_{S^1}(x)=\mathbb Rx`，full `J` 多值，normal-norm truncation sharp modulus为 truncation radius；
- pure power Cayley 与 tanh Cayley：`EX-11/LC-15`、`EX-13/LC-16` 的 scaling 后公式一致；
- BWY 三个 logical regions 与 Voisei rotation threshold均和 source-verification 一致。

### 4.2 local/global 或 vacuity 必须保留的限定

| Origin | 安全标签 | 不安全简写 |
|---|---|---|
| `MGB-01` / `EX-14` | restricted graph；source exact data只在 `U=[0,1/16],W=R` | 把 `\tau=2` 写成任意小区间或 full-domain theorem |
| `LC-15` / `EX-11` / `AR-01` | 同一 Cayley-power family 的 global、scaled、restricted germ | 把三个 ID 当三个独立 natural objects；把 local zero set与 global `{-1,0,1}` 混合 |
| `RM-04` main | `N_L` 的 F-MSR domain-vacuous；projection residual EB nonvacuous | 把两个 residual 的 modulus直接排序 |
| `RM-07` | F 的四类 regularity全成立且 modulus 0；fixed-target侧 domain-vacuous | 只写 “与 RM-06 同样 primal regularity” |
| `MGB-05` | residual escape / graph isolation | 纯 domain-vacuity |
| `EX-20` | big-solution / full-value local triviality | domain-vacuity（其 domain 实际含 interior） |
| `SVG-02/03/06` | exact infimum 0，分别来自 branch pinning、residual jump、domain-vacuity | 把 modulus 0 统一解释成同一机制 |
| `RM-06` | slice 已证 linear EB failure；full-tube q=1/2 是 candidate | 用 slice asymptotic宣称 full q-EB theorem |

### 4.3 candidate / numerical proof 审计

- 正确保留 `CANDIDATE`：`AR-02/04/06` 的 full multifunction MSR、`RM-06` full-tube q-EB、`MGB-07` product sharp modulus、`CP-06` 的“不存在性”外推。
- 需要新增 `CANDIDATE`：在 BCA-M05 的 two-scale upper proof补齐前，`CP-02` 的 exact all-pairs exponent、`AR-02/06` 的 `G_{\eta_*}` upper label。
- 已是 analytic proof、数值仅自检：`MGB-02` endpoint `L=2`、`MGB-09` block singular values、rotation Cayley norms、`LC-07` shear norms、`LC-17` derivative minimum等。

---

## 5. 安全去重映射

下表不是删条目建议；它规定 synthesis/Catalog integration 如何计数与引用。

| Canonical ID | Exact aliases / family members | 安全处理 |
|---|---|---|
| `CAN-CUBIC` | `EX-01 = SVG-04 = LC-21`；`RM-02` 使用同一个 F；`CP-05` 的 `p=3` | operator只计一次；RM/CP保留算法 observation |
| `CAN-ZERO` | `EX-19 = SVG-05 = LC-01` | 完全去重为一个 operator 点 |
| `CAN-ABS` | `EX-16 = SVG-14` | 完全去重 |
| `CAN-PM-REL` | `EX-18 = SVG-12` | 完全去重；统一 primary source label |
| `CAN-N-HALFLINE` | `SVG-01 = LC-12`；`SVG-02` 同 operator、不同 target `(0,-1)` | operator一份，两个 reference observations |
| `CAN-MU-N-HALFLINE` | `SVG-07 = LC-10` | 完全去重 |
| `CAN-RESTRICTED-SLOPE` | `SVG-08 = LC-13` | 完全去重 |
| `CAN-DIAG-PROJ` | `SVG-11 = MGB-12 = LC-06|_{c=1}` | 一份 operator；BWY/paramonotone observation单列 |
| `CAN-SKEW` | `MGB-13 = LC-04|_{\omega=1}`（orientation无关） | 一份 operator；cyclic与 linear-Cayley字段合并 |
| `CAN-POS-SCALAR` | `LC-02` family = `CP-03` family；`MGB-16` 是 `c=1` | family一份，保留 tuned step/algorithm字段 |
| `CAN-NEG-SCALAR` | `LC-03` family；`EX-15=MGB-22=LC-03|_{c=1}`；`MGB-03` 是 subcritical step | family一份；`MGB-19` 是 restricted-domain germ，不能当 exact global alias |
| `CAN-CAYLEY-POWER` | `EX-11 = LC-15` after `\lambda_0=1`；`AR-01` 是 restricted germ | global/scaled/local observations保留，不重复计点 |
| `CAN-TANH-CAYLEY` | `EX-13 = LC-16` after `\lambda_0=1` | 完全按 scaling去重 |
| `CAN-N-SUBSPACE` | `SVG-10 = RM-04` main F | operator一份；algorithm residual另列 |
| `CAN-N-SINGLETON` | `SVG-06 = RM-04` isolated variant；`RM-07` primal F 也是同对象 | 一份 operator，三个用途 observations |
| `CAN-SUBDIFF-ABS` | `SVG-03 = RM-03` | operator一份；prox residual另列 |
| `CAN-NEG-SQRT` | `MGB-01 = EX-14|_{r_0=1/16}` after catalog restriction | MGB-01 为 source canonical；EX-14 是 general ALG family，不算第二 source witness |
| `CAN-CIRCLE-NORMAL` | `MGB-20 = SVG-16` | 一份对象；source theorem与 circle P2计算统一 |
| `CAN-SHIFTED-NEGABS` | `MGB-21` 与 `SVG-17` 由 output affine shift对应 | 只记 affine-equivalent，不作 literal alias |
| `CAN-TANGENT-PAIR` | `SVG-20` 与 `RM-06` 使用同一 line/parabola sets | underlying set pair一份；set mapping、normal sum、DR residual是不同 mappings |
| `CAN-TRANSVERSE-LINES` | `SVG-18` axes 与 `RM-07` angle family | 同 family不同参数；不是 exact alias |

补充：`LC-09` 的 compact diagonal `D` 只是 `MGB-09` 中 `D+B` 的一个分量，**不能**把二者去重为同一 operator。

另外严禁以下误合并：single-valued `|x|` 与 set-valued `\partial|x|`；projection `P_C` 与 normal cone `N_C`；algorithm map `T=P_C` 与 primal operator `F=N_C`。

---

## 6. `\gamma q` sharpness 与 anchored/all-pairs 的循环性审计

### 6.1 逻辑上已通过

- `A_\gamma(p)\iff P_\gamma(p)` 在同一 fixed base、同一 window、同一 selection 与常数下是定义级等价；catalog 没有构造一个非法的同-base反例。
- `CP-06` 的 branch lemma (2.18) 代数正确：isolated zero、`q>1` q-MSR 与 residual趋零时，solution-anchored RL-1 自动出现；它不推出 all-pairs Lipschitz。
- `AR-01` 正确区分“一步 `\Theta(r^\gamma)`”与 convergence：self-map/invariance失败，所以 sharp one-step law不等于 rate theorem。

### 6.2 信息上循环、不得当作独立规律证据

`CP-01` 先定义

\[
\alpha:=\gamma q
\]

再把 normal update 直接设为 `z^+=P_\alpha(z)`，同时把 F 的第一 residual 分量设计成 `|w|^{1/q}`。所以 `r_+=r^{\gamma q}` 是一个**calibrated realization**：它证明“该组合可被显式达到”，但不是从独立 graph geometry 与独立 regularity data 反推出的经验支持。

`CP-02` 又令

\[
\beta=q/\gamma-1
\]

以强制 oscillatory all-pairs exponent 等于 `\gamma`。这个例子适合证明 all-pairs exponent 与 anchored exponent可分离、generic `\gamma q` 上界可很松；它同样不能被当成 `\gamma` 与 `q` 自发配对的独立样本。

**必须附在 integration handoff 的直接警告句：**

> CP-01 与 CP-02 是按目标 exponents 反向校准的 existence constructions。它们可检验公式的可达性、非 sharpness 与量词机制，但在判断 universal compensation law 时权重必须低于 independently sourced / independently parameterized examples；不得把 `\alpha=\gamma q` 或 `\beta=q/\gamma-1` 的定义恒等式重新包装成发现的规律。

---

## 7. 高风险 C 队列（按优先级）

1. **CP-01：** 先执行 BCA-B01 的全局延伸或 interior-localization 二选一；随后重算 zero set、q-MSR、restricted all-pairs RL、drift margin与 exact recurrence。修复前不要复用其标签。
2. **RM-07 / RM-04 isolated variant：** 补全 `N_{\{0\}}` 的 MR/SMR/SMSR/MSR exact 0；重写与 RM-06 的比较坐标。
3. **LC-11 / RM-03：** 先修正 stepsize公式并补齐 `\partial|\cdot|` 的 MR/SMR，避免公式与 regularity signature继续传播。
4. **CP-02：** 从 two-scale lemma独立证明 h 的 maximal Hölder exponent；再独立复算 F 的 q-MSR 与 actual order。明确记录其 exponent calibration。
5. **AR-02 / AR-06 / EX-17：** 证明 `G_{\eta_*}` upper bound；检查不同参数 preimages；并把 graph-anchored relation与 selected single-valued P-property分开记号。
6. **RM-06：** 用 BCA-M09 的 fixed-set证明锁定 slice result；另行决定 full-tube q=1/2 EB，不得由 slice外推。
7. **Atlas (3.10)–(3.12)：** 用 `\varepsilon`-nearest solutions 重写，逐项核对 graph/MSR windows。
8. **CAN-CAYLEY-POWER：** 合并查看 `LC-15/EX-11/AR-01`，分别重算 global folds、各零点 local inverse modulus、restricted-domain invariance；避免把同 family当三份证据。
9. **LC-16/17/18：** 独立复算 two-variable `q=1/3` MR 的 exact asymptotic constants；这些比 fixed-target constants更容易因 opposite-sign pair产生额外 `2^{1-q}`。
10. **MGB-09：** 虽然 source与 block algebra一致，仍复算 `\|A^{-1}\|=1`、global regularity moduli与 high-block `\|R\|=1`，因为它同时承载多个 cross-gap标签。
11. **MGB-05/06/07：** 保留 Spingarn historical naming为 pending；分别标记 graph isolation、nonclosed graph、product candidate，不能只给 yes/no。
12. **SVG-16/MGB-20：** 在 full cone、normal-norm truncation、attentive branch三种 graph上分别重算 hypomonotonicity与 MR；禁止跨 branch复制结论。
13. **EX-05 与 EX-06：** 拆卡后分别验证 gauge domination subsequences与 `q_*=1-c`，不要把同一个 family lemma当作两份独立 proof。
14. **SVG-20/21 与 EX-22：** 复核 full-neighborhood power EB；EX-22 先修正 `\mathbb N_+` 再进入 coderivative或closed-graph计算。

---

## 8. Handoff

在进入 C 之前，最低修复顺序是：

1. 修 `CP-01` ambient scope；
2. 补 `RM-07` 的完整 regularity signature；
3. 更新 atlas 的 Luke–Tam strict edge 与 Voisei attribution；
4. 应用 canonical 去重映射；
5. 将 oscillatory Hölder upper bounds降为 candidate或补 lemma；
6. 修 `EX-22` 索引、拆 `EX-05/06`、统一 primary source labels。

完成这些修复以后，B catalog 可作为 C 的逐例重算输入；本审计不对 monotonicity–regularity trade-off 作任何结论。
