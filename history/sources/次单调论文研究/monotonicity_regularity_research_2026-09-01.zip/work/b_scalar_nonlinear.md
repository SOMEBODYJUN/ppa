# Subagent B(MAX)：标量非线性、幂与 gauge 的 gap-example catalog

> 日期：2026-09-01  
> 性质：阶段 B 的构造与候选标签；每一条仍须由阶段 C 独立重算。  
> 范围：实直线或简单低维空间中的闭图显式对象。本文不写任何 seesaw synthesis。

## 0. 统一 convention、证据与速查

在 Hilbert-to-itself 条目中固定

\[
(x,u),(y,v)\in\operatorname{gph}F,\quad a=x-y,\quad b=u-v,
\quad d=a+\lambda b,\quad r=a-\lambda b.
\]

RL 比值为

\[
Q_{\lambda,\gamma}=\frac{|r|}{|d|^\gamma};
\]

若 \(d=0\) 而 \(r\ne0\)，则比值记为 \(+\infty\)。Regularity 一律在标出的
\((\bar x,\bar y)\) 讨论，并采用 residual-exponent convention

\[
d(x,F^{-1}(\bar y))\le \kappa d(\bar y,F(x))^q.
\]

“sharp largest \(q_*\)”只指 fixed-target MSR/SMSR；它不自动给 two-variable
\(q\)-MR。特别是 \(q>1\) 的 fixed-target 性质可以非平凡，而 normed-space 中
nonconstant inverse localization 不会是 pairwise \(q>1\)-Hölder。

### 0.1 来源与检索记录

本文的映射均由显示公式构造；除 EX-14 的形状与 Luke--Tam 的平方根例子相近外，
不把任何条目标成“原文反例”。定义和换算只依赖以下 primary/authoritative locators：

- higher-order \(q\)-subregularity：[Mordukhovich--Ouyang](https://arxiv.org/abs/1507.04825)；
- nonlinear/gauge subregularity：[Kruger](https://arxiv.org/abs/1502.06159)；
- SMSR、isolated calmness：[Cibulka--Dontchev--Kruger](https://arxiv.org/abs/1701.02078)；
- monotone/Cayley 字典：[Bauschke--Moffat--Wang](https://arxiv.org/abs/1101.4688)；
- \(\rho\)-mono/comono 与 conical resolvent：[Bauschke--Moursi--Wang](https://arxiv.org/abs/1902.09827)；
- LT-submonotonicity 的原始发表页：[Luke--Tam](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863)。

检索日期为 2026-09-01；本轮是 benchmark/definition verification，不声称 systematic
search。EX-14 的常数由本文独立计算，因此不依赖无法逐页读取的 publisher PDF。
除非条目另列来源，每个 ID 的 `source/status` 均为 **ALG construction + VERIFIED
definition source above**；这是各条目的共同 source 字段，而不是把本文构造冒充成
文献已有例子。

### 0.2 条目索引

| ID | 对象 | 主要 gap cell | sharp fixed-target law |
|---|---|---|---|
| EX-01 | \(x^3\) | monotone + weak linear regularity | \(q_*=1/3\) |
| EX-02 | \(\operatorname{sgn}x\sqrt{|x|}\) | monotone + SMR + higher-order SMSR | \(q_*=2\) |
| EX-03 | flat exponential | monotone but no power EB | logarithmic gauge only |
| EX-04 | inverse-log cusp | monotone + SMR of every fixed-target power order | all finite \(q\) |
| EX-05/06 | two oscillating gauges | mutually incomparable gauges | common \(q_*=1-c\) |
| EX-07 | asymmetric mixed powers | worst branch controls | \(q_*=1/2\) |
| EX-08 | \(x^2\) | local hypo/LT + no MR/SMSR | \(q_*=1/2\) |
| EX-09 | \((x,z)\mapsto(x^3,0)\) | MSR without isolation; monotone | \(q_*=1/3\) |
| EX-10 | \(x^3-x\) | critical Cayley cusp; genuine local RL\(_{1/3}\) + SMR | \(q_*=1\) |
| EX-11 | pure Cayley power | genuine global RL\(_\alpha\) + SMR | \(q_*=1\) at each zero |
| EX-12 | clipped Cayley power | bounded genuine RL\(_\gamma\), \(\gamma\le\alpha\) | \(q_*=1\) |
| EX-13 | Cayley \(\tanh\) | RL all exponents but only inherited; weak EB | \(q_*=1/3\) |
| EX-14 | restricted \(-\sqrt{x}\) | LT but no finite hypomonotonicity | \(q_*=2\) |
| EX-15 | \(-x\) | hypo + SMR; LT depends singular step | \(q_*=1\) |
| EX-16 | \(|x|\) | SMSR not MR; LT step threshold | \(q_*=1\) |
| EX-17 | \(x(2+\sin(1/x))\) | anchored RL + SMSR, no all-pairs RL/MR | \(q_*=1\) |
| EX-18 | \(\{x,-x\}\) | MR + SMSR but not SMR; no graph lower bound | \(q_*=1\) |
| EX-19 | zero map | monotone/RL but only vacuous MSR | nonisolated |
| EX-20 | vertical slab | MR not SMSR; Aubin not isolated calm | vacuous MSR |
| EX-21 | inverse of \(y\sin(1/y)\) | isolated calm not Aubin | \(q_*=1\) |
| EX-22 | sparse vertical fibers + square curve | neither Aubin nor isolated calm | \(q_*=1/2\) MSR |
| EX-23 | clipped identity | saturation; strong local but weak global graph | \(q_*=1\) |

## 1. Power、cusp 与 gauge 族

### EX-01 — Cubic power \(F(x)=x^3\)

**Identity/formulas.** Space \(H=\mathbb R\); \(F\) is single-valued, continuous, full-domain,
and

\[
\operatorname{gph}F=\{(x,x^3):x\in\mathbb R\},\quad
\operatorname{zer}F=\{0\},\quad F^{-1}(y)=\sqrt[3]{y}.
\]

For every \(\lambda>0\), \(J_{\lambda F}(t)\) is the unique real root \(u\) of
\(u+\lambda u^3=t\), and \(R_{\lambda F}(t)=2u-t\).

**Gap and graph proof.** For graph points,

\[
ab=(x-y)(x^3-y^3)=(x-y)^2(x^2+xy+y^2)\ge0.
\]

Thus \(F\) is maximally monotone. It is not strongly monotone on any neighborhood of zero,
because \(F(x)/x=x^2\to0\). It is not globally cocoercive because secant slopes are
unbounded. On \([-\delta,\delta]\), the sharp scalar Lipschitz slope is \(3\delta^2\), hence
the sharp cocoercivity constant is \(1/(3\delta^2)\).

Implicit differentiation through \(t=u+\lambda u^3\) gives

\[
R'_{\lambda F}(t)=\frac{1-3\lambda u^2}{1+3\lambda u^2},
\]

so global RL\((\lambda,1,1)\) holds and \(L=1\) is sharp (limits at \(u=0\) and
\(|u|\to\infty\)). No global RL exponent \(\gamma<1\) is possible, since
\(|R(t)|\asymp |t|\) at infinity. On a bounded Minty window the subunit estimates are merely
inherited from Lipschitzness.

**Regularity at \((0,0)\).** The exact residual law is

\[
d(x,\{0\})=|x|=|F(x)|^{1/3}.
\]

Hence fixed-target \(q\)-SMSR/MSR holds iff \(q\le1/3\); \(q_*=1/3\) and its exact modulus
is 1. Ordinary MSR, SMSR, MR and SMR fail. The inverse is globally \(1/3\)-Hölder with
sharp opposite-sign constant \(2^{2/3}\), so \(F\) is two-variable \(1/3\)-MR, but
\(F^{-1}\) is neither calm nor Aubin in the linear sense. Zero is isolated; no vacuity occurs.

**Status/source.** ALG construction; power-exponent convention checked against
[Mordukhovich--Ouyang](https://arxiv.org/abs/1507.04825).

---

### EX-02 — Square-root power \(F(x)=\operatorname{sgn}(x)\sqrt{|x|}\)

**Identity/formulas.** \(H=\mathbb R\), continuous single-valued full-domain,

\[
\operatorname{gph}F=\{(x,\operatorname{sgn}x\sqrt{|x|})\},\quad
\operatorname{zer}F=\{0\},\quad F^{-1}(y)=\operatorname{sgn}(y)|y|^2.
\]

For \(t\ne0\), put

\[
s(t)=\frac{\sqrt{\lambda^2+4|t|}-\lambda}{2}.
\]

Then \(J_{\lambda F}(t)=\operatorname{sgn}(t)s(t)^2\) and
\(R_{\lambda F}(t)=2J_{\lambda F}(t)-t\), with both equal to zero at \(t=0\).

**Graph/RL.** The map is increasing, hence maximally monotone and global RL\(_1\) with
sharp \(L=1\). It is not globally strongly monotone (secant slopes tend to zero at infinity)
and is not cocoercive on any neighborhood of zero (slopes blow up there). On
\([-\delta,\delta]\), it is strongly monotone with sharp modulus
\(1/(2\sqrt\delta)\). Global RL\(_\gamma\), \(\gamma<1\), fails by the asymptotically linear
Cayley map at infinity; bounded-window subunit RL is inherited, not genuine.

**Regularity at \((0,0)\).** Exactly

\[
|x|=|F(x)|^2.
\]

Thus fixed-target \(q\)-SMSR holds iff \(q\le2\), with exact modulus 1 at \(q=2\) and
exact modulus 0 for every \(q<2\), including ordinary SMSR. Since the inverse
\(y\mapsto\operatorname{sgn}(y)y^2\) is a single-valued local Lipschitz localization,
\(F\) is SMR (therefore MR); its exact linear regularity modulus at the origin is 0.
The inverse is Aubin and isolatedly calm, both with exact point modulus 0. This does **not**
make \(F\) two-variable \(q\)-MR for \(q>1\): away from the center inside every target
neighborhood, \(|y_1^2-y_2^2|/|y_1-y_2|^q\to\infty\) as \(y_2\to y_1\ne0\).

**Gap.** Strong inverse stability can coexist with lack of cocoercivity and with a
fixed-target exponent strictly above one.

---

### EX-03 — Flat exponential: power EB fails but a logarithmic gauge is exact

Let

\[
F(0)=0,\qquad F(x)=\operatorname{sgn}(x)e^{-1/|x|}\quad(x\ne0).
\]

**Identity/formulas.** This is a continuous increasing full-domain map with range \((-1,1)\),
closed graph and isolated zero. For \(0<|y|<1\),

\[
F^{-1}(y)=\frac{\operatorname{sgn}y}{\log(1/|y|)}.
\]

For each \(\lambda>0\), \(J_{\lambda F}(t)\) is the unique solution of
\(u+\lambda F(u)=t\), and \(R=2J-I\).

**Graph/RL.** \(F\) is maximally monotone. Its derivative on \(x>0\) is
\(e^{-1/x}/x^2\), whose global maximum is \(4e^{-2}\) at \(x=1/2\). Hence \(F\) is
sharply \(4e^{-2}\)-Lipschitz and sharply \(e^2/4\)-cocoercive, but has no positive
strong-monotonicity modulus on any neighborhood of zero. Its reflected resolvent is
nonexpansive; \(L=1\) is sharp because \(F'(x)\to0\) at zero. Subunit global RL fails at
infinity.

**Regularity at \((0,0)\).** With \(r=|F(x)|\),

\[
|x|=\phi_{\log}(r):=\frac1{\log(1/r)}\qquad(0<r<e^{-1}).
\]

Thus \(\phi_{\log}\)-SMSR is exact with modulus 1. For every \(q>0\),
\(\phi_{\log}(r)/r^q\to\infty\), so there is no positive power MSR/SMSR exponent at all;
in particular MSR, SMSR, MR and SMR fail. The inverse is gauge-isolatedly-calm but is not
Hölder-calm of any positive exponent. This is a nonvacuous isolated-zero example.

**Status/source.** ALG; gauge terminology from
[Kruger](https://arxiv.org/abs/1502.06159).

---

### EX-04 — Inverse-log cusp: every fixed-target power order, and SMR modulus zero

Define

\[
F(0)=0,\qquad
F(x)=\frac{\operatorname{sgn}(x)}{\log(e+1/|x|)}\quad(x\ne0).
\]

It is continuous, strictly increasing, full-domain, has range \((-1,1)\), closed graph and
\(\operatorname{zer}F=\{0\}\). For \(0<|y|<1\),

\[
F^{-1}(y)=\frac{\operatorname{sgn}y}{e^{1/|y|}-e}. \tag{1.1}
\]

The resolvent is the unique implicit root of \(u+\lambda F(u)=t\); \(R=2J-I\).

**Graph/RL.** Increasing continuity gives maximal monotonicity and global RL\(_1\) with
sharp \(L=1\) (the derivative tends to zero in the saturation tails). Every sufficiently
small symmetric graph window is strongly monotone, while no positive local cocoercivity
constant exists at zero because \(F'\) is unbounded there.

**Regularity.** From (1.1), with residual \(r\),

\[
|x|=\psi(r):=\frac1{e^{1/r}-e}=o(r^q)\quad\text{for every }q>0.
\]

Therefore fixed-target \(q\)-SMSR holds for **every finite** \(q>0\), with exact point
modulus 0. The inverse in (1.1) is single-valued and locally Lipschitz (indeed flat), so
\(F\) is SMR/MR with exact modulus 0; its inverse is Aubin and isolatedly calm. As in EX-02,
two-variable \(q>1\)-MR does not follow and in fact fails for a nonconstant inverse
localization. This example separates arbitrarily strong fixed-target order from the
two-variable order notion.

---

### EX-05/EX-06 — A pair of mutually incomparable increasing gauges

Fix \(0<c<1/\sqrt2\). For \(0<t\le e^{-1}\), set

\[
s=\log(1/t),\qquad A(s)=cs\sin(\log s),\qquad
\phi_\pm(t)=\exp[-s\mp A(s)], \tag{1.2}
\]

and set \(\phi_\pm(0)=0\), \(\phi_\pm(t)=t\) for \(t\ge e^{-1}\). Since

\[
\frac{d}{ds}[s\pm A(s)]
=1\pm c(\sin\log s+\cos\log s)>1-c\sqrt2>0,
\]

both \(\phi_\pm\) are continuous strictly increasing gauges (the pieces meet at \(e^{-1}\)).
Define two odd homeomorphisms

\[
F_\pm(x)=\operatorname{sgn}(x)\phi_\pm^{-1}(|x|).
\]

**Identity/formulas.** Both graphs are closed, single-valued and full-domain;
\(\operatorname{zer}F_\pm=\{0\}\), and

\[
F_\pm^{-1}(y)=\operatorname{sgn}(y)\phi_\pm(|y|).
\]

For every \(\lambda>0\), \(J\) is the unique implicit root
\(u+\lambda F_\pm(u)=t\), and \(R=2J-I\).

**Graph/RL.** Both maps are maximally monotone, hence global RL\(_1\) with \(L=1\).
They are not strongly monotone or cocoercive on any whole neighborhood of zero: the
oscillating effective exponent produces secant slopes tending both to zero and infinity.
Global subunit RL fails in the linear extension tails.

**Exact gauge and power properties.** If \(r=|F_\pm(x)|\), then exactly

\[
|x|=\phi_\pm(r). \tag{1.3}
\]

Moreover

\[
\frac{\phi_+(t)}{\phi_-(t)}=e^{-2A(s)}
\]

is unbounded above and has liminf zero, because \(A(s)\) takes values tending to
\(+\infty\) and \(-\infty\). Consequently:

- EX-05 (\(F_+\)) has exact \(\phi_+\)-SMSR but fails \(\phi_-\)-SMSR;
- EX-06 (\(F_-\)) has exact \(\phi_-\)-SMSR but fails \(\phi_+\)-SMSR.

Both nevertheless have the same sharp largest **power** exponent

\[
q_*=1-c.
\]

Indeed \(s\pm A(s)-(1-c)s=cs(1\pm\sin\log s)\ge0\), giving modulus 1 at
\(q=1-c\), with equality on the corresponding \(\sin\log s=\mp1\) subsequence.
For \(q>1-c\) the opposite subsequence makes \(\phi_\pm(t)/t^q\to\infty\); for
\(q<1-c\) the exact modulus is zero. Since \(q_*<1\), ordinary MSR/SMSR, MR and SMR
all fail. The zero is isolated and the gauge bounds are nonvacuous.

**Gap.** A scalar monotone homeomorphism and even the complete power signature \(q_*\)
do not determine its gauge-regularity class.

---

### EX-07 — Asymmetric mixed powers

Let

\[
F(x)=\begin{cases}x^2,&x\ge0,\\-\sqrt{-x},&x<0.\end{cases} \tag{1.4}
\]

This is a continuous strictly increasing full-domain homeomorphism. Its inverse is

\[
F^{-1}(y)=\begin{cases}\sqrt y,&y\ge0,\\-y^2,&y<0,\end{cases}
\]

and its only zero is 0. The resolvent is the unique root of \(u+\lambda F(u)=t\), with
the positive branch quadratic and the negative branch reducible to the formula in EX-02;
\(R=2J-I\).

**Graph/RL.** It is maximally monotone and global RL\(_1\) with sharp \(L=1\).
It is neither strongly monotone nor cocoercive on any two-sided neighborhood of zero:
the positive slope tends to zero and the negative-side slope is unbounded. No global
subunit RL survives the linear Cayley tails.

**Regularity at zero.** On the positive side \(|x|=|F(x)|^{1/2}\), while on the negative
side \(|x|=|F(x)|^2\). Therefore the worst branch controls:

\[
q_*=\min\{1/2,2\}=1/2,
\]

with exact modulus 1. Linear MSR/SMSR, MR and SMR fail; the inverse is precisely
\(1/2\)-Hölder at the center but not calm. This also warns that averaging one-sided orders
would give a false exponent.

---

### EX-08 — Even polynomial \(F(x)=x^2\)

**Identity/formulas.** Single-valued continuous closed graph,

\[
\operatorname{zer}F=\{0\},\qquad
F^{-1}(y)=\begin{cases}\{-\sqrt y,\sqrt y\},&y\ge0,\\\varnothing,&y<0.\end{cases}
\]

Globally, \(J_{\lambda F}(t)\) consists of the real roots of
\(\lambda u^2+u-t=0\); it can be empty or two-valued. On \(|u|\le\delta<1/(2\lambda)\),
the restricted Minty map is injective and

\[
J(t)=\frac{-1+\sqrt{1+4\lambda t}}{2\lambda},\qquad R=2J-I.
\]

**Graph gap.** On \([-\delta,\delta]\), \(F'(x)=2x\ge-2\delta\), so the sharp local
hypomonotonicity modulus is \(2\delta\). For \(2\lambda\delta<1\), the restricted
reflected resolvent has sharp

\[
L=\frac{1+2\lambda\delta}{1-2\lambda\delta},
\]

equivalently a finite LT certificate. Globally \(I+\lambda F\) is a parabola and is not
injective, hence no all-graph RL/LT inequality can hold. The map is not monotone on any
two-sided neighborhood of zero.

**Regularity at zero.** Exactly \(|x|=|F(x)|^{1/2}\). Thus \(q_*=1/2\), modulus 1;
ordinary MSR/SMSR fail. MR fails because every negative target has empty inverse, and SMR
fails also by the two positive branches. The inverse is \(1/2\)-Hölder isolated-calm only
in the fixed-target sense, not linearly calm/Aubin.

---

### EX-09 — Nonisolated power cylinder in \(\mathbb R^2\)

Let

\[
F(x,z)=(x^3,0):\mathbb R^2\to\mathbb R^2.
\]

It is single-valued, continuous, maximally monotone and

\[
\operatorname{zer}F=\{0\}\times\mathbb R,\quad
F^{-1}(y_1,y_2)=
\begin{cases}\{(\sqrt[3]{y_1},z):z\in\mathbb R\},&y_2=0,\\
\varnothing,&y_2\ne0.
\end{cases}
\]

Its resolvent is the product of the cubic resolvent in EX-01 and the identity:

\[
J_{\lambda F}(t_1,t_2)=(J_{\lambda x^3}(t_1),t_2),\quad
R_{\lambda F}(t_1,t_2)=(R_{\lambda x^3}(t_1),t_2).
\]

Hence global RL\(_1\) has sharp \(L=1\); no global subunit exponent is possible because of
the identity second coordinate. The exact residual law is

\[
d((x,z),\operatorname{zer}F)=|x|=\|F(x,z)\|^{1/3}.
\]

Thus \(q\)-MSR holds exactly for \(q\le1/3\), with modulus 1 at the endpoint. SMSR fails
for every order because the solution is nonisolated. MR fails because the range lies in a
proper subspace, and SMR fails. This is a nontrivial (not vacuous) MSR-without-isolation
witness.

## 2. Cayley-generated power、saturation 与 critical-step 对象

### EX-10 — Critical Cayley cusp \(F(x)=x^3-x\)

**Identity/formulas.** On \(\mathbb R\), \(F\) is a continuous polynomial,

\[
\operatorname{gph}F=\{(x,x^3-x)\},\quad
\operatorname{zer}F=\{-1,0,1\},
\]

and \(F^{-1}(y)\) is the set of real roots of \(x^3-x-y=0\). For a resolvent step
\(\eta>0\), the Minty equation is

\[
t=(1-\eta)u+\eta u^3. \tag{2.1}
\]

- If \(0<\eta<1\), (2.1) is globally strictly increasing, so \(J_\eta\) is single-valued.
- If \(\eta=1\), \(J_1(t)=\sqrt[3]t\) and
  \(R_1(t)=2\sqrt[3]t-t\).
- If \(\eta>1\), (2.1) has folds and the full resolvent is multivalued for some inputs.

**Graph-side proof.** Since \(F'(x)=3x^2-1\ge-1\), \(F\) is globally sharply
1-hypomonotone but not monotone. For \(0<\eta<1\), differentiation in (2.1) gives

\[
R_\eta'(t)=\frac{1+\eta-3\eta u^2}{1-\eta+3\eta u^2},
\qquad
\operatorname{Lip}R_\eta=\frac{1+\eta}{1-\eta}. \tag{2.2}
\]

At the **critical** step \(\eta=1\), the signed cube-root inequality gives, on
\(|t|,|s|\le\Delta\),

\[
|R_1(t)-R_1(s)|
\le 2^{5/3}|t-s|^{1/3}+(2\Delta)^{2/3}|t-s|^{1/3}. \tag{2.3}
\]

Thus local RL\(_{1/3}\) holds. It is genuinely \(1/3\): taking \(s=0\) shows every
exponent \(\gamma>1/3\), including Lipschitz/LT, fails. It is not global RL\(_{1/3}\),
because the \(-t\) term dominates at infinity. For \(\eta>1\), failure of Minty
injectivity already rules out any all-graph RL exponent.

**Regularity.** At \((0,0)\), \(F'(0)=-1\), so \(F\) is SMR/MR and SMSR with exact
linear modulus 1. At \((\pm1,0)\), the exact local modulus is \(1/2\). At each of the
three zeros, \(q_*=1\); \(q>1\) fixed-target SMSR fails because the zero is simple.
The inverse has a single-valued Lipschitz localization at each chosen zero, although the
global inverse has three branches near target zero. This supplies a genuine local
RL\(_{1/3}\) + strong inverse-stability cell.

---

### EX-11 — Pure Cayley power; explicit elimination and single-valued \(F\)

Fix \(\lambda_0>0\) and \(0<\alpha<1\). Let

\[
P_\alpha(t)=\operatorname{sgn}(t)|t|^\alpha,\quad
h(t)=\frac{t+P_\alpha(t)}2,\quad
k(t)=\frac{t-P_\alpha(t)}{2\lambda_0}. \tag{2.4}
\]

Define the graph parametrically by \((u,u^*)=(h(t),k(t))\).

**Single-valuedness and elimination.** Both \(t\mapsto t\) and \(P_\alpha\) are strictly
increasing, hence \(h\) is a continuous strictly increasing bijection \(\mathbb R\to\mathbb R\).
Therefore this parameterized graph is the graph of the **single-valued** continuous map

\[
F(u)=k(h^{-1}(u)). \tag{2.5}
\]

Equivalently, \(v=F(u)\) is the unique value satisfying

\[
\boxed{u-\lambda_0v
=P_\alpha(u+\lambda_0v)}. \tag{2.6}
\]

This explicitly disposes of the possible “Cayley relation might be multivalued” issue.
The inverse is

\[
F^{-1}(y)=\{h(t):k(t)=y\}; \tag{2.7}
\]

it is generally multibranch away from a selected zero because \(k\) first decreases and
then increases. At the generating step,

\[
J_{\lambda_0F}(t)=h(t),\qquad R_{\lambda_0F}(t)=P_\alpha(t). \tag{2.8}
\]

The zero equation \(t=P_\alpha(t)\) gives
\(\operatorname{zer}F=\{-1,0,1\}\).

**Exact graph/RL geometry.** For parameters \(t,s\), with
\(\Delta t=t-s\) and \(\Delta p=P_\alpha(t)-P_\alpha(s)\),

\[
\langle a,b\rangle
=\frac{|\Delta t|^2-|\Delta p|^2}{4\lambda_0}. \tag{2.9}
\]

The signed power satisfies the sharp global estimate

\[
|P_\alpha(t)-P_\alpha(s)|
\le 2^{1-\alpha}|t-s|^\alpha, \tag{2.10}
\]

with equality for \(s=-t\ne0\). Thus global RL\((\lambda_0,2^{1-\alpha},\alpha)\)
is sharp. No other global exponent works: \(\gamma>\alpha\) fails at zero, while
\(\gamma<\alpha\) fails at infinity. In particular this is genuinely non-Lipschitz RL.

For \(t\ne0\),

\[
\frac{dF}{du}
=\frac{1-\alpha|t|^{\alpha-1}}
{\lambda_0(1+\alpha|t|^{\alpha-1})}\in(-1/\lambda_0,1/\lambda_0).
\]

Hence \(F\) is globally sharply \(1/\lambda_0\)-hypomonotone, but it is not
LT-submonotone at the generating scale: LT would make (2.8) Lipschitz. This is a useful
parameter-boundary example (\(\lambda_0\sigma=1\)), not a contradiction to a theorem whose
conversion assumes a strict smallness bound.

**Regularity.** At zero, \(F(u)/u\to-1/\lambda_0\), so \(F\) is SMR/MR/SMSR with exact
modulus \(\lambda_0\). At \(u=\pm1\),

\[
F'(\pm1)=\frac{1-\alpha}{\lambda_0(1+\alpha)},
\]

so the exact modulus is \(\lambda_0(1+\alpha)/(1-\alpha)\). All zeros are isolated and
simple; \(q_*=1\) at each. Thus a global genuine subunit RL exponent does not force weak
linear regularity.

---

### EX-12 — Clipped Cayley power: bounded and genuinely sub-Lipschitz

With the same parameters, let

\[
C_\alpha(t)=\operatorname{sgn}(t)\min\{|t|^\alpha,1\},\quad
h_C(t)=\frac{t+C_\alpha(t)}2,\quad
k_C(t)=\frac{t-C_\alpha(t)}{2\lambda_0}. \tag{2.11}
\]

Again \(h_C\) is a strictly increasing onto homeomorphism, so

\[
F_C(u)=k_C(h_C^{-1}(u))
\]

is a single-valued continuous full-domain map, equivalently
\(u-\lambda_0F_C(u)=C_\alpha(u+\lambda_0F_C(u))\). At the generating step,

\[
J(t)=h_C(t),\quad R(t)=C_\alpha(t),\quad
F_C^{-1}(y)=\{h_C(t):k_C(t)=y\},\quad
\operatorname{zer}F_C=\{-1,0,1\}.
\]

Projection onto \([-1,1]\) is nonexpansive, so (2.10) gives global RL exponent \(\alpha\).
More strongly, for every \(0<\gamma\le\alpha\),

\[
|C_\alpha(t)-C_\alpha(s)|\le 2|t-s|^\gamma. \tag{2.12}
\]

For \(|t-s|\le1\), use the \(\alpha\)-Hölder bound and
\(|t-s|^\alpha\le|t-s|^\gamma\); for larger differences use bounded range. No
\(\gamma>\alpha\) works at zero, so these subunit estimates are genuine and no
Lipschitz/LT estimate exists at \(\lambda_0\).

The graph is sharply \(1/\lambda_0\)-hypomonotone, by the same derivative lower bound as
EX-11 (outside the clipped core its slope is \(1/\lambda_0\)). At zero the exact SMR/SMSR
modulus is \(\lambda_0\). At \(\pm1\), the two one-sided inverse slopes give exact modulus
\(\lambda_0(1+\alpha)/(1-\alpha)\). Thus \(q_*=1\) at each zero. EX-11 versus EX-12
isolates the large-scale reason why smaller global Hölder exponents may fail or succeed.

---

### EX-13 — Cayley \(\tanh\): all subunit exponents, but none is genuine

Fix \(\lambda_0>0\) and parameterize

\[
h(t)=\frac{t+\tanh t}{2},\qquad
k(t)=\frac{t-\tanh t}{2\lambda_0},\qquad
F(h(t))=k(t). \tag{2.13}
\]

Since \(h\) is strictly increasing onto, this defines a continuous single-valued full-domain
map. Since \(k'(t)=\tanh^2(t)/(2\lambda_0)\ge0\), \(F\) is maximally monotone and
\(\operatorname{zer}F=\{0\}\). Its inverse is uniquely parameterized by
\(F^{-1}(k(t))=h(t)\). At the generating step,

\[
J_{\lambda_0F}=h,\qquad R_{\lambda_0F}=\tanh.
\]

Thus RL\(_1\) holds sharply with \(L=1\). Since
\(|\tanh t-\tanh s|\le\min\{|t-s|,2\}\), for every \(0<\gamma<1\)

\[
|R(t)-R(s)|\le2^{1-\gamma}|t-s|^\gamma. \tag{2.14}
\]

These estimates are **not genuine**: they are consequences of boundedness plus
Lipschitzness.

The exact scalar slope

\[
\frac{dF}{du}=\frac{\tanh^2t}{\lambda_0(1+\operatorname{sech}^2t)}
\in[0,1/\lambda_0)
\]

shows global \(\lambda_0\)-cocoercivity but no strong monotonicity at zero. Taylor expansion
gives

\[
h(t)=t-\frac{t^3}{6}+O(t^5),\qquad
k(t)=\frac{t^3}{6\lambda_0}+O(t^5),
\]

hence

\[
|u|\sim(6\lambda_0)^{1/3}|F(u)|^{1/3}. \tag{2.15}
\]

Therefore \(q_*=1/3\), with exact endpoint modulus \((6\lambda_0)^{1/3}\).
Ordinary MSR/SMSR, MR and SMR fail; the inverse is single-valued but only cube-root calm.

## 3. LT、hypomonotonicity 与 anchored/all-pairs gaps

### EX-14 — Restricted negative square root: LT but no finite hypomonotonicity

Fix \(0<r_0<1/4\) and define the closed-graph map

\[
F(x)=\{-\sqrt x\}\ (x\in[0,r_0]),\qquad F(x)=\varnothing\ (x\notin[0,r_0]).
\]

It is single-valued on its domain,

\[
\operatorname{zer}F=\{0\},\qquad
F^{-1}(y)=\begin{cases}\{y^2\},&-\sqrt{r_0}\le y\le0,\\
\varnothing,&\text{otherwise}.
\end{cases}
\]

At \(\lambda=1\), write \(x=s^2\), \(0\le s\le\sqrt{r_0}\). The Minty input and
reflection are

\[
p=s^2-s,\qquad J(p)=s^2,qquad R(p)=s^2+s,qquad
s=\frac{1-\sqrt{1+4p}}2, \tag{3.1}
\]

on \(D=[r_0-\sqrt{r_0},0]\); this is a restricted resolvent, not a full-domain one.

For two parameters \(s,t\),

\[
a=(s-t)(s+t),\qquad b=-(s-t),
\]

so

\[
ab=-(s-t)^2(s+t),\qquad
a+b=(s-t)(s+t-1). \tag{3.2}
\]

Let \(c=2\sqrt{r_0}<1\). Then the sharp LT constant is

\[
\boxed{\tau=\max_{0\le s+t\le c}\frac{s+t}{(1-s-t)^2}
=\frac{c}{(1-c)^2}}, \tag{3.3}
\]

and the sharp reflected Lipschitz constant is
\(\sqrt{1+4\tau}=(1+c)/(1-c)\). In contrast,

\[
\frac{-ab}{a^2}=\frac1{s+t}\to\infty
\]

as distinct \(s,t\downarrow0\); no finite local hypomonotonicity modulus exists at the
zero. This proves the strict LT-without-hypo cell analytically.

Finally \(x=|F(x)|^2\), so \(q_*=2\) with modulus 1 and ordinary SMSR has exact modulus
0. MR/SMR fail because every positive nearby target has empty inverse. The inverse is
isolatedly calm (empty positive fibers are harmless for that one-sided inclusion), but not
Aubin. The square-root form is close to a seed mentioned by
[Luke--Tam](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863); all displayed
constants here are independent ALG calculations, not an attribution to their exact example.

---

### EX-15 — Anti-identity \(F(x)=-x\): hypomonotone + SMR, with a singular LT step

**Identity/formulas.** On \(\mathbb R\),

\[
\operatorname{gph}F=\{(x,-x)\},\quad
\operatorname{zer}F=\{0\},\quad F^{-1}=F.
\]

For a step \(\eta\ne1\),

\[
J_{\eta F}(t)=\frac{t}{1-\eta},\qquad
R_{\eta F}(t)=\frac{1+\eta}{1-\eta}t. \tag{3.4}
\]

At \(\eta=1\), \(I+F\equiv0\): its range is \(\{0\}\), and
\(J_F(0)=\mathbb R\) is multivalued.

**Graph/LT.** Here \(ab=-a^2\), so the sharp hypomonotonicity modulus is 1. For every
\(\eta\ne1\), global RL\(_1\)/LT holds with sharp

\[
L=\frac{1+\eta}{|1-\eta|}.
\]

At the singular step \(\eta=1\), any two distinct graph points have \(d=a+b=0\) and
\(r=2a\ne0\); every RL/LT estimate fails. Thus “hypomonotone” by itself does not remove
the resolvent-step singularity. At \(0<\eta<1\) this same object lies in the both-hypo-and-LT
cell.

**Regularity.** Exactly \(|x|=|F(x)|\). The map is SMR, MR, SMSR and MSR at zero,
all with exact modulus 1; its inverse is Aubin and isolatedly calm. The sharp fixed-target
exponent is \(q_*=1\). Hence strong inverse stability does not repair a bad Cayley step.

---

### EX-16 — Absolute value \(F(x)=|x|\): SMSR but not MR

**Identity/formulas.** This is a continuous single-valued map with

\[
\operatorname{zer}F=\{0\},\qquad
F^{-1}(y)=\begin{cases}\{-y,y\},&y\ge0,\\\varnothing,&y<0.
\end{cases}
\]

For \(0<\eta<1\), the Minty map is strictly increasing piecewise linear and

\[
J_{\eta F}(t)=
\begin{cases}t/(1+\eta),&t\ge0,\\t/(1-\eta),&t<0,
\end{cases}
\]

while \(R=2J-I\). At \(\eta=1\), the entire negative half-line has Minty input zero;
for \(\eta>1\), both positive and negative branches generate the same positive inputs, so
the resolvent is multivalued.

**Graph/RL.** Since \(F+I=2\max\{x,0\}\) is increasing, \(F\) is sharply
1-hypomonotone. For \(0<\eta<1\), global RL\(_1\) has sharp

\[
L=\frac{1+\eta}{1-\eta}. \tag{3.5}
\]

For \(\eta\ge1\), Minty collisions prove failure of every all-pairs RL exponent.

**Regularity at zero.** The residual identity \(|F(x)|=|x|\) gives SMSR/MSR and
\(q_*=1\), exact modulus 1. MR fails because negative nearby targets have empty inverse;
SMR fails as well. Equivalently, \(F^{-1}\) is isolatedly calm (and calm) at \((0,0)\),
but not Aubin. This is the standard SMSR-without-MR cell, now with its graph and step-size
geometry made explicit.

---

### EX-17 — Oscillatory coefficient: anchored RL and SMSR, but neither all-pairs RL nor MR

Define

\[
F(0)=0,\qquad F(x)=x\bigl(2+\sin(1/x)\bigr)\quad(x\ne0). \tag{3.6}
\]

It is continuous, single-valued, has closed graph and \(\operatorname{zer}F=\{0\}\).
The inverse is the root set

\[
F^{-1}(y)=\{x:x(2+\sin(1/x))=y\},
\]

and, for \(\eta>0\),

\[
J_{\eta F}(t)=\{u:t=u[1+\eta(2+\sin(1/u))]\},\qquad R=2J-I, \tag{3.7}
\]

with the continuous extension at \(u=0\).

**Anchored versus all-pairs.** Relative to the zero graph point, put
\(c(x)=2+\sin(1/x)\in[1,3]\). Then

\[
\frac{|x-\eta F(x)|}{|x+\eta F(x)|}
=\frac{|1-\eta c(x)|}{1+\eta c(x)}
\le L_{\rm anc}(\eta)<1, \tag{3.8}
\]

where the sharp anchored constant is

\[
L_{\rm anc}(\eta)=
\max\left\{\frac{|1-\eta|}{1+\eta},
\frac{|1-3\eta|}{1+3\eta}\right\}.
\]

However, for \(x\ne0\),

\[
F'(x)=2+\sin(1/x)-\frac{\cos(1/x)}x. \tag{3.9}
\]

At \(x_n=(2\pi n)^{-1}\), this tends to \(-\infty\), while at
\(z_n=((2n+1)\pi)^{-1}\) it tends to \(+\infty\). The derivative of
\(g_\eta=I+\eta F\) therefore changes sign infinitely often in every neighborhood of zero.
A continuous injective scalar map on an interval must be monotone, so \(g_\eta\) is not
injective on any such neighborhood. Hence the full graph has no local all-pairs RL estimate
of **any** exponent, despite the sharp anchored RL\(_1\) bound.

若采用允许 set-valued selections 的 pointwise almost-FNE convention，(3.8) 只控制
从 base Minty input 0 出发的 selection；它不提供其他 input 之间的 pairwise 控制，
也不使 (3.7) 在邻域中单值。因而这里的严格缺口同时说明“anchored/pointwise”量词
不能静默升级为 all-pairs 量词。

The same negative derivative sequence rules out every finite local hypomonotonicity modulus.
Thus anchored solution-relative geometry is strictly weaker than two-point LT/RL geometry.

**Regularity.** Since

\[
|x|\le|F(x)|\le3|x|,
\]

SMSR/MSR holds with exact modulus 1, and \(q_*=1\). It is nonvacuous and the zero is
isolated. MR fails: by continuity of (3.9), there are critical points \(\xi_n\to0\) with
\(F'(\xi_n)=0\); MR around \((0,0)\) would impose a uniform regularity estimate at all
nearby graph points, while a differentiable scalar map with zero derivative is not metrically
regular there. SMR fails also because the folds give multiple nearby inverse branches.
Accordingly \(F^{-1}\) is isolatedly calm at the base but not Aubin.

---

### EX-18 — Two-branch relation \(F(x)=\{-x,x\}\)

**Identity/formulas.** The graph is the closed union of two lines,

\[
\operatorname{gph}F=\{(x,x)\}\cup\{(x,-x)\},\quad
\operatorname{zer}F=\{0\},\quad F^{-1}=F.
\]

For \(\eta\ne1\), every input \(t\) has the two resolvent candidates

\[
J_{\eta F}(t)=\left\{\frac{t}{1+\eta},\frac{t}{1-\eta}\right\},\quad
R_{\eta F}(t)=\left\{\frac{1-\eta}{1+\eta}t,
\frac{1+\eta}{1-\eta}t\right\}. \tag{3.10}
\]

At \(\eta=1\), the negative-slope branch gives every \(x\) at input zero. Thus no step
admits all-graph RL: for \(\eta\ne1\), the same nonzero Minty input has two different
reflections; for \(\eta=1\), input zero does.

**No finite pairwise graph lower bound.** Take a point \((x,x)\) on the positive line and
\((y,-y)\) on the negative line. Then

\[
ab=(x-y)(x+y)=x^2-y^2.
\]

With \(x_n=1/n\), \(y_n=x_n+1/n^2\), both graph points tend to zero but
\(ab/a^2\to-\infty\). Hence no finite local hypomonotonicity modulus exists (and no LT
certificate can bypass the explicit Minty collisions).

**Regularity at zero.** For every \(x,y\),

\[
d(x,F^{-1}(y))=\min\{|x-y|,|x+y|\}=d(y,F(x)). \tag{3.11}
\]

Thus MR has exact modulus 1. Also
\(d(0,F(x))=|x|\), so SMSR has exact modulus 1 and \(q_*=1\). Nevertheless SMR fails:
for each \(y\ne0\), the localized inverse contains \(\{-y,y\}\). This fills the
MR + SMSR but not SMR cell with a graph that has no finite monotonicity defect modulus.

## 4. MSR/MR 与 Aubin/calm 的多分支四象限

### EX-19 — Zero operator: monotone/RL with only vacuous MSR

Let \(F(x)=0\) on \(\mathbb R\). Then

\[
\operatorname{gph}F=\mathbb R\times\{0\},\quad
\operatorname{zer}F=\mathbb R,\quad
F^{-1}(y)=\begin{cases}\mathbb R,&y=0,\\\varnothing,&y\ne0,
\end{cases}
\]

and \(J_{\lambda F}=R_{\lambda F}=I\). It is maximally monotone and sharp global
RL\(_1\) has \(L=1\). Global RL\(_\gamma\), \(\gamma<1\), fails on the unbounded line;
bounded-window versions are inherited. At any \((\bar x,0)\), MSR holds with modulus 0 only
because \(d(x,\operatorname{zer}F)\equiv0\); this is explicitly a **vacuous** error bound.
SMSR fails (nonisolated zero), while MR/SMR fail because nearby nonzero targets have empty
inverse. The inverse is calm with modulus 0 but not isolatedly calm or Aubin around the
chosen branch.

---

### EX-20 — Vertical slab: MR but not SMSR; Aubin but not isolated calm

Define

\[
F(x)=\begin{cases}\mathbb R,&|x|\le1,\\\varnothing,&|x|>1.
\end{cases} \tag{4.1}
\]

Then

\[
\operatorname{gph}F=[-1,1]\times\mathbb R,\quad
\operatorname{zer}F=[-1,1],\quad F^{-1}(y)=[-1,1]\ \forall y.
\]

For every \(\lambda>0\) and input \(t\),
\(J_{\lambda F}(t)=[-1,1]\) and
\(R_{\lambda F}(t)=2[-1,1]-t\); hence no RL estimate is possible. Directly, choose two
nearby graph points with \(b=-a/\lambda\ne0\): then \(d=0\) but \(r=2a\ne0\).
Choosing \(a=\varepsilon^2,b=-\varepsilon\) also shows that no finite local
hypomonotonicity modulus exists.

At \((0,0)\), shrink the \(x\)-neighborhood inside \((-1,1)\). Then

\[
d(x,F^{-1}(y))=0=d(y,F(x))
\]

for every nearby \(x,y\), so MR and MSR have exact modulus 0. SMSR fails because the zero
set is nonisolated, and SMR fails because every inverse fiber contains an interval. On the
inverse side, the constant map \(F^{-1}(y)=[-1,1]\) is Aubin/calm with modulus 0 but is not
isolatedly calm at \((0,0)\). This is the MR-without-SMSR and Aubin-without-isolated-calm
cell; its MSR is again vacuous.

---

### EX-21 — Inverse oscillation: isolated calm but not Aubin

Let

\[
G(0)=0,\qquad G(y)=y\sin(1/y)\ (y\ne0),\qquad F:=G^{-1}. \tag{4.2}
\]

Thus

\[
\operatorname{gph}F=\{(G(y),y):y\in\mathbb R\},\quad
F^{-1}=G,\quad \operatorname{zer}F=\{0\}.
\]

The graph is closed. The inverse values \(F(x)=\{y:y\sin(1/y)=x\}\) are generally
multibranch. At step \(\lambda>0\), the resolvent relation is parameterized by

\[
t=y(\lambda+\sin(1/y)),\quad J(t)=y\sin(1/y),\quad
R(t)=y(\sin(1/y)-\lambda). \tag{4.3}
\]

The first function in (4.3) has derivative
\(\lambda+\sin(1/y)-\cos(1/y)/y\), with alternating unbounded signs. It is noninjective
on every neighborhood, and distinct parameters with the same \(t\) have distinct
reflections. Hence no local all-graph RL estimate exists for any \(\lambda\). The same
critical-point mechanism rules out a uniform finite standard graph modulus.

Since \(|G(y)|\le|y|\), every \(y\in F(x)\) obeys \(|x|\le|y|\), hence

\[
|x|\le d(0,F(x)). \tag{4.4}
\]

Small positive and negative targets are attained on oscillatory lobes, so the residual is
finite. Along \(\sin(1/y)=\pm1\), equality holds in (4.4), proving exact SMSR modulus 1 and
\(q_*=1\). Equivalently, the single-valued inverse \(G\) is isolatedly calm/calm with exact
modulus 1. It is not Aubin because
\(G'(y)=\sin(1/y)-\cos(1/y)/y\) is unbounded. Thus MR and SMR fail. This fills the
isolated-calm-without-Aubin cell using a closed multibranch relation.

---

### EX-22 — Sparse vertical fibers plus square curve: neither Aubin nor isolated calm

Let

\[
K=\{0\}\cup\{1/n:n\in\mathbb N\},\qquad
G(y)=K\cup\{\operatorname{sgn}(y)\sqrt{|y|}\},\qquad F:=G^{-1}. \tag{4.5}
\]

Equivalently, the mapping has the explicit form

\[
F(x)=\begin{cases}
\mathbb R,&x\in K,\\
\{\operatorname{sgn}(x)x^2\},&x\notin K.
\end{cases} \tag{4.6}
\]

Its graph

\[
\operatorname{gph}F=(K\times\mathbb R)
\cup\{(x,\operatorname{sgn}(x)x^2):x\in\mathbb R\}
\]

is closed; \(F^{-1}=G\) and \(\operatorname{zer}F=K\). Every resolvent fiber contains
all the candidates \(x\in K\), because one may choose
\(u^*=(t-x)/\lambda\in F(x)\). Thus \(J\) and \(R\) are multivalued for every input and
no RL estimate exists. Vertical fibers accumulating at zero also rule out every finite local
hypomonotonicity constant: take \(a=1/n\) and choose graph-output difference
\(b=-1/\sqrt n\), so \(ab/a^2=-\sqrt n\to-\infty\).

For \(x\notin K\), \(d(0,F(x))=|x|^2\), whereas it is zero on \(K\). Therefore

\[
d(x,K)\le|x|=d(0,F(x))^{1/2}. \tag{4.7}
\]

Equality holds for negative \(x\to0\), so \(q_*=1/2\) and the endpoint MSR modulus is 1.
Ordinary MSR fails. SMSR of any order fails because the zero is nonisolated.

On the inverse side, isolated calmness fails already because
\(G(0)=K\) has nonzero points converging to zero. Calmness (hence Aubin) fails by taking
\(y<0\): the moving point \(-\sqrt{|y|}\in G(y)\) has distance \(\sqrt{|y|}\) from the
nonnegative set \(G(0)=K\), and the ratio to \(|y|\) diverges. Consequently MR and SMR
fail. This gives the neither-Aubin-nor-isolated-calm cell while retaining a sharp fractional
MSR law.

---

### EX-23 — Saturated identity \(F(x)=\operatorname{clip}(x,-1,1)\)

Define

\[
F(x)=\begin{cases}-1,&x<-1,\\x,&|x|\le1,\\1,&x>1.
\end{cases}
\]

This is a continuous single-valued maximally monotone map with zero \(\{0\}\). Its inverse is

\[
F^{-1}(y)=\begin{cases}
\{y\},&|y|<1,\\
[1,\infty),&y=1,\\
(-\infty,-1],&y=-1,\\
\varnothing,&|y|>1.
\end{cases}
\]

For \(\lambda>0\),

\[
J_{\lambda F}(t)=\begin{cases}
t+\lambda,&t<-(1+\lambda),\\
t/(1+\lambda),&|t|\le1+\lambda,\\
t-\lambda,&t>1+\lambda,
\end{cases} \tag{4.8}
\]

and \(R=2J-I\). The slopes of \(R\) are \(1\) on the two tails and
\((1-\lambda)/(1+\lambda)\) in the center, so global RL\(_1\) has sharp \(L=1\).
No global \(\gamma<1\) estimate holds because \(R(t)=t\mp2\lambda\) in the unbounded tails.

The map is sharply 1-cocoercive and monotone, but not globally strongly monotone because of
saturation. Locally at zero it is the identity: MR, SMR, MSR and SMSR all have exact modulus
1, the inverse is Aubin and isolatedly calm, and \(q_*=1\). The corresponding **global**
error bound fails, since \(d(x,\{0\})=|x|\) while \(d(0,F(x))=1\) for \(|x|>1\).
This cleanly separates local regularity from global saturation geometry.

## 5. 逻辑区域覆盖与交给 C 的审计点

### 5.1 已显式填充的 gap cells

| Gap | both | left only | right only | neither |
|---|---|---|---|---|
| monotone vs ordinary SMSR | EX-02, EX-23 | EX-03, EX-19 | EX-15, EX-17 | EX-08 |
| all-pairs RL (specified step) vs SMSR | EX-02, EX-15 off singular step | EX-19 | EX-15 at \(\eta=1\), EX-17 | EX-08 globally |
| hypomonotone vs LT (same restricted scale) | EX-15 for \(\eta\ne1\), EX-16 for \(\eta<1\) | EX-15 at \(\eta=1\) | EX-14 | EX-17 |
| MR vs SMSR | EX-02, EX-15 | EX-20 | EX-16, EX-21 | EX-08 |
| Aubin vs isolated calm of inverse | EX-02/15/23 | EX-20 | EX-16/21 | EX-22 |
| power signature vs gauge class | EX-05 and EX-06 share \(q_*=1-c\) | exact \(\phi_+\) only | exact \(\phi_-\) only | each fails the other gauge |

这里“left/right only”均按表头次序解释。EX-19/20 的 MSR 已醒目标成 vacuous，不能把
它们当成非平凡 error-bound 数据点。

### 5.2 C 必须独立复核的边界

1. EX-05/06 的 fixed-target sharp power exponent 是 \(1-c\)；不要据此自动赋予
   two-variable Hölder MR exponent。若 C 要计算 pairwise modulus，需从
   \(\phi_\pm'\) 或直接差商重新开始。
2. EX-10 的 \(1/3\) RL 只在 critical step \(\eta=1\) 且 bounded Minty window成立；
   不能写成 global。
3. EX-11 的 pure power只有 global exponent \(\alpha\)；EX-12 因 bounded clipping 才
   同时容许所有 \(\gamma\le\alpha\)。
4. EX-13 的 \(\gamma<1\) 证书是 bounded + Lipschitz 的继承，不是 genuine Hölder
   singularity。
5. EX-14 是 restricted graph/domain；其 MR 失败来自 target-side noncoverage，而
   isolated calmness允许空 fiber。
6. EX-17 的 anchored bound只以 \((0,0)\) 为一端。把它错写成 all-pairs 会与
   Minty noninjectivity直接矛盾。
7. EX-18 的 MR+SMSR 不推出 SMR是 set-valued branch multiplicity，不应与
   differentiable single-valued inverse theorem混用。
8. EX-19/20 必须保留 domain-vacuity标签；EX-09/21/22 的 MSR 则非vacuous。

### 5.3 解析验证清单

- 所有 graph/zero/inverse 公式均由直接代入获得；没有用数值网格证明全称命题。
- Cayley entries EX-11--13 均证明了 \(h=(I+R)/2\) 严格递增且 onto，因而生成的是
  single-valued \(F\)，并给出消元式或参数逆。
- 所有 sharp residual exponents 都由精确等式或双边渐近给出，并提供失败序列。
- 所有 all-pairs RL 失败均由 zero-denominator collision、Minty noninjectivity或明确
  Hölder ratio 发散给出。
- 文献仅承载定义/convention；本 catalog 的具体常数标为 ALG，等待 C 独立复算。
