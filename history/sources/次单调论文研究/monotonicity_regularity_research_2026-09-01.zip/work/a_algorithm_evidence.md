# 算法定理证据表：generalized monotonicity × metric regularity

> **文档角色。** 本文件只做 theorem-level evidence collection，供最终 integrator 使用；不据此宣称存在或不存在统一“跷跷板”。检索/核验日期：2026-09-01。
>
> **范围。** PPA/relaxed PPA、forward–backward/proximal-gradient、Douglas–Rachford/ADMM、Peaceman–Rachford、FBF/extragradient、projection/alternating projections、Newton/semismooth Newton、KL/error-bound 方法。

## 0. 证据与可比性编码

| 编码 | 含义 |
|---|---|
| `V3` | 已从 primary-source 全文核对 theorem statement、假设与关键 rate/constant；可直接进入 atlas/integration。 |
| `V2` | primary source 的 theorem statement 已核对，但某些长常数只保留论文原记号，或结论依赖另一个已指明命题。 |
| `V1` | 只核对到摘要/索引/二手转述；不得用来建立严格比较。本文不以 `V1` 支撑任何结论。 |
| `J` | 同一定理中 graph geometry 与 regularity **共同**进入充分条件或收缩常数。只表示“联合控制”，不表示两者可互换。 |
| `A` | 同一算法/同一问题类中存在两套替代 sufficient branches，结论和量词足够接近，可供后续谨慎比较。 |
| `B` | 仅为边界证据：不同结论、不同 residual、不同量词或不同问题类，不能组成补偿对。 |
| `P` | 尚待 primary-source 定理级核验；不作事实使用。 |

### 统一记号警告

- `metric subregularity of F at (x̄,0)` 指局部 `dist(x,F^{-1}(0)) ≤ κ dist(0,F(x))`；不同论文把 `κ`、`κ^{-1}` 或 `γ`称为 modulus，表内保持原文并显式说明。
- fixed-point 文献常假设的是 `Φ:=T-Id` 或 `Id-T` 的 metric subregularity，而不是原 inclusion operator `F` 的 subregularity；二者不得静默互换。
- `strong metric subregularity` 等价于 subregularity 加局部孤立解；它与普通 subregularity产生的“到解集距离”结论不可当作同一结论。
- relaxed PRS/DR 的 `λ` convention 不统一。Davis–Yin 的 `λ=1/2` 是 DRS、`λ=1` 是 PRS；Shen–Pan 的相应 fixed-point relaxation 使用 `[0,2]`，其端点 `λ=2` 才是 PRS 型端点。

## 1. 总览索引

| ID | 算法 | graph/monotonicity 假设 | regularity / EB 假设 | 结论 | 可比性 | 证据 |
|---|---|---|---|---|---|---|
| PPA-01 | PPA | maximal monotone | `F` metrically subregular | 局部 Q-linear distance | `J` | `V3` |
| PPA-02 | relaxed PPA | maximal monotone | `F` metrically subregular | 局部 Q-linear distance | `J` | `V3` |
| PPA-03 | PPA | maximal monotone | metric `q`-subregularity | polynomial / linear / superlinear regimes | `J` | `V3` |
| PPA-04 | generalized PPA | **无 monotonicity** | metric regularity / strong subregularity | 选择序列的局部 linear/superlinear | `B` | `V2` |
| PPA-05 | local PPA | local maximal submonotonicity | metric subregularity | 局部 R-linear | `J` | `V3` |
| FXP-01 | abstract fixed-point | pointwise almost averaged | residual metric subregularity | 局部 linear | `J` | `V3` |
| FB-01 | relaxed forward–backward | maximal monotone + cocoercive | sum metrically subregular | 局部 Q-linear distance | `J` | `V3` |
| FB-02 | nonconvex forward–backward | hypomonotone/submonotone, calm gradient | FB residual metrically subregular | 局部 linear | `J` | `V3` |
| PG-01 | convex proximal-gradient | convexity + Lipschitz gradient | prox-gradient EB | objective Q-linear, iterates R-linear | `J` | `V3` |
| PG-02 | linesearch forward–backward | convex composite | `∂(f+g)` metrically subregular | iterates Q-linear | `J` | `V3` |
| DR-01 | generalized DR | two maximal monotone; one Lipschitz | sum metrically subregular | 局部 Q-linear distance | `J` | `V3` |
| DR-02 | DR/ADMM | convex subdifferentials | (i) strong convexity+cocoercivity **or** (ii) residual EB | 局部 linear | `A` | `V3` |
| DR-03 | nonconvex DR | manifold + convex linear-quadratic geometry | DR residual metrically subregular | 局部 linear | `J` | `V3` |
| PRS-01 | relaxed PRS | strong convexity + smoothness of one term | 无 metric regularity | global linear fixed-point iterates | `B` | `V3` |
| FBF-01 | nonlinear FB / FBF / extragradient | maximal monotonicity + cocoercive/Lipschitz pieces | full inclusion metrically subregular | local Q/R-linear | `J` | `V3` |
| AP-01 | cyclic projections | elemental subregularity / almost averagedness | subtransversality-type metric regularity | 局部 linear | `J` | `V2` |
| NEW-01 | generalized Newton | 无 monotonicity | strong (q-)subregularity | conditional superlinear / order | `B` | `V3` |
| NEW-02 | semismooth Newton | semismoothness; no monotonicity | all linearizations strongly subregular | conditional superlinear | `B` | `V3` |
| KL-01 | prox-gradient / iPiano | composite descent geometry | Luo–Tseng EB ⇒ KL-1/2 | local linear | `B` | `V3` |

## 2. PPA 与抽象 fixed-point 桥梁

### PPA-01 — Leventhal：maximal monotonicity + metric subregularity

| 字段 | 内容 |
|---|---|
| 算法/映射 | Hilbert 空间，`T` maximal monotone；`x^{k+1}=J_{λ_kT}x^k`。目标 `S=T^{-1}(0)`。 |
| Graph geometry | maximal monotonicity；用于 resolvent firm nonexpansiveness 与 Fejér decrease。 |
| Regularity | `T` 在 `(x̄,0)` metrically subregular，最小/给定 modulus `γ`；定理取任意 `γ̄>γ` 并把初值限制在对应邻域。 |
| 结论/常数 | 对进入该邻域的迭代，`dist(x^{k+1},S)^2 ≤ [γ̄²/(λ_k²+γ̄²)] dist(x^k,S)^2`。若 `inf λ_k>0`，局部 Q-linear distance；若 `λ_k→∞`，比率趋于 0，得到 superlinear distance。 |
| 完整额外假设/量词 | 零集非空；局部性围绕一个零点；结论是到**整个零集**的距离，不要求零点孤立。 |
| 是否可形成补偿对 | `J`：两类假设在同一证明中分别给 Fejér 减少和 residual-to-distance 控制；本文不声称任一可由另一替代。 |
| 来源 | Leventhal, *Metric Subregularity and the Proximal Point Method*, JMAA 360 (2009), [arXiv:0902.4200, Theorem 3.1](https://arxiv.org/abs/0902.4200), [DOI](https://doi.org/10.1016/j.jmaa.2009.07.012). `V3`. |

**校勘警告。** Luke–Tam 2025 的 Remark 3 印出的 Leventhal factor 为 `sqrt(λ²/(λ²+ρ²))`；Leventhal 原定理是 `ρ/sqrt(λ²+ρ²)`（用本文 `ρ=γ̄`）。后者也与 `λ_k→∞` 导致 superlinear 的结论一致。后续文件不得传播前一印刷式。

### PPA-02 — Shen–Pan：relaxed PPA

| 字段 | 内容 |
|---|---|
| 算法/映射 | 有限维 Hilbert 空间；`z^{k+1}=z^k+λ_k(J_{γF}z^k-z^k)`，固定 proximal parameter `γ>0`。 |
| Graph geometry | `F` maximal monotone。 |
| Regularity | `F` at `(z*,0)` metrically subregular with modulus `κ`。 |
| 结论/常数 | 只要迭代收敛到 `z*` 并进入 subregularity 邻域，最终有 `dist(z^{k+1},zer F) ≤ sqrt(1-λ_k(2-λ_k)γ²/(γ+κ)²) dist(z^k,zer F)`。 |
| 完整额外假设 | `λ_k∈[0,2]` 且 `Σ_k λ_k(2-λ_k)=∞`；`zer F≠∅`。该条件同时给出基础收敛并排除一直取端点。 |
| 是否可形成补偿对 | `J`。与 PPA-05 可以比较“同一 PPA 家族、相同 distance 结论”，但常数估计技术不同，不能仅按公式大小排序。 |
| 来源 | Shen & Pan, *Linear convergence of the generalized PPA and several splitting methods for the composite inclusion problem*, [arXiv:1508.05156v4, Theorem 3.1](https://arxiv.org/abs/1508.05156). `V3`. |

### PPA-03 — Li–Mordukhovich：Hölder / metric `q`-subregularity

| 字段 | 内容 |
|---|---|
| 算法/映射 | Hilbert 空间 maximal monotone `T`；PPA `x^{k+1}=J_{λ_kT}x^k`。 |
| Graph geometry | maximal monotonicity。 |
| Regularity | metric `q`-subregularity (`0<q≤1`): `dist(x,S)≤c dist(0,T(x))^q` locally。注意这里 `q<1` 是 Hölder 弱化，不是 Newton 文献的 `q≥1` convention。 |
| 核心递推 | Theorem 7.2 给 `d_{k+1}² ≤ d_k²-c^{-2/q}λ_k² d_{k+1}^{2/q}`，其中 `d_k=dist(x^k,S)`。 |
| Rate regimes | Theorem 7.3：(i) `q∈(0,1)`、常步长：`d_k=O(k^{-q/[2(1-q)]})`；(ii) 若 `λ_k=O(k^s)`, `0<s≤1/[2(1-q)]`：`d_k=O(k^{-2sq})`；(iii) 若 `s≥1/[2(1-q)]`：`d_k=O(k^{-q[1+2s(1-q)]/[2(1-q)]})`；(iv) `q=1` 常步长 R-linear；(v) `q=1, λ_k→∞` R-superlinear。这里按原文保留其 `λ_k=O(k^s)` 表述。 |
| 完整额外假设 | 零集非空；初值/迭代在 q-subregularity 邻域；步长满足各分支条件。多项式 Big-O 是 distance rate，不是 objective rate。 |
| 是否可形成补偿对 | `J`；这是 monotone 基线固定时 regularity exponent 改变 rate 的直接证据，不是 γ 与 RL exponent 的已证组合律。 |
| 来源 | Li & Mordukhovich, *Hölder Metric Subregularity with Applications to Proximal Point Method*, SIAM J. Optim. 22 (2012), [primary PDF, Theorems 7.2–7.3](https://optimization-online.org/wp-content/uploads/2012/02/3340.pdf), [DOI](https://doi.org/10.1137/120864660). `V3`. |

### PPA-04 — Aragón Artacho–Dontchev–Geoffroy：不假设 monotonicity 的 generalized PPA

| 字段 | 内容 |
|---|---|
| 算法/映射 | Banach spaces；`g_n(x_{n+1}-x_n)+T(x_{n+1})∋0`，`g_n(0)=0`。允许 set-valued implicit step。 |
| Graph geometry | 不假设 monotonicity / maximality。只要求 `gph T` locally closed。 |
| Regularity branch 1 | Theorem 3.1：`T` metrically regular at `x̄` for `0`；`g_n` 在共同邻域 Lipschitz，常数 `λ_n` 满足 `sup_n λ_n < 1/[2 reg T(x̄|0)]`。 |
| 结论 branch 1 | 对每个足够近初值，**存在**一个合法选择的序列局部 linearly converging to `x̄`；若 `λ_n→0`，可选得 superlinear。 |
| Regularity branch 2 | Theorem 4.2 用 strong metric subregularity；在序列已存在且留在邻域的条件下，`sup λ_n<1/(2κ)` 给 linear，`λ_n→0` 给 superlinear。 |
| 关键量词限制 | 不是 resolvent 单值性定理，也不是“每个选择序列”收敛；branch 1 的 metric regularity 比普通 subregularity 强，branch 2 又要求孤立解。 |
| 是否可形成补偿对 | `B`。它表明强 inverse stability 可以在另一套 PPA 框架中不配 monotonicity，但因算法、选择量词、regularity 强度和结论均与 PPA-01/05 不同，不能作为严格替代对。 |
| 来源 | Aragón Artacho, Dontchev & Geoffroy, *Convergence of the Proximal Point Method for Metrically Regular Mappings*, ESAIM Proc. 17 (2007), [publisher page](https://www.esaim-proc.org/articles/proc/abs/2007/02/proc071701/proc071701.html), Theorems 3.1, 4.2. `V2`（定理文本已核对；出版社 PDF 在当前环境不可全文解析）。 |

### PPA-05 — Luke–Tam：local maximal submonotonicity + subregularity

| 字段 | 内容 |
|---|---|
| 算法/映射 | Euclidean space；local PPA selection `x^{n+1}∈J_{λF}(x^n)∩B_δ(x̄)`。 |
| Graph geometry | `λF` 在零点邻域按论文 convention **maximally submonotone**，violation `τ`，并有局部 range/maximality 条件使所需 resolvent branch 存在。证明实际使用的 almost-firm resolvent 估计为 `‖Jx-p‖²+‖x-Jx‖²≤(1+2τ)‖x-p‖²`（局部、相对指定 domain，`p` 为相关零点）。由平行四边形恒等式推出的 reflected-resolvent bound 是 `‖Rx-p‖²≤(1+4τ)‖x-p‖²`，不可把其中常数误写成 `1+2τ`。 |
| Regularity | `F` near each relevant zero, relative to domain `D`, metrically subregular，uniform bound `ρ̄`。 |
| 兼容条件 | `τ(1+ρ̄/λ)²<1/2`。选任意 `ρ>ρ̄` 仍满足该严格不等式。 |
| 结论/常数 | Theorem 2：任意按定理局部 branch 生成且保持在球内的序列 R-linearly converges to a zero。证明给 distance contraction `κ=sqrt(1+2τ-[λ/(λ+ρ)]²)<1`。`τ=0` 的 Corollary 1 回到 maximal monotone + subregularity。 |
| 完整额外假设 | `zer F∩D` 非空且 closed；resolvent self-map/局部选择条件；finite dimensional；结论局部且依赖选中的 branch。 |
| 是否可形成补偿对 | `J`，并且 graph violation `τ` 与 subregularity bound `ρ̄` 出现在同一兼容不等式和 rate 中；这是可供 integrator 检验的明确 coupling datum，但定理本身不证明最优 trade-off 或必要性。 |
| 来源 | Luke & Tam, *Generalized Monotonicity and the Proximal Point Algorithm*, Math. Oper. Res. (online 2025), [publisher full text, Assumption 2, Theorem 2, Corollary 1](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863), [DOI](https://doi.org/10.1287/moor.2025.0863). `V3`. |

### FXP-01 — almost averagedness + residual metric subregularity 的抽象模板

| 字段 | 内容 |
|---|---|
| 算法/映射 | set-valued fixed-point iteration `x^{k+1}∈T(x^k)`，常在 affine subset `Λ` 上。Residual `Φ=T-Id`。 |
| Graph geometry | `T` pointwise almost averaged at fixed points with violation `ε≥0` and averaging constant `α∈(0,1)`。 |
| Regularity | `Φ` metrically subregular for `0` relative to `Λ`, modulus `κ`，并满足论文的 local set/annulus invariance 与 residual separation 条件。 |
| 兼容条件/常数 | `κ<sqrt[(1-α)/(εα)]`（`ε=0` 时无上界）；distance contraction `c=sqrt[1+ε-(1-α)/(ακ²)]<1`。 |
| 结论 | 局部 linear decrease of distance to `Fix T∩Λ`；附加闭性/迭代条件下序列 R-linear to a fixed point。 |
| 是否可形成补偿对 | `J`。这是 FB、DR、cyclic projection 多条定理的公共 proof engine；这里的 regularity 是 residual regularity，不能直接标成原 inclusion 的 regularity。 |
| 来源 | Luke, Thao & Tam, *Quantitative convergence analysis of iterated expansive, set-valued mappings*, Math. Oper. Res. 43 (2018), [arXiv:1605.05725v2, Theorem 2.15 and Corollary 2.19](https://arxiv.org/abs/1605.05725). `V3`. |

## 3. Forward–backward 与 proximal-gradient

### FB-01 — Shen–Pan：maximal monotone + cocoercive + sum subregularity

| 字段 | 内容 |
|---|---|
| 算法/映射 | `F=A+C`；relaxed FB `z^{k+1}=z^k+λ_k[J_{γA}(I-γC)z^k-z^k]`。 |
| Graph geometry | `A` maximal monotone；`C` `β`-cocoercive（Theorem 3.2 statement 偶写成未定义的 `B`，上下文与证明均为 `C`）。因此 `F` monotone。 |
| Regularity | `F=A+C` at `(z*,0)` metrically subregular with modulus `κ`。注意不是 FB residual 的 subregularity。 |
| 参数 | `γ∈(0,2β)`；`δ=min{1,β/γ}+1/2`；`λ_k∈[0,δ]` 且 `Σ λ_k(δ-λ_k)=∞`。 |
| 结论/常数 | 最终 `dist(z^{k+1},zer F) ≤ sqrt[1-γ²λ_k(δ-λ_k)/(γ+κ)²] dist(z^k,zer F)`。局部 Q-linear distance（若 relaxation 远离端点）。 |
| 完整额外假设 | finite dimensional；`zer F≠∅`；基础 FB 序列收敛到某零点后才调用该点的局部 subregularity。 |
| 是否可形成补偿对 | `J`。不能与 FB-02 的常数直接比较：FB-02 regularizes `T_FB-Id`，且允许 nonmonotone pieces。 |
| 来源 | Shen & Pan, [arXiv:1508.05156v4, Theorem 3.2](https://arxiv.org/abs/1508.05156). `V3`; 以上 `B/C` 是原文 notation typo 校勘。 |

### FB-02 — Luke–Thao–Tam：nonconvex hypomonotone/submonotone FB

| 字段 | 内容 |
|---|---|
| 算法/映射 | `T_FB=prox_{t g}(Id-t∇f)` near a critical/fixed point，允许 set-valued prox branch。 |
| Graph geometry | `f` is `C¹`; `∇f` calm/Lipschitz locally with constant `L` and pointwise hypomonotone with violation `τ_f`; `g` proper lsc，`∂g` pointwise submonotone with violation `τ_g`；这些条件使 `T_FB` pointwise almost averaged。 |
| Regularity | `Φ_FB=T_FB-Id` 对 `0` metrically subregular，且对足够小 `t` 有 uniform modulus `κ(t)≤κ̄<1/(2sqrt(τ_g))`（`τ_g=0` 时上界解释为无穷）。 |
| 几何常数 | 证明固定 `α_0=1/2` 并令 `t=β/2`；按论文记号，almost-averaged violation 是 `ε(β)=(1+2τ_g)[1+(β/2)(2τ_f+βL²)]-1`，averaging constant `α=2/3`。等价地以实际步长写为 `ε(t)=(1+2τ_g)[1+t(2τ_f+2tL²)]-1`。相应 contraction `c=sqrt[1+ε-1/(2κ̄²)]<1`，取 `t` 足够小。 |
| 结论 | Theorem 3.24 给局部 linear decrease to fixed-point set / R-linear convergence under its neighborhood invariance assumptions。 |
| 完整额外假设 | prox mapping 在所选邻域有相应 branch；固定点/临界点非空；regularity 对 small `t` uniform；所有 almost-averagedness、invariance、closedness 条件按 Theorem 2.15 落地。 |
| 是否可形成补偿对 | `J`：graph violation 与 residual modulus 在 `c<1` 中共同出现。它不证明更弱 monotonicity必然要求更强 regularity；uniform-in-`t` 本身是额外强要求。 |
| 来源 | Luke, Thao & Tam, [arXiv:1605.05725v2, Proposition 3.21 and Theorem 3.24](https://arxiv.org/abs/1605.05725). `V3`. |

**同文 convex boundary.** Corollary 3.25 在 `g` convex、`∇f` globally strongly monotone 且 Lipschitz、FB residual globally/uniformly metrically subregular等条件下给 global linear convergence。它增加而非替换 geometry 与 regularity，故暂不另立“补偿”记录。

### PG-01 — Drusvyatskiy–Lewis：prox-gradient error bound

| 字段 | 内容 |
|---|---|
| 算法/映射 | `φ=f+g` convex；`f` differentiable with `β`-Lipschitz gradient，`g` closed convex。`G_t(x)=t^{-1}[x-prox_{tg}(x-t∇f(x))]`。 |
| Graph geometry | Convexity of both terms and smooth convex cocoercive geometry of `∇f`；`t≤1/β`。 |
| Regularity/EB | 在 sublevel strip `φ(x)≤φ*+ν` 上，`dist(x,S)≤γ‖G_t(x)‖`。这是 algorithmic residual EB；论文另证其与 subdifferential EB/quadratic growth 的定量联系。 |
| 结论/常数 | Theorem 3.2：`φ(x_{k+1})-φ*≤[1-1/(2βγ)](φ(x_k)-φ*)`（在相应参数/level set 内）；若序列有极限点，则 iterates R-linearly converge。论文给 `‖x_{r+k}-x*‖²≤C[1-1/(2βγ)]^k[φ(x_r)-φ*]`，`C=2/{β[1-sqrt(1-(2βγ)^{-1})]²}`。 |
| EB 与 quadratic growth | Theorem 3.3：quadratic growth constant `α` ⇒ subdifferential EB modulus `2/α`；反向 EB modulus `L` ⇒ 任意 `α∈(0,1/L]` 的 quadratic growth。需保持其局部/sublevel assumptions。 |
| 是否可形成补偿对 | `J`，但这里 monotonicity 主要被凸性固定，EB 变化控制 rate；不是“无 monotonicity + EB”的替代定理。 |
| 来源 | Drusvyatskiy & Lewis, *Error bounds, quadratic growth, and linear convergence of proximal methods*, Math. Oper. Res. 43 (2018), [arXiv:1602.06661v2, Theorems 3.2–3.3](https://arxiv.org/abs/1602.06661). `V3`. |

### PG-02 — Bello-Cruz–Li–Nghia：linesearch FB + subdifferential subregularity

| 字段 | 内容 |
|---|---|
| 算法/映射 | finite-dimensional convex composite `F=f+g`；`f` convex differentiable，`g` proper lsc convex；Beck–Teboulle-style linesearch FB。 |
| Graph geometry | `∂F` maximal monotone；`∇f` locally `L`-Lipschitz near the limit。 |
| Regularity | `∂F` metrically subregular at `(x*,0)`，论文以 `κ^{-1}` 记 modulus，即 local `dist(x,S)≤κ^{-1}dist(0,∂F(x))`。 |
| 参数/常数 | Proposition 4.1 令 `α=min{α_K/2,θ/(2L)}`；最终 distance factor `1/sqrt(1+ακ)`，objective `O((1+ακ)^{-k})`。Theorem 4.2 给 iterates Q-linear factor `1/sqrt(1+ακ/4)`，并给 objective Q-linear factor `(sqrt(1+ακ/4)+1)/(2sqrt(1+ακ/4))`。 |
| 完整额外假设 | 已知生成序列收敛到 `x*`；linesearch 参数满足论文条件；结论最终/局部。 |
| 是否可形成补偿对 | `J`；和 PG-01 residual 不同，不能用 `γ=κ^{-1}` 直接代换常数。 |
| 来源 | Bello-Cruz, Li & Nghia, *Q-linear convergence of forward-backward splitting method and uniqueness of optimal solution to Lasso*, [arXiv:1806.06333v1, Proposition 4.1 and Theorem 4.2](https://arxiv.org/abs/1806.06333). `V3`. |

## 4. Douglas–Rachford、ADMM 与 Peaceman–Rachford

### DR-01 — Shen–Pan：sum subregularity + one Lipschitz component

| 字段 | 内容 |
|---|---|
| 算法/映射 | generalized relaxed DR for `0∈(A+B)x`，fixed parameter `γ>0`；shadow sequence 收敛到解。 |
| Graph geometry | `A,B` maximal monotone；此外其中一个是 single-valued and `1/β`-Lipschitz。单值 Lipschitz 不等于 cocoercive，定理仍保留 maximal monotonicity。 |
| Regularity | `F=A+B` at `(x*,0)` metrically subregular with modulus `κ`。 |
| Relaxation | `λ_k∈[0,2]`, `Σλ_k(2-λ_k)=∞`。 |
| Rate: A single-valued | 最终 distance factor `sqrt{1-λ_k(2-λ_k)/D_A²}`，其中 `D_A=2+sqrt(1+γ²β^{-2})[1+κ(γ^{-1}+β^{-1})]`。 |
| Rate: B single-valued | 最终 factor `sqrt{1-β²λ_k(2-λ_k)/D_B²}`，其中 `D_B=(γ+β)[1+κ sqrt(γ^{-2}+β^{-2})]`。 |
| 完整额外假设 | finite dimensional；解非空；基础 generalized DR 序列的收敛条件；local subregularity 在 limit solution 处。结论为 shadow 到 `zer(A+B)` 的最终 Q-linear distance。 |
| 是否可形成补偿对 | `J`。但额外的 one-component Lipschitz 假设是独立第三轴，不能将结果归因于 monotonicity/subregularity 两轴。 |
| 来源 | Shen & Pan, [arXiv:1508.05156v4, Theorem 3.3](https://arxiv.org/abs/1508.05156). `V3`. |

**PRS 排除项。** 在这篇论文的 relaxation convention 下，纯 PRS 端点对应 `λ_k=2`，故 `λ_k(2-λ_k)=0` 且违反发散条件。DR-01 **不能**被引用为 metric-subregularity 下 PRS linear convergence。

### DR-02 — Aspelmeier–Charitha–Luke：同一 convex DR/ADMM 问题的两条 sufficient branches

| 字段 | 内容 |
|---|---|
| 算法/问题 | `min_u J(u)+H(Au)`；`J,H` proper lsc convex，`A` injective；dual inclusion `0∈(B+D)x` with `B=∂(J*∘(-A^T))`, `D=∂H*`；DR fixed-point iteration，与 ADMM 等价。 |
| 共同 graph geometry | convexity ⇒ relevant subdifferentials maximal monotone，DR operator firmly/quasi-firmly nonexpansive on the relevant affine set `W`。solution set nonempty，fixed `η>0`。 |
| Branch (i): geometry | `H` locally `μ`-strongly convex and `∂H` `β`-inverse strongly monotone。 |
| Branch (i): rate | 从足够近起点，linear factor `K=sqrt[1-2ηβμ²/(μ+η)²]`。 |
| Branch (ii): EB | 在邻域、相对 `W`，`‖x-x^+‖≥sqrt(κ) dist(x,Fix T)`；等价于 `Id-T` metric subregular with modulus `1/sqrt(κ)`。 |
| Branch (ii): rate | Theorem 2.3(ii) 给 `dist(x^+,Fix T)≤sqrt(1-κ)dist(x,Fix T)` 所驱动的局部 linear DR/ADMM convergence。条件 (2.14) 本身是 `Id-T` 的普通 metric subregularity/coercivity estimate relative to `W`，**不要求** `Fix T∩W` 为 singleton。Theorem 1.6 和 PLQ Theorem 2.7 另给“relative isolated fixed point ⇒ strong subregularity/该 coercivity”的充分路线。 |
| 完整额外假设 | 邻域与 affine invariance `T:W→W`；条件对所有 `x^+∈Tx`；ADMM primal/dual variables的 rate 经 DR equivalence 与 resolvent nonexpansiveness传递。若使用 Theorem 1.6/2.7 验证条件，才额外需要 relative isolatedness。结论是局部的。 |
| 是否可形成补偿对 | `A`：这是少见的同一问题/同一 DR–ADMM 框架中的两个 sufficient branches。但 (i) 与 (ii) 并未被证明互相排斥，且常数不可直接排序；只能给 integrator 作“候选替代机制”证据。 |
| 来源 | Aspelmeier, Charitha & Luke, *Local Linear Convergence of the ADMM/Douglas–Rachford Algorithms without Strong Convexity and Application to Statistical Imaging*, SIAM J. Imaging Sci. 9 (2016), [arXiv:1508.04468v3, Theorems 1.6 and 2.3](https://arxiv.org/abs/1508.04468). `V3`. |

**PLQ specialization.** 同文 Theorem 2.7 以 `J,H` piecewise linear-quadratic 导出 DR operator polyhedral；若 relevant fixed point 在 `W` 中 isolated，则 Robinson-type polyhedral error bound 给局部 linear。这里 polyhedrality 是 regularity 的来源，而不是 weaker monotonicity。

### DR-03 — nonconvex DR：almost firm geometry + residual subregularity

| 字段 | 内容 |
|---|---|
| 算法/问题 | DR applied to `f+g`；`g=ι_Ω` for a smooth manifold `Ω`，`f` convex linear-quadratic；迭代限制在 affine hull `Λ`。 |
| Graph geometry | manifold projector/reflector 在 reference point 附近提供 pointwise almost firm nonexpansiveness（violation 可随邻域缩小）；linear-quadratic prox 提供相应 averaged geometry。不是 global monotone inclusion 结论。 |
| Regularity | `Φ_DR=T_DR-Id` at fixed points, relative to `Λ`, metrically subregular with modulus `κ`。 |
| 结论/常数 | 对任意满足兼容条件的足够小 `ε>0`，局部 distance factor不超过 `sqrt(1+ε-1/κ²)`；Theorem 3.33 给局部 linear convergence。 |
| 完整额外假设 | paper 的 affine-invariance、fixed-point consistency、局部 manifold regularity 与 initialization 条件；`c<1` 要求 `ε<κ^{-2}`。 |
| 是否可形成补偿对 | `J`。regularity 是 fixed-point residual；`ε` 可缩小依赖光滑 manifold 局部化，不能与 operator submonotonicity violation 等同。 |
| 来源 | Luke, Thao & Tam, [arXiv:1605.05725v2, Theorem 3.33](https://arxiv.org/abs/1605.05725). `V3`. |

### PRS-01 — Davis–Yin：strong convexity + smoothness，无 EB 的纯 PRS linear theorem

| 字段 | 内容 |
|---|---|
| 算法/映射 | `min(f+g)` on Hilbert space；`z^{k+1}=(1-λ_k)z^k+λ_k R_{γf}R_{γg}z^k`。论文 convention：`λ=1/2` DRS，`λ=1` PRS。 |
| Graph geometry | `f,g` closed proper convex；Theorem 4.1 假设 `g` `μ_g`-strongly convex且 differentiable with `1/β_g`-Lipschitz gradient (`μ_gβ_g>0`)。这等价于 `∂g` 同时 strongly monotone 与 `β_g`-cocoercive。 |
| Regularity/EB | 无 metric regularity/subregularity/error-bound assumption。 |
| 结论/常数 | 对每步 `λ_k∈[0,1]`，`‖z^{k+1}-z*‖≤C(λ_k)‖z^k-z*‖`, `C(λ)=sqrt[1-4γλμ_g/(1+γ/β_g)²]`。取 `λ=1` 覆盖纯 PRS；`γ=β_g` 时 `C(λ)=sqrt(1-λ μ_gβ_g)`。global contraction。 |
| 完整额外假设 | fixed point存在；prox mappings well-defined by convexity；若要 uniform linear，`λ_k` 需使 `sup C(λ_k)<1`。 |
| 是否可形成补偿对 | `B`。它提供“强 graph geometry、无 EB”基准，但不能直接与 DR-01 的 subregularity theorem 配对：算法端点、正则假设和输出变量不同。 |
| 来源 | Davis & Yin, *Faster convergence rates of relaxed Peaceman–Rachford and ADMM under regularity assumptions*, Math. Oper. Res. 42 (2017), [arXiv:1407.5210, Theorem 4.1 and Remark 4.1](https://arxiv.org/abs/1407.5210), [primary preprint PDF](https://ww3.math.ucla.edu/camreport/cam14-58.pdf). `V3`. |

**混合 regularity 边界。** 同文 Theorem 4.3 若强凸性与 smoothness 分属 `f,g` 两项，factor 为 `sqrt[1-(4λ/3)min{γμ,β/γ,1-λ}]`；由于 `λ=1` 时最后一项为 0，该定理明确**不**推出 pure PRS linear convergence。

## 5. FBF / extragradient

### FBF-01 — Giselsson：nonlinear FB projection-correction framework

| 字段 | 内容 |
|---|---|
| 总框架 | Solve `0∈(A+C)x`; variable nonlinear metric maps `M_k`，projection correction in metric `S`。 |
| Graph geometry | `A` maximal monotone；`C` `1/β`-cocoercive relative to metric `P`, with paper parameter `β∈[0,4)`；`M_k` maximal monotone, single-valued, uniformly `L_M`-Lipschitz and `1`-strongly monotone in `P`-norm。 |
| Regularity | `A+C` metrically subregular at every solution for `0` with modulus `κ`（local；在 infinite dimension 需 uniform solution-neighborhood version）。 |
| 结论/常数 | Theorem 3：finite-dimensional或上述 uniform 条件下，distance locally Q-linear、iterates locally R-linear。`c=sqrt[1-ε_θ(2-ε_θ)χ²/(1+κξ)²]`，其中 `χ=(1-β/4)[λ_min(P)/(L_M²λ_max(S^{-1}))][λ_min(P)/λ_max(S)]`，`ξ=L_M sqrt[λ_max(S^{-1})/λ_min(S)]+β λ_max(S^{-1})/λ_min(P^{-1})`。 |
| Relaxation | `θ_k∈[ε_θ,2-ε_θ]`；其它 bounded-metric assumptions 按 Assumptions 1–2。 |
| FBF/extragradient specialization | Theorem 4 handles `0∈B+D+E+K`: `B+D` maximal monotone, `D` Lipschitz, `E` cocoercive, `K` skew；full sum metrically subregular + finite dimension ⇒ local Q/R-linear。令 `E=K=0` gives FBF; 再令 `B=0` gives extragradient。其 admissible `γ`/relaxation须满足 Theorem 4 的 `γ≤(4-ε)/(β_E+4L_D)` 等界。 |
| 是否可形成补偿对 | `J`。不过 `M_k` strong monotonicity、component Lipschitz/cocoercivity、metric conditioning均进入 `χ,ξ`，故这不是纯两轴数据点。 |
| 来源 | Giselsson, *Nonlinear Forward-Backward Splitting with Projection Correction*, SIAM J. Optim. 31 (2021), [arXiv:1908.07449v3, Theorems 3–4 and §6.1.2](https://arxiv.org/abs/1908.07449). `V3`. |

## 6. Projection / alternating projections

### AP-01 — cyclic projections：set geometry + subtransversality-type metric regularity

| 字段 | 内容 |
|---|---|
| 算法/映射 | Cyclic projection mapping for closed sets `Ω_1,…,Ω_m`，在 product-space/affine set `Λ` 上分析其 fixed points and cycles。Projections可 set-valued。 |
| Graph/set geometry | 各集合在 reference points 满足 elemental subregularity；由此各 projector/composition pointwise almost averaged，individual violations `ε_j` 合成 `ε̄`，composition averaging constant `α=m/(m+1)`（firm components 情形）。 |
| Regularity | 论文的 product-space set-valued mapping满足 subtransversality / metric-regularity-type estimate，modulus `κ`；另需 residual bridge constant `σ`，故 fixed-point residual effective modulus `κ̄=κσ`。 |
| 兼容条件/常数 | `c=sqrt[1+ε̄-(1-α)/(ακ̄²)]<1`。这与抽象 FXP-01 形式相同。 |
| 结论 | Theorem 3.14 在明确的 affine-invariance、cycle/fixed-point consistency、neighborhood 与 residual assumptions 下，cyclic projection iterates locally linearly approach relevant cycle/fixed-point set；附加 closedness条件给 R-linear sequence convergence。 |
| 完整额外假设 | 不能只写“superregular + subtransversal”：需保留 Theorem 3.14 的 technical condition linking set inconsistency gaps/residuals (`σ`)、initialization region、map invariance，及 compatibility `c<1`。 |
| 是否可形成补偿对 | `J`：almost-averaged violation 与 transversality modulus同入 rate。但 monotonicity side 实际是 set/projector geometry，不是 operator inner-product monotonicity；只能作为 graph-geometry 扩展数据。 |
| 来源 | Luke, Thao & Tam, [arXiv:1605.05725v2, Theorem 3.14](https://arxiv.org/abs/1605.05725). `V2`（定理结构与 rate 已核，长 product-space mapping definitions须由 atlas逐项抄录原文后才可独立复现）。 |

### AP-02 — 必要性边界：linear convergence 可迫使 residual subregularity / subtransversality

| 字段 | 内容 |
|---|---|
| 内容 | 对 pointwise almost averaged mappings，若迭代相对 fixed-point set linearly monotone，并满足论文的 iterate-to-residual 比较条件，则 `Φ=T-Id` 必须 metrically subregular；应用于 alternating projections时，相应 set collection 必须 subtransversal。 |
| 用途 | 这是“EB 不只是一个任意 sufficient assumption”的必要性证据，但不是 monotonicity–regularity 替代定理，也不提供相同常数的 iff。 |
| 来源 | Luke, Teboulle & Thao, *Necessary Conditions for Linear Convergence of Iterated Expansive, Set-Valued Mappings*, Math. Program. (2018), [arXiv:1704.08926v2](https://arxiv.org/abs/1704.08926). `V2`；integrator 使用前应针对所选 AP corollary 复核全部集合假设。 |

## 7. Newton / semismooth Newton

### NEW-01 — generalized Newton under strong metric (q-)subregularity

| 字段 | 内容 |
|---|---|
| 问题/算法 | Banach spaces，generalized equation `0∈f(x)+F(x)`；Newton step `0∈f(x_k)+Df(x_k)(x_{k+1}-x_k)+F(x_{k+1})`。 |
| Graph geometry | 不要求 `F` monotone；`f` Fréchet differentiable。 |
| Regularity | Theorem 6.1：`f+F` strongly metrically subregular at `(x̄,0)`；Theorem 6.2：strong metric `q`-subregularity，论文 convention `q≥1`，即 `‖x-x̄‖^{1/q}≤λ dist(0,(f+F)(x))`。 |
| Smoothness | Thm 6.1 要 `Df` continuous at `x̄`；Thm 6.2 要 `Df` Hölder of exponent `α∈(0,1]`。 |
| 结论/常数 | 若一个生成序列的 tail 保持在定理邻域，Thm 6.1 给 superlinear convergence。Thm 6.2 给 recurrence `‖e_{k+1}‖^{1/q}≤Lλ‖e_k‖^{1+α}`，故 order `q(1+α)`。 |
| 关键量词限制 | 定理不保证每一步 linearized generalized equation有解、解唯一或迭代自动留在邻域；它是 **conditional rate theorem**。strong subregularity还包含 isolated solution。 |
| 是否可形成补偿对 | `B`。无 monotonicity说明 inverse stability可驱动 Newton 局部 rate，但 Newton 的 derivative cancellation 是额外核心机制；不能与 PPA/FB 的 Fejér geometry 作同结论比较。 |
| 来源 | Cibulka, Dontchev & Kruger, *Strong Metric Subregularity of Mappings in Variational Analysis and Optimization*, JMAA 457 (2018), [arXiv:1701.02078v1, Theorems 6.1–6.3](https://arxiv.org/abs/1701.02078). `V3`. |

### NEW-02 — semismooth Newton：线性化映射的 strong subregularity

| 字段 | 内容 |
|---|---|
| 问题/算法 | generalized equation `0∈f(x)+F(x)`，其中 `f:R^n→R^m` 在解 `x̄` 附近 locally Lipschitz、在 `x̄` semismooth，`F:R^n⇉R^m`。给定 `x_k`，取 `A_k∈∂_C f(x_k)` 并求 `x_{k+1}` 满足 `0∈f(x_k)+A_k(x_{k+1}-x_k)+F(x_{k+1})`。 |
| Graph geometry | 无 monotonicity；核心几何是 semismooth first-order approximation。 |
| Regularity | 对每个 `A∈∂_C f(x̄)`，线性化模型 `H_A(x):=f(x̄)+A(x-x̄)+F(x)` 在 `(x̄,0)` strongly metrically subregular。定理证明利用 `∂_C f(x̄)` 的紧性和 generalized Jacobian 的 outer semicontinuity，在邻域中获得 uniform error estimate；statement 本身不另加一个手工 uniform-modulus 假设。 |
| 结论 | Theorem 6.4：任何合法生成且最终留在邻域的序列 superlinearly converges to `x̄`。 |
| 关键限制 | 与 NEW-01 相同：不自动给 well-definedness/unique step/globalization。经典 strong metric regularity Newton定理往往给更强的存在唯一性，因此不能只因 rate同为 superlinear而视为同结论。 |
| 是否可形成补偿对 | `B`。regularity落在线性化 family而非原映射 alone；适合作为“共同对象可能是 derivative/coderivative”的候选证据，不能提前作统一判断。 |
| 来源 | Cibulka, Dontchev & Kruger, [arXiv:1701.02078v1, Theorem 6.4](https://arxiv.org/abs/1701.02078). `V3`. |

## 8. KL / error-bound 方法

### KL-01 — Luo–Tseng EB ⇒ KL exponent `1/2` ⇒ first-order local linear

| 字段 | 内容 |
|---|---|
| 模型 | `F=h+P`; `h` `C¹` on an open domain with locally Lipschitz gradient，`P` proper closed convex（按论文结构假设）。stationary set `X={x:0∈∇h(x)+∂P(x)}`。 |
| Graph geometry | 不以 operator monotonicity为假设；`h` 可 nonconvex。prox-gradient descent需要 step-size/sufficient-decrease assumptions。 |
| Regularity/EB | Luo–Tseng EB：在指定 level set、prox-gradient residual足够小时，`dist(x,X)≤c‖prox_P(x-∇h(x))-x‖`。另需 Assumption 4.1：stationary values locally separated；且 `X≠∅`。 |
| 结构结论 | Theorem 4.1：上述 EB + separated stationary values ⇒ `F` has KL exponent `1/2` at stationary points（在论文的 continuity/domain conditions下）。 |
| 算法结论 | Proposition 5.1：对 `F=h+g`，`h` smooth with `L`-Lipschitz gradient、`g` proper closed，prox-gradient steps satisfy `0<inf γ_k≤sup γ_k<1/L`；若 `inf F>−∞`、`F` has KL exponent `1/2` 且 generated sequence bounded，则其收敛到 stationary point 并最终 linearly converges。Theorem 5.1 对 iPiano：在其 composite assumptions 下，coercive + KL-`1/2`，momentum `β_m∈[0,1)`, step `α_s∈(0,2(1-β_m)/L)` ⇒ local linear。 |
| 常数 | 论文结论常数由 sufficient-decrease、relative-error、KL constant、step/momentum jointly组成；Theorem 4.1不是给 universal closed-form contraction。为避免把 proof-local constants拼成错误 sharp rate，本表保留“linear”并指向命题。 |
| 是否可形成补偿对 | `B`。这是 EB→desingularization→algorithmic rate 的链，不出现可调 monotonicity hypothesis；可作为另一机制族，不能与 PPA 的同一定理 coupling硬比较。 |
| 来源 | Li & Pong, *Calculus of the Exponent of Kurdyka–Łojasiewicz Inequality and Its Applications to Linear Convergence of First-Order Methods*, Found. Comput. Math. 18 (2018), [arXiv:1602.02915v6, Theorem 4.1, Proposition 5.1, Theorem 5.1](https://arxiv.org/abs/1602.02915). `V3`. |

### KL-02 — convex EB / quadratic growth 与 KL-`1/2` 的边界说明

Drusvyatskiy–Lewis PG-01 已给 convex subdifferential EB ⇄ quadratic-growth constants；Li–Pong KL-01 给特定 composite setting 中 Luo–Tseng EB ⇒ KL-`1/2`。这些不是无条件全局等价：需要 convexity、stationary-value separation、continuity/level-set assumptions。最终 atlas 应分别保留三种 residual：`dist(0,∂F(x))`、prox-gradient residual、KL slope/desingularizing inequality。

## 9. 哪些记录真能进入“强弱补偿候选池”

下表只做 theorem-comparability audit，不作跷跷板结论。

| 候选 | 同算法？ | 同映射/regularity target？ | 同结论与量词？ | 判定 |
|---|---:|---:|---:|---|
| PPA-01 vs PPA-05 | 是（local resolvent PPA） | 基本是 `F` subregularity；PPA-05 relative/local branch | 都是 local distance/R-linear，但 branch/maximality不同 | **可比较，但需保留 domain/selection差异**；PPA-05是最直接 coupling datum。 |
| PPA-04 vs PPA-05 | generalized implicit step相近但不相同 | metric regularity/strong subreg vs subreg | “存在选择序列” vs local branch任意生成序列 | **不可当严格替代对**。 |
| FB-01 vs FB-02 | 都是 FB | `A+C` subreg vs `T_FB-Id` subreg | distance-to-zero vs fixed-point local convergence | **只能机制级比较**。 |
| DR-02 branch (i) vs (ii) | 是 | branch (ii) residual EB；branch (i) no EB | 同一 theorem problem class的局部 linear | **最干净的替代 sufficient-branch候选**；仍非必要性/互斥性结果。 |
| DR-01 vs PRS-01 | DR-family但 relaxation端点不同 | sum subreg vs no EB | local shadow-distance vs global fixed-point contraction | **禁止硬比较**；DR-01不覆盖 pure PRS。 |
| FXP-01 / FB-02 / DR-03 / AP-01 | abstract template及其应用 | 都用 residual subregularity，但 relative sets不同 | 均 local linear | **可比较 proof architecture，不可自动比较 modulus**。 |
| NEW-01/02 vs PPA/FB | 否 | strong subreg of original/linearization vs ordinary subreg/residual | conditional superlinear vs algorithmically generated linear | **独立机制族**。 |
| KL-01 vs PG-01 | 同为 proximal first-order | Luo–Tseng residual vs prox-gradient/subdifferential EB | local linear；前者经 KL链 | **可建立 implication链的特定 setting，不能泛化成等价**。 |

## 10. 明确的禁止误引/比较清单

1. **Leventhal rate。** 使用 `ρ/sqrt(λ²+ρ²)`，不要使用 Luke–Tam Remark 3 印出的 `λ/sqrt(λ²+ρ²)`。
2. **Shen–Pan pure PRS。** `λ=2` 令其关键 decrease term为零并违反 relaxation假设；Theorem 3.3不覆盖 pure PRS。
3. **Shen–Pan FB notation。** Theorem 3.2 中一次出现的“`B` β-cocoercive”是上下文可判定的 typo；实际 smooth component 是 `C`。
4. **不同 residual。** `F`、`A+B`、`T-Id`、prox-gradient mapping、set-intersection mapping的 metric subregularity不是同一属性。
5. **不同 rate object。** objective Q-linear、distance-to-solution-set Q-linear、iterates R-linear、fixed-point residual linear不可只写“linear”后比较常数。
6. **普通 vs strong subregularity。** isolated fixed point/solution是实质额外假设。Aspelmeier Theorem 2.3(ii) 的 coercivity本身只需普通 residual subregularity；其 Theorem 1.6/2.7 的验证路线和 Newton entries 才含 relative isolatedness/strong subregularity。
7. **存在序列 vs 所有序列。** PPA-04 metric-regularity result主要是“存在可选序列”；不能改写成 set-valued resolvent所有选择均收敛。
8. **local vs global。** PRS-01 是 global contraction；PPA-05、FB-02、DR-02/03、AP-01是 local neighborhood statements。
9. **参数 convention。** Hölder metric `q`-subregularity通常 `0<q≤1`；Cibulka–Dontchev–Kruger strong `q`-subregularity用 `q≥1`。同字母不能直接相乘或排序。
10. **sufficient coupling ≠ trade-off theorem。** 形如 `1+ε-C/κ²<1` 或 Luke–Tam compatibility只证明给定 sufficient condition；若无 sharpness/necessity/counterexamples，不应称为完整 trade-off curve。

## 11. Pending queue（不进入事实图谱）

| 方向 | 当前状态 | 需要补核的 primary-source 信息 |
|---|---|---|
| Tseng FBF / extragradient 的更直接 theorem | `P`；FBF-01 已有统一框架 specialization | 寻找不经 Giselsson nonlinear metric框架、直接以 `(A+B)` subregularity给 sharp rate 的 theorem；核查无限维 assumptions。 |
| Standard alternating projections on two nonconvex sets | `P`；AP-01 已覆盖 cyclic quantitative template | Lewis–Luke–Malick 2009 的 exact theorem/rate与 strong regularity/superregularity assumptions；避免把 angle/transversality与 metric regularity同义化。 |
| ADMM metric subregularity of KKT map | `P`；DR-02 已有 residual-EB theorem | 找到同一 ADMM variant同时给 KKT-map subregularity和 exact primal-dual rate/constants的 primary theorem，并标 rank/step assumptions。 |
| Semismooth Newton under strong metric regularity | `P` | 与 NEW-02 相同 generalized equation及相同 well-definedness结论的 paired theorem；否则不得宣称 weaker regularity替代 stronger regularity。 |
| KL exponent general rates | `P` | 在同一 algorithm/descent assumptions下核验 `θ` convention 与 finite/linear/sublinear分区；不同文献 `θ` convention相反。 |

## 12. Primary-source bibliography

1. Leventhal (2009), [arXiv](https://arxiv.org/abs/0902.4200), [DOI](https://doi.org/10.1016/j.jmaa.2009.07.012).
2. Li & Mordukhovich (2012), [primary PDF](https://optimization-online.org/wp-content/uploads/2012/02/3340.pdf), [DOI](https://doi.org/10.1137/120864660).
3. Aragón Artacho, Dontchev & Geoffroy (2007), [publisher](https://www.esaim-proc.org/articles/proc/abs/2007/02/proc071701/proc071701.html).
4. Shen & Pan, [arXiv:1508.05156](https://arxiv.org/abs/1508.05156).
5. Luke, Thao & Tam (2018), [arXiv:1605.05725](https://arxiv.org/abs/1605.05725).
6. Luke & Tam (2025), [publisher/DOI](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863).
7. Drusvyatskiy & Lewis (2018), [arXiv:1602.06661](https://arxiv.org/abs/1602.06661).
8. Bello-Cruz, Li & Nghia, [arXiv:1806.06333](https://arxiv.org/abs/1806.06333).
9. Aspelmeier, Charitha & Luke (2016), [arXiv:1508.04468](https://arxiv.org/abs/1508.04468).
10. Davis & Yin (2017), [arXiv:1407.5210](https://arxiv.org/abs/1407.5210), [primary preprint PDF](https://ww3.math.ucla.edu/camreport/cam14-58.pdf).
11. Giselsson (2021), [arXiv:1908.07449](https://arxiv.org/abs/1908.07449).
12. Luke, Teboulle & Thao (2018), [arXiv:1704.08926](https://arxiv.org/abs/1704.08926).
13. Cibulka, Dontchev & Kruger (2018), [arXiv:1701.02078](https://arxiv.org/abs/1701.02078).
14. Li & Pong (2018), [arXiv:1602.02915](https://arxiv.org/abs/1602.02915).
