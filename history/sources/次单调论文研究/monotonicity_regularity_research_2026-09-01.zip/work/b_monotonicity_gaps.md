# Subagent B(MAX)：generalized-monotonicity gap example catalog

> 状态：2026-09-01 工作稿，仅做 gap examples；不作 seesaw synthesis。  
> 上游：`research/theory_atlas.md` 与 `work/example_entry_schema.md`。  
> 证据纪律：`VERIFIED_SOURCE` 表示已逐式核对可访问的 primary/author
> full text；`ALG` 表示以下显示公式的直接推导；`PENDING_VERIFICATION`
> 不得被 C 当作已发表结论。

## 0. 统一记号与本稿的检索边界

对图点差写

\[
a=x-y,\qquad b=u-v,\qquad d=a+\lambda b,\qquad r=a-\lambda b,
\]

并记录

\[
Q_{\lambda,\gamma}=\frac{\|r\|}{\|d\|^\gamma}.
\]

若存在不同图点使 \(d=0\) 而 \(r\ne0\)，则 resolvent 不是单值，所有有限
RL 常数立即失败。除另有说明，regularity 在 \((0,0)\) 检查，power convention
是 \(d(x,F^{-1}(0))\le \rho d(0,F(x))^q\)。本稿的 Spingarn-pointwise
计算使用 atlas 所列一端固定公式；Spingarn 原文全文尚未取得，因此涉及该历史
名称的结论均同时给出所实际验证的 liminf 公式，不把名称本身当证据。

本轮 primary-source locators：

- Luke--Tam, *Generalized Monotonicity and the Proximal Point Algorithm*,
  official full HTML, Definition 2, Proposition 6, Examples 1--2,
  equations (16)--(21):
  <https://pubsonline.informs.org/doi/10.1287/moor.2025.0863>.
- Bauschke--Wang--Yao (BWY), *Rectangularity and paramonotonicity of
  maximally monotone operators*, Examples 3.5, 5.3, 5.5 and equations
  (19), (38)--(40), (49)--(50): <https://arxiv.org/pdf/1201.4220>.
- Voisei, *General monotonicity*, Example 43, especially pp. 30--33 and the
  conclusion after (87): <https://arxiv.org/pdf/2411.04212>.
- Lei--He, *A hybrid projection-proximal point algorithm for solving
  nonmonotone variational inequality problems*, Definitions 2.2--2.3 and
  the \(x^2\) example immediately following them:
  <https://optimization-online.org/wp-content/uploads/2020/02/7602.pdf>.
- Poliquin--Rockafellar, *Prox-regular functions in variational analysis*,
  Theorem 3.2: <https://doi.org/10.1090/S0002-9947-96-01544-9>;
  BWY-independent localization cautions follow `work/a_relation_audit.md`.
- Spingarn, *Submonotone subdifferentials of Lipschitz functions*, official
  AMS metadata: <https://www.ams.org/tran/1981-264-01/S0002-9947-1981-0597868-8/>;
  the accessible later two-moving/“strictly submonotone” formula is
  Zajíček, Definition 2.1:
  <https://www.heldermann-verlag.de/jca/jca15/jca0651_b.pdf>.

---

## 1. Hypomonotonicity versus Luke--Tam / RL

### MGB-01 — Luke--Tam square-root branch: LT \(\wedge\neg\) hypomonotone

- **Purpose / cell.** LT-submonotone but not any finite local
  hypomonotone; also a sourced strictness witness for
  hypomonotone \(\Rightarrow\) LT. `VERIFIED_SOURCE + ALG`.
- **Object.** \(H=\mathbb R\),
  \(F(x)=-\sqrt x\) for \(x\ge0\), restricted to
  \(U=[0,1/16]\), \(W=\mathbb R\).  For a catalog mapping one may set
  \(A=F|_U\) and \(A(x)=\varnothing\) off \(U\). It is single-valued on
  its domain, nonmaximal as an ordinary graph; LT-maximality is not asserted.
- **Graph / inverse / zeros.** With \(t=\sqrt x\in[0,1/4]\),
  \(\operatorname{gph}A=\{(t^2,-t):0\le t\le1/4\}\),
  \(A^{-1}(y)=\{y^2\}\) for \(y\in[-1/4,0]\), and
  \(\operatorname{zer}A=\{0\}\).
- **Exact graph calculation.** For \(u=t^2,v=s^2\),
  \[
  a=(t-s)(t+s),\quad b=-(t-s),\quad
  \langle a,b\rangle=-(t-s)^2(t+s)
  =-\frac{a^2}{t+s}.
  \]
  Hence the hypomonotonicity quotient \(-\langle a,b\rangle/a^2
  =1/(t+s)\) is unbounded as \(t,s\downarrow0\). This is Luke--Tam
  equation (19), and proves failure for every finite violation.
- **Resolvent and reflected resolvent (\(\lambda=1\)).** The Minty input is
  \(p=t^2-t\in[-3/16,0]\), strictly decreasing in \(t\). Thus
  \[
  J_A(p)=\left(\frac{1-\sqrt{1+4p}}2\right)^2,qquad
  R_A(p)=t^2+t.
  \]
  For two parameters,
  \[
  \frac{|R_Ap-R_Aq|}{|p-q|}=\frac{1+t+s}{1-t-s}\le3.
  \]
  The supremum is \(3\), so global-on-this-restricted-domain RL has sharp
  \((\gamma,L)=(1,3)\), equivalently sharp LT violation
  \(\tau=(3^2-1)/4=2\). This recovers and sharpens the constant in the
  official Example 2, equations (20)--(21).
- **Spingarn formulas.** The two-moving quotient is
  \(\langle a,b\rangle/|a|=-|t-s|\to0\), hence the displayed
  strict-submonotonicity formula holds at \(0\); the one-fixed-end formula
  also tends to \(0\). Thus the non-hypomonotonicity is quadratic-scale,
  not first-order Spingarn failure.
- **Regularity seed.** Exactly
  \[
  d(x,\{0\})=x=|A(x)|^2.
  \]
  Hence \(q\)-SMSR holds locally iff \(q\le2\); at \(q=2\) the sharp
  modulus is \(1\), for \(q<2\) the exact local modulus is \(0\), and
  \(q>2\) fails. Ordinary MR/SMR around \((0,0)\) fail because positive
  target values near zero have empty inverse. SMSR/isolated calmness hold.
- **Locator.** Luke--Tam official Example 2, lines/formulas (19)--(21).

### MGB-02 — \(-x^2\) on the critical half interval: hypo \(\wedge\neg\) LT, but RL\(_{1/2}\)

- **Purpose / cell.** Finite hypomonotonicity does not imply any finite
  LT constant once the resolvent-collapse threshold is reached; nevertheless
  a sharp Hölder reflected-resolvent survives. `VERIFIED_SOURCE + ALG`.
- **Object.** \(A:[0,1/2]\to\mathbb R\), \(A(x)=-x^2\), empty off the
  interval. Single-valued, nonmaximal.
- **Graph / inverse / zeros.** \(A^{-1}(y)=\{\sqrt{-y}\}\) for
  \(y\in[-1/4,0]\); \(\operatorname{zer}A=\{0\}\).
- **Exact graph calculation.** For \(s=x+y\),
  \[
  b=-sa,\qquad \langle a,b\rangle=-s a^2\ge-a^2.
  \]
  Thus the sharp hypomonotonicity constant is \(1\).
- **Failure of LT / Lipschitz RL.** For \(\lambda=1\),
  \[
  d=(1-s)a,\qquad r=(1+s)a,qquad
  \frac{|r|}{|d|}=\frac{1+s}{1-s}\to\infty
  \]
  along distinct \(x,y\to1/2\). This is the endpoint case of
  Luke--Tam Example 1, equations (16)--(18); no finite \(\tau\) exists.
- **Sharp Hölder RL.** Since \(p=x-x^2\in[0,1/4]\),
  \[
  J_A(p)=\frac{1-\sqrt{1-4p}}2,\qquad R_A(p)=2J_A(p)-p.
  \]
  Directly,
  \[
  Q_{1,1/2}^2=|x-y|\frac{(1+s)^2}{1-s}\le4.
  \]
  The supremum \(4\) is approached as \(x,y\to1/2\), so
  \(\gamma_{\max}=1/2\) and sharp \(L=2\). All \(0<\gamma<1/2\) also
  hold on this bounded Minty domain after changing \(L\); every
  \(\gamma>1/2\) fails at \(p=1/4\).
- **Spingarn formulas.** Continuity gives the two-moving quotient
  \(-s|x-y|\to0\); hence the displayed strict Spingarn condition holds at
  every point, including \(1/2\), despite LT failure there.
- **Regularity seed.** \(d(x,\{0\})=x=|A(x)|^{1/2}\). Thus sharp maximum
  residual exponent is \(q=1/2\), with modulus \(1\); ordinary MSR/SMSR
  fail. At \((1/2,-1/4)\), the derivative is \(-1\), so the one-sided
  inverse branch is Lipschitz, but two-sided MR fails for targets below
  \(-1/4\) because of the restricted range.

### MGB-03 — negative scalar line: hypo \(\wedge\) LT with sharp constants

- **Purpose / cell.** Positive control point for MGB-01/02.
- **Object.** \(A(x)=-kx\) on \(\mathbb R\), \(0<k<1/\lambda\).
  It is maximally \(k\)-hypomonotone because \(A+kI=0\) is maximally
  monotone; it is not monotone.
- **Formulas.** \(A^{-1}(y)=-y/k\), \(\operatorname{zer}A=\{0\}\),
  \[
  \langle a,b\rangle=-k a^2,\quad
  J_{\lambda A}p=\frac{p}{1-\lambda k},\quad
  R_{\lambda A}p=\frac{1+\lambda k}{1-\lambda k}p.
  \]
  Therefore the sharp hypomonotone modulus is \(k\), sharp RL\(_1\)
  constant is \(L=(1+\lambda k)/(1-\lambda k)\), and sharp LT parameter
  for \(\lambda A\) is \(\tau=\lambda k/(1-\lambda k)^2\).
  No global RL\(_\gamma\), \(\gamma<1\), holds because the nonzero linear
  reflected map has unbounded increments.
- **Regularity seed.** All MR/MSR/SMR/SMSR properties hold at zero with
  exact modulus \(1/k\); the residual law is \(|x|=k^{-1}|A(x)|\).

### MGB-04 — negative cubic on \(\mathbb R\): \(\neg\)global-hypo \(\wedge\neg\)RL

- **Purpose / cell.** Natural smooth object in the neither cell; separates
  local prox-regular/hypomonotone behavior from global classes.
- **Object.** \(A(x)=-x^3=\partial(-x^4/4)\), full-domain, single-valued.
  \(A^{-1}(y)=\{-\sqrt[3]y\}\), \(\operatorname{zer}A=\{0\}\).
- **Graph side.** \(b=-(x^2+xy+y^2)a\), so
  \[
  \langle a,b\rangle=-(x^2+xy+y^2)a^2.
  \]
  The coefficient is unbounded globally, hence no finite global
  hypomonotonicity modulus. On \([-M,M]\), it is \(3M^2\)-hypomonotone
  (sharp local derivative bound).
- **RL failure.** For every \(\lambda>0\), \(p=x-\lambda x^3\) is not
  injective on \(\mathbb R\); hence distinct graph points have \(d=0\),
  so all global RL exponents fail. Local RL\(_1\) holds only on intervals
  avoiding the turning points \(x=\pm(3\lambda)^{-1/2}\).
- **Regularity seed.** \(|A(x)|=|x|^3\). The sharp maximum power-SMSR
  exponent at zero is \(q=1/3\) with modulus \(1\); ordinary MSR/SMSR
  and MR/SMR fail. The generating smooth function is locally prox-regular
  at every fixed point but has no global uniform prox-regular threshold.

---

## 2. Spingarn pointwise / strict formulas versus LT

### MGB-05 — an isolated pole branch: LT \(\wedge\neg\) Spingarn-pointwise

- **Purpose / cell.** Explicit converse gap showing that an all-pairs LT
  estimate in Minty coordinates need not control the one-fixed-end
  first-order Spingarn quotient when outputs escape to infinity. `ALG`.
- **Object.** Fix \(0<\varepsilon<1\). Define
  \[
  A(0)=0,\qquad A(x)=-1/x\quad(0<x\le\varepsilon),
  \]
  and empty otherwise. Its graph is closed, single-valued on its domain,
  and nonmaximal. The inverse is \(A^{-1}(0)=\{0\}\),
  \(A^{-1}(y)=\{-1/y\}\) for \(y\le-1/\varepsilon\); zero set \(\{0\}\).
- **LT/RL calculation (\(\lambda=1\)).** For two positive points,
  \[
  \frac{|r|}{|d|}=\frac{|1-1/(xy)|}{1+1/(xy)}<1.
  \]
  Against the isolated graph point \((0,0)\),
  \[
  \frac{|x+1/x|}{|x-1/x|}=\frac{1+x^2}{1-x^2}
  \le L_\varepsilon:=\frac{1+\varepsilon^2}{1-\varepsilon^2}.
  \]
  Thus sharp RL\(_1\) constant is \(L_\varepsilon\), hence LT holds with
  \(\tau=(L_\varepsilon^2-1)/4\).
- **Resolvent.** The Minty domain is
  \(D=(-\infty,\varepsilon-1/\varepsilon]\cup\{0\}\),
  \[
  J_A(p)=\frac{p+\sqrt{p^2+4}}2\quad(p<0\text{ in the branch}),
  \qquad J_A(0)=0,
  \]
  and \(R=2J-I\).
- **Spingarn failure at \(0\).** For \(x\downarrow0\), the atlas
  pointwise quotient is
  \[
  \frac{\langle A(0)-A(x),0-x\rangle}{|x|}
  =-\frac1x\to-\infty.
  \]
  Hence even pointwise submonotonicity fails; consequently the
  two-moving strict formula fails as well.
- **Regularity seed.** Off zero the residual is \(1/x\to\infty\); for
  every \(q>0\), \(x\le\rho |A(x)|^q\) holds sufficiently near zero with
  exact local modulus \(0\). Thus SMSR/isolated calmness hold in a
  degenerate-strong sense, while MR/SMR fail because nearby nonzero target
  values have empty inverse. This entry must carry the `domain-vacuity`
  warning into C.

### MGB-06 — rational/irrational sign staircase: pointwise \(\wedge\neg\) strict, still LT

- **Purpose / cell.** Separates Spingarn's one-fixed-end and two-moving
  formulas, while showing LT does not repair a lack of graph continuity.
  `ALG`; deliberately nonclosed/nonmaximal.
- **Object.** Fix \(0<\delta<1/2\), and set \(A(0)=0\). For
  \(0<|x|<\delta\), let
  \[
  A(x)=\operatorname{sgn}(x)c(x),\qquad
  c(x)=\begin{cases}1,&x\in\mathbb Q,\\2,&x\notin\mathbb Q.\end{cases}
  \]
  The zero set is \(\{0\}\); inverse fibers of \(\pm1,\pm2\) are the
  corresponding rational/irrational half-intervals.
- **Spingarn formulas at zero.** For the fixed endpoint,
  \(\langle A(x)-A(0),x\rangle/|x|=c(x)\ge1\), so the displayed
  pointwise condition holds. Choose \(x_n>y_n>0\to0\) with \(x_n\)
  rational and \(y_n\) irrational. Then
  \[
  \frac{(A(x_n)-A(y_n))(x_n-y_n)}{|x_n-y_n|}=-1,
  \]
  so the strict/two-moving condition fails.
- **LT/RL.** Minty images lie in five separated clusters. Pairs with the
  same output have ratio \(1\). For distinct outputs, \(|b|\ge1\) and
  \(|a|<2\delta\), hence
  \[
  Q_{1,1}\le\frac{|b|+|a|}{|b|-|a|}
  \le\frac{1+2\delta}{1-2\delta}.
  \]
  Thus a finite LT/RL\(_1\) constant exists. The displayed bound is a
  safe class bound; sharpness is left for C.
- **Regularity seed.** \(|A(x)|\ge1\) off zero, so all power-SMSR
  inequalities hold locally with exact modulus \(0\). MR/SMR fail since
  the range has no neighborhood of zero. The graph is not locally closed,
  which must be retained in any coderivative discussion.

### MGB-07 — direct-product splice: \(\neg\)strict Spingarn \(\wedge\neg\) LT

- **Purpose / cell.** Fills the neither cell without pretending that one
  failure mechanism must cause the other. `ALG`.
- **Object.** On \(\mathbb R^2\), take the direct product
  \[
  A=A_1\times A_2,
  \]
  where \(A_1(x)=-x^2\) on \([0,1/2]\) is MGB-02 and \(A_2\) is the
  rational/irrational staircase MGB-06 on \((-\delta,\delta)\). Base the
  Spingarn/LT comparison at \((1/2,0)\). The map is single-valued on its
  product domain, nonclosed because of \(A_2\), and nonmaximal.
- **Failure certificates.** Holding the second coordinate at zero and
  using \(x_1,y_1\to1/2\) reproduces MGB-02's unbounded
  \(Q_{1,1}\), so LT fails. Holding the first coordinate fixed at
  \(1/2\) and taking rational/irrational second-coordinate pairs
  reproduces the strict quotient \(-1\), so strict Spingarn fails.
- **Graph / inverse / resolvent.** The graph and inverse are Cartesian
  products. Wherever component resolvents are single-valued,
  \(J_A=(J_{A_1},J_{A_2})\) and \(R_A=(R_{A_1},R_{A_2})\); the first
  component already precludes Lipschitz RL. The zero set is \(\{(0,0)\}\).
- **Regularity seed at zero.** Along \((x_1,0)\), residual is \(x_1^2\),
  so no power-SMSR exponent above \(1/2\) is possible. The staircase
  residual is at least one off its zero, so it adds no smaller asymptotic
  exponent. Thus \(q=1/2\) is the candidate sharp product exponent;
  C should verify the precise product-norm modulus and graph-vacuity flag.

MGB-02 alone supplies strict-Spingarn \(\wedge\neg\)LT, MGB-01 supplies
strict-Spingarn \(\wedge\)LT, and MGB-06 supplies
\(\neg\)strict-Spingarn \(\wedge\)LT. Hence MGB-01/02/06/07 fill all four
logical cells for the displayed two-moving formula versus LT.

---

## 3. Paramonotone versus rectangular / 3-star

### MGB-08 — BWY skew plus ball normal: rectangular \(\wedge\neg\) paramonotone

- **Purpose / source.** The finite-dimensional sourced independence cell.
  `VERIFIED_SOURCE`: BWY Example 3.5, equation (19).
- **Object.** In \(H=\mathbb R^2\), let
  \[
  S=\begin{pmatrix}0&1\\-1&0\end{pmatrix},\qquad
  C=\{x:\|x\|\le1\},\qquad A=S+N_C.
  \]
  It is set-valued on the sphere, maximally monotone, and rectangular,
  but not paramonotone.
- **Graph / zeros.** For \(\|x\|<1\), \(Ax=\{Sx\}\); for \(\|x\|=1\),
  \(Ax=Sx+\mathbb R_+x\); outside \(C\), it is empty. The zero set is
  \(\{0\}\). Nonparamonotonicity is visible already from any nonzero
  interior \(x\): \(\langle x,Sx\rangle=0\), but the cross graph point
  \((x,0)\) is absent. BWY obtains rectangularity from maximality plus
  bounded domain.
- **Inverse.** It is in fact single-valued. If \(\|y\|<1\), then
  \(A^{-1}y=-Sy\). If \(\|y\|\ge1\), set
  \(t=\sqrt{\|y\|^2-1}\); then
  \[
  A^{-1}y=\frac{tI-S}{\|y\|^2}y\in S^1.
  \]
- **Resolvent.** Put \(p\in\mathbb R^2\). If
  \(\|p\|\le\sqrt{1+\lambda^2}\),
  \[
  J_{\lambda A}p=(I+\lambda S)^{-1}p
  =\frac{I-\lambda S}{1+\lambda^2}p.
  \]
  Otherwise set \(\alpha=\sqrt{\|p\|^2-\lambda^2}>1\); then
  \[
  J_{\lambda A}p=\frac{\alpha I-\lambda S}{\alpha^2+\lambda^2}p,
  \qquad \|J_{\lambda A}p\|=1.
  \]
  In all cases \(R=2J-I\).
- **Graph/RL seed.** Monotonicity gives \(\langle a,b\rangle\ge0\) and
  global RL\(_1\) with \(L=1\). No global \(\gamma<1\) RL can hold on
  the unbounded Minty domain: on an exterior ray
  \(R(p)=2J(p)-p=-p+O(1)\).
- **Regularity seed.** Near \((0,0)\), \(A=S\), an invertible isometry.
  Hence MR/MSR/SMR/SMSR all hold locally with exact modulus \(1\).

### MGB-09 — BWY diagonal plus block skew: paramonotone \(\wedge\neg\) rectangular

- **Purpose / source.** Infinite-dimensional sourced converse cell.
  `VERIFIED_SOURCE`: BWY Example 5.5, equations (49)--(50).
- **Object.** On \(H=\ell^2\), define
  \[
  (Dx)_n=x_n/n,\qquad
  B(x_1,x_2,x_3,x_4,\ldots)=(-x_2,x_1,-x_4,x_3,\ldots),
  \qquad A=D+B.
  \]
  It is continuous linear, full-domain, maximally monotone, strictly
  monotone and paramonotone, but not rectangular.
- **Graph side.** Since \(B^*=-B\),
  \[
  \langle x,Ax\rangle=\sum_{n\ge1}\frac{x_n^2}{n}>0\quad(x\ne0),
  \]
  but the strong-monotonicity modulus is zero. BWY proves failure of
  rectangularity from nonclosed \(\operatorname{ran}D\).
- **Inverse / zeros / exact stability.** On block \(k\), with
  \(a_k=(2k-1)^{-1}, b_k=(2k)^{-1}\),
  \[
  A_k=\begin{pmatrix}a_k&-1\\1&b_k\end{pmatrix},\qquad
  A_k^{-1}=\frac1{1+a_kb_k}
  \begin{pmatrix}b_k&1\\-1&a_k\end{pmatrix}.
  \]
  Because \(a_k-b_k=a_kb_k\), the singular values of \(A_k\) are
  \(1\) and \(1+a_kb_k\). Hence \(A\) is boundedly invertible,
  \(\|A^{-1}\|=1\), and \(\operatorname{zer}A=\{0\}\).
- **Resolvent/RL.** \(J_{\lambda A}\) and \(R_{\lambda A}\) are the
  block-diagonal matrices \((I+\lambda A_k)^{-1}\) and
  \((I-\lambda A_k)(I+\lambda A_k)^{-1}\). Monotonicity gives global
  RL\(_1\), \(L=1\); the norm is exactly \(1\) by the high-block limit
  \(A_k\to\begin{psmallmatrix}0&-1\\1&0\end{psmallmatrix}\).
- **Regularity seed.** Despite zero strong-monotonicity modulus, all four
  metric (sub)regularity properties hold globally at zero with exact
  modulus \(\|A^{-1}\|=1\). This is a high-priority C recomputation point.

### MGB-10 — Volterra integration: \(\neg\)paramonotone \(\wedge\neg\)rectangular

- **Purpose / source.** Infinite-dimensional sourced neither cell.
  `VERIFIED_SOURCE`: BWY Example 5.3, equations (38)--(40).
- **Object.** \(H=L^2[0,1]\),
  \[
  (Vx)(t)=\int_0^t x(s)\,ds.
  \]
  It is continuous, injective, linear and maximally monotone, but neither
  paramonotone nor rectangular.
- **Exact graph identity / failure proof.** With \(e\equiv1\),
  \[
  \langle x,Vx\rangle=\frac12\left(\int_0^1x\right)^2.
  \]
  Choose \(x(t)=t-1/2\ne0\). Then the inner product is zero while
  \(Vx\ne0\), violating the linear paramonotonicity criterion; BWY
  Proposition 4.5 then rules out rectangularity.
- **Inverse / zeros / resolvent.** \(\operatorname{zer}V=\{0\}\), and
  \(V^{-1}y=y'\) on the range
  \(\{y\in H^1:y(0)=0\}\). Solving the Volterra equation gives
  \[
  (J_{\lambda V}p)(t)=p(t)-\lambda\int_0^t
  e^{-\lambda(t-s)}p(s)\,ds,
  \qquad R_{\lambda V}=2J_{\lambda V}-I.
  \]
- **RL seed.** Maximal monotonicity gives global RL\(_1\), \(L=1\).
  Every global \(\gamma<1\) fails by nonzero linear homogeneity.
- **Regularity seed.** \(\operatorname{ran}V\) is dense and nonclosed;
  high-frequency unit vectors have \(\|Vx_n\|\to0\). Thus MR, MSR,
  SMR and SMSR all fail at zero. More strongly, fixing a small amplitude
  and using that singular sequence disproves every power/gauge
  subregularity whose gauge tends to zero.

### MGB-11 — adjoint Volterra: a second, orientation-reversed neither object

- **Purpose / source.** Avoid treating the BWY neither cell as a single
  accidental orientation. `VERIFIED_SOURCE`: the second assertion of BWY
  Example 5.3.
- **Object.** On \(L^2[0,1]\),
  \[
  (V^*x)(t)=\int_t^1x(s)\,ds.
  \]
  BWY proves that \(V^*\) is continuous, injective, maximally monotone,
  neither paramonotone nor rectangular.
- **Formulas.** Again
  \(\langle x,V^*x\rangle=\frac12(\int_0^1x)^2\); the same
  \(x(t)=t-1/2\) witnesses nonparamonotonicity. Its zero is \(0\), and
  \((V^*)^{-1}y=-y'\) on \(\{y\in H^1:y(1)=0\}\). Moreover
  \[
  (J_{\lambda V^*}p)(t)=p(t)-\lambda\int_t^1
  e^{-\lambda(s-t)}p(s)\,ds.
  \]
  Global RL\(_1\) holds with \(L=1\), while every global
  \(\gamma<1\) fails by homogeneity. Reflection of the singular-sequence
  argument in MGB-10 shows failure of every ordinary or power/gauge MSR
  at zero.

### MGB-12 — diagonal projection: paramonotone \(\wedge\) rectangular

- **Purpose / cell.** Finite-dimensional both-cell control with a
  nonisolated zero set. `ALG`; also a convex-gradient/subdifferential
  instance covered by BWY Facts 1.3--1.4.
- **Object.** \(A:\mathbb R^2\to\mathbb R^2\),
  \(A(x_1,x_2)=(0,x_2)=\operatorname{diag}(0,1)x\). It is continuous
  linear, maximally monotone, \(1\)-cocoercive, paramonotone and
  rectangular, but not strongly monotone.
- **Exact formulas.** \(A^{-1}(y_1,y_2)=\varnothing\) if \(y_1\ne0\),
  and \(A^{-1}(0,y_2)=\mathbb R\times\{y_2\}\). Thus
  \(\operatorname{zer}A=\mathbb R\times\{0\}\), and
  \[
  J_{\lambda A}=\operatorname{diag}\left(1,\frac1{1+\lambda}\right),
  \quad
  R_{\lambda A}=\operatorname{diag}\left(1,
  \frac{1-\lambda}{1+\lambda}\right).
  \]
  The graph identity is \(\langle a,b\rangle=a_2^2=\|b\|^2\).
  Sharp global RL\(_1\) constant is \(1\); no global
  \(\gamma<1\) holds because of the identity action on the kernel.
- **Regularity seed.** Exactly
  \(d(x,\operatorname{zer}A)=|x_2|=\|Ax\|\), so MSR has modulus \(1\).
  SMSR and SMR fail because the zero is nonisolated; MR fails because the
  range is a proper subspace.

---

## 4. The \(n\)-cyclic hierarchy: explicit rotations

For \(\theta\in[-\pi,\pi]\), write

\[
Q_\theta=\begin{pmatrix}\cos\theta&-\sin\theta\\
\sin\theta&\cos\theta\end{pmatrix}.
\]

Voisei Example 43 proves that \(Q_\theta\) is \(n\)-cyclically monotone
iff \(|\theta|\le\pi/n\). Since every such full-domain continuous linear
operator is already maximally monotone, any \(n\)-cyclic extension would
also be a monotone extension; hence it is maximal \(n\)-cyclic (`ALG` from
the sourced threshold plus ordinary maximality). For all \(\theta\),

\[
Q_\theta^{-1}=Q_{-\theta},\quad \operatorname{zer}Q_\theta=\{0\},\quad
\langle a,Q_\theta a\rangle=\cos\theta\|a\|^2.
\]

With \(\Delta=1+2\lambda\cos\theta+\lambda^2\),

\[
J_{\lambda Q_\theta}
=\frac{(1+\lambda\cos\theta)I-\lambda\sin\theta K}{\Delta},
\qquad
\|R_{\lambda Q_\theta}\|
=\sqrt{\frac{1-2\lambda\cos\theta+\lambda^2}
{1+2\lambda\cos\theta+\lambda^2}}, \tag{Rot-Cayley}
\]

where \(K=Q_{\pi/2}\). Each \(Q_\theta\) is an isometry, so all four
metric (sub)regularity properties at zero have exact modulus \(1\).

### MGB-13 — quarter-turn \(Q_{\pi/2}\): maximal 2-cyclic, not 3-cyclic

- **Gap.** \(|\theta|=\pi/2\) meets the \(n=2\) threshold and violates
  the \(n=3\) threshold. Thus it is maximally monotone but not 3-cyclic.
- **Other graph classes.** The inner product is identically zero. Since
  \(Q_{\pi/2}x\ne0\) for \(x\ne0\), it is not paramonotone. It is not
  rectangular either (BWY Proposition 5.1: a continuous linear monotone
  operator is rectangular iff it is positively cocoercive; a nonzero
  skew map is not).
- **RL.** `(Rot-Cayley)` gives sharp global \(L=1\) for every \(\lambda\),
  even though \(J\) is a strict contraction
  \(\|J\|=(1+\lambda^2)^{-1/2}\). No global \(\gamma<1\) holds.

### MGB-14 — \(Q_{\pi/3}\): maximal 3-cyclic, not 4-cyclic

- **Gap.** \(\pi/3\le\pi/3\) but \(\pi/3>\pi/4\). It is
  \(1/2\)-strongly monotone, hence paramonotone and rectangular, yet is
  not 4-cyclic.
- **RL/regularity.** `(Rot-Cayley)` yields the sharp contraction
  \[
  L=\sqrt{\frac{1-\lambda+\lambda^2}{1+\lambda+\lambda^2}}<1.
  \]
  All linear regularity moduli remain exactly \(1\), since the operator
  itself is an isometry. This distinguishes graph coercivity \(1/2\)
  from inverse conditioning \(1\).

### MGB-15 — \(Q_{\pi/4}\): maximal 4-cyclic, not 5-cyclic

- **Gap.** \(\pi/4\le\pi/4\) but \(\pi/4>\pi/5\). The strong
  monotonicity modulus is \(1/\sqrt2\).
- **RL.** Sharp
  \[
  L=\sqrt{\frac{1-\sqrt2\lambda+\lambda^2}
  {1+\sqrt2\lambda+\lambda^2}}<1.
  \]
  Inverse, zero and all regularity moduli are as in the common rotation
  formulas. This is a genuinely different hierarchy level, not a
  reparameterization of MGB-14.

### MGB-16 — identity: cyclic at every order

- **Purpose / cell.** Top control for the rotation hierarchy.
- **Object/formulas.** \(A=I=\partial(\|x\|^2/2)\) on any nonzero real
  Hilbert space. It is maximally cyclically monotone, strongly monotone,
  cocoercive, paramonotone and rectangular. Its inverse is itself, zero is
  \(0\),
  \[
  J_{\lambda A}=\frac1{1+\lambda}I,\qquad
  R_{\lambda A}=\frac{1-\lambda}{1+\lambda}I.
  \]
  Sharp RL\(_1\) constant is \(|1-\lambda|/(1+\lambda)\) (zero when
  \(\lambda=1\)); all metric regularity moduli equal \(1\).

---

## 5. VI pseudomonotone / quasimonotone gaps

Here the VI definitions are exactly those in Lei--He Definitions 2.2--2.3;
they are not Brézis pseudomonotonicity.

### MGB-17 — \(2+\sin x\): VI-pseudomonotone \(\wedge\neg\) monotone

- **Object / gap.** \(F:\mathbb R\to\mathbb R\), \(F(x)=2+\sin x>0\).
  If \(F(x)(y-x)\ge0\), then \(y\ge x\), so
  \(F(y)(y-x)\ge0\); hence it is VI-pseudomonotone (and quasi).
  It is not monotone on intervals where \(\cos x<0\).
- **Inverse / zeros.** There are no zeros. For \(y\in[1,3]\), put
  \(\alpha=\arcsin(y-2)\in[-\pi/2,\pi/2]\); then
  \[
  F^{-1}(y)=\{\alpha+2k\pi,\ \pi-\alpha+2k\pi:k\in\mathbb Z\},
  \]
  with the coincident endpoint solutions counted once; off \([1,3]\)
  the inverse is empty.
- **Graph side.** By the mean-value theorem,
  \[
  \langle a,b\rangle=(x-y)(\sin x-\sin y)
  =\cos\xi\,a^2\ge-a^2,
  \]
  with sharp global hypomonotonicity constant \(1\).
- **Resolvent/RL.** For \(0<\lambda<1\),
  \(g(x)=x+\lambda(2+\sin x)\) is a bijection and
  \(J_{\lambda F}=g^{-1}\). Differentiating the reflected branch gives
  \[
  \left|\frac{dR}{dp}\right|
  =\left|\frac{1-\lambda\cos x}{1+\lambda\cos x}\right|
  \le\frac{1+\lambda}{1-\lambda},
  \]
  and the bound is sharp. At \(\lambda=1\), near
  \(x=(2m+1)\pi\), Minty increments are cubic while reflected increments
  are linear, so the sharp local exponent is \(\gamma=1/3\), not \(1\).
  For \(\lambda>1\), \(g\) is not injective and RL fails.
- **Regularity seed.** The zero set is empty, so zero-error-bound labels
  are inapplicable. At \((\pi/2,3)\),
  \(3-F(x)\sim (x-\pi/2)^2/2\): maximum local strong-subregularity
  exponent for target \(3\) is \(q=1/2\), with asymptotic modulus
  \(\sqrt2\), while MR fails. At every point with \(\cos x\ne0\), SMR
  holds with exact infinitesimal modulus \(1/|\cos x|\).

### MGB-18 — square on \([-1,1]\): quasimonotone \(\wedge\neg\) pseudomonotone

- **Object / source.** \(F(x)=x^2\) on \(C=[-1,1]\). Lei--He state this
  example immediately after Definitions 2.2--2.3. If the quasi antecedent
  is strict, then \(x\ne0\) and \(y>x\), so the conclusion holds. For
  pseudomonotonicity take \(x=0,y=-1\): the antecedent equals zero but the
  conclusion is \(-1<0\).
- **Inverse / zeros.** \(F^{-1}(y)=\{\pm\sqrt y\}\) for \(0<y\le1\),
  \(F^{-1}(0)=\{0\}\), and it is empty otherwise; the zero set is
  \(\{0\}\).
- **Graph side.** \(b=(x+y)a\), hence
  \[
  \langle a,b\rangle=(x+y)a^2\ge-2a^2;
  \]
  the sharp global hypomonotone constant is \(2\).
- **Resolvent/RL.** If \(0<\lambda<1/2\), then
  \[
  J_{\lambda F}(p)=\frac{-1+\sqrt{1+4\lambda p}}{2\lambda},
  \quad
  L_{\rm RL,1}=\frac{1+2\lambda}{1-2\lambda}.
  \]
  At \(\lambda\ge1/2\), the Minty map loses a uniform lower slope
  (and for \(\lambda>1/2\) loses injectivity), so Lipschitz RL fails;
  the critical endpoint has a square-root Hölder branch.
- **Regularity seed.** \(\operatorname{zer}F=\{0\}\) and
  \(d(x,S)=|x|=|F(x)|^{1/2}\). Thus the sharp maximum power-SMSR
  exponent is \(q=1/2\), modulus \(1\); ordinary MSR/SMSR and MR/SMR
  fail at zero.

### MGB-19 — negative identity: neither quasi nor pseudo

- **Object / gap.** \(F(x)=-x\) on \([-1,1]\). With
  \(x=-1/2,y=1/2\), the quasi antecedent is positive and the conclusion
  negative. Hence neither VI-quasimonotonicity nor pseudomonotonicity holds.
- **Inverse / zeros.** \(F^{-1}(y)=\{-y\}\) for \(|y|\le1\), empty
  otherwise, and \(\operatorname{zer}F=\{0\}\).
- **Graph/RL.** \(\langle a,b\rangle=-a^2\), so the sharp
  hypomonotone constant is \(1\). For \(\lambda\ne1\),
  \[
  J_{\lambda F}p=\frac p{1-\lambda},\qquad
  R_{\lambda F}p=\frac{1+\lambda}{1-\lambda}p
  \]
  on the restricted Minty range, giving sharp
  \(L=(1+\lambda)/|1-\lambda|\). At \(\lambda=1\), the Minty map
  collapses and every RL condition fails.
- **Regularity seed.** The zero is isolated and
  \(|x|=|F(x)|\); all local MR/MSR/SMR/SMSR moduli at zero equal \(1\).

---

## 6. Prox-regularity versus localized/full hypomonotonicity

### MGB-20 — the unit circle: prox-regular set, full normal graph not hypomonotone

- **Purpose / cell.** Shows why normal-norm truncation in the
  prox-regularity characterization is essential. `ALG` based on the
  standard smooth-manifold normal formula; the same witness is recorded
  in `work/a_relation_audit.md`.
- **Object.** \(C=S^1\subset\mathbb R^2\), a prox-regular set, and its
  full limiting/proximal normal mapping
  \[
  N_C(x)=\operatorname{span}\{x\}\quad(x\in S^1),
  \qquad N_C(x)=\varnothing\quad(x\notin S^1).
  \]
  It is set-valued, nonmonotone and not maximally monotone.
- **Exact graph side.** For \(u=\alpha x\), \(v=\beta y\),
  \[
  \langle x-y,u-v\rangle
  =(\alpha+\beta)(1-\langle x,y\rangle)
  =\frac{\alpha+\beta}{2}\|x-y\|^2.
  \]
  Letting \(\alpha\to-\infty\) proves that no finite full-graph local
  hypomonotonicity modulus exists. If \(|\alpha|,|\beta|\le M\), the
  localized/truncated graph is \(M\)-hypomonotone, exactly the missing
  restriction.
- **Inverse / zeros / resolvent.** \(\operatorname{zer}N_C=C\).
  Moreover \(N_C^{-1}(0)=C\) and
  \(N_C^{-1}(y)=\{\pm y/\|y\|\}\) for \(y\ne0\).
  For \(p\ne0\), both \(x=p/\|p\|\) and \(x=-p/\|p\|\) satisfy
  \(p\in x+\lambda N_C(x)\); for \(p=0\), every \(x\in C\) does.
  Therefore the full \(J_{\lambda N_C}\) is multivalued and every full
  RL condition fails. On the attentive small-normal branch near
  \((\bar x,0)\), the local resolvent is the single-valued radial
  projection \(p\mapsto p/\|p\|\).
- **Regularity seed.** Fixed-target MSR is trivial with modulus \(0\):
  every domain point is already a zero and off-domain residual is
  \(+\infty\). SMSR fails because the zero is nonisolated. MR fails at
  \((\bar x,0)\): take \(y=t z\) with \(z\to\bar x\) but nonparallel;
  \(d(\bar x,N_C^{-1}(y))\asymp\|z-\bar x\|\), whereas
  \(d(y,N_C(\bar x))\asymp t\|z-\bar x\|\), whose ratio is \(1/t\).

### MGB-21 — \(-|x|\) affine-shifted: attentive hypo branch, not prox-regular

- **Purpose / cell.** Shows that localized hypomonotonicity without the
  proximal-subgradient hypothesis does not characterize prox-regularity.
  `ALG`; source theorem boundary is Poliquin--Rockafellar Theorem 3.2.
- **Object.** Let \(g(x)=-|x|-x\), and take the limiting subdifferential
  \(A=\partial g\):
  \[
  A(x)=\begin{cases}\{0\},&x<0,\\\{0,-2\},&x=0,\\\{-2\},&x>0.
  \end{cases}
  \]
  This is the affine-shifted version of \(f=-|x|\) at
  \((\bar x,\bar v)=(0,1)\).
- **Attentive branch versus full graph.** Restricting output to a small
  neighborhood of \(0\) leaves the constant branch \(A(x)=0\) for
  \(x\le0\), which is monotone. Nevertheless \(g\) is not prox-regular
  at \((0,0)\): the support inequality at \(x=0,v=0,x'=t>0\) would require
  \(-2t\ge-r t^2/2\), impossible for small \(t\). Equivalently, the
  reference vector is not proximal.
- **Full graph degeneration.** Pair \((-\epsilon,0)\) with
  \((\epsilon,-2)\):
  \[
  \langle a,b\rangle=-4\epsilon,qquad \|a\|^2=4\epsilon^2,
  \]
  so no finite full-graph local hypomonotonicity modulus exists.
  The full resolvent is globally multivalued for each \(\lambda>0\)
  because the Minty ranges of the two affine branches overlap; hence full
  RL fails. The attentive branch has \(J=I\) on its natural one-sided
  range and RL\(_1\), \(L=1\).
- **Inverse / zeros / regularity.** \(\operatorname{zer}A=(-\infty,0]\).
  More explicitly, \(A^{-1}(0)=(-\infty,0]\),
  \(A^{-1}(-2)=[0,\infty)\), and all other inverse fibers are empty.
  For \(x>0\), \(d(0,A(x))=2\), while for \(x\le0\) it is zero. Hence
  MSR holds with exact local modulus \(0\), but SMSR fails. MR/SMR fail
  because nearby target values other than \(0\) have empty local inverse.

### MGB-22 — concave quadratic: prox-regular \(\wedge\) global hypomonotone

- **Purpose / cell.** Positive control for MGB-20/21.
- **Object.** \(f(x)=-x^2/2\) is globally prox-regular with threshold
  \(r=1\), and \(A=\partial f=-I\) is globally sharply
  \(1\)-hypomonotone. It is maximally \((-1)\)-monotone because
  \(A+I=0\) is maximally monotone.
- **Exact formulas.** \(A^{-1}=-I\), zero \(0\), and for
  \(\lambda\ne1\)
  \[
  J_{\lambda A}=\frac1{1-\lambda}I,qquad
  R_{\lambda A}=\frac{1+\lambda}{1-\lambda}I.
  \]
  Thus RL\(_1\) is sharp with \(L=(1+\lambda)/|1-\lambda|\), while
  \(\lambda=1\) is exact resolvent collapse. All metric regularity and
  subregularity moduli at zero equal \(1\).

### MGB-23 — convex ball normal: prox-regular \(\wedge\) full monotone normal graph

- **Purpose / cell.** Contrasts the same bounded geometry with MGB-20.
- **Object.** For the closed unit ball \(B\subset\mathbb R^m\),
  \(A=N_B=\partial\iota_B\) is maximally monotone, paramonotone,
  rectangular and the set is prox-regular. Its zero set is the whole ball.
- **Inverse.** \(N_B^{-1}(0)=B\), while
  \(N_B^{-1}(y)=\{y/\|y\|\}\) for every \(y\ne0\).
- **Resolvent/RL.** \(J_{\lambda A}=P_B\), independent of \(\lambda\),
  and \(R=2P_B-I\) is nonexpansive; sharp global RL\(_1\) constant is
  \(1\). No global \(\gamma<1\) holds because \(R=-I+O(1)\) at infinity.
- **Regularity seed.** MSR for target zero is again trivial with exact
  modulus \(0\) (all domain points are zeros); SMSR fails. This entry is
  included so C does not infer useful inverse stability merely from
  maximal monotonicity plus prox-regularity. MR and SMR also fail around
  every \((\bar x,0)\), \(\bar x\in B\): at an interior point, inverse
  images of arbitrarily small nonzero targets lie on the distant boundary;
  at a boundary point, rotating a target of norm \(t\downarrow0\) (or
  changing its sign when \(m=1\)) gives an unbounded ratio, as in MGB-20.

---

## 7. Gap-cell coverage index (labels only; C must recompute)

| Comparison | \(A\wedge B\) | \(A\wedge\neg B\) | \(\neg A\wedge B\) | \(\neg A\wedge\neg B\) |
|---|---|---|---|---|
| finite hypomonotone / LT | MGB-03 | MGB-02 | MGB-01 | MGB-04 (global) |
| strict Spingarn formula / LT | MGB-01 | MGB-02 | MGB-06 | MGB-07 |
| pointwise Spingarn formula / strict formula | MGB-01/02 | MGB-06 | impossible if the strict quantifier includes the fixed endpoint | MGB-05 |
| paramonotone / rectangular | MGB-12,16 | MGB-09 | MGB-08 | MGB-10,11,13 |
| VI pseudomonotone / quasimonotone | MGB-17 | logically impossible under the stated definitions | MGB-18 | MGB-19 |
| prox-regular / full-graph finite hypo | MGB-22,23 | MGB-20 | `PENDING`: MGB-21 has only the attentive output branch, not the full graph | MGB-21 for the untruncated full graph |

The third and fourth columns in the last row deliberately distinguish the
attentive graph from the full graph; collapsing those two objects would erase
the actual theorem hypothesis.

### Diversity / maximality index

| IDs | Dimension/value type | maximality status relevant to the entry |
|---|---|---|
| MGB-01--07 | finite-dimensional, mostly single-valued restricted graphs | nonmaximal; MGB-03 is maximally \(k\)-hypomonotone |
| MGB-08 | \(\mathbb R^2\), set-valued boundary | maximally monotone |
| MGB-09--11 | \(\ell^2\) or \(L^2\), single-valued linear | maximally monotone |
| MGB-12--16 | finite-dimensional/full Hilbert linear | maximally monotone; rotations maximal at their stated \(n\)-cyclic order |
| MGB-17--19 | scalar VI maps | VI maximality not invoked; MGB-17 is full-domain nonmonotone |
| MGB-20--23 | finite-dimensional set-valued/smooth subgradients | MGB-23 maximally monotone; MGB-22 maximally \((-1)\)-monotone; MGB-20/21 nonmaximal in the relevant graph class |

---

## 8. Reproducibility checks actually executed

The following are checks, not universal proofs; the displayed derivations above
remain the proofs.

1. A \(2001\times401\) grid for MGB-02 returned maximum sampled
   \(Q_{1,1/2}=1.99975\), approaching the proved supremum \(2\) at the
   critical endpoint.
2. Direct SVD of the first, second, tenth and thousandth MGB-09 blocks
   returned singular values \((1+a_kb_k,1)\), including
   \((1.5,1)\), \((1.08333\ldots,1)\), and values tending to \((1,1)\).
3. Substitution into `(Rot-Cayley)` at \(\lambda=1\) returned
   \(L=1,1/\sqrt3,\sqrt2-1\) for
   \(\theta=\pi/2,\pi/3,\pi/4\), respectively.

## 9. Source-verification and pending ledger

| Claim cluster | Status | Locator / limitation |
|---|---|---|
| Luke--Tam \(-\sqrt x\): \(U=[0,1/16]\), \(W=\mathbb R\), \(\tau=2\), nonhypomonotone | `VERIFIED_SOURCE` | official Example 2, eqs. (19)--(21); Definition 2 permits every \(\tau\ge0\) |
| Luke--Tam reflected-resolvent equivalence at \(\tau=2\) | `ALG`, not Prop. 4 | Prop. 4's aFNE statement assumes \(\tau<1/2\); the Cayley identity and explicit branch above establish Lipschitz \(R\) directly |
| BWY independence examples | `VERIFIED_SOURCE` | Examples 3.5, 5.3, 5.5; formulas copied above |
| rotation threshold \(|\theta|\le\pi/n\) | `VERIFIED_SOURCE` preprint | Voisei Example 43, conclusion after (87), arXiv:2411.04212v2 |
| VI \(x^2\) example | `VERIFIED_SOURCE` | Lei--He Definitions 2.2--2.3 and following sentence |
| Spingarn one-fixed-end historical definition / maximal convention | `PENDING_VERIFICATION` | [AMS official metadata](https://www.ams.org/tran/1981-264-01/S0002-9947-1981-0597868-8/) located, but 1981 full text was access-blocked; Zajíček Definition 2.1 verifies the later two-moving formula only |
| MGB-05--07,12,16--23 constructions and extra moduli | `ALG` | explicit formulas supplied; independent C recomputation required |

Search date was 2026-09-01. Reproducible discovery/confirmation strings included:

- `Luke Tam "Generalized Monotonicity and the Proximal Point Algorithm" Example 2 sqrt`
- `site:arxiv.org Bauschke Wang Yao paramonotone rectangular Volterra 2012`
- `site:arxiv.org "n-cyclically monotone" rotation angle pi/n`
- `"Submonotone subdifferentials of Lipschitz functions" Spingarn 1981`

No claim of systematic-search completeness is made.

---

## 10. C-stage priority queue (no synthesis)

1. Recompute MGB-01 and MGB-02 first: they give sourced sharp endpoints
   \((\tau,L)=(2,3)\) and \((\gamma,L)=(1/2,2)\), respectively.
2. Recompute MGB-09 next: it has zero strong-monotonicity modulus but exact
   inverse modulus one, and a false label here would contaminate several gap
   comparisons.
3. For MGB-05/06/07/20/21, explicitly retain closed-graph,
   domain-vacuity and attentive-localization flags; a yes/no MSR label alone
   is misleading.
4. For MGB-10/11, test power/gauge failure with an explicit normalized sine
   sequence rather than relying only on the phrase “range nonclosed.”
5. Do not promote the Spingarn historical naming or maximality statements
   until the primary 1981 pages are obtained.
