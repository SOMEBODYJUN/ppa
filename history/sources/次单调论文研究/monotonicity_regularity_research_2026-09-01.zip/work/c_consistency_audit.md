# C-stage consistency audit

> Scope: cross-file audit of `work/c_gx001_013.md` through
> `work/c_gx066_077.md`, checked against `research/theory_atlas.md`,
> `research/gap_examples.md`, and `work/b_catalog_audit.md`.
> This file is an audit/handoff only. It is not `example_properties.md` and
> makes no seesaw/synthesis judgment.

## 0. Status summary

- **GX coverage:** the mathematical content of all IDs `GX-001`--`GX-077`
  occurs in the six C ledgers. There is one card-structure defect: GX-025 and
  GX-026 remain under one combined C heading.
- **BLOCKER:** none in the printed C calculations. In
  particular, the former B-stage blockers/candidates around GX-069--GX-073
  have been given analytic proofs in C; they must still be integrated with
  the scope qualifications recorded below.
- **MAJOR:** fixed-target/two-variable modulus separation, canonical-alias
  observation scaling, stale B-stage candidates, several `C-DISAGREE` tag
  repairs, and preservation of local/window/stepsize quantifiers.
- **Rule for integration:** a `C-DISAGREE` is authoritative only when the C
  entry contains an analytic extremizer/countersequence or an exact
  optimization. Numerical checks never resolve an endpoint.

## 1. BLOCKER

### CCA-B01 -- none currently established

No C-stage statement presently requires rejection of an entire GX card.

## 2. MAJOR findings

### CCA-M01 -- phase counting must use canonical operators, not all 77 IDs

The C ledgers correctly note several aliases, but an integrator can still
overweight them if every GX row is treated as an independent object. Exact
duplicates or isometric/scaled observations include the zero operator,
positive/negative scalar families, the cubic `x^3`, duplicated shifted
half-line-normal records, `N_{\{0\}}`, power-Cayley/tanh-Cayley variants,
and Volterra/adjoint orientation. Other records share an underlying set or
germ but are **distinct mappings**: a half-line normal at different targets,
`N_L` versus `I-P_L`, the full versus truncated circle normal, and a
tangent-set pair versus its DR residual. They must be linked without being
merged.

**Direct patch sentence:**

> Statistical/phase-cloud counting is by canonical mathematical object.
> A different reference point, stepsize, restriction, truncation, or
> algorithmic residual is retained as an observation record, not counted as
> another independent operator. Distinct mappings on the same underlying
> sets (for example `N_L`, `I-P_L`, and a Douglas--Rachford residual) are not
> literal aliases.

### CCA-M02 -- fixed-target and two-variable power moduli must occupy separate fields

Several exact constants differ solely because opposite targets enter MR/Aubin
but not MSR/calm. The integrator must never copy the fixed-target number into
the two-variable field. Authoritative examples include:

- GX-016: fixed `q=1/3` modulus `(6\lambda_0)^{1/3}`; two-variable
  `q=1/3` MR modulus `(24\lambda_0)^{1/3}`.
- GX-017/GX-018: fixed `q=1/3` modulus `2^{1/3}`; two-variable modulus `2`.
- GX-021: fixed `q=1/3` modulus `1`; two-variable modulus `2^{2/3}`.
- GX-023: fixed logarithmic-gauge modulus `1`; pairwise inverse-gauge
  modulus `2`.
- GX-054: fixed `q=1/3` modulus `1`; pairwise modulus `2^{2/3}`.
- GX-022/GX-024: higher-order fixed-target estimates do not imply
  two-variable `q`-MR for `q>1`.

**Direct patch sentence:**

> Every regularity record has two exponent/modulus slots: (i) fixed-target
> MSR/SMSR, equivalent to calm/isolated calm at the printed graph point, and
> (ii) nearby-target-uniform MR/SMR, equivalent to Aubin plus the required
> single-valued localization. Constants are transferred only through the
> appropriate exact equivalence, never across these two slots.

### CCA-M03 -- “exact modulus 0” needs a mechanism tag and the infimum convention

The C files use the correct infimal-local convention, but a zero modulus can
come from incompatible mechanisms: big solution set, off-domain residual
`+\infty`, local full value, constant inverse branch, residual jump,
residual escape/graph isolation, or a genuinely superlinear inverse germ.
These cannot be merged as one strength level.

**Direct patch sentence:**

> `modulus = 0` means the infimum of admissible local constants after
> shrinking neighborhoods; it need not mean that the inequality with literal
> constant zero holds on a fixed neighborhood. Record one of
> `BIG-SOLUTION`, `DOMAIN-VACUOUS`, `FULL-VALUE`, `BRANCH-PINNING`,
> `RESIDUAL-JUMP`, `RESIDUAL-ESCAPE/GRAPH-ISOLATION`, or
> `SUPERLINEAR-GERM`, and do not compare zero moduli without that tag.

The principal audited instances are:

| Mechanism | Representative records |
|---|---|
| `BIG-SOLUTION + DOMAIN-VACUOUS` | GX-012 at target 0; GX-042 for `N_L`; GX-074 |
| `BRANCH-PINNING + RESIDUAL-JUMP` | GX-012 at target `-1`; GX-046 at `(0,1)`; GX-077 |
| `DOMAIN-VACUOUS + BRANCH-PINNING` | GX-040 and the GX-070 primal `N_{\{0\}}` |
| `SUPERLINEAR-GERM`, residual tending to 0 | GX-022/GX-024 for ordinary modulus; GX-071/GX-072 |

These rows are mechanism labels, not alias claims; for example the two
`N_{\{0\}}` observations are isometric family members, whereas the other
entries are distinct mappings or references.

### CCA-M04 -- high-risk corrected or sharpened facts require narrow scope

The following corrected or sharpened facts have analytic support and may be
adopted, but only in the indicated scope; CCA-M08 supplies the correct status
tag for each:

- **GX-025/026:** the linear tails kill global subunit RL only for
  `\lambda\ne1`; at the tuned step `\lambda=1` the tails cancel, and all
  subunit exponents hold by Lipschitz-plus-bounded-range inheritance. The
  exact subunit constant remains unknown.
- **GX-046:** the full untruncated relation has same-input branch collisions,
  but a base restriction `|x|\le\delta<\lambda` has finite exact RL-1
  constant `(\lambda+\delta)/(\lambda-\delta)`. A graph neighborhood of
  `(0,1)` selects an even simpler constant attentive branch.
- **GX-056:** at step `\lambda=1`, the sharp RL-1 constant is
  `(1+\delta)/(1-\delta)`, not the safe triangle bound
  `(1+2\delta)/(1-2\delta)`; the proof optimizes the feasible ratio
  `t=a/b` whose infimum is `-\delta`.
- **GX-064:** the critical exponent is `1/3`, but the sharp all-pairs local
  constant is `4\sqrt[3]{3}`, while the one-fixed-end/anchored constant is
  `2\sqrt[3]{6}`.

No synthesis may use the superseded broad B wording or safe bound as sharp.

### CCA-M05 -- local/global/stepsize qualifiers are part of each RL datum

The same graph can move between a map, a relation with folds, and a Minty
collision as `\lambda` changes. Integration must retain at least: generating
step, natural Minty domain, graph/base/output window, local versus global,
and whether a subunit exponent is genuine or inherited from bounded range.

**Direct patch sentence:**

> An RL datum is the tuple `(graph/window, lambda, exponent, constant,
> local/global, all-pairs/anchored, genuine/inherited, map/relation)`.
> Suppressing any coordinate invalidates comparisons across GX cards.

### CCA-M06 -- set-pair and Douglas--Rachford moduli use different mappings

For GX-047--GX-052, the set map
`\Phi(x)=(A-x)\times(B-x)` takes values in a product space and operator
inner-product/RL notions are N/A. GX-069/GX-070 instead concern the DR
fixed-point residual `G=I-T_DR`. Their moduli cannot be copied to the primal
normal sum or to `\Phi` without an explicit metric equivalence.

**Direct patch sentence:**

> Keep three separate rows when they occur: set-pair map `\Phi`, primal
> normal/cone operator, and algorithmic residual `I-T`. State the input and
> output norms for each; constants are mapping- and norm-specific.

### CCA-M07 -- GX-025/GX-026 are mathematically covered but not one-card-per-ID

`research/gap_examples.md` has exactly 77 unique GX headings. In the C
ledgers, GX-025 and GX-026 are both computed, but only the combined heading
`GX-025 and GX-026` exists. This does not lose a formula, yet it defeats
machine checking of 77 independent records and leaves source/status fields
ambiguous.

**Direct patch sentence:**

> Retain the shared gauge lemma once, but add separate `## GX-025` and
> `## GX-026` record headings. Each record must independently state its own
> inverse, exact gauge, cross-gauge failure subsequence, power signature,
> source/status and tuned-step RL qualification.

### CCA-M08 -- three `C-DISAGREE` tags are taxonomically too strong

The analytic calculations are useful, but the comparison target must be read
literally:

| ID | C label now | Audit of the B claim | Correct integration tag |
|---|---|---|---|
| GX-025/026 | `C-DISAGREE` | genuine: B said linear tails kill every global subunit step; `\lambda=1` cancels the tail | `C-DISAGREE` |
| GX-046 | conditional scope correction | genuine: B said the full graph has no finite local RL; the base-window calculation disproves that reading | `C-DISAGREE-SCOPE` |
| GX-056 sharp constant | `C-DISAGREE` | B explicitly called `(1+2\delta)/(1-2\delta)` a safe bound and left sharpness to C | `C-SHARPEN` |
| GX-056 local closedness | bundled into same flag | genuine if B's unqualified “not locally closed” was meant at `(0,0)` | `C-DISAGREE-SCOPE` |
| GX-064 constants | `C-DISAGREE/ambiguity` | B asserted only the critical exponent, not a false common constant | `C-REFINE` |
| GX-073 candidates | `C-DISAGREE/C-UPGRADE` | B explicitly marked both conclusions `CANDIDATE` | `C-UPGRADE` only |
| GX-076 continuity | `C-DISAGREE` | genuine: B called the map continuous; it is continuous at 0 but not globally | `C-DISAGREE` |

All genuine disagreements have analytic evidence: exact tail cancellation;
the cross-branch ratio for GX-046; a product-neighborhood graph-limit
sequence for GX-076. The retagging prevents a sharpened bound or resolved
candidate from being misreported as a catalog error.

### CCA-M09 -- five B-stage `CANDIDATE` statuses are now stale

The C ledgers supply full-quantifier analytic proofs for:

- GX-049: full-neighborhood `q=1/2` set-map MSR/SMSR, exact `\sqrt2`;
- GX-057: fixed-target maximal exponent `1/2`, exact modulus 1;
- GX-069: full-tube `q=1/2` MSR, exact modulus 1 (SMSR still fails);
- GX-072: two-scale endpoint all-pairs exponent `\gamma`, full-map
  fixed-target exponent `q`, and invariant Q-order `q`;
- GX-073: endpoint all-pairs exponent `\alpha/(\beta+1)` and full-map
  linear MSR/SMSR modulus 1.

**Direct patch sentence:**

> These five property/exponent labels are `VERIFIED-ALG` after C. Only their
> explicitly listed optimal constants remain unknown. `research/gap_examples.md`
> is a pre-C handoff until these statuses are backfilled and must not override
> the C recomputation.

This does **not** automatically resolve the uncarded AR-06 multifunction
MSR candidate: the general oscillatory Hölder lemma transfers only after its
mapping/window/preimage quantifiers are separately restated.

### CCA-M10 -- GX-060 and GX-061 are one unitary-conjugacy phase point

With `(Uf)(t)=f(1-t)`, `U` is unitary and

\[
V^*=UVU.
\]

Hence all invariant graph, Cayley and regularity coordinates of GX-060 and
GX-061 coincide. They may remain two orientation/source observations, but
counting them as independent phase evidence double-weights one operator up
to isometry. Likewise, GX-028/GX-065 share the same zero germ `x^2`, and
GX-003 with `c=1`/GX-066 share the same zero germ `-I`; their domain, VI and
global RL observations remain distinct.

### CCA-M11 -- GX-071 calibration, scaling and invariance pass, but its optimal RL constant is unknown

The former CP-01 ambient-scope blocker is resolved correctly:

1. `J,F` are defined globally on `R^2`; the tube is only the RL/orbit window.
2. `S=R\times\{0\}` and global fixed-target `q`-MSR has exact modulus 1.
3. The restricted all-pairs exponent is sharply `\gamma` (the anchored
   quotient tends to 2), but (71.4) is only a certified upper constant.
4. `r_{k+1}=r_k^{\alpha}=r_k^{\gamma q}` is an identity because
   `\alpha` was defined as `\gamma q`.
5. The full rectangle is not invariant. The drift estimate (71.7) and the
   positive upper tangential margin must be stated; (71.7) supplies a
   sufficient invariant-subwindow condition.

**Authoritative warning sentence:**

> GX-071 is a reverse-calibrated attainability construction. Its exponent
> identity and invariant subwindow are verified, but its optimal restricted
> RL constant is unknown and it has no evidentiary weight as an independently
> observed universal `\gamma q` law.

### CCA-M12 -- the oscillatory two-scale endpoint proof passes

The lemma preceding GX-071/072 correctly supplies the missing **upper**
bound, not only a failure sequence. Its two cases are exhaustive:

- if `d\gtrsim x^{b+1}`, amplitude gives `x^a\lesssim d^{a/(b+1)}`;
- if `d\ll x^{b+1}`, the derivative bound
  `|h'|\lesssim x^{a-b-1}` gives the same power;
- opposite signs follow from amplitude because the input gap dominates both
  radii.

Adjacent opposite oscillatory extrema then prove failure of every larger
exponent. Thus the sharp exponents for GX-072 and GX-073 are analytically
proved. The lemma does not optimize `L_072` or `L_073`.

### CCA-M13 -- “residual-jump-in-scale” is the wrong mechanism name for GX-072

For GX-072 (and similarly the ordinary-modulus-zero part of GX-071), the
residual tends to zero; there is no jump. The zero ordinary modulus is caused
by the superlinear relation `d=O(r^q)`, `q>1`.

**Direct patch sentence:**

> Replace `residual-jump-in-scale` by `SUPERLINEAR-GERM (nonvacuous,
> residual -> 0)`. Reserve `RESIDUAL-JUMP` for examples such as GX-046 and
> GX-077, where off-solution residuals stay bounded away from zero.

### CCA-M14 -- GX-068 omits exact two-variable `q=1/2` MR

The C card proves fixed-target `q=1/2` MSR/SMSR but stops after saying
ordinary MR fails. The inverse is

\[
F^{-1}(y)=
\begin{cases}
\{y,\pm\sqrt y\},&y>0,\\
\{0\},&y=0,\\
\{y\},&y<0.
\end{cases}
\]

It is locally `1/2`-Aubin with exact modulus 1. For nonnegative targets use
the same square-root branch and
`|\sqrt u-\sqrt v|\le\sqrt{|u-v|}`. Across zero, the identity point in the
negative fiber gives the same estimate after shrinking so that
`2\sqrt u+|v|\le1`. The lower bound is attained by a square-root branch
against target zero. Branch multiplicity prevents every strong/Hölder-strong
localization.

**Direct patch sentence:**

> Moreover, $F^{-1}$ is locally $1/2$-Aubin with exact modulus $1$;
> hence $F$ is $1/2$-metrically regular with exact modulus $1$. Ordinary
> MR and every single-valued/Hölder-strong localization still fail because
> all small positive targets have three local inverse branches.

### CCA-M15 -- GX-076 omits exact two-variable `q=1/2` MR

For `p=(a,b)` and a nearby target `y`, one can construct a point on the
level set `Theta^{-1}(y)` at distance at most
`|Theta(p)-y|^{1/2}`. For example, when `a>=0`:

- if `y>=b^2`, keep `b` and change `a` to `y-b^2`;
- if `0<=y<b^2`, use `(0,sgn(b)\sqrt y)`;
- if `y<0`, use `(y,0)`.

The reflected cases cover `a<0`. After shrinking the neighborhood, the
squared-distance estimates are bounded by the residual. Taking
`p=(0,t),y=0` attains constant 1. Nearby level fibers are curves, so no
strong Hölder localization is possible.

**Direct patch sentence:**

> In addition, $\Theta$ is $1/2$-metrically regular around
> $((0,0),0)$ with exact modulus $1$. It is not Hölder-strongly
> metrically regular because every nonzero small level has a non-singleton
> local fiber.

### CCA-M16 -- atlas (2.6) must use an extended-real reciprocal, not a literal product

The printed identity
`|F|^downarrow * subreg_strong F = 1` becomes the undefined product
`(+infinity)*0` in legitimate modulus-zero examples such as branch-pinned or
superlinear germs.

**Direct patch sentence:**

> Write
> `subreg_strong F = 1/|F|^downarrow`, with the extended-real conventions
> `1/(+infinity)=0` and `1/0=+infinity`; do not interpret this as the literal
> product `0*(+infinity)=1`.

### CCA-M17 -- explicit stepsize ledger for high-risk Cayley families

| ID | Authoritative step-dependent RL statement |
|---|---|
| GX-015 | With `theta=eta/lambda_0`: `eta<lambda_0` has only global RL-1, sharp `(1+theta)/(1-theta)`; `eta=lambda_0` has the unique global exponent `alpha`, `L=2^{1-alpha}`; `eta>lambda_0` folds and all-pairs RL fails. |
| GX-016 | At the generating step `lambda_0`, every subunit exponent holds by bounded range; at every other step only global RL-1 survives, sharp 1. |
| GX-017 | At step 1 every subunit exponent holds; at every other step nonzero linear tails kill them, while RL-1 remains sharp 1. |
| GX-018 | `eta<1`: folds/collisions; `eta=1`: no global exponent but local RL-1 near zero; `eta>1`: global RL-1 `(eta+1)/(eta-1)`, no global subunit exponent. |
| GX-019 | `lambda != 3`: bounded-domain `L^*=(3+lambda)|3-lambda|^{-gamma}`; `lambda=3`: collision and all RL fails. |
| GX-020 | All steps have RL-1 constant 1; global subunit exponents occur only at `lambda=1`, with `L_gamma=2^{1-gamma}`. |
| GX-025/026 | `lambda=1`: all subunit exponents, inherited after exact tail cancellation; `lambda!=1`: nonzero linear tails kill global subunit exponents. |
| GX-030 | `eta<1`: global RL-1 `(1+eta)/(1-eta)`; `eta=1`: local genuine exponent `1/3`, `L=2^{5/3}`, no global exponent; `eta>1`: global collisions, though a small zero branch still has local RL-1. |
| GX-045 truncation | Finite restricted RL-1 exactly when `lambda r_0<1`; threshold/open-inner-radius blow-up must be retained. |
| GX-053 | `lambda<1`: global-on-bounded-domain RL-1 `(1+lambda)/(1-lambda)` plus inherited subunit bounds; `lambda=1`: sharp exponent `1/2`, `L=2`; `lambda>1`: folds. |
| GX-055 | Finite RL-1 iff `lambda>epsilon^2`, sharp `(lambda+epsilon^2)/(lambda-epsilon^2)`; no global subunit exponent on the unbounded pole cluster. |
| GX-056 | Finite RL-1 iff `lambda>delta`, sharp `(lambda+delta)/(lambda-delta)`; subunit bounds are bounded-domain inheritance. |
| GX-064 | `lambda<1`: RL-1 `(1+lambda)/(1-lambda)`; `lambda=1`: local exponent `1/3` with separate anchored/all-pairs constants; `lambda>1`: collisions. |
| GX-065 | `lambda<1/2`: RL-1 `(1+2lambda)/(1-2lambda)`; `lambda=1/2`: exponent `1/2`, `L=2sqrt(2)`; `lambda>1/2`: collisions. |

This table is the minimum safe `lambda/scaling/local-global` information;
none of its tuned-step conclusions may be promoted to an operator-only tag.

### CCA-M18 -- canonical alias/observation constants do not conflict after scoping

| Canonical object/family | Observation-specific constants that must coexist |
|---|---|
| cubic `x^3` (GX-021) | operator fixed `q=1/3` modulus 1; PPA residual modulus `lambda^{-1/3}`; scaled residual `eta F` modulus `eta^{-1/3}` |
| `N_{\{0\}}` family (GX-040/GX-070 primal) | all four ordinary moduli 0 and RL-1 1; dimension is a family parameter, not a literal same-space alias |
| tangent line/parabola | GX-049 set-map `q=1/2` modulus `sqrt2`; GX-069 DR residual modulus 1; tangent primal normal sum modulus 0 but no MR |
| transverse lines | GX-047 set-map modulus `sqrt2` under max output norm; GX-070 DR residual modulus `1/sin(theta)`; primal `N_{\{0\}}` modulus 0 |
| branch union GX-068 | selected identity residual linear modulus `(1+lambda)/lambda`; full resolvent residual fixed `q=1/2` modulus `lambda^{-1/2}`; operator fixed and pairwise `q=1/2` modulus 1 |
| `\partial|x|` (GX-077) | operator MR/MSR/SMR/SMSR modulus 0; prox fixed-point residual EB modulus 1 |
| `N_{[0,infinity)}` (GX-012) | target 0: trivial/nonisolated MSR 0 and no MR; target -1: all four local moduli 0 by branch pinning/residual gap |
| circle normal (GX-045) | full cone has no finite hypo/RL; norm truncation has hypo `r_0` and the thresholded RL constant |
| Volterra orientation (GX-060/061) | exactly unitary conjugate, hence one invariant phase point with two orientation observations |

No sign or scaling conflict remains inside these groups once mapping,
reference, residual, stepsize and norm are separate columns.

## 3. Authoritative constants already cleared for integration

The following values have explicit symbolic derivations in the C ledgers and
supersede looser B-stage bounds (scope is part of the value):

| Item | Authoritative value / qualification |
|---|---|
| GX-030, `\lambda=1`, local all-pairs RL | maximal exponent `1/3`, `L*=2^{5/3}` |
| GX-031 clipped power, global | `0<\gamma\le\alpha`, `L_\gamma^*=2^{1-\gamma}` |
| GX-032 Luke--Tam window | `\tau_*=2`, RL-1 `L*=3`, sharp cohypo violation `1/2`; no finite hypo |
| GX-045 truncated circle normal | hypo modulus `r_0`; RL-1 `(1+\lambda r_0)/(1-\lambda r_0)` iff `\lambda r_0<1` |
| GX-046 base window | RL-1 `(\lambda+\delta)/(\lambda-\delta)` for `\delta<\lambda` |
| GX-049 set-pair map, max product norm | sharp fixed-target `q=1/2` MSR/SMSR modulus `\sqrt2` |
| GX-056, step 1 | RL-1 `(1+\delta)/(1-\delta)` |
| GX-057 fixed-target | maximal exponent `1/2`, exact modulus `1` |
| GX-059 | block singular values `{1,1+a_kb_k}`; all four ordinary moduli `1` |
| GX-064 critical flat point | all-pairs `4\sqrt[3]{3}`; anchored `2\sqrt[3]{6}` |
| GX-065 critical step `\lambda=1/2` | maximal exponent `1/2`, `L*=2\sqrt2` |
| GX-069 DR residual | full-tube fixed `q=1/2` MSR modulus `1`; SMSR fails |
| GX-070 DR residual | all four ordinary moduli `1/\sin\theta`; strong modulus `\sin^2\theta`, coco modulus `1` |
| GX-071 | global fixed `q`-MSR modulus `1`; recurrence exponent `\gamma q`; restricted RL exponent `\gamma`, optimal `L` unknown |
| GX-072 | anchored exponent/point modulus `1`; all-pairs exponent `\gamma`; fixed exponent `q` with modulus `K_q` in (72.4); Q-order `q` |
| GX-073 | all-pairs exponent `\alpha/(\beta+1)`; anchored exponent `\alpha` with exact local constant `3`; full-map linear MSR/SMSR modulus `1` |
| GX-076 | fixed `q=1/2` MSR/SMSR and two-variable `q=1/2` MR modulus `1`; HREG/UHREG modulus `1`; ordinary MR and every strong Hölder localization fail |
| GX-068 | fixed and two-variable `q=1/2` modulus `1`; no strong Hölder localization |

Two C-marked unknowns can be closed analytically and should be patched before
formal integration:

1. **GX-017.** For `0<\gamma<1`, the exact generating-step global constant is
   \[
   \boxed{L_\gamma^*=2^{-\gamma}(1+\gamma)^{(1+\gamma)/2}
   (1-\gamma)^{(1-\gamma)/2}.}
   \]
   Put `s=m+h,t=m-h`. For `h^2<3`, direct differentiation in `m^2`
   shows the fixed-gap maximum is centered at `m=0`; for `h^2\ge3`, the
   range-diameter bound is below the centered global maximum. Maximizing
   `(2h)^{1-\gamma}/(1+h^2)` gives
   `h^2=(1-\gamma)/(1+\gamma)` and the displayed value.
2. **GX-037.** The exact local `1/2` Hölder-Aubin modulus of
   `G(t)=t\sin(1/t)` is
   \[
   \boxed{K^*=\sup_{\Delta>0}\frac{2|\sin(\Delta/2)|}{\sqrt\Delta}
   =\frac{\sqrt2\sin x_*}{\sqrt{x_*}}
   \approx1.20383666149,}
   \]
   where `x_*\in(0,\pi/2)` is the unique root of `\tan x_*=2x_*`.
   Substituting `A=1/s,B=1/t` proves the same-sign limsup; opposite signs
   cannot enlarge it because `G` is even and the input distance is larger.

## 4. Still UNKNOWN / only-safe (must not be promoted)

- GX-025/GX-026: exact tuned-step subunit RL constants and exact endpoint
  two-variable `(1-c)`-MR modulus inside the proved interval.
- GX-052: the optimal bounded-ball linear-regularity modulus; C proves only
  the safe `\kappa_R=\max\{1,4R^2\}`.
- GX-071: optimal restricted-tube RL-`\gamma` constant; (71.4) is safe.
- GX-072 and GX-073: optimal all-pairs endpoint RL constants; the exponents
  are sharp, but (72.3)/(73.3) are safe upper constants.
- GX-045: optimal subunit RL constants on the truncated annulus; the printed
  Lipschitz-derived number is only safe.
- Spingarn historical nomenclature/maximality convention for the relevant
  GX-053--GX-057 formulas remains pending primary full-text verification.

## 5. Set-map / DR moduli that must remain mapping-specific

| ID / mapping | Authoritative regularity coordinate |
|---|---|
| GX-042 `N_L` | fixed MSR infimum 0 by domain/big-solution vacuity; no MR/SMSR |
| GX-042 `I-P_L` | nonvacuous MSR modulus 1; no MR/SMSR |
| GX-047 set map, output max norm | MR/MSR/SMR/SMSR all `\sqrt2` |
| GX-048 set map | MSR 1; no MR/SMSR/SMR |
| GX-049 set map | fixed `q=1/2` MSR/SMSR `\sqrt2`; no ordinary core regularity |
| GX-050 set map | no fixed power MSR/SMSR for any `q>0` |
| GX-051 set map | local MSR/SMSR 1 at 0; no MR/SMR; not boundedly LR |
| GX-052 set map | local MSR/SMSR 1; bounded LR with only-safe `\kappa_R`; no global LR |
| GX-069 DR residual `I-T` | fixed `q=1/2` MSR 1; no ordinary MSR/SMSR/MR/SMR |
| GX-069 primal `N_C+N_D` | fixed MSR/SMSR 0 by domain vacuity; no MR/SMR/HREG |
| GX-070 DR residual `I-T` | all four ordinary moduli `1/\sin\theta` |
| GX-070 primal `N_C+N_D=N_{\{0\}}` | all four ordinary moduli 0; inverse globally pinned |

## 6. PASS ledger

- All 77 IDs have mathematical content; no GX object is missing.
- The CP-01 global-ambient repair, zero set, `q`-MSR and drift margin pass.
- The GX-069 full-tube proof uses the complete `(s,b)` parameterization and
  has exact modulus 1; it is not an extrapolation from the slice.
- The two-scale upper proof and extrema sharpness proof are logically
  separate and both present.
- GX-040/GX-070 correctly restore MR and SMR for the primal
  `N_{\{0\}}`; exact zero is inverse branch pinning, not evidence from a
  nontrivial residual slope.
- Fixed-target versus pairwise constants are separated in all explicitly
  listed high-risk scalar examples.
- The rotation formulas retain the sole singular Cayley point
  `(\theta,\lambda)=(\pm\pi,1)` and do not extend through it.
- Numerical grids are used only as sanity checks; no universal property in
  the six C ledgers rests solely on sampling.

## 7. MINOR / direct cleanup patches

1. Replace the form-feed corruption `rac` by `\frac` in
   `c_gx001_013.md:481` and `c_gx066_077.md:1008`.
2. Add the missing backslash in `c_gx066_077.md:163`, changing
   `,qquad` to `,\qquad`.
3. Delete the duplicated `q-MR` definition line in `theory_atlas.md` (2.2).
4. Call scalar and higher-dimensional `N_{\{0\}}` a
   dimension-parameterized canonical family, not a literal same-space alias.
5. In the GX-071 summary, do not say C found the “exact Hölder constant”:
   C proved the sharp exponent and a certified upper constant only.
6. In `c_gx014_026.md` near the GX-021 formula, change the bare `,qquad`
   to `,\qquad` if it is retained in rendered mathematics.
7. Wherever an extended gauge is used, state the endpoint convention
   `\phi(+\infty)=+\infty` explicitly rather than leaving it implicit.
