# Regularity atlas（Subagent A：regularity side）

> 状态：可合并研究子稿；核验截止 2026-09-01。本文只整理 regularity/error-bound 事实，不作 monotonicity–regularity “跷跷板”结论。

## 0. 约定与证据等级

设 \(X,Y\) 为度量空间（涉及导数/余导数时再加强为赋范、Banach、Asplund 或有限维空间），

\[
F:X\rightrightarrows Y,\quad
(\bar x,\bar y)\in\operatorname{gph}F,\quad
S:=F^{-1}(\bar y),\quad
r_F(x):=d(\bar y,F(x)).
\]

约定 \(d(z,\varnothing)=+\infty\)。本文把 \(\kappa\) 定为距离不等式右侧的上界常数，exact modulus 是可行 \(\kappa\) 的下确界；若文献用
\(\tau d\le r\) 的 lower-rate convention，则 \(\kappa_{\rm exact}=1/\tau_{\rm exact}\)（含通常的 \(0,+\infty\) 约定）。

证据标签：

- **[A]**：已核验 primary-source 全文中的定义/定理/证明；
- **[B]**：只核验到官方出版页/摘要或元数据；
- **[C]**：由显示定义直接得到的初等推导，不冒充文献 theorem。

有些作者把 “locally closed graph” 并入 metric regularity 的定义，有些将其留作导数定理假设。本文把距离不等式视为定义本体，闭图假设单列。另一个高风险点是 “order \(q\)” 有互为倒数的两套 convention，见 §3.1。

## 1. 四个核心 mapping-side regularity

### 1.1 Metric regularity（MR）

**定义（around \((\bar x,\bar y)\)，两变量一致局部）**：存在邻域 \(U\ni\bar x,V\ni\bar y\) 与 \(\kappa\ge0\)，使

\[
d(x,F^{-1}(y))\le \kappa\,d(y,F(x))
\quad(\forall x\in U,\ \forall y\in V). \tag{MR}
\]

\[
\operatorname{reg}F(\bar x\mid\bar y)
:=\inf\{\kappa:(MR)\text{ 对某些 }U,V\text{ 成立}\}.
\]

它可用于 single- 或 set-valued \(F\)，是 local-but-uniform-in-\((x,y)\) 的性质。[S1, A]

**精确三联等价**（标准 neighborhood convention）：

\[
\boxed{
F\text{ MR}
\iff F^{-1}\text{ Aubin}
\iff F\text{ linearly open around }(\bar x,\bar y)}
\]

且

\[
\operatorname{reg}F
=\operatorname{lip}F^{-1}
=(\operatorname{lop}F)^{-1}. \tag{1.1}
\]

Linear openness 是：存在 \(U,V,\varepsilon>0,c>0\)，对所有
\((x,y)\in\operatorname{gph}F\cap(U\times V)\) 与 \(0<t<\varepsilon\)，

\[
B(y,ct)\subset F(B(x,t)). \tag{LO}
\]

[S1, Definition 2.1 and Proposition 2.2, A]

### 1.2 Metric subregularity（MSR）

**定义（at \((\bar x,\bar y)\)，固定 target）**：存在 \(U\ni\bar x,\kappa\ge0\)，

\[
d(x,S)\le\kappa\,r_F(x)\qquad(\forall x\in U). \tag{MSR}
\]

精确模记 \(\operatorname{subreg}F(\bar x\mid\bar y)\)。它不控制附近 \(y\ne\bar y\)。[S2, A]

精确 inverse 等价：

\[
F\text{ MSR at }(\bar x,\bar y)
\iff F^{-1}\text{ calm at }(\bar y,\bar x), \tag{1.2}
\]

模相同。[S3, Definition 2, A]

MR \(\Rightarrow\) MSR（在 MR 中固定 \(y=\bar y\)）；反向严格失败。

### 1.3 Strong metric regularity（SMR）

**定义（inverse localization）**：存在 \(V\ni\bar y,U\ni\bar x\)，使

\[
s(y):=F^{-1}(y)\cap U
\]

在 \(V\) 上恰为单值、取值于 \(U\)，并且 Lipschitz。精确结构是

\[
F\text{ SMR}
\iff F\text{ MR 且 }F^{-1}
\text{ 有 nowhere-multivalued graphical localization}. \tag{1.3}
\]

在标准定义下局部逆的最小 Lipschitz 常数等于 \(\operatorname{reg}F(\bar x\mid\bar y)\)。Robinson 原始 “strong regularity” 的广义方程表述略有差别；不能把 Robinson stability（§5.4）也叫作 SMR。[S2, A]

### 1.4 Strong metric subregularity（SMSR）

**定义（at，一点隔离）**：存在 \(U\ni\bar x,\kappa\ge0\)，

\[
d(x,\bar x)\le\kappa\,r_F(x)\qquad(\forall x\in U). \tag{SMSR}
\]

把 \(F(x)\) 换成 \(F(x)\cap V\) 的截断图版本在缩小邻域后等价。定义本身不要求 locally closed graph；SMSR 自动给出 \(S\cap U=\{\bar x\}\)。[S2, A]

\[
\boxed{SMSR\iff MSR+\bar x\text{ 是 }S\text{ 的孤立点}} \tag{1.4}
\]

\[
F\text{ SMSR}
\iff F^{-1}\text{ isolatedly calm}, \tag{1.5}
\]

且 exact moduli 相同。[S2, A；(1.4) 也直接由定义得到，C]

SMR 同时蕴含 MR 与 SMSR；但 MR 与 SMSR 互不包含，一般 set-valued 情形甚至 MR+SMSR 也未必 SMR，见 §7。

## 2. Inverse-side stability 与 punctual openness

### 2.1 Aubin/Lipschitz-like property

对 \(G:P\rightrightarrows X\) 与 \((\bar p,\bar x)\in\operatorname{gph}G\)，Aubin property around 是：存在 \(V\ni\bar p,U\ni\bar x,L\ge0\)，

\[
G(p_1)\cap U\subset G(p_2)+L\,d(p_1,p_2)\mathbb B
\quad(\forall p_1,p_2\in V). \tag{Aubin}
\]

最小 \(L\) 为 \(\operatorname{lip}G(\bar p\mid\bar x)\)。它是 two-parameter、around/uniform 性质；\(F\) MR \(\Leftrightarrow F^{-1}\) Aubin。[S1, A]

### 2.2 Calmness 与 isolated calmness

Calmness at \((\bar p,\bar x)\)：存在 \(V\ni\bar p,U\ni\bar x,L\ge0\)，

\[
G(p)\cap U\subset G(\bar p)+L\,d(p,\bar p)\mathbb B
\quad(\forall p\in V). \tag{calm}
\]

等价地，对 \(x\in G(p)\cap U\)，
\(d(x,G(\bar p))\le Ld(p,\bar p)\)。可行 \(L\) 的下确界记
\(\operatorname{clm}G(\bar p\mid\bar x)\)。它固定 base parameter，不保证 \(G(p)\ne\varnothing\)。[S3, A]

Isolated calmness：

\[
G(p)\cap U\subset \bar x+L\,d(p,\bar p)\mathbb B
\quad(\forall p\in V). \tag{icalm}
\]

它等价于 calmness 加 \(G(\bar p)\cap U=\{\bar x\}\)（缩小 \(U\) 后模相同）。[S2, A/C]
可行 \(L\) 的下确界是 isolated-calmness modulus，并由 (1.5) 精确等于 inverse mapping 的 strong-subregularity modulus。

Aubin \(\Rightarrow\) calm；isolated calm \(\Rightarrow\) calm；Aubin 与 isolated calm 互不包含，见 §7。

### 2.3 Metric semiregularity / hemiregularity（固定 \(x=\bar x\)）

这是把 MR 的 \(x\) 固定；MSR 则固定 \(y\)。文献中 “semiregularity” 有命名冲突，Uderzo 为避免冲突使用 hemiregularity。[S4, A]

Punctual/hemiregular 版本：

\[
d(\bar x,F^{-1}(y))\le\kappa d(y,\bar y)
\qquad(\forall y\in V). \tag{HREG}
\]

它精确等价于：

- punctual linear openness：
  \(B(\bar y,ct)\subset F(B(\bar x,t))\)；
- \(F^{-1}\) 在 \((\bar y,\bar x)\) Lipschitz lower semicontinuous：
  \(F^{-1}(y)\cap B(\bar x,Ld(y,\bar y))\ne\varnothing\)。

可行 \(\kappa\) 的下确界为 hemiregularity modulus，并等于 punctual openness bound 的倒数（采用同一球 convention）。[S1, A]

更 uniform 的版本是

\[
d(\bar x,F^{-1}(y))\le\kappa d(y,F(\bar x)). \tag{UHREG}
\]

当 \(F(\bar x)\) 在 \(\bar y\) 附近局部单值时两者一致；一般 UHREG 强于 HREG。[S4, A]

MR \(\Rightarrow\) UHREG \(\Rightarrow\) HREG，首个蕴含严格。MSR 与 HREG 互不包含；甚至 MSR+HREG 也不推出 MR（§7）。所以 semiregularity 不是 MR–MSR 一维轴上的中点。

## 3. Hölder、higher-order、gauge / φ regularity

### 3.1 两套互为倒数的 exponent convention

本项目 RL 初稿采用 **residual-exponent convention (R)**：

\[
d(x,S)\le \rho\,r_F(x)^q. \tag{R-q}
\]

此 convention 下，对小残差 \(r<1\)，\(q\) 越大性质越强：

- \(0<q<1\)：Hölder/fractional subregularity，弱于 \(q=1\)；
- \(q=1\)：ordinary MSR；
- \(q>1\)：higher-order/power MSR，强于 linear，且并不退化。[S5, S6, A]

另一批文献采用 **distance-exponent convention (D)**：

\[
\tau\,d(x,S)^p\le r_F(x). \tag{D-p}
\]

它与 (R-q) 的换算为 \(q=1/p\)，\(\rho=\tau^{-q}\)。S7 的 “\(p\)-order strong subregularity” 指 (D-p)，不是 (R-p)。任何 \(\gamma q\) 组合前必须先统一 convention。[S7, A]

### 3.2 Metric \(q\)-(sub)regularity

对 \(q>0\)：

\[
\begin{aligned}
q\text{-MR}:&\ d(x,F^{-1}(y))\le\kappa d(y,F(x))^q
&&(x\in U,y\in V),\\
q\text{-MSR}:&\ d(x,S)\le\kappa r_F(x)^q
&&(x\in U),\\
q\text{-SMSR}:&\ d(x,\bar x)\le\kappa r_F(x)^q
&&(x\in U).
\end{aligned} \tag{3.1}
\]

各性质的 exact modulus 仍取 (3.1) 中可行 \(\kappa\) 的下确界。Inverse-side 分别是 \(F^{-1}\) 的 \(q\)-Hölder Aubin、\(q\)-calm、\(q\)-isolated calm，且按同一 upper-constant convention 模相等。[S5, S6, A/C]

对 \(0<q\le1\)，\(q\)-MR 精确等价于：

- \(F^{-1}\) pseudo-Hölder/Aubin of order \(q\)；
- openness at order \(p=1/q\)：存在 \(U,V,\varepsilon,c>0\)，对
  \((x,y)\in\operatorname{gph}F\cap(U\times V)\)、\(0<t<\varepsilon\)，
  \[
  B(y,c\,t^{1/q})\subset F(B(x,t)). \tag{H-open}
  \]

若 \(\operatorname{lop}_{1/q}\) 是可行 \(c\) 的上确界，则在一致球 convention 下
\[
\operatorname{reg}_{q}F=(\operatorname{lop}_{1/q}F)^{-q}
=\operatorname{lip}_{q}F^{-1}.
\]
[S8, A；一般局部形式与模换算也可由定义证明，C]

关键退化：通常 two-variable 定义下 \(q>1\) metric **regularity** 只允许局部常值型非平凡性，因此没有有用的高阶 MR 理论；但 \(q>1\) MSR/SMSR 完全可以非平凡。[S6, A]

若 \(q_2>q_1>0\)，在残差充分小的邻域中

\[
q_2\text{-MSR}\Rightarrow q_1\text{-MSR},\qquad
q_2\text{-SMSR}\Rightarrow q_1\text{-SMSR}, \tag{3.2}
\]

通常严格。对 \(0<q_1<q_2\le1\) 的 \(q\)-MR 同理。[S5, A/C]
并且在 \(q_2\)-estimate 真正高阶时，降到 \(q_1<q_2\) 的 exact upper modulus 可能等于 \(0\)；因此“性质蕴含”不等于正模数之间存在非退化比较。[C]

### 3.3 Gauge / φ / \(g\)-subregularity

设 \(\varphi:[0,\infty)\to[0,\infty)\) 单调递增、\(\varphi(0)=0\)、\(\varphi(t)>0\)（\(t>0\)）。常用定义：

\[
d(x,S)\le\kappa\,\varphi(r_F(x))\qquad(x\in U). \tag{φ-MSR}
\]

Kruger 用 lower-rate 形式
\(\tau d(x,S)\le\varphi(r_F(x))\)，在主要微分判据中进一步假设 \(\varphi\) 连续可微、\(\varphi'(t)>0\)。其精确 lower-rate 是

\[
{}^sr_{\varphi}[F](\bar x,\bar y)
=\liminf_{x\to\bar x,\,x\notin S}
\frac{\varphi(r_F(x))}{d(x,S)}. \tag{3.3}
\]

\(\varphi(t)=t\) 回到 MSR；\(\varphi(t)=t^q\) 回到 power/Hölder MSR。[S5, A]

更一般的 \(g\)-subregularity 用各向异性的 \(g(y)\)：

\[
\tau d(x,S)\le g(y)\quad(x\in U,\ y\in F(x)), \tag{g-MSR}
\]

其中典型假设为 \(g(\bar y)=0\)、在 \(\bar y\) 连续、离开 \(\bar y\) 局部 Lipschitz，并满足 positivity/coercivity。[S5, A]

Gauge 之间没有天然全序。若 \(\varphi_1(t)\le C\varphi_2(t)\) 在 \(0\) 附近成立，则
\(\varphi_1\)-MSR \(\Rightarrow\varphi_2\)-MSR；若二者互不以常数倍支配，则一般无 implication。[C]

Gauge-MR 可定义为
\(d(x,F^{-1}(y))\le\kappa\varphi(d(y,F(x)))\)，inverse 是 \(\varphi\)-Aubin；严格递增时 openness 用广义逆 \(\varphi^{-1}\) 描述。术语尚不统一，引用时必须给公式。

## 4. Error bounds 与 strong error bounds

### 4.1 标量 EB

对 \(f:X\to\mathbb R\cup\{+\infty\}\)，令
\(S_f:=\{x:f(x)\le0\}\)。Local error bound at \(\bar x\in S_f\)：

\[
d(x,S_f)\le\kappa[f(x)]_+\qquad(x\in U). \tag{EB}
\]

Hölder/gauge EB 把右侧换成
\(\kappa[f(x)]_+^q\) 或 \(\kappa\varphi([f(x)]_+)\)。exact lower-rate：

\[
\operatorname{Er}f(\bar x)
=\liminf_{x\to\bar x,\,f(x)>0}
\frac{[f(x)]_+}{d(x,S_f)}. \tag{4.1}
\]

[S5, A]

MSR 正是 residual \(r_F\) 的 EB：

\[
d(x,S)\le\kappa r_F(x). \tag{4.2}
\]

\(\varphi\)-MSR 同理。注意：即使 \(\operatorname{gph}F\) 闭，
\(x\mapsto r_F(x)\) 也未必 lower semicontinuous；完整 slope 理论因此使用图上的二变量函数或其 lsc envelope，不能无条件套用单变量 lsc theorem。[S5, A]

### 4.2 Strong EB / sharp minimum

“Strong error bound”命名并不统一。本文采用 isolated 版本：

\[
d(x,\bar x)\le\kappa[f(x)]_+\qquad(x\in U). \tag{SEB}
\]

它等价于 EB 加 \(S_f\cap U=\{\bar x\}\)。对 mapping residual，它正是 SMSR；SMSR 还等价于 \(\bar x\) 是 \(x\mapsto r_F(x)\) 的 local sharp minimizer。[S2, A]

对 complete metric spaces 上 lsc EB 模型，exact EB lower-rate 等于 uniform strict outer **nonlocal** slope；无完备性/lsc 时只有单向估计。[S5, Theorem 3.1, A]

SMSR 有更简单的精确率：

\[
|F|^{\downarrow}(\bar x\mid\bar y)
:=\liminf_{x\to\bar x,\,x\ne\bar x}
\frac{r_F(x)}{d(x,\bar x)}. \tag{4.3}
\]

\[
SMSR\iff |F|^{\downarrow}>0,\qquad
|F|^{\downarrow}\,
\operatorname{subreg}_{\rm strong}F=1. \tag{4.4}
\]

[S2, A]

## 5. Directional、relative、partial 与 uniform variants

### 5.1 Directional metric (sub)regularity：两种不同对象

**图方向版本**：给定 \((u,v)\)，存在 \(\delta,\kappa>0\)，对
\(t\in[0,\delta]\)、\((u',v')\in B((u,v),\delta)\)，且测试点距图不超过 \(O(t)\)，

\[
d(\bar x+tu',F^{-1}(\bar y+tv'))
\le\kappa d(\bar y+tv',F(\bar x+tu')). \tag{DMR-gph}
\]

方向 MSR 固定 \(\bar y\)，只让 \(x=\bar x+tu'\) 沿 \(u\) 变化。[S9, A]

\[
MR\iff DMR\text{ in }(0,0)
\Rightarrow DMR\text{ in every nonzero direction}; \tag{5.1}
\]

\[
MSR\iff DMSR\text{ in }0
\iff DMSR\text{ in every nonzero }u. \tag{5.2}
\]

DMR in \((u,0)\Rightarrow\) DMSR in \(u\)。非切向方向可真空成立。[S9, Lemma 8, A]

**输出残差方向版本**：给定 \(w\in Y\)，只对满足

\[
y\in F(x)+\operatorname{cone}B(w,\delta)
\]

的残差方向要求 MR。普通 MR 推出所有 \(w\)-directional MR；当方向锥含 \(0\) 的邻域时退化为 MR。[S10, A]

两者限制对象不同（图切向 \((u,v)\) vs. output residual cone），不可因同名而等同。

### 5.2 Relative metric regularity

给定 \(V\subset X\times Y\)，记 \(V_y:=\{x:(x,y)\in V\}\)。一种严格定义是：

\[
d\big(x,F^{-1}(y)\cap\overline{V_y}\big)
\le\kappa d(y,F(x)) \tag{RMR}
\]

对所有
\((x,y)\in V\cap B((\bar x,\bar y),\varepsilon)\) 且
\(d(y,F(x))<\varepsilon\) 成立。[S10, A]

输出方向 MR 是适当 \(V\) 的特例。由于左端也限制了解，任意缩小 \(V\) 不一定单调“变弱”；不能笼统写 ordinary MR \(\Rightarrow\) arbitrary relative MR。

### 5.3 Partial regularity 与 uniformity in parameters

对 \(F:X\times P\rightrightarrows Y\)，令 \(F_p(x):=F(x,p)\)。With respect to \(x\), uniformly in \(p\) 的 MR：

\[
d(x,F_p^{-1}(y))\le\kappa d(y,F_p(x))
\quad(\forall x\in U,p\in V,y\in W). \tag{PMR}
\]

Partial Aubin/open 定义类似，且在同一个 parameter slice 上保持三联等价与 reciprocal moduli。[S1, Definition 2.5, A]

它不等于把 \((x,p)\) 当整体变量的 full MR。对标准 product metric，PMR **推出** full MR：full inverse 允许保持同一个 \(p\)，故其距离不大于 slice inverse distance。反向一般失败，例如 \(F(x,p)=p\) 作为 \((x,p)\mapsto y\) 可由改变 \(p\) 获得 full MR，但每个固定 \(p\) 的 \(x\)-slice 是常值映射，非 partial MR。[C]

### 5.4 Robinson stability 与 partial MSCQ

对 \(g(p,x)\in C\)，令
\(\Gamma(p):=\{x:g(p,x)\in C\}\)。Robinson stability：

\[
d(x,\Gamma(p))\le\kappa d(g(p,x),C)
\quad(\forall p\in V,x\in U). \tag{RS}
\]

它是 \(x\mapsto g(p,x)-C\) 对附近 \(p,x\) 的 **uniform subregular/error-bound**，不是 ordinary two-target MR。[S11, A]

Partial MSCQ 只要求每个附近 feasible \((p,x)\) 的 slice 在 \((x,0)\) MSR，但邻域与模 \(\kappa_{p,x}\) 可依赖 \((p,x)\)。所以

\[
RS\Rightarrow partial\ MSCQ, \tag{5.3}
\]

反向一般失败（缺 uniform modulus/neighborhood）。[S11, A]

### 5.5 “Subregularity around”

普通 MSR/SMSR 只在 reference graph point。较新的 “(strong) subregularity around \((\bar x,\bar y)\)” 要求：存在图邻域 \(W\) 与同一 \(\kappa\)，使 \(F\) 在每个
\((x,y)\in\operatorname{gph}F\cap W\) 都以该 \(\kappa\) (strongly) subregular。inverse 对应 calmness/isolated calmness around nearby graph points。[S12, A]

它强于 at-reference 版本；不要把 around 当修辞。有限维 polyhedral multifunction 在每个图点附近 uniform MSR/calm，但 strong 版本还需 relevant inverse fibers 局部隔离。

## 6. 集合族 linear regularity / transversality

对闭集合族 \(\Omega_1,\ldots,\Omega_m\subset X\)，
\(\Omega:=\cap_i\Omega_i\ne\varnothing\)：

- **global linear regularity**：
  \[
  d(x,\Omega)\le\kappa\max_i d(x,\Omega_i)\quad(\forall x\in X); \tag{LR}
  \]
- **bounded linear regularity**：每个 bounded \(B\subset X\) 有自己的 \(\kappa_B\)；
- **local linear regularity at \(\bar x\in\Omega\)**：只在 \(B(\bar x,\delta)\) 成立。

对两个集合，local LR 就是 subtransversality：

\[
\alpha d(x,A\cap B)\le\max\{d(x,A),d(x,B)\}
\quad(x\text{ near }\bar x). \tag{ST}
\]

它等价于标准集合映射的 MSR。更 robust 的 transversality 要求 (ST) 对 \(A,B\) 的所有小平移 uniform 成立，等价于该集合映射的 MR。[S13, A]

\[
\text{global LR}\Rightarrow\text{bounded LR}
\Rightarrow\text{local LR at every point}; \tag{6.1}
\]

\[
\text{transversality}\Rightarrow\text{subtransversality}, \tag{6.2}
\]

且 (6.2) 严格：\(A=B=\mathbb R\times\{0\}\) 在原点 subtransversal，但不 transversal，因为小的相反平移可使交集为空。[S13, Example 2, A]

若 \(A,B\) 闭凸且在交集每点都 subtransversal，则 boundedly linearly regular；一般非凸情形不能省 uniform/compactness 论证。[S14, A]

“Linear regularity of sets”不是任意 mapping 的 MR；只有在指定 product/difference set-valued encoding 下才等价。

## 7. 严格蕴含与 non-comparability witnesses

以下都在参考点 \((0,0)\)，只证明逻辑 strictness；完整条目应由 B/C 重算。

### 7.1 核心四性质

1. **MR \(\Rightarrow\) MSR，严格。** \(F(x)=|x|\) 是 SMSR（故 MSR），但非 MR：任意负 \(y\) 的逆像为空。
2. **SMSR \(\Rightarrow\) MSR，严格。** 常值 \(F(x)=0\) 的 \(S=\mathbb R\)，MSR 左端恒零；但 \(0\) 非孤立，故不 SMSR。
3. **MR 与 SMSR 互不包含。**
   - \(F:\mathbb R^2\to\mathbb R,\ F(x_1,x_2)=x_1\) 是 surjective linear、故 MR；零集为直线，故不 SMSR。
   - \(F(x)=|x|\) SMSR 但不 MR。
4. **MR+SMSR 不推出 SMR（set-valued）。**
   \[
   F(x)=\{-x,x\}
   \]
   同时 MR 与 SMSR，模均为 1；但
   \(F^{-1}(y)=\{-y,y\}\) 在小 \(y\ne0\) 二值，故不 SMR。[S2, explicit counterexample, A]
5. **Strictly differentiable single-valued 特例。** 若 derivative range closed：
   MR \(\iff Df(\bar x)\) surjective；
   SMSR \(\iff Df(\bar x)\) injective；
   SMR \(\iff Df(\bar x)\) invertible。
   因而此类映射 MR+SMSR \(\Rightarrow\) SMR；不可外推到 set-valued 情形。[S2, Proposition 1.2, A]

### 7.2 Aubin/calm/isolated calm

1. **Aubin \(\Rightarrow\) calm，严格。**
   \(G(t)=t\sin(1/t)\)（\(t\ne0\)），\(G(0)=0\)，有
   \(|G(t)|\le|t|\)，故 calm；其导数在 0 附近无界，故不局部 Lipschitz/Aubin。[C]
2. **Isolated calm \(\Rightarrow\) calm，严格。**
   常值集合映射 \(G(t)=[-1,1]\) 在 \((0,0)\) calm（模 0），但 base fiber 非局部单点，故不 isolated calm。[C]
3. **Aubin 与 isolated calm 互不包含。**
   上述常值区间映射 Aubin 但不 isolated calm；上述振荡单值映射 isolated calm 但不 Aubin。[C]

### 7.3 Semiregularity 与 subregularity

1. **UHREG 严格强于 HREG**：令
   \(F(0)=\{0\}\cup\{1/n:n\in\mathbb N\}\)，而 \(F(x)=\{x\}\)（\(x\ne0\)）。
   Identity branch 给 \(d(0,F^{-1}(y))\le |y|\)，故 HREG。取
   \(y_n=1/n+1/n^3\)，则
   \[
   d(0,F^{-1}(y_n))\asymp 1/n,\qquad
   d(y_n,F(0))\le1/n^3,
   \]
   故 UHREG 失败。该 graph 是闭的。[C]
2. **MSR 不推出 HREG**：\(F(x)=|x|\)，负 \(y\) 不可达。
3. **HREG 不推出 MSR**：\(F(x)=\{x,x^2\}\)。因为 branch \(x=y\)，
   \(d(0,F^{-1}(y))\le|y|\)；但 \(S=\{0\}\) 且小 \(x\) 时
   \(r_F(x)=\min\{|x|,x^2\}=x^2\)，MSR 失败。
4. **MSR+HREG 不推出 MR**：\(F(x)=\{x,0\}\)。HREG 由 branch \(x=y\) 得到；MSR 因 \(S=\mathbb R\) 平凡成立。取 \(y>0,x=\sqrt y\)，
   \[
   d(x,F^{-1}(y))\asymp\sqrt y,\qquad d(y,F(x))=y,
   \]
   故 MR 失败。[C]

### 7.4 Exponent strictness

给定 \(q_*>0\)，令 \(F(x)=|x|^{1/q_*}\)。则

\[
d(x,S)=|x|,\qquad r_F(x)=|x|^{1/q_*},
\]

故它满足 (R)-\(q\)-SMSR 当且仅当 \(q\le q_*\)。这证明 (3.2) strict，并给 sharp exponent witness。[C]

## 8. Derivative、coderivative 与 slope 判据

本节采用正齐次映射的标准 norm-like quantities：
\[
\|H\|^+:=\sup_{\|u\|\le1}\sup_{v\in H(u)}\|v\|,
\qquad
\|H\|^-:=\sup_{\|u\|\le1}d(0,H(u)),
\]
并对空值使用 \(d(0,\varnothing)=+\infty\)。不同文献的 “inner/outer norm” 上下标排版略异，应用 exact-modulus formula 前应核对其定义。[S2, A]

### 8.1 MR / Aubin

**有限维、locally closed graph**：Mordukhovich limiting coderivative criterion：

\[
F\text{ MR}
\iff [\,0\in D^*F(\bar x,\bar y)(y^*)\Rightarrow y^*=0\,], \tag{8.1}
\]

并可用 \(D^*F(\bar x,\bar y)^{-1}\) 的 outer norm 表示 exact modulus。对 \(G\) 的 Aubin 性质，核条件为
\(D^*G(\bar p,\bar x)(0)=\{0\}\)。[S3/S15, A]

**无限维 Asplund**：不能无条件照抄 (8.1)。一个完整版本要求 closed graph around reference、mixed coderivative kernel condition 加 PSNC（partial sequential normal compactness）；有限维 PSNC 自动成立。[S16, Theorem 2.1, A]

**Graphical derivative neighborhood criterion**：对 locally closed graph 的 Banach multifunction，邻近图点的
\(DF(x\mid y)^{-1}\) surjection/inner-norm bound 给出 MR；finite-dimensional domain 时成为必要/精确条件，两边有限维还有 exact formulas。[S17, A]

**Strictly differentiable single-valued \(f\)**：
MR iff \(Df(\bar x)\) surjective；
SMR iff \(Df(\bar x)\) boundedly invertible；exact moduli 是相应 inverse inner/operator norm。[S2, A]

### 8.2 MSR / calm

MSR 没有对一般非凸 multifunction 有效的简单单点 limiting-coderivative iff。可靠层级：

1. 总是精确的 ratio：
   \[
   {}^sr[F](\bar x,\bar y)
   =\liminf_{x\to\bar x,\,x\notin S}
   \frac{r_F(x)}{d(x,S)};
   \]
   MSR iff 此量 \(>0\)，upper modulus 为倒数。[S5, A]
2. Complete spaces + locally closed graph：二变量 uniform strict nonlocal slope 给 exact characterization。[S5, A]
3. Asplund/convex：Fréchet subdifferential slopes、outer coderivatives 给一系列 sufficient/necessary 条件；箭头可逆性依 lsc、Asplund fuzzy sum rule、凸性或 smoothness，不能压成无假设 point test。[S5, A]
4. 有限维 directional coderivative：FOSCMS 等 directional limiting coderivative 条件是 sufficient；普通 MR criterion 是更强 special case。[S9, A]

Calmness 通过 inverse 翻译。

### 8.3 SMSR / isolated calm

一般度量空间：steepest displacement rate (4.3) 是精确 iff。[S2, A]

Graphical derivative 总有

\[
\|DF(\bar x\mid\bar y)^{-1}\|^+
\le\operatorname{subreg}_{\rm strong}F(\bar x\mid\bar y). \tag{8.2}
\]

若 \(X\) finite-dimensional，

\[
SMSR\iff DF(\bar x\mid\bar y)^{-1}(0)=\{0\}; \tag{8.3}
\]

若 \(X,Y\) 都 finite-dimensional，(8.2) 为 modulus equality。[S2, Theorem 5.1, A]

Fréchet coderivative：当 \(X\) finite-dimensional，给 SMSR modulus 上界；局部凸图时为 equality。一般非凸图可极不 sharp：\(F(x)=\{x,-x\}\) 的该上界为 \(+\infty\)，真实 SMSR modulus 为 1。[S2, Theorem 5.2, A]

Power graphical derivative \(D_pF\) 由

\[
(\bar x+t_ku_k,\bar y+t_k^pv_k)\in\operatorname{gph}F
\]

定义，刻画的是 (D)-\(p\) strong subregularity
\(\tau\|x-\bar x\|^p\le r_F(x)\)。有限维 \(X,Y\)：

\[
(D)\text{-}p\text{ SMSR}
\iff D_pF(\bar x,\bar y)^{-1}(0)=\{0\}, \tag{8.4}
\]

模由 \(p\)-homogeneous norm 精确给出。换成本项目 (R)-\(q\) 时须代 \(p=1/q\)。[S7, A]

### 8.4 线性、polyhedral、convex、semialgebraic

对 bounded linear \(A:X\to Y\)：

- MR iff \(A\) surjective；
- MSR iff \(\operatorname{rge}A\) closed（有限维自动）；
- SMSR iff \(A\) injective 且 range closed；
- SMR iff \(A\) bijective。

Exact moduli 是 quotient/inverse 的 inner/outer norm。[S1, S2, A/C]

有限维 graph 为有限个 convex polyhedra 并集的 multifunction：

- 在每个图点具有 MSR/calmness；
- SMSR iff reference inverse point isolated；
- MR/SMR 仍需额外 surjectivity/local uniqueness。[S2, S12, A]

局部凸图下，SMSR 的 Fréchet-coderivative modulus equality 成立；凸 EB 模型有较简单的 neighborhood subgradient-slope tests。[S2, S5, A]

有限维 closed-graph semialgebraic multifunction 在局部/compact regime 具有某个 Hölder subregularity exponent；exponent 依对象，不是 universal number。若再有 openness 与 locally closed range，可得 Hölder MR 与 inverse pseudo-Hölder 等价。[S8, A]

## 9. 可直接并入总 atlas 的关系边

### 9.1 Exact equivalences

- \(MR(F)\iff Aubin(F^{-1})\iff linear\ openness\ around(F)\)，模按 (1.1)。
- \(MSR(F)\iff calm(F^{-1})\iff residual\ EB\)。
- \(SMSR(F)\iff isolated\ calm(F^{-1})\iff MSR+isolated\ inverse\ point\iff strong\ residual\ EB\)。
- \(SMR(F)\iff MR+single\text{-}valued\ inverse\ localization\)。
- \(HREG(F)\iff punctual\ linear\ openness(F)\iff Lipschitz\ lower\ semicontinuity(F^{-1})\)。
- \(q\)-MR \(\iff q\)-Aubin of inverse \(\iff\) openness order \(1/q\)（同一 exponent convention）。
- Set-pair local LR \(\iff\) subtransversality \(\iff\) MSR of standard set mapping；transversality \(\iff\) MR of that mapping。

### 9.2 Strict implications

- \(SMR\Rightarrow MR\Rightarrow MSR\)，均 strict。
- \(SMR\Rightarrow SMSR\Rightarrow MSR\)，均 strict。
- \(Aubin\Rightarrow calm\)，strict；\(isolated\ calm\Rightarrow calm\)，strict。
- \(MR\Rightarrow UHREG\Rightarrow HREG\)，一般 strict。
- \(q_2\)-MSR/SMSR \(\Rightarrow q_1\)-MSR/SMSR for \(q_2>q_1>0\)，strict。
- \(RS\Rightarrow partial\ MSCQ\)，一般 strict。
- transversality \(\Rightarrow\) subtransversality，strict。

### 9.3 Non-comparability / failed conjunctions

- MR \(\perp\) SMSR；SMR 位于其严格交集内。
- MR+SMSR \(\not\Rightarrow\) SMR for general set-valued maps。
- Aubin \(\perp\) isolated calm。
- MSR \(\perp\) HREG；MSR+HREG \(\not\Rightarrow\) MR。
- partial-in-\(x\) MR uniformly in \(p\Rightarrow\) full MR in \((x,p)\)（标准 product metric）；反向一般失败。
- ordinary MR 与 arbitrary relative-to-\(V\) MR 不能仅按“限制测试点”推箭头，因为 relative definition 同时限制解。
- 两个没有 asymptotic constant domination 的 gauges 一般不可比。

## 10. Assumption audit

| Claim | 已核验假设 | 不可擅删 |
|---|---|---|
| MR–Aubin–linear openness | 标准 neighborhood definitions | 纯定义等价不需把 closed graph 混入 |
| finite-dimensional Mordukhovich criterion | locally closed graph | infinite-dimensional 不能照抄 |
| Asplund coderivative iff Aubin/MR | closed graph + PSNC + mixed coderivative | PSNC 在无限维不是装饰 |
| MR graphical-derivative exact test | locally closed graph；exactness需 finite-dimensional assumptions | 一般 Banach 先只有 estimate/sufficiency |
| SMSR \(DF^{-1}(0)=\{0\}\) iff | finite-dimensional domain；exact modulus 再需 \(X,Y\) finite | 无限维 converse 可失败 |
| SMSR Fréchet-coderivative equality | finite-dimensional domain + locally convex graph | 一般非凸只有一侧且可极不 sharp |
| MSR exact nonlocal-slope test | complete spaces + locally closed graph/lsc model | \(r_F\) 不必 lsc |
| Fréchet subdifferential criteria | Asplund + lsc/local closedness，或 convex/smooth substitute | fuzzy sum rule 关键 |
| \(q>1\) MR degeneracy | ordinary two-variable residual-exponent convention | 不适用于 fixed-target MSR |
| power graphical derivative iff | S7 的 distance-exponent convention + finite dimensions | 与本项目 exponent 互为倒数 |
| directional coderivative iff DMR | finite-dimensional + closed graph + graph-direction definition | 不适用于 output-cone definition |
| polyhedral SMSR iff isolated | finite-dimensional finite union convex polyhedral graphs | 不代表 MR/SMR 自动 |

## 11. 术语冲突 / 待核实

1. **Semiregularity**：至少有固定 \(x\) 的 hemiregularity 与其他书中同名概念；总稿必须写公式。
2. **Strong regularity**：Robinson 原始广义方程形式与现代 SMR localization 需按模型对齐。
3. **Hölder order**：residual exponent 与 distance exponent 互为倒数。
4. **Strong error bound**：可能指 isolated、global 或 uniform EB；本文只用 (SEB)。
5. **Directional regularity**：graph direction、output residual direction、relative cone 不可混成一节点。
6. **Relative regularity**：有的定义只限测试点，有的同时限 inverse solutions；关系箭头随定义变。
7. **Subregularity around**：不是经典 at-reference MSR 的同义词。
8. **Gauge regularity**：是否含外部常数、是否要求 concave/\(C^1\)/strictly increasing，各文献不同。

## 12. 交给 Subagent B 的优先 gap pairs

1. MR vs SMSR：填满四个逻辑区域，并区分 single-/set-valued。
2. MR+SMSR vs SMR：寻找自然的 branch crossing / nonunique inverse localization。
3. MSR vs HREG：寻找 optimization/normal-cone/constraint-system 自然对象。
4. Aubin vs isolated calm：用解映射填四象限。
5. Linear MSR vs \(q>1\) MSR：sharp exponent family；再找仅有非幂 gauge 的例子。
6. Asymptotically incomparable gauges：显式 residual profiles。
7. At-reference MSR vs MSR around / RS：modulus blow-up 导致 pointwise 但不 uniform。
8. Ordinary vs directional MR：非切向真空、部分方向、所有非零方向但零方向失败。
9. Relative vs ordinary MR：分别填两侧 implication failure。
10. Local/bounded/global LR：凸、非凸、无限维 strictness。
11. Polyhedral/semialgebraic：linear EB、仅 Hölder EB、sharp exponent、无 SMR。
12. 无限维：surjective/injective/closed-range 拆分 MR、MSR、SMSR、SMR。

## 13. Primary-source register

- **S1 [A]** M. Durea, R. Strugariu, *Openness Stability and Implicit Multifunction Theorems*, Definitions 2.1, 2.3, 2.5 and Proposition 2.2: https://arxiv.org/html/1102.0415v2
- **S2 [A]** R. Cibulka, A. L. Dontchev, A. Y. Kruger, *Strong Metric Subregularity of Mappings in Variational Analysis and Optimization*: https://arxiv.org/html/1701.02078v1
- **S3 [A]** H. Gfrerer, J. V. Outrata, *On Lipschitzian Properties of Implicit Multifunctions*: https://arxiv.org/html/1611.08260v1
- **S4 [A]** A. Uderzo, *An Implicit Multifunction Theorem for the Hemiregularity of Mappings*: https://arxiv.org/html/1703.10552v2
- **S5 [A]** A. Y. Kruger, *Nonlinear Metric Subregularity*: https://arxiv.org/html/1502.06159v2
- **S6 [A]** B. S. Mordukhovich, W. Ouyang, *Higher-Order Metric Subregularity and Its Applications*: https://arxiv.org/html/1507.04825v1
- **S7 [A]** A. Y. Kruger et al., *Isolated Calmness and Sharp Minima via Hölder Graphical Derivatives*: https://arxiv.org/html/2106.08149v2
- **S8 [A]** J. H. Lee, T.-S. Pham, *Openness, Hölder Metric Regularity, and Hölder Continuity Properties of Semialgebraic Set-Valued Maps*: https://arxiv.org/abs/2004.02188 ; full text https://optimization-online.org/wp-content/uploads/2020/04/7726.pdf
- **S9 [A]** Graph-direction regularity, Definition 7, Lemma 8, Theorem 9 in S3: https://arxiv.org/html/1611.08260v1
- **S10 [A]** N. H. Huynh, M. Théra, *Directional Metric Regularity of Multifunctions*: https://arxiv.org/html/1304.7748v1
- **S11 [A]** H. Gfrerer, B. S. Mordukhovich, *Robinson Stability of Parametric Constraint Systems*: https://arxiv.org/html/1609.02238v2
- **S12 [A]** H. Gfrerer, J. V. Outrata, *On the Isolated Calmness Property of Implicitly Defined Multifunctions*: https://arxiv.org/pdf/2208.01331
- **S13 [A]** A. Y. Kruger, D. R. Luke, N. H. Thao, *About Subtransversality of Collections of Sets*: https://arxiv.org/html/1611.04787v2
- **S14 [A]** A. Y. Kruger, D. R. Luke, N. H. Thao, *Set Regularities and Feasibility Problems*: https://arxiv.org/html/1602.04935v1
- **S15 [A]** Finite-dimensional Mordukhovich criterion as used in S3, including directional extension: https://arxiv.org/html/1611.08260v1
- **S16 [A]** B. S. Mordukhovich, O. Nguyen, *Subdifferential Calculus for Ordered Set-Valued Mappings*, generic Asplund PSNC + mixed-coderivative characterization in Theorem 2.1: https://arxiv.org/pdf/2410.11362
- **S17 [A]** A. L. Dontchev, M. Quincampoix, N. Zlateva, *Aubin Criterion for Metric Regularity*: https://www.heldermann-verlag.de/jca/jca13/jca0526_b.pdf
- **S18 [A]** G. Li, B. S. Mordukhovich, *Hölder Metric Subregularity with Applications to Proximal Point Method*: https://optimization-online.org/wp-content/uploads/2012/02/3340.pdf
- **S19 [B]** H. Frankowska, M. Quincampoix, official publisher page: https://link.springer.com/article/10.1007/s10107-010-0401-7

### Evidence-depth note

定义、核心等价、strictness source examples 与假设边界主要由 S1–S18 全文支撑，证据深度 [A]。S19 只作历史定位，标 [B]，未单独支撑任何带精确量词的结论。文中 [C] witnesses/implications 均为显示公式的直接代入或邻域缩小；后续 C agent 应独立重算。
