# Subagent B(MAX)：set-valued / normal-cone / projection gap examples

> 状态：B 阶段显式例子目录；供 C 独立重算，**不是** synthesis。
> 日期：2026-09-01。除特别说明外，空间带 Euclidean/Hilbert 范数，
> \(d(z,\varnothing)=+\infty\)，正则性参考点逐条给出。

## 0. 统一约定、来源与防误读规则

对 \(F:H\rightrightarrows H\)，\((x,u),(y,v)\in\operatorname{gph}F\) 时记
\(a=x-y,b=u-v\)。若 \(F\) 的值域不是 \(H\)，则
\(J_{\lambda F}=(I+\lambda F)^{-1}\) 与 \(R_{\lambda F}\) **类型不匹配，记 N/A**；
这不是“算不出”。集合对统一用

\[
\Phi_{A,B}(x):=(A-x)\times(B-x),
\qquad \|(\xi,\eta)\|_{\max}:=\max\{\|\xi\|,\|\eta\|\}.
\tag{0.1}
\]

于是 \(\Phi_{A,B}^{-1}(0,0)=A\cap B\)，且 primary source 的 Proposition 2 给出

\[
\{A,B\}\text{ transversal}\iff \Phi_{A,B}\text{ MR},\qquad
\{A,B\}\text{ subtransversal}\iff \Phi_{A,B}\text{ MSR}.
\tag{0.2}
\]

**Primary/authoritative locators.**

- [Minty 1962：maximal monotonicity 与 full-range resolvent](https://projecteuclid.org/journals/duke-mathematical-journal/volume-29/issue-3/Monotone-nonlinear-operators-in-Hilbert-space/10.1215/S0012-7094-62-02933-2.short)。
- [Rockafellar 1970：proper lsc convex subdifferential 的 maximal monotonicity](https://msp.org/pjm/1970/33-1/p19.xhtml)。
- [Bauschke--Moffat--Wang 2011：resolvent/firmly-nonexpansive 字典](https://arxiv.org/abs/1101.4688)。
- [Kruger--Luke--Thao 2017，Definitions 1--3 与 Proposition 2：set regularity 编码](https://arxiv.org/pdf/1611.04787)。
- [Kruger--Luke--Thao，Set Regularities and Feasibility Problems](https://arxiv.org/html/1602.04935v1)。
- [Poliquin--Rockafellar--Thibault 2000：prox-regular set、投影与 truncated normal hypomonotonicity](https://doi.org/10.1090/S0002-9947-00-02550-2)。
- [Poliquin--Rockafellar 1996：prox-regular function 与 attentive subgradient localization](https://doi.org/10.1090/S0002-9947-96-01544-9)。

文献只承载上述定义/一般字典；下列多数具体对象及常数是 **SELF-CONSTRUCTED / ALG**。
特别地，任何 normal cone 的 hypomonotonicity 声明都会打印 normal-norm truncation；绝不把
prox-regular set 的 truncated theorem 偷换成 full-cone theorem。

## 1. Normal cones、subdifferentials、maximality 与四类核心正则性

### SVG-01 — 半直线边界的 convex normal：maximal graph + vacuous MSR + nonisolated zeros

- **目的 / gap cells：** maximally cyclically monotone \(\wedge\neg\mathrm{MR}\wedge
  \mathrm{MSR}\wedge\neg\mathrm{SMSR}\)；强图结构但弱 inverse stability；定义域造成的 vacuity。
- **空间、映射、图：** \(H=\mathbb R\)，\(C=[0,\infty)\)，\(F=N_C=\partial\delta_C\)：
  \[
  F(x)=\begin{cases}\{0\},&x>0,\\(-\infty,0],&x=0,\\\varnothing,&x<0,
  \end{cases}\quad
  \operatorname{gph}F=((0,\infty)\times\{0\})\cup(\{0\}\times(-\infty,0]).
  \]
  set-valued，\(\operatorname{dom}F=C\)。
- **零点、inverse：** \(S=\operatorname{zer}F=C\)（非孤立）；
  \(F^{-1}(y)=\{0\}\) if \(y<0\)，\(=C\) if \(y=0\)，\(=\varnothing\) if \(y>0\)。
- **resolvent：** 对任意 \(\lambda>0\)，\(J_{\lambda F}=P_C=p_+:=\max\{p,0\}\)，
  \(R_{\lambda F}=2p_+-p=|p|\)。
- **graph / RL：** convex normal 故 max cyclic/max monotone；
  \(\langle a,b\rangle\ge0\)，但取不同正 \(x,y\) 得 \(b=0\)，故非 strict/strong；
  vertical fiber 排除任何正 cocoercivity。\(R=|\cdot|\) 的全局精确 Lipschitz 常数为 1，
  故 RL\((\lambda,1,1)\)；全局无 \(\gamma<1\) Hölder bound（令 \(p\to\infty,q=0\)）。
- **regularity at \((0,0)\)：** MSR exact infimum \(0\)，因为 \(x\in C\Rightarrow
  d(x,S)=r_F(x)=0\)，而 \(x<0\Rightarrow r_F(x)=+\infty\)。这是
  **DOMAIN-VACUOUS MSR**，不是 residual growth。SMSR/isolated calmness失败，因为 \(S=C\) 非孤立。
  MR失败：取 \(x=0,y>0\)，左侧 \(d(0,F^{-1}(y))=+\infty\)，右侧
  \(d(y,F(0))=y<\infty\)。故 SMR 亦失败。
- **参数 / 来源：** \(\lambda>0\)；对象计算为 ALG；maximality/resolvent 字典见 Minty、Rockafellar、BMW locators。

### SVG-02 — 同一 normal cone 的 interior-normal reference：弱 graph + modulus-zero SMR

- **目的 / gap cells：** 与 SVG-01 只换 reference graph point，得到
  \(\neg\)strong graph \(\wedge\mathrm{SMR}\)；证明 regularity 不由 operator 名称单独决定。
- **对象：** 仍为 SVG-01 的 \(F=N_{[0,\infty)}\)，graph、inverse、zero、\(J=P_C\)、\(R=|\cdot|\) 全同。
- **graph / RL：** max cyclic/max monotone、非 strong；RL\((\lambda,1,1)\) global。
- **regularity at \((\bar x,\bar y)=(0,-1)\)：** 取 \(V\Subset(-\infty,0)\)，则
  \(F^{-1}(y)\cap U=\{0\}\) 对所有 \(y\in V\)。inverse localization 是常值，故 SMR、MR、
  SMSR、MSR 全成立，SMR/MR exact modulus infimum为 \(0\)。SMSR 的 exact infimum也为 0：
  \(x>0\) 时 \(d(-1,F(x))=1\)，\(x<0\) 时为 \(+\infty\)，缩小 \(U\) 即可使比值上界趋零。
  reference solution 对 target \(-1\) 是孤立的。
- **失败机制 / 警告：** 这是“normal 位于 cone interior”产生的 branch pinning；并不把 \(F\) 变成 strongly monotone。
- **参数 / 来源：** 任意 \(\lambda>0\)；ALG + 上述 convex-normal primary locators。

### SVG-03 — \(\partial |x|\)：maximal cyclic、非 strong，但 inverse 局部常值

- **目的 / gap cells：** maximal monotone \(\wedge\neg\)strong \(\wedge\mathrm{SMR}\)；
  weak graph / strong regularity 的自然 nonsmooth object。
- **空间、映射、图：** \(H=\mathbb R\)，\(F=\partial|\cdot|\)：
  \[
  F(x)=\{-1\}\ (x<0),\quad F(0)=[-1,1],\quad F(x)=\{1\}\ (x>0).
  \]
  graph 是两条水平射线加 \(\{0\}\times[-1,1]\)；set-valued。
- **零点、inverse：** \(S=\{0\}\)；
  \(F^{-1}(y)=(-\infty,0]\) if \(y=-1\)，\(\{0\}\) if \(|y|<1\)，
  \([0,\infty)\) if \(y=1\)，否则为空。
- **resolvent：** \(J_{\lambda F}(p)=\operatorname{sgn}(p)(|p|-\lambda)_+\)；
  \[
  R(p)=\begin{cases}p+2\lambda,&p<-\lambda,\\-p,&|p|\le\lambda,\\p-2\lambda,&p>\lambda.
  \end{cases}
  \]
- **graph / RL：** 作为 convex subdifferential，max cyclic/max monotone；非 strong（同一水平支上 \(b=0\)）。
  \(R\) global nonexpansive，精确常数 1，故 RL\((\lambda,1,1)\)；global \(\gamma<1\) 失败于无界射线。
- **regularity at \((0,0)\)：** 对 \(|y|<1\)，inverse localization恒为 \(0\)，故 SMR/MR exact
  modulus infimum \(0\)。固定 target 0 时，\(x\ne0\Rightarrow r_F(x)=1\)，故 SMSR/MSR 成立且
  exact infimum 0；零点孤立。这里 modulus 0 来自 residual jump，不是空定义域。
- **参数 / 来源：** \(\lambda>0\)；Rockafellar 1970 承载 convex-subdifferential maximality，其余 ALG。

### SVG-04 — \(\partial(x^4/4)=x^3\)：maximal cyclic 但仅 \(q=1/3\) power-SMSR

- **目的 / gap cells：** maximally cyclically monotone \(\wedge\neg\mathrm{MSR}\wedge
  q\text{-SMSR}\)；强 graph pedigree 不给线性 error bound。
- **空间、映射、图：** \(H=\mathbb R\)，\(F(x)=x^3\)，single-valued，
  \(\operatorname{gph}F=\{(x,x^3)\}\)，\(S=\{0\}\)，\(F^{-1}(y)=\sqrt[3]{y}\)。
- **resolvent：** 对 \(\lambda>0\)，令 \(h_\lambda(t)=t+\lambda t^3\)；它严格递增满射，
  \(J_{\lambda F}=h_\lambda^{-1}\)，\(R(p)=2h_\lambda^{-1}(p)-p\)。这是可重复求解的唯一实 cubic root。
- **graph / RL：**
  \(\langle a,b\rangle=(x-y)^2(x^2+xy+y^2)\ge0\)，但 quadratic coefficient 的 infimum为0，
  故 monotone/maximal cyclic而非 strong。\(R'(h_\lambda(x))=(1-3\lambda x^2)/(1+3\lambda x^2)\)，
  故 global exact \(\operatorname{Lip}R=1\) 与 RL\((\lambda,1,1)\)；global \(\gamma<1\) 失败。
- **regularity at \((0,0)\)：** exact residual law
  \[
  d(x,S)=|x|,\qquad r_F(x)=|x|^3.
  \]
  因此 ordinary MSR/SMSR失败，MR/SMR亦失败（cube-root inverse非 Lipschitz）。在 residual-exponent convention
  下，\(q\)-SMSR 恰对 \(0<q\le1/3\) 成立；largest sharp exponent \(q_*=1/3\)，在
  \(q=1/3\) exact modulus为1（\(q<1/3\) exact infimum 0）。零点孤立，失败不是 nonisolation/vacuity。
- **来源：** SELF-CONSTRUCTED / ALG；subdifferential maximality由 Rockafellar 1970 支撑。

### SVG-05 — 零算子：maximal monotone + 全体零点 + trivial MSR

- **目的 / gap cells：** maximal monotone \(\wedge\mathrm{MSR}\wedge\neg\mathrm{MR}
  \wedge\neg\mathrm{SMSR}\)；大解集造成的 triviality。
- **空间、映射、图：** \(H=\mathbb R\)，\(F(x)=\{0\}\)；
  \(\operatorname{gph}F=\mathbb R\times\{0\}\)，single-valued，\(S=\mathbb R\)。
  \(F^{-1}(0)=\mathbb R\)，\(F^{-1}(y)=\varnothing\) for \(y\ne0\)。
- **resolvent / graph：** \(J_{\lambda F}=I,R_{\lambda F}=I\)。
  \(\langle a,b\rangle=0\)：maximal monotone但非 strict/strong；RL\((\lambda,1,1)\) exact，global
  \(\gamma<1\) 失败。
- **regularity at \((\bar x,0)\)：** \(d(x,S)\equiv0\)，所以 MSR exact 0 是
  **BIG-SOLUTION-SET TRIVIALITY**。SMSR失败（\(\bar x\) 不孤立）。MR失败：任意小 \(y\ne0\)
  有 inverse empty 而 \(d(y,F(\bar x))=|y|<\infty\)；SMR失败。
- **来源 / 参数：** SELF-CONSTRUCTED；\(\lambda>0\)。

### SVG-06 — \(N_{\{0\}}\)：vertical graph，形式上任意 strong modulus，且 modulus-zero SMR

- **目的 / gap cells：** maximality vs strong；展示“strong graph”可因没有不同 primal points 而 vacuous。
- **空间、映射、图：** \(H=\mathbb R\)，\(F=N_{\{0\}}=\partial\delta_{\{0\}}\)：
  \(F(0)=\mathbb R,F(x)=\varnothing\ (x\ne0)\)，\(\operatorname{gph}F=\{0\}\times\mathbb R\)，set-valued。
- **零点、inverse：** \(S=\{0\}\)；对每个 \(y\in\mathbb R\)，\(F^{-1}(y)=\{0\}\)。
- **resolvent：** \(J_{\lambda F}\equiv0\)，\(R_{\lambda F}=-I\) for every \(\lambda>0\)。
- **graph / RL：** 任意图点对都有 \(a=0\)，故 \(\langle a,b\rangle=0\ge\mu\|a\|^2\)
  对**每个** \(\mu>0\) 成立，且 \(F-\mu I=F\) 仍 max monotone；这是 primal-direction vacuity，
  不是 contraction。事实上 \(R=-I\) 的 exact Lipschitz/RL\(_1\) 常数为1。
- **regularity at \((0,0)\)：** inverse global constant singleton，故 SMR/MR exact infimum 0。
  SMSR/MSR亦成立、exact infimum 0，但其固定-target inequality 对 \(x\ne0\) 只看到
  \(r_F(x)=+\infty\)：同时标记 **DOMAIN-VACUOUS SMSR**。零点孤立。
- **来源：** convex normal 的 canonical example；ALG + Minty/Rockafellar/BMW locators。

### SVG-07 — \(\mu I+N_{[0,\infty)}\)：maximally strong + SMR，但 reflected resolvent 不收缩

- **目的 / gap cells：** 两边都强；同时分离“strong \(F\)”与“\(R\) contraction”。
- **空间、映射、图：** \(\mu>0\)，
  \[
  F(x)=\begin{cases}\{\mu x\},&x>0,\\(-\infty,0],&x=0,\\\varnothing,&x<0.
  \end{cases}
  \]
  graph 为斜射线加 vertical cone；set-valued；\(F-\mu I=N_{[0,\infty)}\)，故 maximally
  \(\mu\)-strongly monotone，且 exact strong modulus \(\mu\)。因多值，不可能有正 cocoercivity常数。
- **零点、inverse：** \(S=\{0\}\)；
  \(F^{-1}(y)=0\) for \(y\le0\)，\(=y/\mu\) for \(y>0\)，即 \(F^{-1}(y)=y_+/\mu\)。
- **resolvent：** 对 \(\lambda>0\)，
  \[
  J(p)=\begin{cases}0,&p\le0,\\p/(1+\lambda\mu),&p>0,\end{cases}\quad
  R(p)=\begin{cases}-p,&p\le0,\\\frac{1-\lambda\mu}{1+\lambda\mu}p,&p>0.
  \end{cases}
  \]
  因负半轴斜率为 \(-1\)，\(\operatorname{Lip}R=1\)，并非 contraction；RL\((\lambda,1,1)\) exact。
- **regularity at \((0,0)\)：** inverse global single-valued \(1/\mu\)-Lipschitz，故 SMR/MR exact
  modulus \(1/\mu\)。固定 target residual 对 \(x>0\) 为 \(\mu x\)，对 \(x<0\) 为 \(+\infty\)，
  故 SMSR/MSR exact \(1/\mu\)，零点孤立（只有 domain 外一侧是 vacuous，sharpness由 domain 内给出）。
- **来源：** SELF-CONSTRUCTED / ALG；strong/maximal/resolvent字典见 Minty/BMW。

### SVG-08 — restricted \(\mu I\)：strong graph + SMSR，但不 maximal、无 MR

- **目的 / gap cells：** strong inequality 不补偿 output coverage；strong vs maximality 正交。
- **空间、映射、图：** \(\mu>0\)，\(F(x)=\{\mu x\}\) for \(x\ge0\)，否则空；
  \(\operatorname{gph}F=\{(x,\mu x):x\ge0\}\)，single-valued on proper domain。
- **零点、inverse：** \(S=\{0\}\)；\(F^{-1}(y)=\{y/\mu\}\) for \(y\ge0\)，否则空。
- **resolvent：** \(D_\lambda=\operatorname{ran}(I+\lambda F)=[0,\infty)\)，且仅在此 natural domain
  \(J(p)=p/(1+\lambda\mu)\)，\(R(p)=kp\)，\(k=(1-\lambda\mu)/(1+\lambda\mu)\)。
- **graph / RL：** \(\langle a,b\rangle=\mu a^2\)，exact strong modulus \(\mu\)。
  非 maximal：\(F-\mu I\) 是只定义在半线上的零图，可加入 \((-1,0)\)。在 \(D_\lambda\) 上
  RL\((\lambda,|k|,1)\) exact（\(\lambda\mu=1\) 时 \(R=0\)）。
- **regularity at \((0,0)\)：** SMSR/MSR exact \(1/\mu\)，零点孤立；MR/SMR失败，因为任意
  小 \(y<0\) 使 inverse empty，而 \(d(y,F(0))=|y|\)。因此是
  **strong graph + strong fixed-target regularity + weak target-uniform regularity**。
- **来源：** SELF-CONSTRUCTED / ALG。

### SVG-09 — singleton graph：graph strength 与 SMSR 同时 vacuous

- **目的 / gap cells：** 对“强/强”标签做 vacuity stress test；不可把它当作 seesaw 数据的普通强点。
- **空间、映射、图：** \(H=\mathbb R\)，\(F(0)=\{0\}\)，\(F(x)=\varnothing\) for \(x\ne0\)；
  \(\operatorname{gph}F=\{(0,0)\}\)，\(S=\{0\}\)，且
  \(F^{-1}(0)=\{0\}\)、\(F^{-1}(y)=\varnothing\) for \(y\ne0\)。
- **resolvent：** \(D_\lambda=\{0\}\)，\(J(0)=R(0)=0\)；无 full-domain resolvent。
- **graph / RL：** 所有 pairwise monotonicity、strong monotonicity（任意 \(\mu\)）、cocoercivity（任意
  \(\beta\)）及 RL（任意 \(L>0,0<\gamma\le1\)）都只测试同一图点，故
  **GRAPH-VACUOUS**。图非 maximal，可同时沿多种方向扩张。
- **regularity at \((0,0)\)：** MSR/SMSR 对任意正 modulus成立且 exact infimum0，因为
  \(x\ne0\Rightarrow r_F(x)=+\infty\)：**DOMAIN-VACUOUS**；零点孤立。MR/SMR失败：
  \(x=0,y\ne0\) 时 inverse empty而 residual finite。
- **来源：** SELF-CONSTRUCTED / ALG。

### SVG-10 — subspace normal \(N_L\)：maximal monotone isometry Cayley + nonisolated/vacuous MSR

- **目的 / gap cells：** normal cone / projection / nonisolated zero；maximal graph 与 fixed-target
  error bound 的 triviality。
- **空间、映射、图：** \(H=\mathbb R^2\)，\(L=\mathbb R\times\{0\}\)，
  \(F=N_L\)：\(F(x_1,0)=\{0\}\times\mathbb R\)，domain 外为空；
  \(\operatorname{gph}F=L\times L^\perp\)，set-valued。
- **零点、inverse：** \(S=L\)（非孤立）；\(F^{-1}(y)=L\) if \(y\in L^\perp\)，否则空。
- **resolvent / reflected：** \(J_{\lambda F}=P_L(p_1,p_2)=(p_1,0)\)，
  \(R=2P_L-I=(p_1,-p_2)\)，与 \(\lambda\) 无关。
- **graph / RL：** 对图点差 \(a\in L,b\in L^\perp\)，\(\langle a,b\rangle=0\)。
  max cyclic/max monotone但非 strict/strong/cocoercive；\(R\) 是正交 reflection，RL\((\lambda,1,1)\)
  exact，global \(\gamma<1\) 失败。
- **regularity at \((0,0)\)：** MSR exact0：domain点全是零点，domain外 residual \(+\infty\)，故
  **DOMAIN-VACUOUS + BIG-SOLUTION-SET**。SMSR失败（零点非孤立）。MR失败：取小
  \(y\notin L^\perp\)，inverse空但 \(d(y,F(0))=d(y,L^\perp)<\infty\)；SMR失败。
- **来源：** canonical convex-normal example；ALG + Minty/Rockafellar/BMW。

### SVG-11 — projection residual \(I-P_L\)：1-cocoercive + exact MSR，但无 MR/SMSR

- **目的 / gap cells：** strong co-graph geometry \(\wedge\) nonisolated zeros；projection geometry 与
  target-surjectivity分离。
- **空间、映射、图：** \(H=\mathbb R^2,L=\mathbb R\times\{0\}\)，
  \(F=I-P_L=P_{L^\perp}\)，即 \(F(x_1,x_2)=(0,x_2)\)，single-valued，full domain。
  \(\operatorname{gph}F=\{((x_1,x_2),(0,x_2))\}\)。
- **零点、inverse：** \(S=L\)（非孤立）；若 \(y=(0,y_2)\)，
  \(F^{-1}(y)=\mathbb R\times\{y_2\}\)，否则为空。
- **resolvent：** \(J(p_1,p_2)=(p_1,p_2/(1+\lambda))\)，
  \(R(p_1,p_2)=(p_1,(1-\lambda)p_2/(1+\lambda))\)。
- **graph / RL：** \(\langle a,b\rangle=a_2^2=\|b\|^2\)，故 exact 1-cocoercive、monotone、
  max monotone，但非 strong（沿 \(L\)）。\(\operatorname{Lip}R=1\) 因 \(L\) 方向为 identity，
  所以 RL\((\lambda,1,1)\) exact。
- **regularity at \((0,0)\)：** \(d(x,S)=|x_2|=\|F(x)\|\)，故 MSR exact modulus1，非 vacuous。
  SMSR失败因 \(S\) 非孤立。MR失败因 range \(L^\perp\ne H\)：取小 \(y_1\ne0\) 即 inverse empty；
  SMR失败。
- **来源：** SELF-CONSTRUCTED / ALG；projector/FNE 字典见 BMW。

### SVG-12 — branch union \(F(x)=\{-x,x\}\)：MR + SMSR 仍不推出 SMR

- **目的 / gap cells：** 核心 regularity 逻辑区
  \(\mathrm{MR}\wedge\mathrm{SMSR}\wedge\neg\mathrm{SMR}\)；piecewise multifunction；弱 graph / 强 regularity。
- **空间、映射、图：** \(H=\mathbb R\)，\(F(x)=\{-x,x\}\)，
  \(\operatorname{gph}F=\{(x,x)\}\cup\{(x,-x)\}\)，set-valued。
- **零点、inverse：** \(S=\{0\}\)；\(F^{-1}(y)=\{-y,y\}\)。
- **resolvent：** 对 \(\lambda\ne1\)，
  \(J(p)=\{p/(1+\lambda),p/(1-\lambda)\}\)（在 \(p=0\) 两值重合）；
  \(\lambda=1\) 时负斜率支把全部 \(x\) 映到 Minty input 0。故任何 \(\lambda>0\) 的 resolvent
  relation 都没有所需单值性，\(R\) 同样多值。
- **graph / RL：** 负支上 \(\langle a,b\rangle=-a^2\)；cross-branch 取
  \(x=t,y=t+t^2\) 可使 \(\langle a,b\rangle/|a|^2\to-\infty\)，故甚至在 \((0,0)\)
  无 finite local hypomonotonicity modulus。Minty collisions 直接否定所有 all-pairs RL\((\lambda,L,\gamma)\)。
- **regularity at \((0,0)\)：** 对所有 \(x,y\)，
  \[
  d(x,F^{-1}(y))=\min\{|x-y|,|x+y|\}=d(y,F(x)),
  \]
  故 global MR exact modulus1。又 \(r_F(x)=|x|=d(x,S)\)，故 SMSR/MSR exact1、零点孤立。
  但任意 \(y\ne0\) 的 inverse 在任意 reference neighborhoods 中含 \(\pm y\) 两支，故无 single-valued
  localization，SMR失败。
- **来源：** SELF-CONSTRUCTED / ALG；作为 general multifunction 的标准 branch-uniqueness witness。

### SVG-13 — vertical-value multifunction：MR 但非 SMSR/SMR，且 graph 无 finite local hypo modulus

- **目的 / gap cells：** 核心区域
  \(\mathrm{MR}\wedge\mathrm{MSR}\wedge\neg\mathrm{SMSR}\wedge\neg\mathrm{SMR}\)；
  weak graph / strong target-uniform regularity；genuinely set-valued。
- **空间、映射、图：** \(H=\mathbb R^2\)，
  \[
  F(x_1,x_2)=\{x_1\}\times\mathbb R,\quad
  \operatorname{gph}F=\{((x_1,x_2),(x_1,u_2)):x_1,x_2,u_2\in\mathbb R\}.
  \]
  full-domain set-valued map。
- **零点、inverse：**
  \(S=F^{-1}(0,0)=\{0\}\times\mathbb R\)（非孤立），且
  \(F^{-1}(y_1,y_2)=\{y_1\}\times\mathbb R\)。
- **resolvent：** 对 \(\lambda>0\)，
  \[
  J_{\lambda F}(p)=\{p_1/(1+\lambda)\}\times\mathbb R,\quad
  R_{\lambda F}(p)=\{(1-\lambda)p_1/(1+\lambda)\}\times\mathbb R.
  \]
  两者是 relations，不是 maps。
- **graph / RL：** 对图点差 \(b_1=a_1\)，
  \(\langle a,b\rangle=a_1^2+a_2b_2\)。任意 graph neighborhood 内取
  \(a=(0,t^2),b=(0,-t)\)，即可令
  \(\langle a,b\rangle/\|a\|^2=-1/t\to-\infty\)；无 finite local
  hypomonotonicity modulus。\(J\) 对每个 input 都多值，故所有 all-pairs RL 失败。
- **regularity at \(((0,0),(0,0))\)：** 全局恒等式
  \[
  d(x,F^{-1}(y))=|x_1-y_1|=d(y,F(x))
  \]
  给 MR/MSR exact modulus 1。SMSR失败，因为 \(S\) 非孤立；inverse localization 的
  \(x_2\)-fiber 永不单值，故 SMR失败。
- **来源：** SELF-CONSTRUCTED / ALG。

### SVG-14 — absolute-value map：SMSR 但非 MR；精确 hypomonotonicity 与 resolvent phase change

- **目的 / gap cells：** 核心区域
  \(\mathrm{SMSR}\wedge\mathrm{MSR}\wedge\neg\mathrm{MR}\wedge\neg\mathrm{SMR}\)；
  piecewise single-valued、弱 graph / strong fixed-target regularity。
- **空间、映射、图：** \(H=\mathbb R\)，\(F(x)=|x|\)，
  \(\operatorname{gph}F=\{(x,|x|)\}\)，\(S=\{0\}\)；
  \(F^{-1}(y)=\{-y,y\}\) for \(y>0\)，\(\{0\}\) for \(y=0\)，空 for \(y<0\)。
- **resolvent：** 若 \(0<\lambda<1\)，\(I+\lambda F\) 是分段双射，且
  \[
  J(p)=\begin{cases}p/(1-\lambda),&p<0,\\p/(1+\lambda),&p\ge0,\end{cases}\quad
  R(p)=\begin{cases}\frac{1+\lambda}{1-\lambda}p,&p<0,\\
  \frac{1-\lambda}{1+\lambda}p,&p\ge0.\end{cases}
  \]
  若 \(\lambda=1\)，整个负半轴映到 Minty input 0；若 \(\lambda>1\)，正 input 有两支、负 input
  无 preimage。
- **graph / RL：** \(|F(x)-F(y)|\le|x-y|\)，故
  \(\langle a,b\rangle\ge-|a||b|\ge-|a|^2\)，且在 \(x,y<0\) 取等，global
  hypomonotonicity sharp modulus为1。对 \(0<\lambda<1\)，RL\(_1\) sharp
  \(L=(1+\lambda)/(1-\lambda)\)；\(\lambda\ge1\) 因 Minty collision 不满足 all-pairs RL。
- **regularity at \((0,0)\)：**
  \(d(x,S)=r_F(x)=|x|\)，故 SMSR/MSR exact modulus1，零点孤立；sharp largest
  residual exponent为 \(q_*=1\)。MR失败：取任意小 \(y<0\)，inverse为空而
  \(d(y,F(0))=|y|\)；故 SMR失败。
- **来源：** SELF-CONSTRUCTED / ALG。

### SVG-15 — \(F(x)=\{0,x\}\)：MSR + HREG 仍无 MR，且大零集使 EB trivial

- **目的 / gap cells：** piecewise multifunction；fixed-\(x\) semiregularity 与 fixed-target
  subregularity 的 conjunction 仍不推出 MR；大解集。
- **空间、映射、图：** \(H=\mathbb R\)，
  \(F(x)=\{0,x\}\)，\(\operatorname{gph}F=(\mathbb R\times\{0\})\cup\{(x,x)\}\)。
- **零点、inverse：** \(S=\mathbb R\)；\(F^{-1}(0)=\mathbb R\)，
  \(F^{-1}(y)=\{y\}\) for \(y\ne0\)。
- **resolvent：**
  \(J_{\lambda F}(p)=\{p,p/(1+\lambda)\}\)（\(p=0\) 时重合），
  \(R_{\lambda F}(p)=\{p,(1-\lambda)p/(1+\lambda)\}\)。
- **graph / RL：** cross-branch 取 \((x,u)=(t,t)\)、\((y,v)=(t+t^2,0)\)，有
  \(a=-t^2,b=t\)，故 \(\langle a,b\rangle/\|a\|^2=-1/t\to-\infty\)：
  无 finite local hypomonotonicity modulus。相同 input 的两 resolvent values 否定 all-pairs RL。
- **regularity at \((0,0)\)：** \(S=\mathbb R\)，故 MSR exact0 是
  **BIG-SOLUTION-SET TRIVIALITY**，SMSR失败。HREG成立且 exact modulus1，因为
  \(d(0,F^{-1}(y))=|y|\) for \(y\ne0\)。MR失败：固定小 \(x\ne0\) 后令
  \(y\to0,y\ne0\)，
  \[
  \frac{d(x,F^{-1}(y))}{d(y,F(x))}
  =\frac{|x-y|}{\min\{|y|,|x-y|\}}\to\infty.
  \]
  SMR亦失败。
- **来源：** SELF-CONSTRUCTED / ALG。

### SVG-16 — unit circle full normal vs norm-truncated normal：truncation 是必要的

- **目的 / gap cells：** prox-regular set；证明“full normal graph hypomonotone”是错误命题，
  同时展示 smooth/prox-regular individual geometry 与 weak regularity of \(N_C\) at zero normal。
- **空间、映射、图：** \(H=\mathbb R^2\)，\(C=S^1=\{x:\|x\|=1\}\)，使用 proximal/limiting
  normal（本例二者相同）
  \[
  F=N_C,\qquad F(x)=\{\alpha x:\alpha\in\mathbb R\}\ (x\in C),\quad
  \operatorname{gph}F=\{(x,\alpha x):\|x\|=1,\alpha\in\mathbb R\}.
  \]
  domain 外为空；\(C\) 是 \(C^\infty\) manifold、reach 1，故 prox-regular。
- **零点、inverse：** \(S=C\)（非孤立）；\(F^{-1}(0)=C\)，且
  \(F^{-1}(y)=\{\pm y/\|y\|\}\) for \(y\ne0\)。
- **full resolvent relation：** 对 \(p\ne0\)，
  \[
  J_{\lambda F}(p)=\{p/\|p\|,-p/\|p\|\};
  \]
  对 \(p=0\)，\(J(0)=C\)（取 normal coefficient \(-1/\lambda\)）。故 full \(J,R\) 多值。
  在 \((\bar x,0)\) 的 graph localization、\(p\) 近 \(\bar x\) 时，nearest branch 是
  \(J^{\rm loc}(p)=P_C(p)=p/\|p\|\)，
  \(R^{\rm loc}(p)=2p/\|p\|-p\)。
- **sharp graph computation：** 对 \(u=\alpha x,v=\beta y,c=\langle x,y\rangle\)，
  \[
  \langle x-y,u-v\rangle=(\alpha+\beta)(1-c)
  =\frac{\alpha+\beta}{2}\|x-y\|^2. \tag{16.1}
  \]
  在 **full cone graph** 上令 \(\alpha=\beta=-M\to-\infty\)，没有任何 finite
  hypomonotonicity modulus。若明确截断 \(\|u\|,\|v\|\le\rho\)，即
  \(|\alpha|,|\beta|\le\rho\)，则
  \[
  \langle a,b\rangle\ge-\rho\|a\|^2,
  \]
  且 \(\alpha=\beta=-\rho\) 达到，故 truncated sharp modulus为 \(\rho\)。
  full graph 因 Minty collisions 无 RL；localized nearest branch 才有 local Lipschitz/RL\(_1\)。
- **regularity at \((\bar x,0)\)：** MSR exact0，因为 domain 点全在 \(S=C\)，domain 外 residual
  \(+\infty\)：**DOMAIN-VACUOUS + NONISOLATED**；SMSR失败。MR失败：取 unit tangent
  \(w\perp\bar x\)、\(y_\varepsilon=\varepsilon w\)，则
  \(d(\bar x,F^{-1}(y_\varepsilon))=\sqrt2\)，而
  \(d(y_\varepsilon,F(\bar x))=\varepsilon\)。SMR失败。
- **来源：** 对象与 (16.1) 为 ALG；“prox-regular \(\Leftrightarrow\) locally single-valued
  projection / hypomonotone **truncation**”见 Poliquin--Rockafellar--Thibault 2000 primary locator。

### SVG-17 — \(f=-|x|\) at \((0,1)\)：local monotone subgradient graph 不推出 prox-regularity

- **目的 / gap cells：** prox-regular converse 中 proximal-subgradient 假设不可删；
  attentive/local graph 与 full graph/resolvent分离。
- **空间、映射、图：** \(H=\mathbb R\)，\(f(x)=-|x|\)，取 limiting subdifferential
  \[
  F=\partial f,\qquad
  F(x)=\{1\}\ (x<0),\quad F(0)=\{-1,1\},\quad F(x)=\{-1\}\ (x>0).
  \]
  set-valued；\(\operatorname{zer}F=\varnothing\)。对 target \(1\)，
  \(F^{-1}(1)=(-\infty,0]\)。
- **resolvent relation：** 对 \(\lambda>0\)，
  positive branch 给 \(x=p+\lambda\) when \(p>-\lambda\)，negative branch给
  \(x=p-\lambda\) when \(p<\lambda\)，端点还含 \(x=0\)。故
  \(-\lambda<p<\lambda\) 有两 resolvent values，full \(J,R\) 多值，all-pairs RL失败。
- **local graph geometry at \((0,1)\)：** 取 dual neighborhood 不含 \(-1\)，local graph恰为
  \(\{(x,1):x\le0\}\)，所以 \(\langle a,b\rangle=0\)：local monotone/hypomonotone。
  但 \(1\notin\partial_Pf(0)\)，且任意 fixed \(r\) 的 prox-support inequality在 \(t>0\) 要求
  \[
  -t=f(t)\ge f(0)+1\cdot t-\frac r2t^2
  \quad\Longleftrightarrow\quad r\ge4/t,
  \]
  对 \(t\downarrow0\) 不可能。因此 \(f\) 不在 \((0,1)\) prox-regular；这正是不能删掉
  “reference subgradient proximal”的显示见证。
- **regularity at \((0,1)\)：** fixed-target solution set \((-\infty,0]\) 非孤立。
  \(x>0\) 时 residual \(d(1,F(x))=2\)，故 MSR成立且 exact infimum0（非 domain-vacuous，
  但受 residual jump + 大解集支配）；SMSR失败。MR失败，因为任意 \(y\) 近1但 \(y\ne1\)
  都有 empty inverse，而 \(d(y,F(0))<\infty\)。SMR失败。
- **来源：** seed 来自 atlas 的 converse-assumption audit；support反证为 ALG；
  prox-regular characterization见 Poliquin--Rockafellar 1996 primary locator。

## 2. Projection / set transversality / linear-regularity gaps

### SVG-18 — 两坐标轴：transversal pair，set mapping 具有 SMR

- **目的 / gap cells：** set geometry 与 inverse stability 两边都强；给 (0.2) 的完全显式模型。
- **空间、集合、projectors：** \(X=\mathbb R^2\)，
  \(A=\mathbb R\times\{0\}\)，\(B=\{0\}\times\mathbb R\)，\(\bar x=0\)。
  \(P_A(r,s)=(r,0)\)，\(P_B(r,s)=(0,s)\)，且 \(P_AP_B=0\)（一次完整 alternating cycle 到交点）。
- **set mapping、graph、zero、inverse：**
  \[
  \Phi(x)=(A-x)\times(B-x),\quad
  \operatorname{gph}\Phi=\{(x,(u,v)):x+u\in A,\ x+v\in B\},
  \]
  \(\operatorname{zer}\Phi=A\cap B=\{0\}\)。写
  \(u=(u_1,u_2),v=(v_1,v_2)\)，则
  \[
  \Phi^{-1}(u,v)=\{(-v_1,-u_2)\}. \tag{18.1}
  \]
  因 \(\Phi:X\rightrightarrows X^2\)，\(J_{\lambda\Phi},R_{\lambda\Phi}\) 为 N/A。
- **精确 set/error-bound geometry：**
  \[
  d(x,A\cap B)=\sqrt{x_1^2+x_2^2},\quad
  \max\{d(x,A),d(x,B)\}=\max\{|x_2|,|x_1|\}.
  \]
  故 global linear regularity / subtransversality 的 error-bound modulus为 \(\sqrt2\)，且
  \(x_1=x_2\ne0\) 达到。\(N_A(0)=B,N_B(0)=A\)，所以
  \(N_A(0)\cap[-N_B(0)]=\{0\}\)：集合横截。
- **regularity：** 由 (18.1)，inverse 是 global single-valued map，且从 output max norm 到
  Euclidean norm 的 exact Lipschitz modulus为 \(\sqrt2\)。因此 \(\Phi\) 的 SMR/MR exact
  modulus \(\sqrt2\)；固定 target 的 SMSR/MSR亦 exact \(\sqrt2\)，零点孤立，无 vacuity。
- **individual graph geometry：** \(N_A,N_B\) 各自为 maximally cyclically monotone，
  \(J_{\lambda N_A}=P_A,J_{\lambda N_B}=P_B\)，reflected maps 是正交 reflections；这不替代 pair
  transversality 的单独验证。
- **来源：** 对象/常数 ALG；(0.2) 与 mapping (0.1) 见 Kruger--Luke--Thao 2017
  Definitions 1--3 / Proposition 2 primary locator。

### SVG-19 — identical lines：subtransversal but not transversal（primary-source strict witness）

- **目的 / gap cells：** \(\mathrm{subtransversality}\wedge\neg\mathrm{transversality}\)；
  \(\mathrm{MSR}\wedge\neg\mathrm{MR}\wedge\neg\mathrm{SMSR}\)；set linear-regularity strict gap。
- **空间、集合、projection：** \(X=\mathbb R^2\)，
  \(A=B=L=\mathbb R\times\{0\}\)，\(\bar x=0\)；
  \(P_A=P_B=P_L(r,s)=(r,0)\)，alternating projection 一步到 \(L\)。
- **set mapping、graph、zero、inverse：** \(\Phi\) 如 (0.1)，
  \(\operatorname{zer}\Phi=L\)（非孤立）。对
  \(u=(u_1,u_2),v=(v_1,v_2)\)，
  \[
  \Phi^{-1}(u,v)=
  \begin{cases}\mathbb R\times\{-u_2\},&u_2=v_2,\\
  \varnothing,&u_2\ne v_2.
  \end{cases}
  \]
  \(\operatorname{gph}\Phi=\{(x,(u,v)):x+u,x+v\in L\}\)；\(J/R\) N/A。
- **精确 set geometry：**
  \(d(x,A\cap B)=d(x,A)=d(x,B)=|x_2|\)，故 global linear regularity/MSR exact
  modulus1，非 domain-vacuous，但零集很大。小的不同 vertical translations 变成两条不相交平行线，
  所以不 transversal。
- **regularity：** \(\Phi\) MSR exact1；SMSR失败因 \(L\) 非孤立。MR失败：取
  \(u=(0,\varepsilon),v=0\)，inverse empty，而其到 \(\Phi(0)=L\times L\) 的 max-distance为
  \(\varepsilon<\infty\)。SMR失败。
- **normal geometry：** \(N_A(0)=N_B(0)=L^\perp\)，故
  \(N_A(0)\cap[-N_B(0)]=L^\perp\ne\{0\}\)。每个 individual normal cone仍 max cyclic，
  \(J=P_L,R=2P_L-I\)。
- **来源：** [Kruger--Luke--Thao 2017, Examples 1--2（原文即 \(A=B=\mathbb R\times\{0\}\)）](https://arxiv.org/pdf/1611.04787)；
  这里 inverse 与 moduli 为独立 ALG。

### SVG-20 — line tangent to parabola：smooth/prox-regular sets，但 ordinary subtransversality失败

- **目的 / gap cells：** 两个 individually smooth/prox-regular sets \(\wedge\)
  neither transversality nor subtransversality；ordinary regularity 两边弱但有 sharp \(q=1/2\)
  Hölder error bound。
- **空间、集合：** \(X=\mathbb R^2\)，
  \[
  A=\{(s,0):s\in\mathbb R\},\qquad
  B=\{(t,t^2):t\in\mathbb R\},\qquad A\cap B=\{0\}.
  \]
  两者是 closed \(C^\infty\) embedded manifolds，因而在 0 附近 prox-regular。
- **projectors：** \(P_A(r,s)=(r,0)\)。局部 \(P_B(r,s)=(t,t^2)\)，其中唯一小 root
  \[
  t-r+2t(t^2-s)=0. \tag{20.1}
  \]
  在 \(x_\tau=(\tau,0)\) 上，root \(t=\tau-2\tau^3+O(\tau^5)\)。
- **set mapping、graph、inverse：** \(\Phi\) 如 (0.1)，zero为 \(\{0\}\)，graph由
  \(x+u\in A,x+v\in B\) 给出。若 \(\Delta:=v_2-u_2\)，则
  \[
  \Phi^{-1}(u,v)=
  \begin{cases}
  \{(-v_1+\sqrt\Delta,-u_2),(-v_1-\sqrt\Delta,-u_2)\},&\Delta>0,\\
  \{(-v_1,-u_2)\},&\Delta=0,\\
  \varnothing,&\Delta<0.
  \end{cases} \tag{20.2}
  \]
  \(J/R\) N/A。
- **ordinary failure与 sharp exponent：** 沿 \(x_\tau=(\tau,0)\)，
  \(d(x_\tau,A)=0\)，由 (20.1)
  \[
  d(x_\tau,B)=\tau^2(1+O(\tau^2)),\qquad d(x_\tau,A\cap B)=|\tau|.
  \]
  故无 local linear regularity/subtransversality，\(\Phi\) 非 MSR/SMSR；更不 transversal/MR/SMR。
  另一方面若 \(\varepsilon=\max\{d(x,A),d(x,B)\}\)，取近投影
  \((t,t^2)\in B\) 可得 \(|x_2|\le\varepsilon\)、\(|x_1-t|\le2\varepsilon\)、
  \(t^2\le3\varepsilon\)，从而
  \(\|x\|\le C\varepsilon^{1/2}\)。所以 \(q=1/2\)-SMSR/MSR 成立；上面的
  \(x_\tau\) 证明 \(q_*=1/2\) sharp。
- **normal / truncation：** \(N_A(0)=N_B(0)=\{0\}\times\mathbb R\)，normal qualification失败。
  每个 smooth curved-manifold normal 的 hypomonotonicity只对 local norm-truncated graph陈述；
  不声称 \(N_B\) full cone graph有 finite modulus。
- **来源：** SELF-CONSTRUCTED / ALG；smooth/prox-regular 与 set-regularity框架见
  Poliquin--Rockafellar--Thibault 2000、Kruger--Luke--Thao primary locators。

### SVG-21 — infinite-dimensional zero-angle subspaces：normal intersection trivial 仍无 subtransversality

- **目的 / gap cells：** 无限维 closed-subspace / set-linear-regularity gap；显示 finite-dimensional
  normal qualification 不能在缺 closed-angle/range 条件下照搬；两 individual normal cones max，
  pair regularity 两边都弱。
- **空间、集合：** 令 \(K=\ell^2\)，\(H=K\oplus K\)，
  \(T:K\to K\) 为 \(Te_n=n^{-1}e_n\)（bounded、compact、injective，range非闭）。取
  \[
  A=K\oplus\{0\},\qquad B=\operatorname{gra}T,\qquad A\cap B=\{0\}.
  \]
  \(A,B\) 是 closed linear subspaces。
- **projectors / individual resolvents：**
  \[
  P_A(u,v)=(u,0),\qquad
  P_B(u,v)=(z,Tz),\quad z=(I+T^*T)^{-1}(u+T^*v).
  \]
  \(N_A,N_B\) 都 maximally cyclically monotone，\(J_{\lambda N_A}=P_A\)、
  \(J_{\lambda N_B}=P_B\)，reflected resolvents是 subspace reflections。
- **set mapping、inverse：** \(\Phi\) 如 (0.1)，zero为 \(\{0\}\)。写
  \(u=(u_1,u_2),v=(v_1,v_2)\)，则
  \[
  \Phi^{-1}(u,v)=
  \begin{cases}
  \{(T^{-1}(v_2-u_2-Tv_1),-u_2)\},&
  v_2-u_2-Tv_1\in\operatorname{ran}T,\\
  \varnothing,&\text{otherwise}.
  \end{cases}
  \]
  graph仍由 \(x+u\in A,x+v\in B\) 给出；\(J/R\) N/A。
- **subtransversality failure：** 对 \(z_n=(e_n,0)\in A\)，
  \[
  d(z_n,A\cap B)=1,\qquad d(z_n,A)=0,\qquad
  d(z_n,B)=\frac1{\sqrt{n^2+1}}\to0.
  \]
  缩放为 \(t_nz_n\to0\) 保持同一 ratio，故 local/bounded/global linear regularity全失败，
  \(\Phi\) 非 MSR/MR/SMSR/SMR。更强地，对每个 \(q>0\) 都可选 \(t_n\downarrow0\) 使
  \(t_n/(t_n/\sqrt{n^2+1})^q\to\infty\)：\(q=1\) 任取；\(q>1\) 可取 \(t_n=n^{-1}\)；
  \(0<q<1\) 取 \(t_n=n^{-k}\) 且 \(0<k<q/(1-q)\)。故无任何 power-\(q\) MSR。
- **normal surprise：** \(A^\perp=\{0\}\oplus K\)，
  \(B^\perp=\{(-T^*w,w):w\in K\}\)。因 \(T^*\) injective，
  \(N_A(0)\cap[-N_B(0)]=\{0\}\)，但 Friedrichs angle 为0且相关 range不闭，仍不 transversal。
- **来源：** SELF-CONSTRUCTED / ALG；无限维警告与 set mapping equivalence依
  Kruger--Luke--Thao 2017 的 normed-space formulation。

### SVG-22 — local linear regularity at one point does not imply bounded linear regularity

- **目的 / gap cells：** local-at-reference \(\wedge\neg\)bounded \(\wedge\neg\)global；
  同一 closed nonconvex pair 在不同 intersection components 有隔离与切触两种机制。
- **空间、集合：**
  \[
  X=\mathbb R^2,\quad A=\mathbb R\times\{0\},\quad
  B=\{(0,0)\}\cup\{(2+t,t^2):t\in\mathbb R\}.
  \]
  二者 closed，\(A\cap B=\{(0,0),(2,0)\}\)。
- **projection：** \(P_A(r,s)=(r,0)\)。在 0 的充分小 neighborhood，\(P_Bx=0\)；
  在 \((2,0)\) 附近，parabola branch projection参数 \(t\) 满足
  \(2+t-r+2t(t^2-s)=0\)。
- **set mapping / graph / inverse：** \(\Phi\) 如 (0.1)，
  \(\operatorname{gph}\Phi=\{(x,(u,v)):x+u\in A,x+v\in B\}\)，
  \(\operatorname{zer}\Phi=A\cap B\)，
  \[
  \Phi^{-1}(u,v)=(A-u)\cap(B-v).
  \]
  该交集是 isolated-point translate 与/或 quadratic equations 的有限 union；\(J/R\) N/A。
- **regularity at reference 0：** parabola component 与 0 有正距离，故对充分小 \(x\)，
  \(d(x,B)=\|x\|\) 且 \(d(x,A\cap B)=\|x\|\)。因此 local linear regularity/MSR exact
  modulus1。0 在 solution set中孤立，故 \(\Phi\) 亦 SMSR exact1；但 pair不 transversal：
  locally \(B=\{0\}\)，generic small translations of the point and line不相交，所以 MR/SMR失败。
- **bounded/global failure：** 在另一交点附近取 \(x_t=(2+t,0)\)，则
  \(d(x_t,A)=0\)，
  \(d(x_t,B)=t^2(1+O(t^2))\)，
  \(d(x_t,A\cap B)=|t|\)。所以包含 \((2,0)\) 的某个 bounded ball上没有统一 modulus，
  从而不 boundedly linearly regular、更不 global。
- **来源：** SELF-CONSTRUCTED / ALG；local/bounded/global definitions见
  Kruger--Luke--Thao, Set Regularities and Feasibility Problems primary locator。

### SVG-23 — boundedly linearly regular but not globally linearly regular

- **目的 / gap cells：** bounded \(\wedge\neg\)global linear regularity 的显式 closed-set witness。
- **空间、集合：**
  \[
  X=\mathbb R^2,\quad A=\mathbb R\times\{0\},\quad
  B=\{(0,0)\}\cup\{(t,1/t):t\ge1\}.
  \]
  \(B\) closed，且 \(A\cap B=\{0\}\)。
- **projection：** \(P_A(r,s)=(r,0)\)。在 0 的小 neighborhood，\(P_Bx=0\)；对 hyperbola
  branch 的 projection 参数 \(t\ge1\) 满足
  \[
  t-r-\frac{1/t-s}{t^2}=0
  \]
  （并与 isolated candidate \(0\) 比较距离）。
- **set mapping / graph / inverse：** \(\Phi\) 如 (0.1)，graph由
  \(x+u\in A,x+v\in B\) 给出，zero为 \(\{0\}\)，
  \(\Phi^{-1}(u,v)=(A-u)\cap(B-v)\)；\(J/R\) N/A。
- **local / bounded proof：** 0 到 hyperbola branch 有正距离，因此近0有
  \(d(x,B)=\|x\|\)，local modulus为1且 \(\Phi\) 在 \((0,0)\) SMSR/MSR（零点孤立）。
  对任意固定 bounded ball \(\overline B_R(0)\)，令
  \(g(x)=\max\{d(x,A),d(x,B)\}\)。在近0处 \(g(x)=\|x\|\)；在 compact annulus
  \(\{\delta\le\|x\|\le R\}\) 上，\(g\) 连续且无零点，故
  \(\sup d(x,\{0\})/g(x)<\infty\)。所以 family boundedly linearly regular。
- **global failure：** 沿 \(x_t=(t,0)\)，\(t\ge1\)，
  \[
  d(x_t,A\cap B)=t,\qquad d(x_t,A)=0,\qquad
  d(x_t,B)\le1/t,
  \]
  因而所需 global modulus至少 \(t^2\to\infty\)。pair 在0也不 transversal（local second set
  是 isolated point），所以 \(\Phi\) 非 MR/SMR。
- **来源：** SELF-CONSTRUCTED / ALG；linear-regularity层级 terminology见
  Kruger--Luke--Thao primary locator。

## 3. Coverage index（只作 B→C handoff，不作 seesaw synthesis）

| ID | object type | graph-side coordinate | regularity coordinate at printed reference | isolation / vacuity |
|---|---|---|---|---|
| SVG-01 | convex normal | max cyclic, not strong | MSR; not MR/SMSR/SMR | nonisolated; domain-vacuous |
| SVG-02 | same normal, shifted target | max cyclic, not strong | SMR/MR/SMSR/MSR, modulus infimum 0 | isolated target fiber; partly domain-vacuous |
| SVG-03 | convex subdifferential | max cyclic, not strong | SMR/MR/SMSR/MSR, modulus infimum 0 | isolated; residual jump |
| SVG-04 | smooth convex subdifferential | max cyclic, not strong | no linear MSR; sharp \(q=1/3\)-SMSR | isolated; nonvacuous |
| SVG-05 | zero operator | max monotone, not strong | MSR only | nonisolated; big-solution triviality |
| SVG-06 | vertical normal | max and formally any strong modulus | SMR/MR/SMSR/MSR, infimum 0 | isolated; domain-vacuous |
| SVG-07 | shifted convex normal | maximally \(\mu\)-strong | SMR/MR/SMSR/MSR, \(1/\mu\) | isolated; sharp nonvacuous side |
| SVG-08 | restricted slope | \(\mu\)-strong, nonmaximal | SMSR/MSR \(1/\mu\); no MR/SMR | isolated; output-coverage failure |
| SVG-09 | singleton graph | all pairwise labels vacuous, nonmaximal | SMSR/MSR only, infimum 0 | isolated; both graph/domain vacuous |
| SVG-10 | subspace normal | max cyclic, \(R\) isometry | MSR only | nonisolated; domain-vacuous |
| SVG-11 | projection residual | exact 1-cocoercive | MSR exact1; no MR/SMSR/SMR | nonisolated; nonvacuous |
| SVG-12 | two-branch relation | no finite local hypo, no RL | MR + SMSR, not SMR | isolated; branch nonuniqueness |
| SVG-13 | vertical-value relation | no finite local hypo, no RL | MR/MSR exact1; no SMSR/SMR | nonisolated |
| SVG-14 | absolute value | sharp 1-hypomonotone | SMSR/MSR exact1; no MR/SMR | isolated; nonvacuous |
| SVG-15 | zero/identity union | no finite local hypo, no RL | MSR + HREG; no MR/SMSR/SMR | nonisolated; big-solution triviality |
| SVG-16 | circle normal | full cone no finite hypo; truncated sharp \(\rho\) | MSR only | nonisolated; domain-vacuous |
| SVG-17 | limiting subgradient | local monotone localization, full RL fails | MSR only at target1 | nonisolated; residual jump |
| SVG-18 | transverse axes | two max-normal components; transverse pair | \(\Phi\) SMR/MR/SMSR/MSR \(\sqrt2\) | isolated; nonvacuous |
| SVG-19 | identical lines | two max-normal components; nontransverse pair | \(\Phi\) MSR exact1 only | nonisolated |
| SVG-20 | tangent smooth sets | truncated local normal geometry only | no ordinary MSR; sharp \(q=1/2\)-SMSR | isolated; nonvacuous |
| SVG-21 | zero-angle subspaces | two max normals; pair angle zero | no power-\(q\) MSR for any \(q>0\) | isolated; nonvacuous |
| SVG-22 | isolated + tangent components | pointwise local strong EB, globally mixed | local SMSR/MSR; no MR; not bounded LR | locally isolated |
| SVG-23 | isolated + asymptotic branch | bounded but not global LR | local SMSR/MSR; no MR | isolated |

### 3.1 Required logical regions actually populated

- **MR / SMSR / SMR core:** SMR (SVG-02/03/06/07/18)；MR but not SMSR
  (SVG-13)；SMSR but not MR (SVG-08/14/22/23)；MR + SMSR but not SMR
  (SVG-12)；neither MR nor SMSR (SVG-04/20/21)；MSR without either
  (SVG-01/05/10/11/15/17/19)。
- **maximality vs strong:** maximal not strong (SVG-01/03/04/05/10)；
  strong not maximal (SVG-08)；both (SVG-07)；neither in a nonvacuous branch object
  (SVG-14)，另有 singleton-vacuity stress test (SVG-09)。
- **cross-axis cloud:** graph weak / regularity strong (SVG-02/03/12/13/14)；
  graph pedigree strong / regularity weak (SVG-04/05/10/11，其中“strong”是 maximal/cyclic/coco
  而非统一 scalar order)；both strong (SVG-07/18)；both weak (SVG-20/21)。
- **set linear regularity strict gaps:** transversal \(\Rightarrow\) subtransversal 的 strict witness
  SVG-18 vs SVG-19；local \(\not\Rightarrow\) bounded 为 SVG-22；bounded
  \(\not\Rightarrow\) global 为 SVG-23；even local subtransversality 可失败于 finite-dimensional
  tangency (SVG-20) 与 infinite-dimensional zero angle (SVG-21)。
- **truncation / vacuity audit:** full-normal truncation necessity由 SVG-16 定量显示；
  domain-vacuity由 SVG-01/06/09/10/16 标红；big-solution triviality由 SVG-05/15 区分；
  residual-jump modulus-zero由 SVG-03/17 区分。

## 4. Source-verification and validation record

- **Search mode：** bounded primary-source confirmation，非 systematic review；检索日期
  2026-09-01。broad queries 包括
  “transversality subtransversality sets metric regularity arXiv 1611.04787”、
  “Poliquin Rockafellar prox-regular normal cone hypomonotonicity”、
  “Rockafellar maximal cyclically monotone subdifferential 1970”、
  “Minty monotone nonlinear operators Hilbert 1962”；搜索界面未提供可靠 hit counts。
- **VERIFIED_SOURCE：** Kruger--Luke--Thao 2017 full text 的 Definitions 1--3、
  Proposition 2、identical-lines Examples 1--2；Rockafellar 1970 official journal page；
  Minty 1962 Project Euclid record；BMW arXiv author manuscript；Poliquin--Rockafellar--Thibault
  DOI/primary bibliographic record。未把 abstract-only access 当成逐页 theorem verification。
- **EXECUTED_LOCAL / ALG checks：** 所有 displayed inverse、resolvent、inner products 与 residual
  laws由直接代入得到；SVG-20/22 的 \(t^2\) tangency order 来自显示 projection stationarity；
  SVG-21 的 distance 是每个 coordinate two-dimensional line projection的闭式值。
- **PENDING C audit：** exact moduli采用 atlas conventions，仍须 C 独立重算；尤其请复核
  SVG-20 的 \(q=1/2\) full-neighborhood constant、SVG-21 的 all-\(q\) failure quantifiers、
  SVG-22/23 的 mapping-side MR failure，以及 SVG-16 localized reflected-resolvent最优常数。
- **No synthesis：** 本文件只登记可计算 points 和 strict-gap witnesses；没有从这些点推出
  monotonicity--regularity trade-off law，也没有把任何 heuristic analogy 升级为 theorem。
