# Monotonicity atlas（Subagent A：monotonicity side）

> 版本：2026-09-01。范围限于 generalized monotonicity/graph geometry；不在此稿中作任何 monotonicity–regularity “跷跷板”结论。除特别说明外，空间是实 Hilbert 空间 \(H\)，映射 \(A:H\rightrightarrows H\) 可多值，且比较图上任意两点
>
> \[
> (x,u),(y,v)\in\operatorname{gra}A,\qquad a=x-y,\quad b=u-v.
> \]

## 0. 证据等级、约定与 Cayley 字典

### 0.1 证据等级

- **FT-P**：已读取 primary source 全文（作者稿、期刊全文或官方扫描）。
- **ABS-P**：只核验到 primary source 的官方摘要/元数据；不据此声称正文中的精细常数。
- **FT-LP**：全文可读的 later primary source；用于核验原始术语的现代标准表述。
- **ALG**：由已列定义直接代数推导，给出推导式，不冒充文献定理。

“maximal \(Q\)”一律指在保持性质 \(Q\) 的图包含偏序下无真扩张；这与“值域/定义域最大”“数值参数最大”不同。局部性质若未指定邻域、基点和值截断，原则上不与全局性质画无条件蕴含边。

### 0.2 Resolvent/reflected-resolvent 的精确字典

固定 \(\lambda>0\)，令

\[
D_\lambda:=\operatorname{ran}(I+\lambda A),\qquad
J_{\lambda A}=(I+\lambda A)^{-1},\qquad
R_{\lambda A}=2J_{\lambda A}-I.
\]

给定两图点，置 \(d=a+\lambda b,\ r=a-\lambda b\)。在 Minty 参数化 \(p=x+\lambda u,q=y+\lambda v\) 下，

\[
p-q=d,\quad J_{\lambda A}p-J_{\lambda A}q=a,\quad
R_{\lambda A}p-R_{\lambda A}q=r,\quad
4\lambda\langle a,b\rangle=\|d\|^2-\|r\|^2. \tag{C}
\]

这里 \(J,R\) 首先只定义在 \(D_\lambda\)。任何“在整个 \(H\) 上”的结论都还需要 \(D_\lambda=H\)，通常由 maximality/Minty surjectivity 给出。[Minty 1962, **FT-P**](https://projecteuclid.org/journals/duke-mathematical-journal/volume-29/issue-3/Monotone-nonlinear-operators-in-Hilbert-space/10.1215/S0012-7094-62-02933-2.short)；[Bauschke–Moffat–Wang 2011, **FT-P**](https://arxiv.org/pdf/1101.4688)。

尺度和取逆规则（**ALG**）是后文参数换算的保险丝：

\[
\operatorname{gra}A^{-1}=\{(u,x):(x,u)\in\operatorname{gra}A\},\qquad
\lambda A:\ (a,b)\mapsto(a,\lambda b).
\]

## 1. 核心 pairwise graph classes

### 1.1 Monotone、strict、uniform、strong

| 类 | 精确定义（所有图点对） | 空间/值型/范围 | inverse 与参数 | resolvent / reflected resolvent | maximality 与主要关系 |
|---|---|---|---|---|---|
| monotone | \(\langle a,b\rangle\ge0\) | Hilbert；可多值；默认全图全局，局部版只在指定图邻域 | 自对偶：\(A^{-1}\) monotone | 由 (C)：\(J\) firmly nonexpansive，等价 \(R\) nonexpansive（先在 \(D_\lambda\)） | maximally monotone \(\Longleftrightarrow D_\lambda=H\)（任一/每一 \(\lambda>0\)）；Minty 定理 |
| strictly monotone | \(x\ne y\Rightarrow\langle a,b\rangle>0\) | 可多值；严格性只排除不同 base points，不排除同一点多值 | \(A^{-1}\) 的 strictness 不是自动结论 | 对 max monotone \(A\)，\(J\) 满足相应严格 firm inequality；若再加 \(A\) at most single-valued，则 \(R\) strictly nonexpansive | strong \(\Rightarrow\) strict \(\Rightarrow\) monotone，均严格 |
| uniformly monotone | \(\langle a,b\rangle\ge\phi(\|a\|)\)，\(\phi\) increasing 且只在 \(0\) 为 \(0\) | Hilbert；可多值；可作局部 modulus | 取逆后成为以 \(\|b\|\) 为自变量的 uniform co-monotonicity，不是原式自对偶 | \(\langle Jp-Jq,(I-J)p-(I-J)q\rangle\ge\lambda\phi(\|Jp-Jq\|)\) | \(\phi(t)=\mu t^2\) 即 \(\mu\)-strong；一般 uniform 不等价于任何固定 \(\mu>0\) |
| \(\mu\)-strongly monotone | \(\langle a,b\rangle\ge\mu\|a\|^2,\ \mu>0\)；等价 \(A-\mu I\) monotone | Hilbert；可多值；局部/全局均可定义 | \(A^{-1}\) 是 \(\mu\)-cocoercive，而非一般意义下 \(\mu\)-strong | \((1+\lambda\mu)J_{\lambda A}\) firmly nonexpansive，故 \(J\) Lipschitz \(\le(1+\lambda\mu)^{-1}\)。若 \(A\) maximal，则 \(\lambda\mu I+(1+\lambda\mu)R_{\lambda A}\) nonexpansive | maximal \(\mu\)-monotone 可定义为 \(A-\mu I\) max monotone；strong 单独不保证 maximal |

以上 resolvent 刻画见 [Bauschke–Moffat–Wang 2011, Thms. 2.1, 4.3, **FT-P**](https://arxiv.org/pdf/1101.4688)。必须避免两个常见误写：

1. \(J_{\lambda A}\) 是 Banach contraction **不能反推** \(A\) strong monotone；二维 \(90^\circ\) 旋转 \(S\) 满足 \(\langle z,Sz\rangle=0\)，但 \(J_S\) 的范数是 \(1/\sqrt2\)。
2. \(A\) strong monotone 一般只给 \(J\) contraction，**不保证** \(R\) contraction。对 max monotone \(A\)，\(R_A\) 是 Banach contraction 当且仅当 \(A\) 与 \(A^{-1}\) 都 strong monotone；精确等价的 pairwise 条件为

   \[
   (1-\beta^2)(\|a\|^2+\|b\|^2)
   \le2(1+\beta^2)\langle a,b\rangle,\qquad 0\le\beta<1.
   \]

   见同文 Thm. 4.4 和 Cor. 4.7。

严格包含见证：\(x\mapsto x^3\) 在 \(\mathbb R\) strictly monotone 但无全局 strong modulus；\(A=0\) monotone 但不 strict；\(A=\mu I+N_C\)（非平凡闭凸 \(C\)）可 maximal strong 且多值。

### 1.2 \(\rho\)-monotone / hypomonotone / weakly monotone

统一采用

\[
\langle a,b\rangle\ge\rho\|a\|^2,\qquad \rho\in\mathbb R. \tag{M\(_\rho\)}
\]

- \(\rho>0\)：strongly monotone；\(\rho=0\)：monotone；\(\rho=-r<0\)：\(r\)-hypomonotone，即 \(A+rI\) monotone。现代优化中的“\(r\)-weakly monotone”通常就是这个式子；该名称在 PDE、序理论及伪单调文献还有别义，不能脱离公式合并。
- 空间/值型：Hilbert、可多值；全局或在图邻域局部成立。参数 convention 有 signed \(\rho\) 或 violation \(r\ge0\) 两种，本稿始终标符号。
- inverse：取逆得到 \(\rho\)-comonotone，不是同参数 \(\rho\)-monotone。
- maximality：maximally \(\rho\)-monotone 等价 \(A-\rho I\) maximally monotone。
- resolvent（**ALG**）：若 \(\rho=-r\) 且 \(\lambda r<1\)，

  \[
  \langle Jp-Jq,p-q\rangle\ge(1-\lambda r)\|Jp-Jq\|^2,
  \]

  所以 \(J\) Lipschitz \(\le(1-\lambda r)^{-1}\)，且 \(R\) Lipschitz \(\le(1+\lambda r)/(1-\lambda r)\)；\(A=-rI\) 说明这些界可达。full-domain 仍需相应 maximality。

主来源：[Bauschke–Moursi–Wang 2019, **FT-P**](https://arxiv.org/pdf/1902.09827)。弱单调术语的一种公式用法见 [El Farouq, **FT-P**](https://fc.isima.fr/~naelfaro/publis/ElFarouq-JOTA-Progressive-Pseudomonotonie.pdf)。

### 1.3 \(\rho\)-comonotone、cocoercive、cohypomonotone

定义

\[
\langle a,b\rangle\ge\rho\|b\|^2,\qquad \rho\in\mathbb R. \tag{C\(_\rho\)}
\]

这是 \((M_\rho)\) 的逆像：

\[
A\text{ is }\rho\text{-comonotone}
\Longleftrightarrow A^{-1}\text{ is }\rho\text{-monotone}. \tag{1.1}
\]

- \(\rho=\beta>0\)：\(\beta\)-cocoercive，也常叫 \(\beta\)-inverse strongly monotone；它自动 at most single-valued 且 \(1/\beta\)-Lipschitz（在定义域上），并蕴含 monotone。
- \(\rho=-s<0\)：\(s\)-cohypomonotone。它是 \(A^{-1}\) 的 \(s\)-hypomonotonicity；不要把 “co-” 当成补集或概率论中的 comonotonicity。
- scaling：若 \(A\) 是 \(\rho\)-comonotone，则 \(\lambda A\) 是 \(\rho/\lambda\)-comonotone。
- resolvent：若 \(\rho>-\lambda\)，\(J_{\lambda A}\) 在 \(D_\lambda\) single-valued，并为 conically averaged，系数

  \[
  \alpha=\frac{\lambda}{2(\lambda+\rho)}.
  \]

  \(R_{\lambda A}\) 的精确二次刻画是

  \[
  \|Rp-Rq\|^2\le\|p-q\|^2-\frac{\rho}{\lambda}
  \|(I-R)p-(I-R)q\|^2. \tag{1.2}
  \]

  当 \(\rho>-\lambda/2\) 时 \(J\) 是通常意义下 averaged；\(\rho=-\lambda/2\) 时仅能保证 nonexpansive；\(\rho<0\) 时 \(R\) 可 expansive。
- maximality：在 \(\rho>-\lambda\) 的 admissible 区间，maximal \(\rho\)-comonotone \(\Longleftrightarrow D_\lambda=H\)。

来源：[Bauschke–Moursi–Wang 2019, **FT-P**](https://arxiv.org/pdf/1902.09827)。

关系不是一条轴：strong monotone 与 cocoercive 由 inversion 对偶，互不蕴含。\( \mu I+N_C\) 可 strong 而非 single-valued/cocoercive；\(\operatorname{diag}(0,1)\) 是 \(1\)-cocoercive 但不 strong。即便单值、monotone、Lipschitz 也未必 cocoercive：非零 skew rotation 是反例。额外假设“\(A\) 是 \(\mu\)-strong 且 \(L\)-Lipschitz”才推出 \(\mu/L^2\)-cocoercivity。对 \(A=\nabla f\)，\(f\) convex 且梯度 \(L\)-Lipschitz 时有更强的 Baillon–Haddad \(1/L\)-cocoercivity；其梯度/凸性假设不可删。[Bauschke–Combettes 2010, **FT-P**](https://www.heldermann-verlag.de/jca/jca17/jca0932_b.pdf)。

固定参数下 hypo 与 cohypo 也不可排成全序。标量 \(A=-kI\) 满足 \(r\)-hypomonotone 当且仅当 \(k\le r\)，满足 \(s\)-cohypomonotone 当且仅当 \(k\ge1/s\)；随 \(r,s,k\) 可落入不同逻辑区域。

## 2. 两参数 semimonotonicity 与名称冲突

### 2.1 \((\mu,\rho)\)-semimonotone（Evens–Pas–Latafat–Patrinos convention）

在基点 \((x',y')\in\operatorname{gra}A\) 的定义是

\[
\langle x-x',y-y'\rangle
\ge\mu\|x-x'\|^2+\rho\|y-y'\|^2
\quad\forall(x,y)\in\operatorname{gra}A. \tag{S\(_{\mu,\rho}\)}
\]

若对每个图点作基点成立，即 global \((\mu,\rho)\)-semimonotone；“at \((x',y')\)”与 global 必须区分，maximality 是同参数图包含极大。定义及下述代数换算对 Hilbert 空间有意义，但所引 Evens et al. 原文的定理设置是有限维 \(\mathbb R^n\)；其 maximal transform、outer-semicontinuity 与 full-domain resolvent 结论在本稿只按该设置引用，不擅自升级到任意无限维 Hilbert 空间。[Evens et al. 2023, Def. 4.1, **FT-P**](https://arxiv.org/pdf/2305.03605)。

精确 calculus：

\[
A^{-1}:(\mu,\rho)\mapsto(\rho,\mu),\qquad
\lambda A:(\mu,\rho)\mapsto(\lambda\mu,\rho/\lambda). \tag{2.1}
\]

因此 \((\mu,0)\) 统一 strong/hypo，而 \((0,\rho)\) 统一 coco/cohypo。可行参数区有两个容易漏掉的退化面：

- 若 \([\mu]_{-}[\rho]_{-}\ge1/4\)，Young inequality 使每个映射都满足该不等式，性质无区分力。
- 若 \([\mu]_{+}[\rho]_{+}>1/4\)，不存在含两个不同图点的非退化图；在等号正参数边界，图被迫落在 affine slope \(2\mu I+c\) 上。

当 \(\mu\rho<1/4\) 时，令

\[
\xi=\frac{\rho}{\sqrt{1-4\mu\rho}},\qquad
\nu=\frac{2\mu}{1+\sqrt{1-4\mu\rho}},\qquad
\mathcal M=(A-\nu I)^{-1}-\xi I.
\]

则 \(A\)（maximally）\((\mu,\rho)\)-semimonotone 当且仅当 \(\mathcal M\)（maximally）monotone。这是 inverse characterization，但不是简单的 \(A^{-1}\) monotone。

对 admissible 步长

\[
\lambda\in\left(
\frac{2[-\rho]_+}{1+\sqrt{1-4\mu\rho}},
\frac{1+\sqrt{1-4\mu\rho}}{2[-\mu]_+}
\right), \tag{2.2}
\]

零分母解释为 \(+\infty\)，maximality 等价于 \(J_{\lambda A}\) full-domain；其 Lipschitz modulus 可取

\[
L_J(\lambda)=
\frac{|1+2\rho/\lambda|+\sqrt{1-4\mu\rho}}
{2(1+\mu\lambda+\rho/\lambda)}. \tag{2.3}
\]

reflected-resolvent 不是一般的无交叉项 Lipschitz 球。令 \(m=\lambda\mu,s=\rho/\lambda\)，由 (C) 直接得到精确式（**ALG**）

\[
(1-m-s)\|d\|^2-(1+m+s)\|r\|^2
-2(m-s)\langle d,r\rangle\ge0. \tag{2.4}
\]

因此把所有 \((\mu,\rho)\) 类按单一 \(R\)-Lipschitz 常数排序会丢掉方向/交叉项信息。

### 2.2 Otero–Iusem 的 \(\theta\)-semimonotone

其 convention（\(\theta\in(0,1)\)）为

\[
\langle a,b\rangle\ge-\frac\theta2(\|a\|^2+\|b\|^2). \tag{O\(_\theta\)}
\]

即 \((\mu,\rho)=(-\theta/2,-\theta/2)\)。它 self-dual；maximality 也在 inversion 下保持。若 \(\theta\ge1\)，Young inequality 使条件对所有映射自动成立，所以论文只取 \(0<\theta<1\)。若 \(A\) 是 \(r\)-hypomonotone 且 \(r<1/2\)，则 \(A\) 是 \(2r\)-semimonotone，但逆向一般不成立。

论文给出显式 monotone transform：

\[
\beta=\frac{1-\sqrt{1-\theta^2}}\theta,\quad
\eta=\frac{1+\sqrt{1-\theta^2}}\theta,\quad
\gamma=\frac\theta{2\sqrt{1-\theta^2}},
\]

且 \((A+\beta I)^{-1}+\gamma I\)（maximally）monotone 当且仅当 \(A\)（maximally）\(\theta\)-semimonotone；\((A+\lambda I)^{-1}\) 在 \(\lambda\in(\beta,\eta)\) single-valued Lipschitz，maximal 时 full-domain。[Otero–Iusem 2010, **FT-P**](https://webdoc.sub.gwdg.de/ebook/serien/e/IMPA_A/672.pdf)。

同一文中的 premonotone 是另一条件，例如

\[
\langle x-y,u-v\rangle\ge-\sigma(y)\|x-y\|,
\]

右侧是基点依赖、一次阶且不对称；不能因名称相近并入 \((\mu,\rho)\)-semimonotonicity。

### 2.3 “submonotone”至少有两种不等价传统

#### (a) Luke–Tam 的 resolvent-adapted submonotonicity

在集合 \(U\subset H,W\subset H\) 上、violation \(\tau\ge0\)：

\[
\langle a,b\rangle\ge-\tau\|a+b\|^2,\quad
(x,u),(y,v)\in\operatorname{gra}A\cap(U\times W). \tag{LT\(_\tau\)}
\]

这是局部/全局均可的 set-valued graph inequality；inverse-invariant。其 “maximal submonotone on \(U\times W\)” 指不存在保持同一局部不等式的真图扩张。由 (C)（此处 \(\lambda=1\)）精确等价

\[
\|R_Ap-R_Aq\|\le\sqrt{1+4\tau}\,\|p-q\|. \tag{2.5}
\]

作者在算法框架中常再取 \(\tau<1/2\) 以使 almost-firm violation 小于 \(1\)；但 (2.5) 的代数等价本身对任意 \(\tau\ge0\) 成立。若 \(A\) 是 \(\sigma\)-hypomonotone 且 \(\sigma<1/2\)，则它是 LT-submonotone，

\[
\tau=\frac\sigma{1-2\sigma}. \tag{2.6}
\]

逆向需要额外图斜率控制；\(F(x)=-\sqrt{x}\) 在小正区间是 LT-submonotone 而非任何有限常数的局部 hypomonotone，给出严格性。[Luke–Tam 2025, 官方全文 HTML, **FT-P**](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863)。

#### (b) Spingarn/variational-analysis 的 asymptotic submonotonicity

后续文献常把其局部标准形写为

\[
\liminf_{\substack{y,y'\to\bar x,\ y\ne y'\\
u\in A(y),v\in A(y')}}
\frac{\langle u-v,y-y'\rangle}{\|y-y'\|}\ge0. \tag{SP}
\]

它通常配以局部有界、闭凸值等条件，约束缩小尺度下的一阶负偏差，不是固定 \(\tau\) 的 \(\|a+b\|^2\) bound。原始来源 [Spingarn 1982, **ABS-P**](https://www.tandfonline.com/doi/abs/10.1080/01630568208816109)；公式由 later full-text source 核验 [Jofré–Thibault, **FT-LP**](https://www.heldermann-verlag.de/jca/jca15/jca0651_b.pdf)。在取得原始全文前，不把 (SP) 的所有历史变体或 “maximal submonotone” 与 LT 定义互换。

## 3. VI 传统：quasimonotone / pseudomonotone

取凸集 \(C\subset H\) 与单值 \(F:C\to H\)。一种 Karamardian/VI convention 是

\[
\begin{aligned}
F\text{ pseudomonotone}:&\quad
\langle F(x),y-x\rangle\ge0
\Rightarrow\langle F(y),y-x\rangle\ge0,\\
F\text{ quasimonotone}:&\quad
\langle F(x),y-x\rangle>0
\Rightarrow\langle F(y),y-x\rangle\ge0.
\end{aligned} \tag{VI}
\]

在此 convention 下

\[
\text{monotone}\Rightarrow\text{pseudomonotone}
\Rightarrow\text{quasimonotone},
\]

且均严格：\(F(x)=2+\sin x\) 在任一实区间上取正值，故 pseudomonotone，但在含导数为负区段的区间不 monotone；\(F(x)=x^2\) 在 \([-1,1]\) quasimonotone 但不 pseudomonotone。[Aussel et al. 2020, **FT-P**](https://optimization-online.org/wp-content/uploads/2020/02/7602.pdf)。

这些定义用 \(F(x),F(y)\) 分别相对位移的符号，不是 \(\langle F(x)-F(y),x-y\rangle\) 的定量下界；一般没有 \(A^{-1}\)、\(J_A\)、\(R_A\) 的 pairwise metric 等价，也没有统一的“maximal graph extension”主流含义。多值、strict/pseudo-plus 等变体必须另给量词。

**Brézis pseudomonotonicity 是不同概念。** 在 reflexive Banach 空间的一种单值序列定义为：若 \(x_n\rightharpoonup x\) 且

\[
\limsup_n\langle Ax_n,x_n-x\rangle\le0,
\]

则对每个 \(y\)，

\[
\langle Ax,x-y\rangle\le
\liminf_n\langle Ax_n,x_n-y\rangle.
\]

它是弱拓扑/极限闭合性质；在适当 boundedness/hemicontinuity 等假设下，monotone operators 给出重要子类，但它与 (VI) 不可无假设互换。[Papageorgiou–Rădulescu–Repovš 2018, **FT-P**](https://arxiv.org/pdf/1810.03995)。

## 4. 多点图结构：cyclic、\(n\)-cyclic、paramonotone、3*-monotone

### 4.1 \(n\)-cyclic monotonicity 与 maximal cyclic monotonicity

对 \(n\ge2\)，\(A\) 是 \(n\)-cyclically monotone 若对任意 \(n\) 个图点、\(x_{n+1}=x_1\)，

\[
\sum_{i=1}^{n}\langle x_i-x_{i+1},u_i\rangle\ge0. \tag{N\(_n\)}
\]

\(n=2\) 正是 ordinary monotonicity；对所有 \(n\) 成立称 cyclically monotone。若 \(m\ge n\)，\(m\)-cyclic \(\Rightarrow n\)-cyclic。取逆保持 \(n\)-cyclicity（循环重排后等价）。maximal \(n\)-cyclic 是相对于固定 \(n\) 的图极大。

严格层级可由 \(\mathbb R^2\) 旋转给出：角度 \(\theta\) 的 rotation \(R_\theta\) 是（maximal）\(n\)-cyclic monotone 当且仅当 \(|\theta|\le\pi/n\)；故选 \(\pi/(n+1)<|\theta|\le\pi/n\) 即得 \(n\)-cyclic 但非 \((n+1)\)-cyclic。只有 \(\theta=0\) 属于全部阶。[Bauschke et al. 2024, **FT-P preprint**](https://arxiv.org/html/2411.04212v2)。

Rockafellar 定理：\(A\) cyclically monotone 当且仅当 \(\operatorname{gra}A\subseteq\operatorname{gra}\partial f\) 对某 proper convex \(f\)；maximal cyclically monotone 当且仅当 \(A=\partial f\)（取 proper lsc convex representative）。因此 maximal cyclic \(\Rightarrow\) maximal monotone，严格性由非零 skew rotation 给出。[Rockafellar 1966, **FT-P**](https://msp.org/pjm/1966/17-3/pjm-v17-n3-p08-p.pdf)；[Rockafellar 1970, **FT-P**](https://msp.org/pjm/1970/33-1/pjm-v33-n1-p19-s.pdf)。

resolvent 侧：对 max cyclic \(A=\partial f\)，\(J_A=\operatorname{prox}_f\)；更一般的 cyclic condition 等价于 \(J_A\) 的 cyclic firm nonexpansiveness

\[
\sum_{i=1}^n\langle x_i-J_Ax_i,\ J_Ax_i-J_Ax_{i+1}\rangle\ge0.
\]

它是多点条件，不能压缩为比 nonexpansiveness 更小的单一 Lipschitz 常数。[Bauschke–Moffat–Wang 2011, Thm. 2.1(xvi), **FT-P**](https://arxiv.org/pdf/1101.4688)。

### 4.2 Paramonotone

标准定义先假设 \(A\) monotone，再要求

\[
\langle a,b\rangle=0
\Rightarrow (x,v),(y,u)\in\operatorname{gra}A. \tag{P}
\]

它可多值、全局；局部变体必须另行声明。该性质在 inversion 下自对偶。maximally paramonotone 通常意为既 max monotone 又 paramonotone，而不是另造一种不含 monotonicity 的扩张序。

对 max monotone \(A\)，若 \(T=J_A\)，resolvent 刻画是

\[
\|Tx-Ty\|^2=\langle x-y,Tx-Ty\rangle
\Rightarrow
\begin{cases}
Tx=T(Tx+y-Ty),\\
Ty=T(Ty+x-Tx).
\end{cases} \tag{4.1}
\]

见 [Bauschke–Moffat–Wang 2011, Thm. 2.1(xv), **FT-P**](https://arxiv.org/pdf/1101.4688)。strong monotone、positive cocoercive 及 convex subdifferentials 都 paramonotone；ordinary max monotone 不必 paramonotone。

### 4.3 Rectangular / 3*-monotone

标准定义先假设 monotone，并要求对每个 \(x\in\operatorname{dom}A,v\in\operatorname{ran}A\)，

\[
\inf_{(z,w)\in\operatorname{gra}A}
\langle x-z,v-w\rangle> -\infty. \tag{R3*}
\]

它又称 rectangular；与 **3-cyclic monotone 完全不是同一概念**。它在 inversion 下自对偶。对 max monotone \(A\)、\(T=J_A\)，等价

\[
\inf_{z\in H}\langle Tx-Tz,(y-Ty)-(z-Tz)\rangle>-\infty,
\quad x,y\in H. \tag{4.2}
\]

见 [Bauschke–Moffat–Wang 2011, Thm. 2.1(xvii), **FT-P**](https://arxiv.org/pdf/1101.4688)。strong monotone、positive cocoercive 与 convex subdifferentials 均 rectangular。

Paramonotone 与 rectangular 在一般 max monotone 类中互不蕴含：[Bauschke–Wang–Yao 2012, **FT-P**](https://arxiv.org/pdf/1201.4220) 给出

- rectangular 非 paramonotone：\(\mathbb R^2\) 中 skew rotation 加单位球 normal cone；
- paramonotone 非 rectangular：\(\ell^2\) 上对角 \(D(x_n)=(x_n/n)\) 与 block-skew isometry 之和；
- 两者皆非：Volterra 型 max monotone operator。

### 4.4 不要混淆三种“3”

| 名称 | 数学对象 | 是否 pairwise |
|---|---|---|
| 3-cyclic monotone | (N\(_3\)) 的三点循环和 | 否 |
| 3*-monotone / rectangular | (R3*) 的 domain–range 下界 | 由整张图的 infimum 定义 |
| 3-monotone（少数文献） | 有时就是 3-cyclic，有时另有 convention | 必须查公式 |

## 5. Banach 空间 analogue：accretive / m-accretive

令 \(X\) 为实 Banach 空间，\(A:X\rightrightarrows X\)。\(A\) accretive 的范数定义是

\[
\|x-y+\lambda(u-v)\|\ge\|x-y\|,
\quad\forall\lambda>0,\quad (x,u),(y,v)\in\operatorname{gra}A. \tag{A}
\]

借 normalized duality map \(J_X(z)=\{z^*:\langle z,z^*\rangle=\|z\|^2=\|z^*\|^2\}\)，可表为存在适当 \(j\in J_X(x-y)\) 使 \(\langle u-v,j\rangle\ge0\)；非光滑 Banach 空间中量词 convention 要随原文核对。\(m\)-accretive 定义为 accretive 且

\[
\operatorname{ran}(I+\lambda A)=X\quad\text{对所有 }\lambda>0.
\]

- 值型/范围：可多值，全局；可定义 strong accretive、inverse strongly accretive，但要用 duality map，只有在 Hilbert 空间才分别还原 strong monotone/cocoercive。
- inverse：一般 Banach 中不存在由 \(X\) 与 \(X^*\) 无缝互换而保持同型的简单 \(A^{-1}\) 结论；Hilbert 自对偶后恢复前述 calculus。
- resolvent：accretive \(\Rightarrow J_{\lambda A}\) 在其 range 上 single-valued nonexpansive；m-accretive 使其 full-domain。
- reflected resolvent：\(2J-I\) 的 nonexpansiveness 使用 Hilbert 平行四边形恒等式，不能由 Banach-space accretivity 普遍推出。
- maximality：m-accretive \(\Rightarrow\) maximal accretive；在 Hilbert 空间二者与 maximal monotone 等价，在一般 Banach 空间不能无条件把“maximal accretive”替换为“m-accretive”。

主来源：[Browder 1968, **FT-P**](https://www.pnas.org/doi/pdf/10.1073/pnas.61.2.388)；[official historical scan, **FT-P**](https://projecteuclid.org/journals/hiroshima-mathematical-journal/volume-2/issue-1/Accretive-mappings-in-Banach-spaces/10.32917/hmj/1206137811.pdf)。

## 6. Prox-regularity 与 localized hypomonotone graphs

这是函数/集合的变分几何与 monotonicity 的连接，不应把 prox-regular 本身称为某一全局 monotone operator class。

对 proper lsc \(f:H\to(-\infty,+\infty]\)，\(f\) 在 \((\bar x,\bar v)\in\operatorname{gra}\partial f\) prox-regular with threshold \(r\ge0\) 的核心局部支持式为

\[
f(x')\ge f(x)+\langle v,x'-x\rangle-\frac r2\|x'-x\|^2, \tag{PR}
\]

其中 \(x,x'\) 接近 \(\bar x\)、\(v\in\partial f(x)\) 接近 \(\bar v\)，并有 \(f\)-attentive level localization。交换两点相加得到 attentive localized subgradient graph 的

\[
\langle x_1-x_2,v_1-v_2\rangle\ge-r\|x_1-x_2\|^2. \tag{6.1}
\]

在 proper/lsc、prox-bounded 及 precise attentive-localization 假设下，(6.1) 也构成 prox-regularity 的局部刻画。若 \(\lambda r<1\)，localized proximal resolvent \((I+\lambda\partial f)^{-1}\) 在 \(\bar x+\lambda\bar v\) 附近 single-valued Lipschitz；粗界为 \(1/(1-\lambda r)\)。[Rockafellar–Poliquin 1996, **ABS-P**](https://www.jstor.org/stable/2155081)；[Poliquin–Rockafellar, authors’ full manuscript, **FT-P**](https://sites.math.washington.edu/~rtr/papers/rtr268-VariProx.pdf)；[later full treatment, **FT-LP**](https://www.heldermann-verlag.de/jca/jca17/jca0849_b.pdf)。

对 prox-regular set \(C\)，相应对象是 **localized and norm-truncated** normal cone graph；因 \(N_C(x)\) 对法向尺度是锥，不能把 bounded-normal 的局部 hypomonotonicity 擅自升级为整个 \(N_C\) 的全局有限 \(r\)-hypomonotonicity。投影 \(P_C=(I+N_C)^{-1}\) 的局部单值/Lipschitz 性也要在对应 tubular neighborhood 陈述。

## 7. RL 条件在 atlas 中的精确位置

用户给定 RL：对图点差 \(a,b\)、固定 \(\lambda>0\)，

\[
\|a-\lambda b\|\le L\|a+\lambda b\|^\gamma,\qquad 0<\gamma\le1. \tag{RL}
\]

由 (C) 精确等价

\[
\lambda\langle a,b\rangle\ge\frac14
\left(\|d\|^2-L^2\|d\|^{2\gamma}\right), \tag{7.1}
\]

也等价于 \(R_{\lambda A}:D_\lambda\to H\) 的 \((L,\gamma)\)-Hölder 性。RL 本身令 \(J,R\) 在 \(D_\lambda\) single-valued（同一 \(d\) 时右端为零），但不推出 \(D_\lambda=H\)，故不自动推出任何 maximality。

### 7.1 \(\gamma=1\)：两个已有理论的精确重参数化

此时

\[
\lambda\langle a,b\rangle\ge\frac{1-L^2}{4}\|d\|^2. \tag{7.2}
\]

1. 若 \(L\ge1\)，对算子 \(\lambda A\)，(7.2) **正是** Luke–Tam submonotonicity，

   \[
   \tau=\frac{L^2-1}{4},\qquad L=\sqrt{1+4\tau}. \tag{7.3}
   \]

   \(L=1\) 即 ordinary monotonicity；\(L<1\) 是比 monotonicity 更强的 self-dual quadratic condition，而不是负 violation 的 LT 命名。
2. 展开 \(\|d\|^2=\|a\|^2+\|\lambda b\|^2+2\langle a,\lambda b\rangle\)，(7.2) 等价于 \(\lambda A\) 的 \((k,k)\)-semimonotonicity，

   \[
   k=\frac{1-L^2}{2(1+L^2)}. \tag{7.4}
   \]

   当 \(L\ge1\)，它也是 Otero–Iusem 的 \(\theta\)-semimonotonicity，

   \[
   \theta=-2k=\frac{L^2-1}{L^2+1},\qquad
   \theta=\frac{2\tau}{1+2\tau},\quad
   \tau=\frac{\theta}{2(1-\theta)}. \tag{7.5}
   \]

所以 \(\gamma=1\) 不是仅“类似”已有理论，而是在上述参数和 scaling 下精确落入两种已发表 class。

### 7.2 \(0<\gamma<1\)：scale-dependent，不等价于固定二次参数

式 (7.1) 的负偏差阶是 \(\|d\|^{2\gamma}\)，故一般不能用固定 \((\mu,\rho)\) 或固定 hypomonotone 常数等价表示。

- **局部包含**：若 \(A\) monotone 且只考察 \(\|d\|\le\delta\)，则 \(\|r\|\le\|d\|\le\delta^{1-\gamma}\|d\|^\gamma\)，即 local RL，\(L=\delta^{1-\gamma}\)。
- **全局不包含**：在无界空间，\(A=0\) maximal monotone 且 \(R=I\)，但 \(\|p-q\|\le L\|p-q\|^\gamma\) 对任意固定 \(L\) 在大尺度失败。因此 monotone 不蕴含 global RL\(_\gamma\)。
- **RL 不推出 monotone**：在 \(\mathbb R\) 取全局 \(\gamma\)-Hölder 但近零 expansive 的

  \[
  R(t)=c\,\operatorname{sgn}(t)|t|^\gamma,
  \]

  再以 \(x\mapsto((x+R x)/2,(x-R x)/(2\lambda))\) 参数化一张图，则 RL 成立（Hölder 常数至多 \(2^{1-\gamma}c\)），但 \(R\) 在零附近不是 nonexpansive，故由 (C) 图不 monotone。这是 **ALG 构造见证**，后续 C 应再检查其 graph/inverse 细节。
- **conic rigidity**：若图差可沿无界射线同比缩放，RL\(_\gamma\) 对 \(t\to\infty\) 强迫所有对应 \(r=0\)。对 full-domain linear Cayley graph，这退化为 \(R=0\)，即 \(A=\lambda^{-1}I\)。所以 genuinely \(\gamma<1\) 的全局 RL 与线性/锥性有强冲突。

定位结论仅限于：\(\gamma<1\) RL 是以 **Minty input scale \(\|a+\lambda b\|\)** 度量的非齐次 Cayley graph geometry；它与传统按 \(\|a\|\)、\(\|b\|\) 二次齐次的 monotonicity classes 通常只有局部、尺度依赖或额外结构下的关系，不能放进一条无条件强弱链。

## 8. 可直接合并的关系矩阵（主干）

符号：\(\Rightarrow_s\) 为严格蕴含；\(\perp\) 为已给双向缺口；“假设”栏为空即按本稿默认 Hilbert/global convention。

| From | Relation | To | 假设/参数 | strictness 或来源 |
|---|---:|---|---|---|
| maximal monotone | \(\Leftrightarrow\) | \(J_{\lambda A}:H\to H\) firmly nonexpansive | 任一 \(\lambda>0\) | Minty；FT-P |
| monotone | \(\Leftrightarrow\) | \(R_{\lambda A}\) nonexpansive on \(D_\lambda\) | 无 full-domain 声称 | (C) |
| \(\mu\)-strong | \(\Rightarrow_s\) | strict monotone | \(\mu>0\) | \(x^3\) 反向失败 |
| strict monotone | \(\Rightarrow_s\) | monotone |  | \(0\) 反向失败 |
| \(\mu\)-strong | \(\Leftrightarrow\) | \((1+\lambda\mu)J_{\lambda A}\) firmly nonexpansive | max/full-domain 版 | BMW 2011 |
| \(R_{\lambda A}\) contraction | \(\Leftrightarrow\) | \(A\) 与 \(A^{-1}\) 均 strong | max monotone；scaled moduli | BMW Cor. 4.7 |
| \(\beta\)-cocoercive | \(\Rightarrow_s\) | monotone and \(1/\beta\)-Lipschitz | \(\beta>0\) | skew rotation 显示反向失败 |
| strong monotone | \(\perp\) | cocoercive | 无单值/满域附加假设 | \(\mu I+N_C\)；diag\((0,1)\) |
| \(\rho\)-monotone \(A\) | \(\Leftrightarrow\) | \(\rho\)-comonotone \(A^{-1}\) | signed parameter | 直接取逆 |
| \(r\)-hypomonotone | \(\Leftrightarrow\) | monotone after \(+rI\) shift |  | 定义 |
| \(r\)-hypomonotone | \(\Rightarrow_s\) | LT-\(\tau\)-submonotone | \(r<1/2,\tau=r/(1-2r),\lambda=1\) | \(-\sqrt x\) 反向失败 |
| \((\mu,\rho)\)-semi \(A\) | \(\Leftrightarrow\) | \((\rho,\mu)\)-semi \(A^{-1}\) |  | Evens et al. |
| Otero \(\theta\)-semi | \(=\) | \((-\theta/2,-\theta/2)\)-semi | \(0<\theta<1\) | 参数识别 |
| RL\(_{\gamma=1,L\ge1}\) for \(\lambda A\) | \(=\) | LT-\(\tau\)-submonotone | \(\tau=(L^2-1)/4\) | (7.3) |
| RL\(_{\gamma=1}\) for \(\lambda A\) | \(=\) | \((k,k)\)-semimonotone | \(k=(1-L^2)/(2(1+L^2))\) | (7.4) |
| monotone | \(\perp\) | global RL\(_{0<\gamma<1}\) | 无界尺度 | \(A=0\) 与 Hölder-\(R\) 构造 |
| maximal cyclic | \(\Rightarrow_s\) | maximal monotone |  | nonzero skew rotation |
| \((n+1)\)-cyclic | \(\Rightarrow_s\) | \(n\)-cyclic | \(n\ge2\) | rotation thresholds |
| strong or positive cocoercive | \(\Rightarrow\) | paramonotone and rectangular |  | pairwise bound |
| paramonotone | \(\perp\) | rectangular | 即便 max monotone | BWY 2012 三类例子 |
| VI monotone | \(\Rightarrow_s\) | VI pseudomonotone | 单值 \(F:C\to H\) | positive nonmonotone scalar |
| VI pseudomonotone | \(\Rightarrow_s\) | VI quasimonotone | 同一 convention | \(x^2\) on \([-1,1]\) |
| Hilbert accretive | \(=\) | monotone | Riesz identification | Browder/Minty |
| Hilbert m-accretive | \(=\) | maximal monotone |  | range theorem |
| prox-regular \(f\) | \(\Leftrightarrow_{\rm local}\) | attentive localized hypomonotonicity of \(\partial f\) | proper lsc/prox-bounded 等 | Poliquin–Rockafellar |

### 8.1 特别需要保留的 non-edges

- “maximal”与“strong”正交：限制 \(\mu I\) 到真子集仍 strong 但非 maximal；\(N_C\) maximal monotone 但通常非 strong。
- \(J_A\) contraction 不等于 strong monotonicity；\(R_A\) contraction 更不是 strong monotonicity的单边结果。
- 3*-monotone 与 3-cyclic 无一般等价。
- VI pseudomonotone 与 Brézis pseudomonotone 无无条件同一性。
- Luke–Tam submonotone 与 Spingarn submonotone 无无条件同一性。
- 在一般 Banach 空间，maximal accretive 与 m-accretive、reflected resolvent nonexpansive 都不能照搬 Hilbert 结论。

## 9. Gap-search 的短见证清单

这些只作 B/C 候选，不替代独立重算。

| ID 候选 | 对象 | 快速用途 |
|---|---|---|
| M-01 | \(A=0\) | max mono；非 strict/strong；global RL\(_{\gamma<1}\) 在大尺度失败 |
| M-02 | \(A(x)=x^3\) on \(\mathbb R\) | strict mono 非 strong；局部 modulus 可精算 |
| M-03 | \(90^\circ\) rotation on \(\mathbb R^2\) | max mono、Lipschitz、非 coco/cyclic/paramono；\(J\) contraction 但 A 非 strong |
| M-04 | \(A=\mu I+N_C\) | max strong、多值、非 coco；测试 maximality 与单值性分离 |
| M-05 | \(A=\operatorname{diag}(0,1)\) | coco/rectangular/paramono，非 strong |
| M-06 | \(A=-kI\) | hypo/cohypo 参数区与 resolvent 常数均可 sharp 计算 |
| M-07 | \(F(x)=-\sqrt x\) on small interval | LT-submono 非 hypomono |
| M-08 | rotations \(R_\theta\) | 精确填充 \(n\)-cyclic 层级 |
| M-09 | \(F(x)=2+\sin x\) | VI pseudo 非 mono |
| M-10 | \(F(x)=x^2\) on \([-1,1]\) | VI quasi 非 pseudo |
| M-11 | BWY 的 \(\ell^2\) diagonal+skew | paramono 非 rectangular |
| M-12 | skew+\(N_{B}\) | rectangular 非 paramono |
| M-13 | Volterra operator | max mono 且 paramono/rectangular 皆非 |
| M-14 | Hölder \(R(t)=c\operatorname{sgn}(t)|t|^\gamma\) 的 Cayley graph | genuinely Hölder RL、非 monotone 的构造候选 |

## 10. 来源台账（直接 URL 与阅读深度）

| 主题 | 来源 | 深度 | 本稿使用范围 |
|---|---|---:|---|
| Minty/maximal/resolvent | [Minty 1962](https://projecteuclid.org/journals/duke-mathematical-journal/volume-29/issue-3/Monotone-nonlinear-operators-in-Hilbert-space/10.1215/S0012-7094-62-02933-2.short) | FT-P | range/full-domain、firm nonexpansiveness |
| resolvent duality | [Bauschke–Moffat–Wang 2011](https://arxiv.org/pdf/1101.4688) | FT-P | strong/coco/paramono/rectangular/cyclic 与 \(J,R\) |
| signed mono/comono | [Bauschke–Moursi–Wang 2019](https://arxiv.org/pdf/1902.09827) | FT-P | \(\rho\)-mono/comono、conical averagedness |
| \((\mu,\rho)\)-semi | [Evens–Pas–Latafat–Patrinos 2023](https://arxiv.org/pdf/2305.03605) | FT-P | 定义、变换、admissible resolvent |
| symmetric semimonotone | [Otero–Iusem 2010](https://webdoc.sub.gwdg.de/ebook/serien/e/IMPA_A/672.pdf) | FT-P | \(\theta\)-semi、premonotone、transform |
| LT submonotone | [Luke–Tam 2025](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863) | FT-P | 定义、maximality、R characterization、gap example |
| Spingarn submono | [Spingarn 1982](https://www.tandfonline.com/doi/abs/10.1080/01630568208816109)；[later formulation](https://www.heldermann-verlag.de/jca/jca15/jca0651_b.pdf) | ABS-P + FT-LP | 仅区分 historical asymptotic definition |
| cyclic monotone | [Rockafellar 1966](https://msp.org/pjm/1966/17-3/pjm-v17-n3-p08-p.pdf)；[Rockafellar 1970](https://msp.org/pjm/1970/33-1/pjm-v33-n1-p19-s.pdf) | FT-P | subdifferential/maximal cyclic |
| \(n\)-cyclic | [Bauschke et al. 2024](https://arxiv.org/html/2411.04212v2) | FT-P preprint | hierarchy、rotation witness |
| para vs rectangular | [Bauschke–Wang–Yao 2012](https://arxiv.org/pdf/1201.4220) | FT-P | independence examples |
| paramonotonicity | [Censor–Iusem–Zenios](https://www.heldermann-verlag.de/jca/jca05/j152.pdf) | FT-P | 原始体系/算法背景 |
| cocoercive gradient | [Bauschke–Combettes 2010](https://www.heldermann-verlag.de/jca/jca17/jca0932_b.pdf) | FT-P | Baillon–Haddad assumptions |
| VI quasi/pseudo | [Aussel et al. 2020](https://optimization-online.org/wp-content/uploads/2020/02/7602.pdf) | FT-P | convention 与 examples |
| Brézis pseudo | [Papageorgiou et al. 2018](https://arxiv.org/pdf/1810.03995) | FT-P | sequential convention |
| accretive | [Browder 1968](https://www.pnas.org/doi/pdf/10.1073/pnas.61.2.388)；[official historical scan](https://projecteuclid.org/journals/hiroshima-mathematical-journal/volume-2/issue-1/Accretive-mappings-in-Banach-spaces/10.32917/hmj/1206137811.pdf) | FT-P | accretive/m-accretive/resolvent |
| prox-regular | [Rockafellar–Poliquin 1996](https://www.jstor.org/stable/2155081)；[authors’ manuscript](https://sites.math.washington.edu/~rtr/papers/rtr268-VariProx.pdf)；[later full treatment](https://www.heldermann-verlag.de/jca/jca17/jca0849_b.pdf) | ABS-P + FT-P + FT-LP | attentive hypomonotonicity、proximal localization |

## 11. 覆盖缺口与待核实项

1. **Spingarn 原始全文**尚未取得；(SP) 由 later full text 核验，但原文的局部有界/闭凸值量词及 “maximal submonotone” historical convention 仍须逐页核对。
2. **Banach accretivity** 中 duality map 的“存在 \(j\)”还是“对所有 \(j\)”依空间光滑性和作者 convention 变化；本稿以范数式 (A) 为主定义。
3. **Brézis pseudomonotone 多值版本**、Browder–Minty type pseudomonotonicity、type \((S)_+\) 尚未系统展开；它们属于弱拓扑闭合轴，不宜用 VI 定义补齐。
4. **Prox-regular set** 的 exact projection Lipschitz modulus 依 uniform prox-radius、normal truncation 和邻域；本稿只记录结构性连接，常数留 C 独立计算。
5. **Local maximality** 可能指“localized graph 与 global maximal graph coincident”或“局部无扩张”；合并时须保留来源 convention。
6. 未展开但值得下一版加入：pseudomonotone-plus、strict/strong quasimonotonicity、angle-bounded monotonicity、cyclic cocoercivity、\(p\)-uniform monotonicity、Banach \(T\)-accretivity。

## 12. 可机器/人工合并的关系边列表

~~~text
monotone --iff[Cayley,on D_lambda]--> R_lambda nonexpansive
maximal_monotone --iff[Minty,lambda>0]--> J_lambda full_domain_firmly_nonexpansive
mu_strong --strict_implies--> strict_monotone --strict_implies--> monotone
mu_strong(A) --iff[inversion]--> mu_cocoercive(A_inverse)
rho_monotone(A) --iff[inversion]--> rho_comonotone(A_inverse)
R_lambda_contraction --iff[maximal_monotone]--> strong(A) AND strong(A_inverse)
beta_cocoercive --strict_implies--> monotone AND (1/beta)-Lipschitz
strong_monotone --incomparable--> cocoercive
r_hypomonotone --iff--> monotone(A+rI)
r_hypomonotone --strict_implies[r<1/2,tau=r/(1-2r)]--> LukeTam_tau_submonotone
(mu,rho)_semimonotone(A) --iff[inversion]--> (rho,mu)_semimonotone(A_inverse)
Otero_theta_semimonotone --equal--> (-theta/2,-theta/2)_semimonotone
RL(gamma=1,L>=1,lambdaA) --equal[tau=(L^2-1)/4]--> LukeTam_tau_submonotone
RL(gamma=1,lambdaA) --equal[k=(1-L^2)/(2(1+L^2))]--> (k,k)_semimonotone
monotone --incomparable[global,unbounded]--> RL(gamma<1)
maximal_cyclic --strict_implies--> maximal_monotone
(n+1)_cyclic --strict_implies--> n_cyclic
strong OR positive_cocoercive --implies--> paramonotone AND rectangular
paramonotone --incomparable[maximal_monotone universe]--> rectangular
VI_monotone --strict_implies--> VI_pseudomonotone --strict_implies--> VI_quasimonotone
Hilbert_accretive --equal--> monotone
Hilbert_m_accretive --equal--> maximal_monotone
prox_regular --local_equiv[attentive/prox-bounded assumptions]--> localized_hypomonotone_subgradient
~~~

### 审核状态

- overall_status：**PROVISIONAL_PASS**（核心定义、参数换算和主干关系有 FT-P 支持；historical submonotonicity、Banach 量词和 prox-set sharp constants 明示待核实）。
- evidence_sufficiency：**SUFFICIENT_FOR_ATLAS_CORE**。
- citation_verification：所有主干边至少有一项 FT-P/FT-LP 或透明 ALG 推导；ABS-P 未单独承载精细常数。
- source_access：公开网页/作者稿/官方扫描；无第三方 API、无凭标题猜测正文。
- next_action：由 Subagent B/C 对 §9 候选逐个独立重算，优先核查 M-07、M-11–M-14 的最优参数与局部量词。
