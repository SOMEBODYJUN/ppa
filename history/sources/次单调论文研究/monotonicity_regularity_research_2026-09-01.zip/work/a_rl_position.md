# RL 条件的精确定位与 prior-art 审计（Subagent A 专项）

> 状态：2026-09-01 工作稿；用途是并入 `theory_atlas.md`，不是最终 seesaw synthesis。  
> 审计对象：用户初稿 `RL_Submonotonicity初稿.md`。  
> 证据标签：**[V-U]** 用户材料中可直接复核；**[V-S]** 已由原始论文全文/官方出版页核对；**[I]** 本报告的代数推论；**[P]** 尚待数据库与引用链穷尽核实。  
> 结论边界：目前检索到的是非常接近的 Hölder-map、Luke–Tam submonotonicity、semimonotonicity 与 conically averaged-resolvent 理论；**没有检索命中精确的 \(\gamma<1\) graph inequality 不等于已证明新颖性**。

## 0. 记号、量词与正确的局部对象

令 \(H\) 为实 Hilbert 空间，\(F:H\rightrightarrows H\)，\(\lambda>0\)，并先固定一个将要比较的 graph 部分

\[
\Gamma\subset \operatorname{gph}F.
\]

对 \((u,u^*),(v,v^*)\in\Gamma\)，记

\[
a=u-v,\qquad b=u^*-v^*,\qquad
x=u+\lambda u^*,\quad y=v+\lambda v^*.
\]

定义 Cayley 坐标域与受限 reflected resolvent

\[
D_\Gamma:=\{u+\lambda u^*:(u,u^*)\in\Gamma\},
\qquad
R_\Gamma(x):=u-\lambda u^*.
\]

这里 \(R_\Gamma\) 起初只是 relation。局部结论必须写在 \(\Gamma\) 和 \(D_\Gamma\) 上；只说“\(F\) 在某邻域满足 RL”而直接使用完整的 \(J_{\lambda F}\) 会遗漏来自邻域外 graph branch 的 preimage。

## 1. RL 的精确数学内容

### 1.1 Cayley–Hölder 等价（含单值性与定义域）

**命题 1 [V-U, I].** 对 \(0<\gamma\le 1\)、\(L>0\)，以下条件精确等价：

1. 对所有 \((u,u^*),(v,v^*)\in\Gamma\)，
   \[
   \|a-\lambda b\|\le L\|a+\lambda b\|^\gamma. \tag{RL}
   \]
2. \(R_\Gamma\) 在 \(D_\Gamma\) 上为单值映射，且
   \[
   \|R_\Gamma x-R_\Gamma y\|\le L\|x-y\|^\gamma
   \qquad(x,y\in D_\Gamma). \tag{CH}
   \]

证明只需代入 \(x-y=a+\lambda b\) 与 \(R_\Gamma x-R_\Gamma y=a-\lambda b\)。如果同一 \(x\) 对应两对 graph 点，则右端为零，故两个 reflected 值相同；线性反变换

\[
u=\frac{x+R_\Gamma x}{2},\qquad
u^*=\frac{x-R_\Gamma x}{2\lambda}
\]

又说明 graph 点本身相同。因此 RL 不仅是 selection-wise 性质，它强迫**受限 resolvent 单值**。反过来，任一 \(\gamma\)-Hölder 映射 \(R:D\to H\) 都生成

\[
\Gamma_R=
\left\{
\left(\frac{x+Rx}{2},\frac{x-Rx}{2\lambda}\right):x\in D
\right\}, \tag{Cayley pullback}
\]

并在该 graph 上满足 RL。这是完全的参数化，而不是启发式类比。

若 \(\Gamma=\operatorname{gph}F\)，则

\[
D_\Gamma=\operatorname{ran}(I+\lambda F),\qquad
J_{\lambda F}=\frac{I+R_\Gamma}{2},\qquad
R_{\lambda F}=2J_{\lambda F}-I
\]

均只在 \(D_\Gamma\) 上有上述含义。RL **不蕴含** \(D_\Gamma=H\)，也不蕴含 maximality。完整 resolvent 的局部存在、full domain 或 self-map 性质都需要另加假设。

### 1.2 内积式与 AFNE 式确实等价

令 \(t=\|a+\lambda b\|\)。恒等式

\[
\|a-\lambda b\|^2
=\|a+\lambda b\|^2-4\lambda\langle a,b\rangle
\]

给出精确等价

\[
\boxed{
\lambda\langle a,b\rangle
\ge \frac14\big(t^2-L^2t^{2\gamma}\big).
} \tag{RL-IP}
\]

又因 \(J=(I+R)/2\)，

\[
\begin{aligned}
&\|Jx-Jy\|^2+|(I-J)x-(I-J)y\|^2\\
&\qquad=\frac12\big(\|x-y\|^2+\|Rx-Ry\|^2\big),
\end{aligned}
\]

所以初稿的

\[
\|Jx-Jy\|^2+|(I-J)x-(I-J)y\|^2
\le \frac12\big(\|x-y\|^2+L^2\|x-y\|^{2\gamma}\big) \tag{AFNE-RL}
\]

与 RL 精确等价，但必须把 \(J\) 理解成 \(J_{\Gamma}:D_\Gamma\to H\)；“\(J\) 多值时 selection-wise”这一表述并不准确，因为对同一输入取两种 selection 后令 \(x=y\)，不等式立即迫使两者相等。

### 1.3 \(\gamma<1\) 对应的是尺度依赖的 signed violation

对 \(t>0\)，RL-IP 可改写为 Luke–Tam 型形式

\[
\lambda\langle a,b\rangle\ge-\tau_\gamma(t)t^2,
\qquad
\tau_\gamma(t)=\frac14\left(L^2t^{-2(1-\gamma)}-1\right). \tag{1.1}
\]

相应的 firm-nonexpansive signed violation 为

\[
\varepsilon_\gamma(t)=2\tau_\gamma(t)
=\frac12\left(L^2t^{-2(1-\gamma)}-1\right). \tag{1.2}
\]

关键尺度事实：

- \(t\downarrow0\) 时，\(\tau_\gamma(t),\varepsilon_\gamma(t)\to+\infty\)；
- \(t=L^{1/(1-\gamma)}\) 时二者过零；
- \(t\to\infty\) 时分别趋于 \(-1/4\) 和 \(-1/2\)。

因此 \(\gamma<1\) 的 RL 在对角线附近通常**不蕴含任何有限常数 violation 的 Luke–Tam submonotonicity、almost nonexpansiveness 或 almost firm nonexpansiveness**。式 (1.1) 是 variable/signed coefficient；若采用文献要求的非负 violation，应取正部，而且在任何含任意小 pair distance 的邻域上其上确界仍为无穷。

## 2. \(\gamma=1\)：参数换算是精确的

### 2.1 与 \((\mu,\rho)\)-semimonotonicity 的一维切片

设

\[
\theta_L:=\frac{1-L^2}{2(1+L^2)}\in(-1/2,1/2).
\]

平方展开给出

\[
\boxed{
\mathrm{RL}(\lambda,L,1)
\iff
\langle a,b\rangle
\ge \mu_L\|a\|^2+\rho_L\|b\|^2,
} \tag{2.1}
\]

其中

\[
\boxed{
\mu_L=\frac{1-L^2}{2\lambda(1+L^2)}=\frac{\theta_L}{\lambda},
\qquad
\rho_L=\frac{\lambda(1-L^2)}{2(1+L^2)}=\lambda\theta_L,
\qquad \rho_L=\lambda^2\mu_L.
} \tag{2.2}
\]

反向换算：若 \((\mu,\rho)=(\theta/\lambda,\lambda\theta)\) 且 \(-1/2<\theta<1/2\)，则

\[
L=\sqrt{\frac{1-2\theta}{1+2\theta}}. \tag{2.3}
\]

故 \(\gamma=1\) RL 不是完整的二参数 semimonotonicity，而是固定 \(\lambda\) 后的 tied curve \(\rho=\lambda^2\mu\)。更简洁地，若把算子先缩放为 \(A=\lambda F\)，则

\[
\boxed{\mathrm{RL}(\lambda,L,1)\iff
A=\lambda F\text{ is }(\theta_L,\theta_L)\text{-semimonotone}.}
\]

特别地，\(\lambda=1\) 时它就是 equal-parameter semimonotonicity；这应当作为 \(\gamma=1\) 最接近、且精确的既有理论定位。Evens–Pas–Latafat–Patrinos 给出一般 \((\mu,\rho)\)-semimonotonicity、inverse/scaling 规则及 resolvent characterization；本文式 (2.1)–(2.3) 是在其定义下的直接代数定位 **[V-S, I]**。该论文陈述在 \(\mathbb R^n\)；上述等价只用 Hilbert 内积恒等式，故代数上直接延伸到实 Hilbert 空间，但其 finite-dimensional maximality/算法结论不能因此自动延伸。

这里“tied curve”指**同一个 inequality 的精确重写**，并不表示 curve 外的 semimonotonicity certificate 不能推出一个较弱 RL bound。事实上令

\[
p=\lambda\mu,\qquad q=\rho/\lambda.
\]

若 \(F\) 是 \((\mu,\rho)\)-semimonotone、\(\mu\rho<1/4\)，并且 stepsize 满足

\[
1+p+q=1+\lambda\mu+\rho/\lambda>0, \tag{2.4a}
\]

则有类级 sharp 保证

\[
\boxed{
\|a-\lambda b\|
\le L_{\mu,\rho}(\lambda)\|a+\lambda b\|,
\qquad
L_{\mu,\rho}(\lambda)
=\frac{|p-q|+\sqrt{1-4pq}}{1+p+q}.
} \tag{2.4b}
\]

推导：置 \(c=\lambda b\)、\(x=a+c\)、\(r=a-c\)。semimonotonicity 变为

\[
(1-p-q)\|x\|^2
\ge(1+p+q)\|r\|^2+2(p-q)\langle x,r\rangle.
\]

在 \(\langle x,r\rangle\ge-\|x\|\|r\|\) 下解关于 \(\|r\|/\|x\|\) 的二次不等式即得 (2.4b)；共线 pair 达到该 bound，所以仅基于 \((\mu,\rho)\) certificate 不能统一改进。条件 (2.4a) 也正是排除 Cayley denominator collapse 的自然 stepsize 条件；若它失败，一般 semimonotonicity class 不保证任何 finite RL 常数。tied 情形 \(p=q=\theta_L\) 时 (2.4b) 精确退化为 \(L\)。hypo、cohypo 与 comonotone 的下述换算也都是该公式的边界切片 **[I；与 Evens et al. Prop. 4.12 的 admissible stepsize 结构一致]**。

| RL 参数 | graph-side 等价 | reflected resolvent | 常用类别中的位置 |
|---|---|---|---|
| \(0<L<1\) | \(\mu_L>0,\rho_L>0\) | contraction，常数 \(L\) | 同时蕴含 \(\mu_L\)-strong monotonicity 与 \(\rho_L\)-cocoercivity；严格强于 monotonicity |
| \(L=1\) | \(\mu_L=\rho_L=0\) | nonexpansive | ordinary monotonicity（在相同 graph/domain 量词下） |
| \(L>1\) | \(\mu_L<0,\rho_L<0\) | Lipschitz，常数 \(L\) | 负参数 semimonotonicity；等价于 Luke–Tam 常数 submonotonicity的缩放版 |

### 2.2 与 Luke–Tam submonotonicity / almost-FNE 的精确换算

把 Luke–Tam 的定义应用于 \(A=\lambda F\)。其 graph inequality 为

\[
\langle a,\lambda b\rangle
\ge-\tau\|a+\lambda b\|^2.
\]

当 \(L\ge1\) 时，RL(\(\lambda,L,1\)) 与它精确等价，且

\[
\boxed{
\tau=\frac{L^2-1}{4},
\qquad
\varepsilon=2\tau=\frac{L^2-1}{2},
\qquad
\operatorname{Lip}(R)=\sqrt{1+4\tau}=L.
} \tag{2.5}
\]

Luke–Tam 2025，Definition 2 与 Proposition 4 在其局部 restricted operator \(F_W\)、域 \(D=(I+F_W)(U)\) 上给出“submonotone \(\tau<1/2\) \(\Leftrightarrow\) resolvent a\(1/2\)-FNE violation \(2\tau<1\) \(\Leftrightarrow\) reflected resolvent Lipschitz \(\sqrt{1+4\tau}\)” **[V-S]**。因此：

- 作为纯代数等价，(2.5) 对所有 \(L\ge1\) 都成立；
- 作为该论文 Proposition 4 的**命名范围和算法定理假设**，\(\tau<1/2\) 对应 \(L<\sqrt3\)；不可把其定理自动外推到 \(L\ge\sqrt3\)；
- \(0<L<1\) 时 (2.5) 给负 \(\tau\)，超出 Luke–Tam 的 \(\tau\ge0\) violation convention；应使用正参数 semimonotonicity/strong monotonicity/cocoercivity 描述。

还必须区分两种量词：Luke–Tam Definition 2 的 uniform submonotonicity比较 restricted graph 中所有 pair；其 fixed-point 收敛框架亦使用“只在 solution/fixed point 作 base point”的 pointwise almost-FNE。后者严格更弱，不能反推本报告的 all-pairs RL。

### 2.3 参数换算总表

| 邻近理论（采用文中 convention） | 假设/参数区间 | 对 RL 的精确或保证性换算 | 关系性质 |
|---|---|---|---|
| Luke–Tam submonotonicity of \(\lambda F\) | \(\tau\ge0\) | \(L=\sqrt{1+4\tau}\) | \(\gamma=1,L\ge1\) 时精确等价；其 Prop. 4 另要求 \(\tau<1/2\) |
| a\(1/2\)-FNE of \(J\) | squared violation \(\varepsilon\ge0\) | \(L=\sqrt{1+2\varepsilon}\), \(\varepsilon=(L^2-1)/2\) | \(L\ge1\) 时精确；\(L<1\) 的负 signed violation 不属于标准 convention |
| almost nonexpansive \(R\) | squared violation \(\epsilon_R\ge0\) | \(\epsilon_R=L^2-1\) | \(L\ge1\) 精确；\(L\le1\) 为 nonexpansive |
| \((\mu,\rho)\)-semimonotone \(F\) | 精确重写时 \(\rho=\lambda^2\mu\)；一般 certificate 时需 \(\mu\rho<1/4\), \(1+\lambda\mu+\rho/\lambda>0\) | tied 参数见 (2.2)–(2.3)；一般 sharp guarantee 见 (2.4b) | RL 本身是 tied one-dimensional slice；curve 外的 admissible semimonotonicity仍可充分推出较弱 RL |
| \(\sigma\)-hypomonotone \(F\) | \(\kappa:=\lambda\sigma<1\) | \(L\le(1+\kappa)/(1-\kappa)\) | sufficient, sharp as a class bound；converse false |
| \(\eta\)-cohypomonotone \(F\) | \(\kappa':=\eta/\lambda<1\) | \(L\le(1+\kappa')/(1-\kappa')\) | sufficient, sharp；converse false |
| \(\beta\)-comonotone \(F\) / conically averaged \(J\) | \(\beta>-\lambda\), \(\alpha=\lambda/[2(\lambda+\beta)]\) | \(L\le1\) if \(\beta\ge0\); \(L\le(\lambda-\beta)/(\lambda+\beta)=4\alpha-1\) if \(-\lambda<\beta<0\) | sufficient；converse false |

### 2.4 inverse 与 scaling（\(\gamma<1\) 时常数会变）

交换 \(a,b\) 并整理得

\[
\boxed{
F\text{ satisfies RL}(\lambda,L,\gamma)
\iff
F^{-1}\text{ satisfies RL}\left(\lambda^{-1},L\lambda^{\gamma-1},\gamma\right).
} \tag{2.6}
\]

当 \(\gamma=1\) 时 \(L\) 不变，且 semimonotone 参数交换 \((\mu,\rho)\leftrightarrow(\rho,\mu)\)。当 \(\gamma<1\) 时，\(L\) 带尺度，不能把数值大小跨单位直接比较。另对 \(c>0\)，

\[
F\text{ satisfies RL}(\lambda,L,\gamma)
\iff
cF\text{ satisfies RL}(\lambda/c,L,\gamma). \tag{2.7}
\]

## 3. \(\gamma<1\)：local/bounded 与 global 的方向相反

### 3.1 固定有界域上的偏序

若 \(\operatorname{diam}D\le\Delta<\infty\)，则：

1. \(R\) 为 \(K\)-Lipschitz \(\Rightarrow\) 对每个 \(0<\gamma<1\)，\(R\) 为 \(\gamma\)-Hölder，常数可取
   \[
   L=K\Delta^{1-\gamma}.
   \]
2. 更一般地，若 \(R\) 为 \(\gamma_2\)-Hölder，且 \(0<\gamma_1\le\gamma_2\le1\)，则它为 \(\gamma_1\)-Hölder，
   \[
   L_{\gamma_1}=L_{\gamma_2}\Delta^{\gamma_2-\gamma_1}.
   \]

在固定的 bounded/local comparison window 上，较大 exponent 较强，且包含一般是严格的。例如

\[
P_\eta(t)=\operatorname{sgn}(t)|t|^\eta
\]

在有界区间上为 \(\eta\)-Hölder（可取 \(2^{1-\eta}\)），但在零点处不具有任何 \(\beta>\eta\) 的 Hölder 性，尤其不 Lipschitz。

### 3.2 全局类不是按 exponent 排列

小尺度 \(s^\gamma>s\)（\(s<1\)），大尺度 \(s^\gamma<s\)（\(s>1\)）。因此 global \(\gamma=1\) 与 global \(0<\gamma<1\) **互不包含**：

- \(F=0\) 时 \(R=I\)，全局 \(1\)-Lipschitz，但对任意 \(\gamma<1\) 不存在全局有限 \(L\)，因为 \(s\le Ls^\gamma\) 在 \(s\to\infty\) 失败；
- 取 \(R=P_\gamma\) 并用 Cayley pullback 构造 graph，则它全局 \(\gamma\)-Hölder，却在零点不 Lipschitz。

同理，\(P_\eta\) 若比较 exponent \(\beta\ne\eta\)：\(\beta>\eta\) 在零附近失败，\(\beta<\eta\) 在无穷远失败。这是“尺度反转”，不是单一强弱轴。

RL(\(\gamma<1\)) 只有在排除对角线的 annulus \(\|x-y\|\ge\delta>0\) 上才给 Lipschitz 常数

\[
K=L\delta^{\gamma-1}.
\]

任何通常的 neighborhood 都含任意小的 pair distance，故不能利用这个式子声称局部 Lipschitz。

## 4. 与最近邻理论的严格关系

### 4.1 hypomonotonicity / cohypomonotonicity

若

\[
\langle a,b\rangle\ge-\sigma\|a\|^2
\]

且 \(\kappa=\lambda\sigma<1\)，则优化 \(\|a-\lambda b\|/\|a+\lambda b\|\) 得到 sharp class bound

\[
\boxed{L\le\frac{1+\kappa}{1-\kappa}}. \tag{4.1}
\]

等号由 \(\lambda b=-\kappa a\) 达到。阈值也是必要的类级保证：\(F=-I/\lambda\) 是 \(\sigma\)-hypomonotone（\(\sigma=1/\lambda\)），但 \(I+\lambda F\) 塌缩，任取不同 \(a\) 时 RL 右端为零、左端非零。

反向不成立。Luke–Tam Example 2 的 \(F(x)=-\sqrt{x}\)（其指定小区间上）是 submonotone，却不是任何有限 violation 的 hypomonotone；由其 submonotonicity 常数换算可得某个 \(\gamma=1\) RL，但仍无 hypomonotonicity **[V-S]**。对 inverse 作同样处理即得 cohypomonotonicity 反例。

若

\[
\langle a,b\rangle\ge-\eta\|b\|^2,
\qquad \eta/\lambda<1,
\]

则对称地有

\[
L\le\frac{1+\eta/\lambda}{1-\eta/\lambda}. \tag{4.2}
\]

### 4.2 cocoercivity / comonotonicity 与 conically averaged resolvent

Bauschke–Moursi–Wang 的原始结果给出：\(F\) 为 \(\beta\)-comonotone 且 \(\beta>-\lambda\) 时，\(J_{\lambda F}\) 是 conically \(\alpha\)-averaged，

\[
\alpha=\frac{\lambda}{2(\lambda+\beta)},
\]

并且 maximality 对应 full-domain resolvent **[V-S]**。若

\[
J=(1-\alpha)I+\alpha N,\qquad N\text{ nonexpansive},
\]

则

\[
R=(1-2\alpha)I+2\alpha N,
\]

从而

\[
\operatorname{Lip}R\le
\begin{cases}
1,&0<\alpha\le1/2,\\
4\alpha-1,&\alpha\ge1/2.
\end{cases} \tag{4.3}
\]

故该理论是 \(\gamma=1\) RL 的充分来源。但反向严格失败：取 \(R=2I\)，则 \(J=3I/2\) 满足 RL(\(\lambda,2,1\))；若它 conically \(\alpha\)-averaged，则唯一候选

\[
N=\left(1+\frac1{2\alpha}\right)I
\]

不是 nonexpansive。对应 Cayley graph 是单值线性算子 \(F(u)=-u/(3\lambda)\)。限制到 bounded \(D\) 后它也满足任意 \(\gamma<1\) 的 RL，但仍不能由 conical averagedness 解释。

### 4.3 almost/nonexpansive 与 pointwise 版本

- \(\gamma=1\)：RL 就是 \(R\) 的 Lipschitz 性；\(L\ge1\) 时 almost-nonexpansive 的 squared violation 为 \(L^2-1\)，而 \(J\) 的 a\(1/2\)-FNE violation 为 \((L^2-1)/2\)。\(L\le1\) 时分别为 nonexpansive 与 firmly nonexpansive；标准的非负 violation convention 会丢失 \(L<1\) 的 contraction 强度。
- \(\gamma<1\)：RL 一般只有 Hölder 几何，标准常数 almost-NE/FNE violation 在对角线附近发散，见 (1.1)–(1.2)。
- all-pairs RL 蕴含每一 base point 的 pointwise Hölder calmness；仅在 solution/fixed point 作 base 的 pointwise almost-FNE 或 anchored RL 不蕴含 all-pairs RL。

### 4.4 Hölder calmness / Hölder Lipschitz-like

在 RL 已强迫 \(R_\Gamma\) 单值之后，(CH) 是 \(R_\Gamma\) 在 \(D_\Gamma\) 上的 uniform pairwise \(\gamma\)-Hölder continuity；因此它蕴含每个 base point 的 Hölder calmness（统一 modulus）。在 set-valued 语言中，其局部 pairwise 版本最接近 Hölder Lipschitz-like/Aubin 型性质，anchored 版本最接近 Hölder calmness。

但它**不是** \(F\) 或 \(F^{-1}\) 的 metric regularity/calmness：RL 是经由线性 Cayley 旋转后的 \(R\) 的 regularity。若要从 coderivative criterion 转回 \(F\)，必须另行控制 \(I+\lambda F\) 的局部可逆性、branch 与定义域；不能自动转移。Barroso 对 \(\|Rx-Ry\|\le L\|x-y\|^\gamma\) 这类 Hölder maps 有直接 map-side 定义和 fixed-point 文献 **[V-S]**，但本轮没有在其文中发现该性质与 operator graph/reflected resolvent 的本报告等价式 **[P]**。

### 4.5 关系判定表

| 比较对象 | global | fixed bounded/local domain | 结论与严格性依据 |
|---|---|---|---|
| RL \(\gamma=1\) vs Luke–Tam | \(L\ge1\) 精确等价（缩放后） | 同，但必须一致地 restrict graph/domain | 参数见 (2.5)；定理的 \(\tau<1/2\) 不可省 |
| RL \(\gamma=1\) vs \((\mu,\rho)\)-semimonotone | tied curve 精确等价 | 同 | RL 只是 \(\rho=\lambda^2\mu\)；一般二参数类不等价 |
| RL \(\gamma=1\) vs RL \(\gamma<1\) | 互不包含 | 前者蕴含后者，严格 | \(R=I\) 与 \(R=P_\gamma\)；bounded 转换常数见 §3 |
| monotone vs RL \(\gamma<1\) | monotone 不蕴含 global RL\(_\gamma\)（\(F=0\)）；反向也不成立 | monotone \(\Rightarrow\) RL\(_\gamma\) on bounded \(D\)；反向严格失败 | bounded example \(R=2I\), \(F=-I/(3\lambda)\) |
| hypo/cohypo vs RL \(\gamma=1\) | violation below resolvent-collapse threshold gives RL | 同 | sufficient sharp；Luke–Tam non-Lipschitz example shows converse false |
| comonotone/conically averaged \(J\) vs RL \(\gamma=1\) | 前者蕴含后者 | 同 | converse fails by \(R=2I\) |
| pointwise-at-solution Hölder/aFNE vs pairwise RL | 前者不蕴含后者 | 前者不蕴含后者 | Luke–Tam explicitly distinguishes pointwise and all-base versions；需 B/C 再给最小显式例 |
| Hölder calmness of \(R\) at one base vs RL | 不蕴含 | 不蕴含 pairwise uniform property | RL 蕴含每点 calmness；单点性质只约束 anchored pairs |
| metric regularity/subregularity of \(F\) vs RL | 一般互不推出 | 一般互不推出 | 不同坐标/量词；需 gap catalog 系统填四象限 |

## 5. 初稿中 \(q\)、\(\gamma q\) 推导的独立复核

### 5.1 已核对为正确的代数链

令 \(S=F^{-1}(0)\)，\(x^+=J_{\lambda F}x\)，\(r=d(x,S)\)。只要所取 graph pair 与 solution pair 位于同一 RL window，初稿用原始 RL 加三角不等式得到

\[
\|x-x^+\|\le\frac12(r+Lr^\gamma), \tag{5.1}
\]

因 \((x-x^+)/\lambda\in F(x^+)\)，

\[
d(0,F(x^+))\le\frac{r+Lr^\gamma}{2\lambda}. \tag{5.2}
\]

若在 \(x^+\) 所在有效域内统一满足

\[
d(u,S)\le\rho,d(0,F(u))^q,
\]

则

\[
\boxed{
d(x^+,S)
\le\frac{\rho}{(2\lambda)^q}(r+Lr^\gamma)^q
=O(r^{\gamma q}).
} \tag{5.3}
\]

更基本的是 gauge composition

\[
\boxed{
d(x^+,S)\le
\psi\!\left(\frac{r+Lr^\gamma}{2\lambda}\right).
} \tag{5.4}
\]

故 \(\gamma q\) 只是“RL 的局部 power \(r^\gamma\)”与“所选 error-bound power \(t^q\)”在这条证明中的复合；它不是目前可宣称的普适 monotonicity–regularity law。Mordukhovich–Ouyang 明确定义任意 \(q>0\) 的 metric \(q\)-subregularity，并指出 \(q>1\) 的 higher-order subregularity 有意义 **[V-S]**；这消除了“\(q>1\) 定义非法”的疑虑，但不消除下列局部量词问题。

初稿的 gauge 充分条件

\[
\limsup_{t\downarrow0}\frac{\psi(t)}{t^{1/\gamma}}
<\left(\frac{2\lambda}{L}\right)^{1/\gamma} \tag{5.5}
\]

代入 (5.4) 后确实给 \(\limsup_{r\downarrow0}\Phi(r)/r<1\)（假设 \(L>0\)）；该常数计算正确。

### 5.2 必须修补的 theorem hypotheses / proof gaps

以下不是对代数 (5.1)–(5.5) 的反驳，而是初稿从一步估计提升为“任何 PPA 序列局部收敛”时缺少的量词或拓扑条件：

1. **局部 graph 与完整 resolvent 混用。** 若 RL 只在 \(\Gamma\) 上成立，完整 \(J_{\lambda F}(x)\) 仍可能从 \(\Gamma\) 外选到其他 branch。应显式使用 \(F_\Gamma\)/\(J_\Gamma\)，或增加 branch exclusion。
2. **存在性与覆盖未由 RL 给出。** RL 给受限 inverse 单值，但不给 \(D_\Gamma\) 包含初始邻域、不给 \(J(D)\subset D\)。PPA theorem 需加 local surjectivity/existence 与 self-map/invariance。
3. **“充分接近 \(S\)”不足以固定 reference solution。** 正则性通常在 \((\bar x,0)\) 定义；若要在整个 tube \(\{d(x,S)<\delta\}\) 使用，需明确 uniformity。否则应固定 \(\bar x\) 和两个 ball。
4. **two-radius localization 仍需证明。** \(\gamma<1\) 时 step 仅为 \(O(r^\gamma)\)，它在小尺度上大于 \(O(r)\)；必须用可求和 step bound 与 inner/outer radius 选择证明不离开有效区，不能只写“从足够近开始”。
5. **所有 selection 的量词。** 若结论声称“任意 PPA sequence”，每一步所有 admissible selection 都必须处于同一 RL/regularity window；否则只能声称某个受控 branch。
6. **subregularity 的评估点是 \(x^+\)。** 需保证每个 \(x^+\) 都落在统一 modulus \(\rho\) 的外层邻域。
7. **极限属于 \(S\)。** finite-length 给 Cauchy；Hilbert 完备性给极限，但由 \(d(x^k,S)\to0\) 只能推出极限在 \(\overline S\)。需 \(S\) 在外层邻域 closed（例如适当 closed-graph/outer-semicontinuity 假设）。
8. **非凸闭集未必有投影（尤其无限维）。** 初稿取 infimum 的写法可保留；完整证明不能无说明地选 \(p=P_Sx\)，应使用 \(\varepsilon\)-minimizer 后令 \(\varepsilon\downarrow0\)。
9. **固定 \(\lambda\) 与 variable stepsize。** 当前换算及常数只覆盖固定 \(\lambda\)；\(\lambda_k\) 需要统一 RL 参数和下/上界重新计算。
10. **critical/supercritical 求和依赖先有 invariant contraction。** \(\gamma q>1\) 时需先选 \(\delta\) 使 \(Cr^{\gamma q-1}\le\vartheta<1\)；\(\gamma q=1\) 时需用严格常数余量选 \(\delta\)。得到 \(r_k\le \vartheta^k r_0\) 后，\(\sum r_k^\gamma<\infty\) 才推出 finite length。
11. **可明显弱化 all-pairs RL。** (5.1)–(5.4) 只把当前 graph pair 与 \((p,0)\) 比较，因此算法证明只需 anchored/solution-relative RL，而不是全 graph pair RL。这一弱化会改变 atlas 中的位置，必须单列。
12. **“最优常数”尚未证明。** 初稿称三角界 \(\frac12(r+Lr^\gamma)\) 在全部信息下“最终最优”目前是合理猜想，不是 theorem；需构造同时达到 RL、distance infimum 与 subregularity 的 extremal example。

### 5.3 关于 q convention 的术语提醒

- Li–Mordukhovich 2012 主要把 Hölder metric subregularity 写作 \(q\in(0,1]\)；
- Mordukhovich–Ouyang 2015 把任意 \(q>0\)，特别是 \(q>1\)，系统称为 higher-order metric \(q\)-subregularity；
- 所以初稿的 \(q\ge1/\gamma>1\) 应标作 **higher-order metric subregularity**，避免读者误以为沿用只允许 \(q\le1\) 的旧 Hölder convention。

## 6. 可直接移交给 B/C 的显式 gap seeds

| ID | Cayley / operator | 已立即可证的用途 | B/C 仍需做的完整计算 |
|---|---|---|---|
| RL-G1 | \(F=0\), \(R=I\) | global RL\(_1\)，非任何 global RL\(_\gamma\), \(\gamma<1\) | regularity 全谱、不同零点 reference |
| RL-G2 | \(R=P_\gamma\) on \(\mathbb R\)，用 Cayley pullback 得 \(F\) | global RL\(_\gamma\) sharp，非 local RL\(_\beta\) for \(\beta>\gamma\)，非 global RL\(_\beta\) for \(\beta<\gamma\) | 显式写 \(F\)、inverse、zer、resolvent 与所有 moduli |
| RL-G3 | bounded \(D\) 上 \(R=2I\)，对应 \(F(u)=-u/(3\lambda)\) | local RL\(_\gamma\) for all \(\gamma<1\)，非 monotone；\(J\) 非 conically averaged | 最优 bounded Hölder 常数、regularity 与边界效应 |
| RL-G4 | \(F=-I/\lambda\) | hypo/cohypo 在 collapse threshold，但 RL 失败 | 用作 sharp threshold；计算 set-valued resolvent at collapsed point |
| RL-G5 | Luke–Tam Example 2: \(F(x)=-\sqrt x\) on specified interval | \(\gamma=1\) RL/submonotone，但非 hypomonotone | 从原文精确抄清区间与最优 \(\tau,L\)，再算 regularity/RL sharpness |
| RL-G6 | RL-G5 的 inverse | cohyponotonicity converse gap | inverse graph 与所有局部 exponent |
| RL-G7 | anchored RL：构造在每个 solution pair 良好、非 solution pairs 爆坏的 graph | 区分 PPA 实际假设与 all-pairs RL | 需要 B 构造最小自然显式例，C 独立验证 |

## 7. 尚需反例或文献核实的 gap 清单

1. **[P] 精确 prior-art 名称。** 继续按完整公式、Cayley transform、reflected resolvent Hölder、Hölder almost-FNE 搜索；目前不能声称 “RL-submonotonicity” 新颖。
2. **\(\gamma<1\) maximal extension。** Luke–Tam 对常数 submonotonicity用 Zorn 给 maximal extension；Hölder-Cayley graph class是否已有同构 maximal-extension/full-domain theorem待查。
3. **full-domain characterization。** 哪些 \(\gamma\)-Hölder \(R:H\to H\) 的 Cayley pullback满足值得使用的 closedness/maximality？这不是 ordinary Minty theorem 的直接推论。
4. **anchored vs all-pairs 的严格自然例。** 要填满 solution-relative RL、pointwise aFNE、uniform RL 三者的所有逻辑区域。
5. **\(\gamma q\) sharpness。** 构造达到 \(r_{k+1}\asymp r_k^{\gamma q}\) 的 isolated 与 nonisolated zero-set 例，并检验临界常数是否 sharp。
6. **无 regularity 互推的四象限。** 对 RL 强/弱与 metric (sub)regularity 强/弱各给多个显式点，不能只靠坐标不同作抽象断言。
7. **coderivative criterion。** 搜索是否已有对 Cayley pullback \(R=(I-\lambda F)(I+\lambda F)^{-1}\) 的 Hölder Aubin/calmness criterion；若自行推导，必须写清 graph transform 与 branch regularity。
8. **global RL 的无穷远约束。** \(\gamma<1\) 强迫 reflected increments sublinear；需要区分这类 growth/coercivity 约束与局部 monotonicity 弱化，避免把 global 与 local points 放在同一轴。

## 8. Primary-source ledger 与检索审计

| 来源 | 本报告使用的事实 | 证据深度 |
|---|---|---|
| D. R. Luke & M. K. Tam, “Generalized Monotonicity and the Proximal Point Algorithm,” *Math. Oper. Res.* (online 2025), [official full HTML](https://pubsonline.informs.org/doi/10.1287/moor.2025.0863) | Def. 1 metric subregularity；pointwise a\(\alpha\)-FNE；Def. 2 submonotonicity；Prop. 4 与 aFNE/reflected Lipschitz 等价；hypomonotonicity比较与 Examples 1–2 | **[V-S] 官方出版页全文与公式** |
| L. Evens, P. Pas, P. Latafat & P. Patrinos, “Convergence of the Preconditioned Proximal Point Method and Douglas–Rachford Splitting in the Absence of Monotonicity,” [full preprint](https://arxiv.org/pdf/2305.03605), [official journal page](https://link.springer.com/article/10.1007/s10107-024-02182-0) | \((\mu,\rho)\)-semimonotonicity定义、hypo/cohypo/cocoercive special cases、inverse/scaling 与 resolvent properties | **[V-S] 作者全文 + 官方元数据** |
| H. H. Bauschke, W. M. Moursi & X. Wang, “Generalized monotone operators and their averaged resolvents,” [full preprint](https://arxiv.org/pdf/1902.09827), [DOI](https://doi.org/10.1007/s10107-020-01500-6) | conically nonexpansive/averaged 定义；\(\rho\)-comonotone与 averaged resolvent characterization；maximality/full domain | **[V-S] 作者全文** |
| D. R. Luke, N. H. Thao & M. K. Tam, “Quantitative convergence analysis of iterated expansive, set-valued mappings,” [preprint](https://arxiv.org/abs/1605.05725), [publisher PDF](https://pubsonline.informs.org/doi/pdf/10.1287/moor.2017.0898) | pointwise almost averaged/FNE 与 gauge metric subregularity fixed-point框架 | **[V-S] 全文可得** |
| B. S. Mordukhovich & W. Ouyang, “Higher-order metric subregularity and its applications,” [author manuscript](https://optimization-online.org/wp-content/uploads/2014/07/4440.pdf) | Definition 3.1：任意 \(q>0\) 的 metric/strong metric \(q\)-subregularity与 exact bound | **[V-S] 全文 PDF** |
| G. Li & B. S. Mordukhovich, “Hölder Metric Subregularity with Applications to Proximal Point Method,” [publisher PDF](https://epubs.siam.org/doi/pdf/10.1137/120864660?download=true) | \(q\in(0,1]\) Hölder metric subregularity与 PPA；inverse-side Hölder stability语境 | **[V-S] 原论文/摘要与全文入口** |
| C. S. Barroso, “Hölder-contractive mappings, nonlinear extension problem and fixed point free results,” [preprint](https://arxiv.org/pdf/2207.03057), [publisher page](https://www.sciencedirect.com/science/article/abs/pii/S0022247X23005243) | \(\alpha\)-Hölder nonexpansive/\(L\)-Lipschitz map-side class | **[V-S] 全文 PDF；与 RL graph 的连接是本报告 [I]** |

本轮交叉检索式（2026-09-01；web search，未使用不可复现的命中数）：

- `"reflected resolvent" "Lipschitz" semimonotone operator`
- `"(mu,rho)-semimonotone" resolvent reflected resolvent`
- `"Generalized Monotonicity and the Proximal Point Algorithm"`
- `conically nonexpansive resolvent comonotone`
- `"Hölder nonexpansive mapping" definition fixed point`
- `"reflected resolvent" "Hölder continuous" monotone`
- `"Hölder firmly nonexpansive"`
- `"Cayley transform" "Hölder continuous" operator resolvent`
- 精确公式片段 `||a-lambda b|| <= L ||a+lambda b||^gamma` 及内积右端的文本变体。

精确公式检索只返回邻近而非同式文献；这应记录为 **[P: no exact hit in accessible web]**，不能提升为 novelty claim。后续应在 MathSciNet/zbMATH/Scopus/Web of Science 或作者引用链中继续核查。
