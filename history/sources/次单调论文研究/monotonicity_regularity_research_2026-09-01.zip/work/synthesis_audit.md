# Adversarial audit of `research/seesaw_synthesis.md`

> Scope: only `research/seesaw_synthesis.md`, checked against
> `research/theory_atlas.md`, `research/gap_examples.md`,
> `research/example_properties.md`, `work/c_phase_cloud.md`, and
> `work/c_consistency_audit.md`. No web search or new literature fact was used.
> The audit treats C-stage analytic recomputation as authoritative over stale
> B-stage candidate labels.

## 0. Readiness before repair

- **BLOCKER:** none.
- **MAJOR:** five bounded repairs are required. None overturns the main
  judgment “D, represented by B+C rather than A”.
- **MINOR:** four precision/coverage repairs are recommended.
- **Pre-repair readiness:** `CONDITIONALLY_READY`.

## 1. BLOCKER

### SA-B01 -- none established

No statement in the synthesis is contradicted strongly enough to reject the
main phase judgment or the RL placement as a whole.

## 2. MAJOR

### SA-M01 -- the conditioned-germ display conflates a selected update with a set-valued map and leaves the PPA residual bridge implicit

- **Location:** synthesis lines 235--263, equations (E)--(C).
- **Evidence:** `theory_atlas.md` (3.10)--(3.12) evaluates original-operator
  regularity at (x^+=J_{\lambda F}x), whereas the abstract fixed-point MSR
  template evaluates (I-T) at the current input (x). C-stage GX-042,
  GX-068--070 and GX-077 show that these residuals cannot be silently copied.
- **Problem:** (d(Tx,S)) is ambiguous for set-valued (T). Moreover,
  (Gx/\lambda\in F(x^+)) gives
  (d(x^+,S)\le \psi_F(\|Gx\|/\lambda)), not immediately the printed
  current-input bound (d(x,S)\le\psi(\|Gx\|)).
- **Why it matters:** this is the central proposed common object. Leaving the
  bridge implicit recreates exactly the residual/target mismatch the synthesis
  warns against.
- **Direct patch:** quantify an admissible update
  (x^+\in T_{\mathcal B}(x)), write (E) and (C) with (d(x^+,S)), and use a
  branch-specific residual (G_{\mathcal B}). For PPA state explicitly
  
  \[
  d(x^+,S)\le\psi_F(\|Gx\|/\lambda),\qquad
  d(x,S)\le \|Gx\|+\psi_F(\|Gx\|/\lambda).
  \]
  
  In the linear case this gives the residual-EB modulus
  (1+\bar\rho/\lambda), which is the quantity appearing in Luke--Tam.

### SA-M02 -- equation (5.2) drops the right-continuity/right-envelope condition required by the epsilon-nearest limit

- **Location:** synthesis lines 378--412 and thresholds (5.3a)--(5.3b).
- **Evidence:** `theory_atlas.md` (3.12) explicitly requires continuity or
  right continuity of (psi), otherwise retaining the corresponding right
  limit.
- **Problem:** for an arbitrary monotone gauge, passing `epsilon -> 0` need
  not yield the printed value at the limiting gauge argument.
- **Direct patch:** state that (5.2) uses a right-continuous gauge; otherwise
  replace (psi) by
  (psi^+(t):=\lim_{s\downarrow t}\psi(s)). Apply (5.3a)--(5.3b) to that
  same effective gauge.

### SA-M03 -- “the negative correlation disappears outside one germ” is stronger than the finite curated phase cloud supports

- **Location:** synthesis line 21.
- **Evidence:** the phase cloud establishes crossings and all four operational
  cells, while its own boundary says no regression or impossibility theorem
  was computed.
- **Problem:** “消失” reads as a universal negative result, whereas the
  evidence only shows that a stable negative trend is no longer supported by
  this catalog.
- **Direct patch:** replace it by “一旦离开同一算法 germ，现有样本不再支持稳定负相关；点云中出现……”.

### SA-M04 -- the boxed (\mathrm{RL}_1\perp\mathrm{RL}_\gamma) needs an explicit neither-inclusion convention

- **Location:** synthesis lines 350--374.
- **Evidence:** `theory_atlas.md` (3.3)--(3.4) proves class-level mutual
  noninclusion on unbounded natural Cayley domains, using (R=I) in one
  direction and a power-Hölder Cayley map in the other. Bounded windows have
  the one-way inheritance (\mathrm{RL}_1\Rightarrow\mathrm{RL}_\gamma).
- **Problem:** (perp) can be misread as disjointness or as saying no map can
  satisfy both. It means neither class contains the other under the stated
  global/unbounded scope.
- **Direct patch:** add exactly that semantic sentence after the box, while
  retaining the bounded-window inheritance sentence.

### SA-M05 -- GX-032 is a Lipschitz Luke--Tam example, not a genuine subunit Hölder critical-flatness example

- **Location:** synthesis line 152.
- **Evidence:** `example_properties.md`, GX-032: sharp RL-1 constant (3),
  maximal local exponent (1); subunit exponents on its bounded restriction
  are inherited. GX-053, GX-064 and GX-065 carry the genuine critical
  subunit exponents.
- **Problem:** the combined cluster wording can incorrectly attribute
  “genuine Hölder Cayley” to GX-032.
- **Direct patch:** split the interpretation: GX-032 witnesses finite LT
  geometry without finite hypomonotonicity; GX-053/064/065 witness genuine
  critical-flatness Hölder Cayley behavior.

## 3. MINOR

### SA-m01 -- GX-004 needs the normalization (\omega=1) in the “all four moduli equal 1” list

- **Location:** synthesis lines 131--133.
- **Evidence:** `example_properties.md`, GX-004 gives all four exact moduli
  (1/\omega); `c_phase_cloud.md` correctly prints “GX-004 with
  (\omega=1)”.
- **Direct patch:** write “GX-004（(\omega=1)）”; also make the local
  references of GX-058 and GX-039 explicit.

### SA-m02 -- “inverse strong” is operational language, not strong metric regularity

- **Location:** synthesis section 2.1.
- **Evidence:** GX-043 has MR/MSR but not SMSR/SMR; it is nevertheless used in
  the “inverse 强” row.
- **Direct patch:** add that “强/弱” in this table is an operational coordinate
  label and that “inverse 强” does not mean the named strong metric regularity
  properties.

### SA-m03 -- the algorithm table is representative, not the complete audited index

- **Location:** synthesis section 3.1.
- **Evidence:** `theory_atlas.md` section 7 additionally contains verified
  rows for relaxed PPA, monotone forward--backward, prox-gradient, FBF /
  extragradient, and KL/composite descent. No citation in the synthesis table
  conflicts with the atlas, but omission must not be read as negative evidence.
- **Direct patch:** retitle the subsection “代表性横向比较” and point to the
  complete theorem index in `theory_atlas.md` section 7. Optionally add the
  FBF/extragradient row because it exposes a third metric-conditioning axis.

### SA-m04 -- the closing phrase overextends the Luke--Tam name to (L<1)

- **Location:** synthesis line 564.
- **Evidence:** the tied semimonotonicity curve is valid for all (L>0), but
  the nonnegative Luke--Tam violation convention corresponds to the
  (L\ge1) part.
- **Direct patch:** write “(gamma=1) lies on the tied semimonotonicity curve;
  its (L\ge1) segment is the Luke--Tam parameterization.”

## 4. Explicit pass findings

- **Canonical counting:** pass. GX-060/061 are not double-counted; the
  dimension-parameterized (N_{\{0\}}) family is not called a literal alias;
  set-map, primal-sum and algorithm-residual observations remain distinct.
- **Modulus zero:** pass. The synthesis separates vacuity, branch pinning,
  residual jump/escape and superlinear germs and gives them different
  empirical meanings.
- **(\gamma=1) conversion:** pass. The formulas
  
  \[
  \mu_L=\frac{1-L^2}{2\lambda(1+L^2)},\quad
  \rho_L=\lambda^2\mu_L,
  \quad \tau=\frac{L^2-1}{4}
  \]
  
  agree with `theory_atlas.md`.
- **(\gamma q):** pass after SA-M02. It is presented as a conditional upper
  bound/gauge composition, not an exact or universal law. GX-071 is
  reverse-calibrated and low-weight; GX-072 shows nonsharpness; GX-073 is not
  called a convergence-rate example.
- **GX-071/072/073:** pass. Weights, unknown optimal constants, anchored versus
  all-pairs exponents, drift margin and noninvariance are all preserved.
- **Algorithms:** no citation or theorem label conflicts with the audited
  atlas. Sufficient conditions are not called necessary or sharp.

## 5. Required recheck after patch

1. Re-read sections 0, 2.1--2.3, 3.1, 4.1, 5.3--5.4 and the final RL
   paragraph.
2. Verify that no occurrence of (d(Tx,S)) remains in the central germ.
3. Verify that (psi^+) is used consistently in the gauge threshold if the
   raw gauge is not right-continuous.
4. Verify that (perp) is defined as neither inclusion, not disjointness.
5. Re-run targeted searches for GX-032, GX-004, GX-071--073, “necessary”,
   “sharp”, and “universal”.

## 6. Post-repair recheck

All five MAJOR and four MINOR repairs were applied **only** to
`research/seesaw_synthesis.md`. Targeted recheck results:

- no residual occurrence of ambiguous `d(Tx,S)` remains;
- the central germ now quantifies (x^+\in T_{\mathcal B}(x)) and
  (G_{\mathcal B}), and the PPA bridge produces
  (1+\bar\rho/\lambda) explicitly;
- equation (5.2) now carries the right-continuity/right-envelope rule, and the
  threshold reuses that effective gauge;
- the RL symbol (perp) is explicitly class-level neither inclusion, not
  disjointness;
- GX-032 is separated from genuine critical Hölder examples;
- GX-004 is normalized by (omega=1), and the table's “inverse strong” label
  is declared operational;
- the algorithm table is labeled representative, points to the full atlas
  index, and now includes the audited FBF/extragradient third-axis row;
- GX-071/072/073 weights, exact-versus-upper-bound status and invariance
  qualifications remain unchanged;
- Markdown fences are balanced.

**Final readiness:** `READY` for integrator use. No unresolved BLOCKER or
MAJOR remains; the main D / B+C judgment was not changed.

## 7. Expert contract

```yaml
contract_version: "1.0"
expert_skill: sci-skills-presubmission-review
project_id: null
paper_family: null
stage_id: null
task_id: null
task_status: COMPLETE
inputs_reviewed:
  - research/seesaw_synthesis.md
  - research/theory_atlas.md
  - research/gap_examples.md
  - research/example_properties.md
  - work/c_phase_cloud.md
  - work/c_consistency_audit.md
outputs:
  - work/synthesis_audit.md
  - research/seesaw_synthesis.md (bounded audit repairs)
evidence_status:
  - VERIFIED_USER_MATERIAL: all cross-check evidence is in the listed workspace files
  - AI_INFERENCE: severity ranking and minimum repairs
assumptions: []
author_input_needed: []
manual_actions: []
quality_checks:
  - cross-residual and target audit completed
  - canonical-weight and modulus-zero audit completed
  - gamma=1 and gamma<1 scope audit completed
  - gamma-q and GX-071/072/073 audit completed
  - post-repair targeted recheck completed
conflicts: []
conflict_resolution_status: NOT_REQUIRED
merge_permission: orchestrator_only
recommended_next_action: parent integrator should include the repaired synthesis in final artifact QA
stage_acceptance_recommendation: PASS_CANDIDATE
```
