# Subagent B(MAX)：线性、矩阵与 Cayley gap-example catalog

> 状态：B 阶段显式例子底稿；**不是**最终 synthesis。  
> 口径：除另注外，空间带标准 Euclidean/Hilbert 范数，参考图点为 \((0,0)\)，\(\lambda>0\)。所有性质均由显示公式重算；`ALG` 表示自行构造/代数验证，不把 atlas 的 seed 标签当作证据。  
> 与 C 的接口：每条都打印 graph、inverse、zero、\(J\)、\(R\)、graph/RL/regularity 计算及 local/global 量词。C 仍应独立复算。

## 0. 复算字典（只用于压缩重复代数）

若 \(F(x)=Mx\) 且 \(I+\lambda M\) 可逆，则

\[
J_{\lambda F}=(I+\lambda M)^{-1},\qquad
R_{\lambda F}=(I-\lambda M)(I+\lambda M)^{-1},
\]

\[
\langle a,b\rangle=a^\top M a,
\qquad
Q_{\lambda,\gamma}(a,b)
=\frac{\|R_{\lambda F}(I+\lambda M)a\|}
{\|(I+\lambda M)a\|^\gamma}.
\]

因此 finite-dimensional linear 情形中：RL\(_1\) 的 sharp 常数为 \(\|R_{\lambda F}\|_2\)；若 \(R\ne0\) 且 Minty domain 无界，则沿射线缩放立即否定每个 \(0<\gamma<1\) 的 global RL；若 \(R=0\)，所有 \(\gamma\in(0,1]\) 都成立且常数下确界为 0。在线性映射的 \((0,0)\) 处，MSR 模数为最小非零奇异值的倒数（range closed 时），MR iff surjective，SMSR iff injective + closed range，SMR iff boundedly invertible。

Cayley-parametrized graph 统一写成（该部分取 \(\lambda=1\)）

\[
\Gamma_R=\left\{\left(u(s),v(s)\right)
=\left(\frac{s+R(s)}2,\frac{s-R(s)}2\right):s\in D\right\}.
\]

此时 Minty input 就是 \(s\)，故 \(J_F(s)=u(s)\)、\(R_F(s)=R(s)\)，且任意两参数 \(s,t\) 满足

\[
\langle a,b\rangle
=\frac14\left(|s-t|^2-|R(s)-R(t)|^2\right),\qquad
Q_{1,\gamma}=\frac{|R(s)-R(t)|}{|s-t|^\gamma}.
\]

分母为 0 时 \(s=t\)，Cayley 参数唯一，分子也为 0；本文将该对视为满足不等式，而不把 \(0/0\) 当数值 ratio。

### 0.1 ID 索引

| ID | 显式对象 | 主 gap |
|---|---|---|
| LC-01 | \(F=0\) | global RL\(_1\not\Rightarrow\)global RL\(_\gamma\)；trivial MSR |
| LC-02 | \(F=cI\) | tuned \(R=0\)；strong+coco+SMR |
| LC-03 | \(F=-cI\) | negative graph + SMR；singular step |
| LC-04 | skew rotation \(\omega K\) | \(J\) contraction without strongness |
| LC-05 | \(\mu I+\omega K\) | \(F,F^{-1}\) strong；\(R\) contraction |
| LC-06 | \(\operatorname{diag}(0,c)\) | cocoercive + MSR，not MR/SMSR |
| LC-07 | nilpotent shear | finite hypo，no finite cohypo |
| LC-08 | \(\operatorname{diag}(-c,d)\) | nonmonotone SMR；possible \(J\) contraction |
| LC-09 | \(\operatorname{diag}(1/n)\) on \(\ell^2\) | maximal+coco，no power MSR |
| LC-10 | \(\mu I+N_{[0,\infty)}\) | strong not coco；\(R\) not contraction |
| LC-11 | \(x\mapsto x_+\) | coco not strong；MSR not MR |
| LC-12 | \(N_{[0,\infty)}\) | maximal not strong；trivial MSR |
| LC-13 | restricted \(\mu x\), \(x\ge0\) | nonmax strong；SMSR not MR |
| LC-14 | restricted zero graph | nonmax nonstrong；bounded Hölder inheritance |
| LC-15 | \(R=P_\alpha\) Cayley graph | genuine RL\(_\alpha\) + local SMR |
| LC-16 | \(R=\tanh\) Cayley graph | all RL exponents，not ordinary MSR |
| LC-17 | \(R=s/(1+s^2)\) Cayley graph | algebraic all-RL / not-MSR witness |
| LC-18 | \(R=s-s^3\) Cayley relation | no global RL；local RL\(_1\)；not MSR |
| LC-19 | \(R=2I\) on \([-1,1]\) | bounded RL\(_1\)+RL\(_\gamma\)；SMR |
| LC-20 | clipped \(R\) | all RL exponents + MSR，not MR/SMSR |
| LC-21 | \(F(x)=x^3\) | maximal/RL\(_1\)，only \(q=1/3\) regularity |

---

## LC-01 — 零算子：global RL\(_1\) 但非任何 global subunit RL；MSR 仅为平凡真

- **用途 / gap cells**：RL\(_1\wedge\neg\mathrm{RL}_\gamma\)（\(0<\gamma<1\)，global unbounded）；RL\(_1\wedge\)MSR\(\wedge\neg\)SMSR\(\wedge\neg\)MR；maximal monotone \(\wedge\neg\)strong。**来源状态：ALG**。
- **对象**：\(H=\mathbb R\)，\(F(x)=0\)（single-valued，domain \(\mathbb R\)）；\(\operatorname{gph}F=\mathbb R\times\{0\}\)，\(\operatorname{zer}F=\mathbb R\)。
- **Inverse / Cayley**：\(F^{-1}(0)=\mathbb R\)，\(F^{-1}(y)=\varnothing\) for \(y\ne0\)；\(J_{\lambda F}=I\)，\(R_{\lambda F}=I\)。
- **Graph side**：\(b=0\)，\(\langle a,b\rangle=0\)。sharp strong modulus为 0；hypomonotonicity modulus 0。因 RHS \(\beta\|b\|^2=0\)，它形式上对任意 \(\beta>0\) cocoercive（退化证书，不代表 inverse stability）。它是 maximally monotone。
- **RL side**：\(Q_{\lambda,1}=1\) for \(a\ne0\)，故 sharp \(L_1=1\)。对 \(0<\gamma<1\)，\(Q=|a|^{1-\gamma}\to\infty\)，无 global 常数；限制 Minty window 直径为 \(\Delta<\infty\) 时 sharp \(L_\gamma=\Delta^{1-\gamma}\)，只是 bounded-window inheritance。
- **Regularity side at \((\bar x,0)\)**：\(d(x,S)=0\) 且 \(d(0,F(x))=0\)，故 MSR exact modulus 0，但这是 nonisolated-solution trivial EB；SMSR 失败。MR 失败：任意 output 邻域含 \(y\ne0\)，此时 inverse 为空；SMR 亦失败。\(F^{-1}\) calm modulus 0，但不 Aubin。
- **验证 / phase**：射线 \(a=t\) 同时验证 RL 指数失败；regularity 失败量词由任意 \(y\to0,y\ne0\) 给出。坐标：nonexpansive Cayley / maximal monotone；target-uniform regularity弱，fixed-target MSR为平凡真。

## LC-02 — 正标量族：tuned step 时唯一的 full-domain linear subunit-RL 情形

- **用途 / gap cells**：strong + cocoercive；MR/MSR/SMSR/SMR 全强；展示 \(R=0\) 时 global RL\(_\gamma\)，以及稍离 tuned step 即只剩 global RL\(_1\)。**来源状态：ALG**。
- **对象**：\(H=\mathbb R\)，\(F(x)=cx\)，\(c>0\)，single-valued；graph \(\{(x,cx)\}\)，zero \(\{0\}\)，inverse \(F^{-1}(y)=y/c\)。
- **Cayley**：
  \[
  J_{\lambda F}=\frac1{1+\lambda c}I,\qquad
  R_{\lambda F}=r_\lambda I,\quad
  r_\lambda:=\frac{1-\lambda c}{1+\lambda c}.
  \]
- **Graph side**：\(b=ca\)，\(\langle a,b\rangle=c|a|^2=(1/c)|b|^2\)。sharp strong modulus \(c\)，sharp cocoercivity \(1/c\)，hypo modulus 0；\(F\) 与 \(F^{-1}\) 分别 strong \(c\) 与 \(1/c\)，且 \(F\) maximally monotone。
- **RL side**：RL\(_1\) sharp \(L=|r_\lambda|<1\)。若 \(\lambda c\ne1\)，任一 \(\gamma<1\) 的 global ratio 为 \(|r_\lambda||d|^{1-\gamma}\)，无界；若 \(\lambda=1/c\)，\(R=0\)，每个 \(0<\gamma\le1\) 及每个 \(L>0\) 都成立（sharp infimum 0）。bounded window diameter \(\Delta\) 时 \(L_\gamma^*=|r_\lambda|\Delta^{1-\gamma}\)。
- **Regularity side**：四种性质都 global；exact modulus
  \[
  \operatorname{reg}F=\operatorname{subreg}F
  =\operatorname{subreg}_{\rm strong}F=1/c,
  \]
  inverse localization global single-valued。残差律 \(|x|=(1/c)|F(x)|\)；largest residual exponent为 1（\(q>1\) 失败，\(q<1\) 在局部由缩窗继承）。
- **验证 / phase**：直接标量代入，无奇异参数。坐标：graph 与 inverse stability 同时强；也说明 subunit global RL 对线性对象高度 step-specific。

## LC-03 — 负标量双射：graph geometry 弱而 regularity 全强

- **用途 / gap cells**：\(\neg\)monotone + MR/SMSR/SMR；global RL\(_1\wedge\neg\mathrm{RL}_\gamma\)；在 \(\lambda c=1\) 显式展示 resolvent branch collapse。**来源状态：ALG**。
- **对象**：\(F(x)=-cx\)，\(c>0\)，single-valued，graph \(\{(x,-cx)\}\)，zero \(\{0\}\)，inverse \(-y/c\)。
- **Graph side**：\(b=-ca\)，\(\langle a,b\rangle=-c|a|^2=-(1/c)|b|^2\)。sharp hypomonotonicity \(\sigma=c\)，sharp cohypomonotonicity \(\eta=1/c\)；无 monotonicity、strongness 或 positive cocoercivity。\(F+cI=0\) maximal monotone，故它是 maximally \(c\)-hypomonotone，但不是 ordinary maximally monotone。
- **Cayley / RL**：若 \(\lambda c\ne1\)，
  \[
  J=\frac1{1-\lambda c}I,\qquad
  R=\frac{1+\lambda c}{1-\lambda c}I,\qquad
  L_1^*=\left|\frac{1+\lambda c}{1-\lambda c}\right|>1.
  \]
  非零线性 \(R\) 使所有 global \(\gamma<1\) 失败。若 \(\lambda c=1\)，\(I+\lambda F=0\)，Minty domain 为 \(\{0\}\) 而 \(J(0)=\mathbb R\) 多值；取两个不同 graph points 得 \(d=0,r=2a\ne0\)，所以任意 RL 都失败。
- **Regularity side**：尽管 graph 非单调，四种 regularity 均 global，exact modulus \(1/c\)；残差律 \(|x|=(1/c)|F(x)|\)。
- **验证 / phase**：奇异 step 的 zero-denominator pair 是显式反证；其余由 1D singular value \(c\) 验证。坐标：weak/negative graph geometry + strongest local inverse stability。

## LC-04 — 二维纯 skew rotation：\(J\) contraction 不推出 \(F\) strong

- **用途 / gap cells**：\(J\) contraction \(\wedge\neg\)strong\((F)\wedge\neg\)strong\((F^{-1})\)；monotone but neither strong nor cocoercive；regularity 全强。**来源状态：ALG（经典 skew seed 的独立计算）**。
- **对象**：\(H=\mathbb R^2\)，\(K=\begin{psmallmatrix}0&-1\\1&0\end{psmallmatrix}\)，\(F(x)=\omega Kx\)，\(\omega>0\)。graph \(\{(x,\omega Kx)\}\)，zero \(\{0\}\)，inverse \(F^{-1}(y)=-(1/\omega)Ky\)。
- **Graph side**：\(b=\omega Ka\)，\(\langle a,b\rangle=0\)，\(\|b\|=\omega\|a\|\)。sharp strong与 signed-comonotone lower modulus均为 0；它 monotone/maximally monotone，但无任何 positive cocoercivity，也非 strict/strong。inverse 同样不 strong。
- **Cayley**：令 \(t=\lambda\omega\)，
  \[
  J=\frac1{1+t^2}(I-tK),\quad
  \|J\|_2=\frac1{\sqrt{1+t^2}}<1,
  \]
  \[
  R=(I-tK)(I+tK)^{-1},\quad R^\top R=I,\quad \|R\|_2=1.
  \]
  \(R\) 是转角 \(-2\arctan t\) 的 rotation（按上述 \(K\) convention）。
- **RL side**：global RL\(_1\) sharp \(L=1\)；因 \(R\ne0\) 且 domain unbounded，每个 \(\gamma<1\) global 失败。任意 diameter-\(\Delta\) window 上 sharp \(L_\gamma=\Delta^{1-\gamma}\)。
- **Regularity side**：\(\sigma_{\min}(F)=\omega\)，故 MR=MSR=SMSR=SMR，exact modulus \(1/\omega\)；残差律 \(\|x\|=\|F(x)\|/\omega\)。
- **验证 / phase**：\((I+tK)^\top(I+tK)=(1+t^2)I\) 与 Cayley orthogonality 给 exact norms。坐标：zero inner-product geometry，却有强 inverse stability；\(J\)-contraction 来自 skew spectrum，不来自 positive graph curvature。

## LC-05 — shifted rotation：strong\((F)\)、strong\((F^{-1})\) 与 contracting \(R\) 同时出现

- **用途 / gap cells**：strong \(\wedge\)cocoercive；\(J,R\) contractions；regularity 全强；LC-04 的正对照。**来源状态：ALG**。
- **对象**：\(F(x)=(\mu I+\omega K)x\) on \(\mathbb R^2\)，\(\mu>0,\omega>0\)。single-valued；\(\operatorname{gph}F=\{(x,(\mu I+\omega K)x):x\in\mathbb R^2\}\)；zero \(\{0\}\)；
  \[
  F^{-1}=\frac{\mu I-\omega K}{\mu^2+\omega^2}.
  \]
- **Graph side**：
  \[
  \langle a,b\rangle=\mu\|a\|^2
  =\frac{\mu}{\mu^2+\omega^2}\|b\|^2.
  \]
  sharp strong modulus \(\mu\)，sharp cocoercivity \(\mu/(\mu^2+\omega^2)\)；\(F^{-1}\) 的 sharp strong modulus也为 \(\mu/(\mu^2+\omega^2)\)。full-domain continuous monotone，故 maximal。
- **Cayley / singular values**：令 \(D_+=(1+\lambda\mu)^2+(\lambda\omega)^2\)，
  \[
  J=\frac{(1+\lambda\mu)I-\lambda\omega K}{D_+},\qquad
  \|J\|_2=D_+^{-1/2},
  \]
  \[
  R=((1-\lambda\mu)I-\lambda\omega K)
  ((1+\lambda\mu)I+\lambda\omega K)^{-1},\qquad
  \|R\|_2=
  \sqrt{\frac{(1-\lambda\mu)^2+(\lambda\omega)^2}{D_+}}<1.
  \]
  两个矩阵都是 scaled rotations，故显示值就是 exact singular value。
- **RL side**：global RL\(_1\) sharp常数为上述 \(\|R\|_2\)。因 \(\omega>0\) 保证 \(R\ne0\)，所有 global \(\gamma<1\) 失败；bounded diameter \(\Delta\) 上常数乘 \(\Delta^{1-\gamma}\)。
- **Regularity side**：\(F\) 的两个 singular values皆为 \(\sqrt{\mu^2+\omega^2}\)，四种 regularity exact modulus皆为 \((\mu^2+\omega^2)^{-1/2}\)。
- **验证 / phase**：利用 \((\alpha I+\beta K)^\top(\alpha I+\beta K)=(\alpha^2+\beta^2)I\)。坐标：graph curvature、co-curvature、Cayley contraction与 inverse stability 都强。

## LC-06 — singular PSD projection-scaling：cocoercive/maximal，但无 MR 或 SMSR

- **用途 / gap cells**：cocoercive \(\wedge\neg\)strong；RL\(_1\wedge\neg\mathrm{RL}_\gamma\)；MSR\(\wedge\neg\)MR\(\wedge\neg\)SMSR；strong graph-side certificate 与 weak isolation/coverage。**来源状态：ALG**。
- **对象**：\(F(x_1,x_2)=(0,cx_2)\)，\(c>0\)，矩阵 \(M=\operatorname{diag}(0,c)\)。single-valued，\(\operatorname{gph}F=\{(x,Mx):x\in\mathbb R^2\}\)，
  \[
  \operatorname{zer}F=\mathbb R\times\{0\},\quad
  F^{-1}(y)=
  \begin{cases}\{(t,y_2/c):t\in\mathbb R\},&y_1=0,\\
  \varnothing,&y_1\ne0.
  \end{cases}
  \]
- **Graph side**：\(\langle a,b\rangle=c a_2^2=(1/c)\|b\|^2\)。sharp cocoercivity \(1/c\)，strong modulus 0；maximally monotone（continuous monotone full-domain）。
- **Cayley**：
  \[
  J=\operatorname{diag}\left(1,\frac1{1+\lambda c}\right),\quad
  R=\operatorname{diag}\left(1,\frac{1-\lambda c}{1+\lambda c}\right),
  \]
  所以 \(\|J\|_2=\|R\|_2=1\)。
- **RL side**：global RL\(_1\) sharp \(L=1\)；identity kernel direction使所有 global \(\gamma<1\) 失败。bounded Minty window diameter \(\Delta\) 上 sharp \(L_\gamma=\Delta^{1-\gamma}\)。
- **Regularity side**：
  \[
  d(x,S)=|x_2|=\frac1c\,d(0,F(x)).
  \]
  MSR exact modulus \(1/c\)，但 zero 非孤立故无 SMSR；range 为一条直线，非 surjective，故无 MR/SMR。
- **验证 / phase**：singular values \(\{c,0\}\)；kernel 与 cokernel 分别直接否定 SMSR 与 MR。坐标：positive co-geometry + exact EB，但 isolation 与 target coverage 都弱。

## LC-07 — nilpotent shear：finite hypomonotone、无任何 finite cohypomonotone modulus

- **用途 / gap cells**：hypomonotone vs cohypomonotone gap；global RL\(_1\)；MSR only；非对称矩阵的 exact \(J,R\) norms。**来源状态：ALG**。
- **对象**：\(F(x)=Nx\) on \(\mathbb R^2\)，\(N=\begin{psmallmatrix}0&1\\0&0\end{psmallmatrix}\)。若 \(x=(x_1,x_2)\)，则 \(F(x)=(x_2,0)\)。single-valued，\(\operatorname{gph}F=\{(x,Nx):x\in\mathbb R^2\}\)，zero \(\mathbb R\times\{0\}\)；
  \[
  F^{-1}(y)=
  \begin{cases}\{(t,y_1):t\in\mathbb R\},&y_2=0,\\
  \varnothing,&y_2\ne0.
  \end{cases}
  \]
- **Graph side**：对 \(a=(p,q)\)，\(b=(q,0)\)，
  \[
  \langle a,b\rangle=pq\ge-\tfrac12(p^2+q^2).
  \]
  \(\operatorname{sym}N\) eigenvalues \(\pm1/2\)，故 sharp hypomonotonicity \(\sigma=1/2\)。但 \(\langle a,b\rangle/\|b\|^2=p/q\)（\(q\ne0\)）无下界，所以不存在任何 finite \(\rho\) 使 \(\langle a,b\rangle\ge\rho\|b\|^2\)；尤其非 cohypomonotone/cocoercive。\(N+\tfrac12I\) full-domain monotone，故 \(F\) maximally \(1/2\)-hypomonotone。
- **Cayley / exact norms**：
  \[
  J=I-\lambda N=\begin{pmatrix}1&-\lambda\\0&1\end{pmatrix},\quad
  \|J\|_2=\frac{\sqrt{\lambda^2+4}+\lambda}{2},
  \]
  \[
  R=I-2\lambda N=\begin{pmatrix}1&-2\lambda\\0&1\end{pmatrix},\quad
  \|R\|_2=\sqrt{1+\lambda^2}+\lambda.
  \]
- **RL side**：global RL\(_1\) sharp \(L=\sqrt{1+\lambda^2}+\lambda\)；nonzero linear \(R\) 使每个 global \(\gamma<1\) 失败。
- **Regularity side**：\(d(x,S)=|x_2|=\|F(x)\|\)，故 MSR exact modulus 1；zero nonisolated，故非 SMSR；rank one，故非 MR/SMR。
- **验证 / phase**：shear \(\begin{psmallmatrix}1&t\\0&1\end{psmallmatrix}\) 的 largest singular value为 \((\sqrt{t^2+4}+|t|)/2\)，代 \(t=\lambda,2\lambda\)。坐标：negative pairwise defect + expansive Cayley + fixed-target EB only。

## LC-08 — indefinite diagonal双射：\(J\) 可 contraction，但 graph 非 monotone

- **用途 / gap cells**：weak graph + strongest regularity；\(J\)-contraction 非 strongness；hypo 与 cohypo 均有 sharp signed modulus。**来源状态：ALG**。
- **对象**：\(F(x_1,x_2)=(-cx_1,dx_2)\)，\(c,d>0\)。single-valued invertible；\(\operatorname{gph}F=\{(x,\operatorname{diag}(-c,d)x):x\in\mathbb R^2\}\)；zero \(\{0\}\)，inverse \(\operatorname{diag}(-1/c,1/d)\)。
- **Graph side**：
  \[
  \langle a,b\rangle=-c a_1^2+d a_2^2.
  \]
  sharp hypomonotonicity \(\sigma=c\)；相对于 \(\|b\|^2=c^2a_1^2+d^2a_2^2\) 的 sharp signed comonotonicity为 \(\rho=-1/c\)。因此无 monotonicity/strongness/positive cocoercivity。\(F+cI\) 为 PSD full-domain，故 maximally \(c\)-hypomonotone。
- **Cayley**：当 \(\lambda\ne1/c\)，
  \[
  J=\operatorname{diag}\left(\frac1{1-\lambda c},\frac1{1+\lambda d}\right),
  \]
  \[
  R=\operatorname{diag}\left(\frac{1+\lambda c}{1-\lambda c},
  \frac{1-\lambda d}{1+\lambda d}\right).
  \]
  exact norms是对应两个绝对对角元的最大值。特别地，\(\lambda c>2\) 时 \(\|J\|_2<1\)，尽管 \(F,F^{-1}\) 都不 strong。
- **RL side**：RL\(_1\) sharp \(L=\|R\|_2\)，所有 global \(\gamma<1\) 失败。若 \(\lambda=1/c\)，沿 \(e_1\) 有 Minty difference 0 而 reflected difference \(2e_1\)，所以所有 RL 失败。
- **Regularity side**：四种 regularity 均 global，exact modulus \(1/\min\{c,d\}\)；残差 sharp bounds为 \(\min(c,d)\|x\|\le\|F(x)\|\le\max(c,d)\|x\|\)。
- **验证 / phase**：全部由 diagonal eigen/singular values直接得到。坐标：负曲率 graph，却具完备 inverse stability；\(J\) contraction 还可由负 eigenvalue 穿过 \(-2/\lambda\) 产生。

## LC-09 — \(\ell^2\) compact positive diagonal：maximal+cocoercive，却连 MSR 都没有

- **用途 / gap cells**：strong-looking graph certificate + weak regularity；closed-range 必要性；RL\(_1\wedge\neg\mathrm{RL}_\gamma\)。**来源状态：ALG（标准 compact diagonal 构造）**。
- **对象**：\(H=\ell^2\)，
  \[
  (F x)_n=\frac{x_n}{n}.
  \]
  bounded single-valued，\(\operatorname{gph}F=\{(x,(x_n/n)_n):x\in\ell^2\}\)，zero \(\{0\}\)；\(F^{-1}y=(ny_n)\) 定义在 \(\operatorname{ran}F=\{y:(ny_n)\in\ell^2\}\)，该 range 非闭。
- **Graph side**：
  \[
  \langle a,b\rangle=\sum_{n\ge1}\frac{|a_n|^2}{n}
  \ge\sum_{n\ge1}\frac{|a_n|^2}{n^2}=\|b\|^2.
  \]
  sharp cocoercivity \(\beta=1\)（\(e_1\) 取等）；strong modulus 0（\(e_n\) 使 Rayleigh quotient \(1/n\to0\)）。它是 continuous full-domain maximally monotone。
- **Cayley / spectra**：
  \[
  (Jx)_n=\frac{n}{n+\lambda}x_n,\qquad
  (Rx)_n=\frac{n-\lambda}{n+\lambda}x_n.
  \]
  \(\|J\|=\|R\|=1\)（均为 supremum，\(J\) 的 1 不取到；\(R\) 可能在特殊小 \(n\) 取绝对值 1，但 tail 总给 supremum 1）。
- **RL side**：global RL\(_1\) sharp \(L=1\)。因任一 coordinate 上 \(R\ne0\)，射线缩放否定所有 global \(\gamma<1\)。
- **Regularity side**：取 \(x=e_n\)，\(\|x\|/\|F(x)\|=n\to\infty\)，故在 \((0,0)\) 无 MSR/SMSR；range 非闭且非 surjective，故无 MR/SMR。更强地，对任意 \(q>0\) 与任意小 \(t>0\)，\(x=t e_n\) 给 ratio \(t/(t/n)^q=n^q t^{1-q}\to\infty\)，所以没有任何 power-\(q\) SMSR。
- **验证 / phase**：coordinate basis 是 universal countersequence，不靠数值采样。坐标：maximal、monotone、1-cocoercive 与 RL\(_1\)，但 inverse stability 在所有 power scales 上崩溃。

## LC-10 — \(\mu I+N_{[0,\infty)}\)：strong/maximal 但非 cocoercive，\(J\) contraction 而 \(R\) 不 contraction

- **用途 / gap cells**：strong\(\wedge\neg\)cocoercive；maximal\(\wedge\)strong；\(J\)-contraction + strong\((F)\) + \(\neg\)strong\((F^{-1})\)；regularity 全强。**来源状态：ALG（normal-cone seed 的独立计算）**。
- **对象 / graph**：\(H=\mathbb R\)，\(C=[0,\infty)\)，凸分析 sign convention 给 \(N_C(0)=(-\infty,0]\)、\(N_C(x)=\{0\}\) for \(x>0\)。令 \(F=\mu I+N_C\)，\(\mu>0\)：
  \[
  F(x)=\begin{cases}\{\mu x\},&x>0,\\ (-\infty,0],&x=0,\\ \varnothing,&x<0.
  \end{cases}
  \]
  它 set-valued，zero \(\{0\}\)。
- **Inverse**：
  \[
  F^{-1}(y)=\frac1\mu\max\{y,0\},
  \]
  是 global single-valued、\(1/\mu\)-Lipschitz，但在 \(y<0\) 的 flat branch 使其不 strongly monotone。
- **Graph side**：normal cone monotonicity给
  \[
  \langle a,b\rangle\ge\mu |a|^2,
  \]
  sharp strong modulus \(\mu\)（取两个 interior graph points）。它 maximally \(\mu\)-monotone且 ordinary maximally monotone。不存在 positive cocoercivity：固定 \(x=0\) 取两个不同 normals，得 \(a=0,b\ne0\)。
- **Cayley**：
  \[
  J(s)=\frac{\max\{s,0\}}{1+\lambda\mu},\qquad
  R(s)=\begin{cases}-s,&s\le0,\\
  \dfrac{1-\lambda\mu}{1+\lambda\mu}s,&s\ge0.
  \end{cases}
  \]
  因而 \(\operatorname{Lip}J=1/(1+\lambda\mu)<1\)，但 \(\operatorname{Lip}R=1\)（negative branch 取等）。
- **RL side**：global RL\(_1\) sharp \(L=1\)，所有 global \(\gamma<1\) 由 negative ray 否定；bounded diameter \(\Delta\) 上 \(L_\gamma^*=\Delta^{1-\gamma}\)。
- **Regularity side**：inverse 的显示 localization 给 SMR/MR；残差对 \(x>0\) 为 \(\mu x\)，对 \(x<0\) 为 \(+\infty\)，故 SMSR/MSR exact modulus也为 \(1/\mu\)。四者均在 \((0,0)\) 成立；empty-value 一侧不降低由 \(x\downarrow0^+\) 达到的 exact modulus。
- **验证 / phase**：same-input two-normal pair反证 cocoercivity；两条 piecewise-linear slopes给 exact Cayley moduli。坐标：strong graph + strong inverse stability，但 reflected contraction 被 inverse strongness 的缺失阻断。

## LC-11 — positive-part map：cocoercive且 \(F^{-1}\) strong，但 \(F\) 不 strong、\(J\) 不 contraction

- **用途 / gap cells**：\(\neg\)strong\((F)\wedge\)cocoercive；strong\((F^{-1})\wedge\neg(J\text{ contraction})\)；MSR without MR/SMSR。**来源状态：ALG**。
- **对象**：\(F(x)=x_+:=\max\{x,0\}\) on \(\mathbb R\)，single-valued，
  \[
  \operatorname{gph}F=\{(x,0):x\le0\}\cup\{(x,x):x\ge0\},\quad
  S=(-\infty,0].
  \]
  \[
  F^{-1}(y)=\begin{cases}\{y\},&y>0,\\ (-\infty,0],&y=0,\\ \varnothing,&y<0.
  \end{cases}
  \]
- **Graph side**：projection firm nonexpansiveness可直接分三种 sign 验证：
  \[
  (x-y)(x_+-y_+)\ge|x_+-y_+|^2.
  \]
  sharp cocoercivity为 1；negative flat branch使 strong modulus 0。full-domain continuous monotone，故 maximal。等价地，\(F^{-1}\) 是 sharp 1-strongly monotone（允许同一 input \(0\) 多值）。
- **Cayley**：
  \[
  J(s)=\begin{cases}s,&s\le0,\\s/2,&s\ge0,\end{cases}\qquad
  R(s)=\begin{cases}s,&s\le0,\\0,&s\ge0.\end{cases}
  \]
  所以 \(\operatorname{Lip}J=\operatorname{Lip}R=1\)；两者都不是 strict contraction。
- **RL side**：global RL\(_1\) sharp \(L=1\)，negative ray否定任意 global \(\gamma<1\)。
- **Regularity side**：
  \[
  d(x,S)=x_+=d(0,F(x)),
  \]
  故 global MSR exact modulus 1（在 boundary reference \((0,0)\) 非平凡）。S 非孤立，故非 SMSR。MR 失败：任意 output 邻域含 \(y<0\) 而 inverse 为空；SMR 失败。
- **验证 / phase**：piecewise slopes及 exact residual identity 完成自检。坐标：co-geometry 强、target coverage/isolation 弱；也给 strong inverse graph inequality 与 resolvent contraction 的 non-equivalence（两者作用在不同 Cayley half）。

## LC-12 — 半线 normal cone：maximal monotone，但 regularity 几乎全弱

- **用途 / gap cells**：maximality\(\wedge\neg\)strong；RL\(_1\) 与 trivial MSR；normal cone 的多值性阻断 cocoercivity。**来源状态：ALG**。
- **对象**：\(F=N_{[0,\infty)}\)：
  \[
  F(x)=\begin{cases}\{0\},&x>0,\\ (-\infty,0],&x=0,\\ \varnothing,&x<0.
  \end{cases}
  \]
  set-valued；zero \([0,\infty)\)；
  \[
  F^{-1}(y)=\begin{cases}\{0\},&y<0,\\ {}[0,\infty),&y=0,\\ \varnothing,&y>0.
  \end{cases}
  \]
- **Graph side**：\(\langle a,b\rangle\ge0\)，sharp strong modulus 0（两个 interior zeros）；同一点 \(x=0\) 的不同 normals否定 positive cocoercivity。它 ordinary maximally monotone。
- **Cayley**：\(J=P_C=s_+\)，\(R=2P_C-I=|s|\)。因此 global RL\(_1\) sharp \(L=1\)；沿正或负 ray 所有 global \(\gamma<1\) 失败。
- **Regularity side at \((0,0)\)**：对 domain 内点 residual为 0且已在 S；domain 外 residual为 \(+\infty\)。故 MSR exact modulus 0，但完全由 solution/domain-vacuity造成。S 非孤立，故无 SMSR；\(y>0\) 时 inverse 为空，故无 MR/SMR。inverse calm可平凡成立，但不 Aubin/isolated calm。
- **验证 / phase**：显式 normal-cone graph 与 projection formula足够。坐标：maximal graph coverage确保 full-domain resolvent，却不确保 output coverage、isolated zero 或非平凡 EB。

## LC-13 — restricted positive slope on a half-line：strong graph + SMSR，但无 MR/maximality

- **用途 / gap cells**：strongness 与 maximality 四象限中的 nonmax+strong；strong graph geometry + weak target-uniform regularity；natural-domain contraction不等于 full-domain resolvent theorem。**来源状态：ALG**。
- **对象**：\(F(x)=\{\mu x\}\) for \(x\ge0\)，\(F(x)=\varnothing\) for \(x<0\)，\(\mu>0\)。single-valued on its proper domain；graph ray \(\{(x,\mu x):x\ge0\}\)，zero \(\{0\}\)。
- **Inverse**：\(F^{-1}(y)=\{y/\mu\}\) for \(y\ge0\)，empty for \(y<0\)。
- **Graph side**：\(\langle a,b\rangle=\mu|a|^2=(1/\mu)|b|^2\)，sharp strong \(\mu\) 与 cocoercive \(1/\mu\)。它不是 maximal：graph 真包含于 full-line \(x\mapsto\mu x\)。
- **Cayley**：natural Minty domain \(D_\lambda=[0,\infty)\)；
  \[
  J(s)=\frac{s}{1+\lambda\mu},\qquad
  R(s)=\frac{1-\lambda\mu}{1+\lambda\mu}s,\qquad s\in D_\lambda.
  \]
- **RL side**：on its natural unbounded domain，RL\(_1\) sharp \(L=|1-\lambda\mu|/(1+\lambda\mu)\)。除 tuned step \(\lambda\mu=1\) 外，所有 global-on-\(D_\lambda\) subunit exponents失败；tuned step 时 \(R=0\) 而全部成立。它没有 full-domain \(J\)。
- **Regularity side at boundary \((0,0)\)**：\(d(x,\{0\})=x=(1/\mu)d(0,F(x))\) for \(x\ge0\)，而 \(x<0\) residual \(+\infty\)，故 SMSR/MSR exact modulus \(1/\mu\)。MR 失败：取 \(x=0,y<0\to0\)，inverse 为空而 residual \(|y|\) 有限；SMR亦失败。largest power-SMSR exponent为 1。
- **验证 / phase**：range-side missing half-neighborhood是失败量词；没有用 empty values伪造 SMSR sharpness，因为正侧序列达到 \(1/\mu\)。坐标：strong pairwise graph + isolated EB，但无 target covering/maximality。

## LC-14 — restricted zero graph：nonmax+non-strong；bounded-domain RL\(_\gamma\) 只是尺度继承

- **用途 / gap cells**：maximality/strongness 的 nonmax+non-strong 象限；bounded RL\(_1\Rightarrow\)RL\(_\gamma\)；trivial MSR 的警示。**来源状态：ALG**。
- **对象**：\(F(x)=\{0\}\) for \(|x|\le1\)，outside 为空。single-valued on domain \([-1,1]\)；graph \([-1,1]\times\{0\}\)，zero \([-1,1]\)，inverse \(F^{-1}(0)=[-1,1]\)、其他 outputs为空。
- **Graph side**：\(b=0\)，inner product 0；strong modulus 0，形式上退化 cocoercive for every \(\beta\)。它 monotone但 nonmaximal（真包含于 LC-01）。
- **Cayley / RL**：\(D_\lambda=[-1,1]\)，\(J=R=I\) on D。RL\(_1\) sharp \(L=1\)；对每个 \(0<\gamma<1\)，
  \[
  L_\gamma^*=\sup_{s,t\in[-1,1]}|s-t|^{1-\gamma}=2^{1-\gamma}.
  \]
  这些 subunit exponents 都非 genuine：同一 map 已 Lipschitz，常数完全来自 \(\operatorname{diam}D=2\)。
- **Regularity side at \((0,0)\)**：在足够小 neighborhood 内所有 domain points皆为 zeros，domain 外 residual \(+\infty\)；MSR exact modulus 0（trivial/domain-vacuous），S 非孤立所以无 SMSR。任意 \(y\ne0\) inverse为空，故无 MR/SMR。
- **验证 / phase**：endpoint pair \((-1,1)\) 达到 Hölder 常数。坐标：partial nonmax graph + bounded-scale RL；inverse stability弱且 EB 无信息量。

## LC-15 — genuine power-Hölder Cayley graph：global RL\(_\alpha\) 且 local SMR

- **用途 / gap cells**：genuine RL\(_{\gamma<1}\wedge\neg\)RL\(_1\)，同时 MR/MSR/SMSR/SMR 全强；global RL\(_1\) vs RL\(_\gamma\) 的反向 strict witness；RL-Hölder 不等于 ordinary weak inverse stability。**来源状态：ALG（Cayley 构造）**。
- **参数 / 对象**：固定 \(0<\alpha<1\)、\(\lambda=1\)，令
  \[
  P_\alpha(s)=\operatorname{sgn}(s)|s|^\alpha,\quad
  u(s)=\frac{s+P_\alpha(s)}2,\quad
  v(s)=\frac{s-P_\alpha(s)}2,\qquad s\in\mathbb R.
  \]
  以 \(\Gamma=\{(u(s),v(s)):s\in\mathbb R\}\) 定义 \(F\)。因 \(u\) strictly increasing 且 onto，\(F:\mathbb R\to\mathbb R\) 是 full-domain single-valued。
- **Graph / zero / inverse**：
  \[
  \operatorname{gph}F=\Gamma,\qquad
  F^{-1}(y)=\{u(s):s-P_\alpha(s)=2y\},
  \]
  后者 global 可多值；\(s=P_\alpha(s)\) 的解为 \(-1,0,1\)，故 \(\operatorname{zer}F=\{-1,0,1\}\)。
- **Cayley**：\(J_F(s)=u(s)\)、\(R_F(s)=P_\alpha(s)\)，均 full-domain。
- **Graph side（sharp）**：对 \(s\ne t\) 令 \(k=(P_\alpha(s)-P_\alpha(t))/(s-t)>0\)，则
  \[
  \frac{b}{a}=\frac{1-k}{1+k}>-1,\qquad
  \langle a,b\rangle=ab\ge-|a|^2.
  \]
  secant slopes \(k\to\infty\) near 0，故 sharp hypomonotonicity modulus为 1（不取等）。等价地 \(F+I=s(u)\) maximally monotone，所以 \(F\) maximally 1-hypomonotone。不存在 finite cohypomonotonicity：让 \(k\downarrow1\) from above 得 \(a/b=(1+k)/(1-k)\to-\infty\)。因此更无 cocoercivity/monotonicity。
- **RL side（sharp exponent）**：经典 concave-power inequality给
  \[
  |P_\alpha(s)-P_\alpha(t)|\le2^{1-\alpha}|s-t|^\alpha,
  \]
  opposite pair \(t=-s\) 取到 sharp constant \(L_\alpha^*=2^{1-\alpha}\)。若候选 exponent \(\beta>\alpha\)，取 \(t=0,s\downarrow0\) 使 ratio \(|s|^{\alpha-\beta}\to\infty\)；若 \(\beta<\alpha\)，取 \(s\to\infty\)。故在 \((0,1]\) 中唯一 global exponent是 \(\beta=\alpha\)，尤其无 global/local-at-zero Lipschitz RL；这是 genuine Hölder，而非 bounded-domain inheritance。
- **Regularity side at \((0,0)\)**：near 0，\(P_\alpha(s)\) dominates \(s\)，故
  \[
  \frac{F(u(s))}{u(s)}=\frac{s-P_\alpha(s)}{s+P_\alpha(s)}\to-1.
  \]
  更强地，缩小 \(|s|<\delta\) 后 \(v(s)\) strictly decreasing，且 inverse secant ratio
  \[
  \frac{|u(s)-u(t)|}{|v(s)-v(t)|}=\frac{1+k}{k-1}\to1
  \quad(\delta\downarrow0)
  \]
  uniformly。故 F 在 \((0,0)\) SMR/MR/SMSR/MSR，四者 exact modulus均为 1；0 是 local isolated zero。在 \((\pm1,0)\)，exact modulus为 \((1+\alpha)/(1-\alpha)\)。global inverse 仍有 folds，不声称 global SMR。
- **验证 / phase**：small/large scaling双向核验 exponent sharpness；secant slope而非 derivative-only 证明 regularity。坐标：graph defect在 Minty small scales 发散、Cayley genuine Hölder，但 inverse 在 zero 附近反而 Lipschitz稳定。

## LC-16 — tanh-Cayley：RL\(_1\) 与所有 subunit RL 同时成立，但 ordinary MSR 失败

- **用途 / gap cells**：RL\(_\gamma\wedge\neg\)MSR（因 zero isolated，也同时 \(\neg\)SMSR/MR/SMR）；bounded-range 而非 bounded-domain 的 global Hölder；sharp power regularity \(q_*=1/3\)。**来源状态：ALG（Cayley 构造）**。
- **对象**：\(\lambda=1\)，\(R(s)=\tanh s\)，
  \[
  u(s)=\frac{s+\tanh s}{2},\qquad v(s)=\frac{s-\tanh s}{2}.
  \]
  \(u'(s)=(1+\operatorname{sech}^2s)/2>0\) 且 onto，故 graph定义 full-domain single-valued \(F\)。\(v\) strictly increasing（\(v'=\tanh^2s/2\)，仅在 0 导数为 0）且 onto，所以 inverse也 global single-valued：若 \(s-\tanh s=2y\)，则 \(F^{-1}(y)=u(s)\)。zero仅 \(\{0\}\)。
- **Cayley**：\(J_F(s)=u(s)\)，\(R_F(s)=\tanh s\)。
- **Graph side（sharp）**：tanh 的 secant slope \(k\in(0,1)\)，故
  \[
  \frac{b}{a}=\frac{1-k}{1+k}\ge0,\qquad
  \frac{a}{b}=\frac{1+k}{1-k}\ge1.
  \]
  因而 F maximally monotone、sharp strong modulus 0（\(k\uparrow1\) near 0）、sharp cocoercivity \(\beta=1\)（\(k\downarrow0\) along far-separated/tail pairs）。
- **RL side**：RL\(_1\) sharp \(L_1=1\)。对每个 \(0<\gamma<1\)，固定 gap \(d>0\) 时 tanh increment 的最大值由 centered pair达到：
  \[
  \max_x[\tanh(x+d)-\tanh x]=2\tanh(d/2).
  \]
  因此 exact global Hölder constant为
  \[
  L_\gamma^*=2^{1-\gamma}\max_{z>0}\frac{\tanh z}{z^\gamma},
  \]
  最大点 \(z_\gamma\) 是 \(2z/\sinh(2z)=\gamma\) 的唯一正解。所有 subunit RL 都是由“Lipschitz + bounded range”产生，故不是 sharp exponent意义下的 genuine Hölder。
- **Regularity side（sharp asymptotics）**：
  \[
  u(s)=s-\frac{s^3}{6}+O(s^5),\qquad
  v(s)=\frac{s^3}{6}+O(s^5).
  \]
  因 S=\(\{0\}\)，\(d(x,S)=|x|\)，而 \(d(0,F(x))\sim|x|^3/6\)。ordinary MSR/SMSR 失败；inverse 非 Lipschitz，故 MR/SMR 失败。largest residual exponent为 \(q_*=1/3\)：q-SMSR exact modulus \(6^{1/3}\)；two-variable q-MR（等价 inverse Hölder）exact asymptotic modulus \(6^{1/3}2^{2/3}=24^{1/3}\)。\(q>1/3\) 失败，\(q<1/3\) local 继承。
- **验证 / phase**：Taylor remainder给 residual order；fixed-gap maximization由 \(\operatorname{sech}^2(x+d)=\operatorname{sech}^2x\) 得 centered pair。坐标：monotone+cocoercive、所有 RL exponents，却只有 Hölder-\(1/3\) inverse stability。

## LC-17 — rational bounded Cayley：第二个 RL\(_\gamma\wedge\neg\)MSR，且 cocoercivity exact \(7/9\)

- **用途 / gap cells**：为 LC-16 的同一逻辑区提供 algebraic、非 transcendental 的独立对象；检验“同 RL 标签、regularity order相同但 graph modulus不同”。**来源状态：ALG**。
- **对象**：\(\lambda=1\)，
  \[
  R(s)=\frac{s}{1+s^2},\quad
  u(s)=\frac12\left(s+\frac{s}{1+s^2}\right),\quad
  v(s)=\frac{s^3}{2(1+s^2)}.
  \]
  令 \(\operatorname{gph}F=\{(u(s),v(s)):s\in\mathbb R\}\)。\(R'(s)=(1-s^2)/(1+s^2)^2\in[-1/8,1]\)，minimum \(-1/8\) at \(|s|=\sqrt3\)。故 \(u'=(1+R')/2\ge7/16>0\)，u strictly increasing onto，F 是 full-domain single-valued。\(v'=(1-R')/2\ge0\) 且只在 0 为 0，故 inverse也 single-valued。zero \(\{0\}\)。
- **Inverse / Cayley**：\(J_F=u\)、\(R_F=R\)；若 \(s^3/[2(1+s^2)]=y\)，则 \(F^{-1}(y)=u(s)\)（该 scalar equation有唯一实根）。
- **Graph side（sharp）**：任意 secant slope \(k\in[-1/8,1]\)。于是
  \[
  \frac{b}{a}=\frac{1-k}{1+k}\ge0,\qquad
  \frac{a}{b}=\frac{1+k}{1-k}\ge\frac79.
  \]
  F maximally monotone，strong modulus 0（\(k\uparrow1\) at 0），sharp cocoercivity \(7/9\)（secants收缩到 \(s=\pm\sqrt3\)）。
- **RL side**：\(\operatorname{Lip}R=1\)，range \([-1/2,1/2]\) 的 diameter为 1。因此对任意 \(0<\gamma<1\)，
  \[
  |R(s)-R(t)|\le\min\{|s-t|,1\}\le|s-t|^\gamma,
  \]
  即 certified global \(L=1\)；exact常数为显示的一维有限极值
  \(L_\gamma^*=\sup_{s\ne t}|R(s)-R(t)|/|s-t|^\gamma\le1\)。RL\(_1\) sharp \(L=1\)，故 subunit exponents非 genuine。
- **Regularity side**：
  \[
  u(s)=s-\frac{s^3}{2}+O(s^5),\qquad
  v(s)=\frac{s^3}{2}+O(s^5).
  \]
  ordinary MSR/SMSR/MR/SMR在 \((0,0)\) 均失败。largest residual exponent \(q_*=1/3\)；q-SMSR exact modulus \(2^{1/3}\)，two-variable q-MR exact asymptotic modulus \(2\)。
- **验证 / phase**：\(R'\) 的 minimum由对 \(z=s^2\) 求导得到 \(z=3\)；Taylor系数直接给 power modulus。坐标：与 LC-16 同为“all RL exponents + only power regularity”，但 co-geometry sharp modulus由 1 降为 \(7/9\)。

## LC-18 — cubic Cayley relation：global 所有 RL 均失败，但 local RL\(_1\)；ordinary MSR 亦失败

- **用途 / gap cells**：\(\neg\)global-RL\(_1\wedge\neg\)global-RL\(_\gamma\wedge\neg\)MSR；local/global 严格分离；set-valued F 但 single-valued inverse。**来源状态：ALG（Cayley 构造）**。
- **对象**：\(\lambda=1\)，\(R(s)=s-s^3\)，
  \[
  u(s)=s-\frac{s^3}{2},\qquad v(s)=\frac{s^3}{2},\qquad s\in\mathbb R.
  \]
  以参数 graph定义 \(F\)。由于 u 非 injective，F generally set-valued；但 u 是 odd cubic onto，所以 domain为 \(\mathbb R\)。zero仅 \(\{0\}\)。
- **Inverse / Cayley**：v 是 bijective，故
  \[
  F^{-1}(y)=\sqrt[3]{2y}-y
  \]
  global single-valued；\(J_F(s)=u(s)\)，\(R_F(s)=s-s^3\)，且 Minty input仍 full-domain。
- **Graph side（sharp signed bounds）**：对 \(h=s-t\)、\(q=s^2+st+t^2\ge0\)，
  \[
  a=(1-q/2)h,\quad b=(q/2)h,\quad
  \langle a,b\rangle=\frac{q(2-q)}4h^2.
  \]
  当 \(q>2\) 时非 monotone。又
  \[
  \frac{\langle a,b\rangle}{|b|^2}=\frac2q-1\ge-1,
  \]
  故 sharp 1-cohypomonotone（\(q\to\infty\) 达下确界）。另一方面 \(\langle a,b\rangle/|a|^2=q/(2-q)\to-\infty\) as \(q\downarrow2\) from above，所以不存在 finite hypomonotonicity modulus。
- **RL side**：\(|R(s)|\sim|s|^3\)，故每个 \(0<\gamma\le1\) 的 global ratio沿 \(t=0,|s|\to\infty\) 发散。local on \(|s|\le\delta\)：若 \(0<\delta\le\sqrt{2/3}\)，则 \(\sup|R'|=1\)，所以 local RL\(_1\) sharp \(L=1\)；同一 window上 RL\(_\gamma\) 可取 \((2\delta)^{1-\gamma}\)，仅为 bounded inheritance。
- **Regularity side at \((0,0)\)**：对小 \(x\)，只有 \(s\approx x\) 的 branch给接近 0 的 output；其他 branches的 outputs远离 0。因此
  \[
  d(0,F(x))\sim\frac{|x|^3}{2},\qquad S=\{0\}.
  \]
  ordinary MSR/SMSR失败；显示 inverse非 Lipschitz，故 MR/SMR失败。largest residual exponent \(1/3\)，q-SMSR exact modulus \(2^{1/3}\)，two-variable q-MR exact asymptotic modulus 2。
- **验证 / phase**：factorization \(s^3-t^3=q(s-t)\) 同时核验 graph bounds；global failure与local derivative bound使用不同尺度，未混合量词。坐标：两轴 ordinary 性质都弱，但仍存在 sharp Hölder-\(1/3\) inverse law。

## LC-19 — bounded dilation \(R=2I\)：bounded window 上 RL\(_1\) 与 RL\(_\gamma\) 同时成立

- **用途 / gap cells**：RL\(_1\wedge\)RL\(_\gamma\) 的 bounded strictness；nonmonotone但 SMR；nonmax strongness/maximality 对照中的 negative-slope partial graph。**来源状态：ALG**。
- **对象**：\(\lambda=1\)，Minty domain \(D=[-1,1]\)，取 \(R(s)=2s\)。Cayley graph为
  \[
  u(s)=\frac{3s}{2},\qquad v(s)=-\frac{s}{2},
  \]
  即
  \[
  F(x)=\{-x/3\}\quad(|x|\le3/2),\qquad F(x)=\varnothing\quad(|x|>3/2).
  \]
  single-valued on its domain；zero \(\{0\}\)；inverse \(F^{-1}(y)=-3y\) for \(|y|\le1/2\)，outside empty。
- **Graph side**：\(b=-a/3\)，
  \[
  \langle a,b\rangle=-\frac13|a|^2=-3|b|^2.
  \]
  sharp hypomonotonicity \(1/3\)，sharp cohypomonotonicity \(3\)，非 monotone/cocoercive。graph 真包含于 full-line \(-I/3\)，故 nonmaximal（ordinary 与 fixed-parameter hypomonotone意义都非 maximal）。
- **Cayley / RL**：\(J(s)=3s/2\)，\(R(s)=2s\) on D。RL\(_1\) sharp \(L=2\)。对任意 \(0<\gamma<1\)，
  \[
  L_\gamma^*=2\sup_{0<h\le2}h^{1-\gamma}=2^{2-\gamma},
  \]
  endpoint gap 2 取等；subunit exponent完全由 bounded diameter继承。若把同一线性 graph延伸到全空间，则所有 subunit global RL 立即失败。
- **Regularity side at \((0,0)\)**：0 位于 domain/range interior，inverse local single-valued，故 MR/MSR/SMSR/SMR 全成立，exact modulus 3；残差律 \(|x|=3|F(x)|\)。这些是 local 性质；不声称跨越 range endpoints 的 global MR。
- **验证 / phase**：所有常数由 endpoint或线性 ratio取到。坐标：expansive/nonmonotone Cayley + strong local inverse stability；bounded Hölder label不代表 genuine graph regularization。

## LC-20 — clipped Cayley：所有 RL exponents + exact MSR，但无 isolation/MR

- **用途 / gap cells**：RL\(_\gamma\wedge\)MSR\(\wedge\neg\)SMSR\(\wedge\neg\)MR；与 LC-16/17 的“RL\(_\gamma\wedge\neg\)MSR”形成同 graph-label不同 regularity 的对照。**来源状态：ALG**。
- **对象**：\(\lambda=1\)，
  \[
  R(s)=\operatorname{clip}_{[-1,1]}(s),\quad
  J(s)=\frac{s+R(s)}2.
  \]
  Cayley反解得到 full-domain single-valued
  \[
  F(x)=x-P_{[-1,1]}x=
  \begin{cases}x+1,&x<-1,\\0,&|x|\le1,\\x-1,&x>1.
  \end{cases}
  \]
  zero \([-1,1]\)；
  \[
  F^{-1}(y)=\begin{cases}\{-1+y\},&y<0,\\ {}[-1,1],&y=0,\\ \{1+y\},&y>0.
  \end{cases}
  \]
- **Graph side**：\(I-P_{[-1,1]}\) 的 elementary case split给
  \[
  \langle a,b\rangle\ge|b|^2.
  \]
  sharp cocoercivity 1；zero interval使 strong modulus 0。F 是 full-domain continuous maximally monotone。
- **RL side（sharp）**：clip 是 1-Lipschitz，且对 gap \(d\) 的最大 output gap为 \(\min\{d,2\}\)。故 RL\(_1\) sharp \(L=1\)，且
  \[
  L_\gamma^*=\sup_{d>0}\frac{\min\{d,2\}}{d^\gamma}=2^{1-\gamma},\qquad 0<\gamma<1.
  \]
  \(d=2\) 取等。subunit exponents由 Lipschitz+bounded range产生，非 genuine。
- **Regularity side**：global exact residual law
  \[
  d(x,[-1,1])=|F(x)|
  \]
  给 global MSR modulus 1。在 interior reference \((0,0)\)，local exact modulus退化为 0（邻域全在 S）；在 boundary \((\pm1,0)\)，local exact modulus为 1。任一 reference zero 都非 isolated，故无 SMSR。MR 在 interior/boundary 都失败：取非零 output \(y\to0\)，inverse与 reference 的距离保持正下界（interior约 1；boundary取错误 sign 时约 2），而 residual趋零；SMR亦失败。
- **验证 / phase**：fixed-gap clipping formula给 exact Hölder modulus，residual identity排除 domain-vacuity。坐标：positive co-geometry + all RL exponents + genuine fixed-target EB，但 target-uniformity/isolation弱。

## LC-21 — scalar cubic \(F(x)=x^3\)：maximal monotone/RL\(_1\)，ordinary MSR 仍失败

- **用途 / gap cells**：RL\(_1\wedge\neg\)MSR；maximal monotonicity 与 error bound独立；为 LC-16/17 的 Cayley-built examples 提供直接 polynomial operator 对照。**来源状态：ALG**。
- **对象**：\(F:\mathbb R\to\mathbb R\)，\(F(x)=x^3\)，single-valued，graph \(\{(x,x^3)\}\)，zero \(\{0\}\)，inverse \(F^{-1}(y)=\operatorname{sgn}(y)|y|^{1/3}\)。
- **Graph side（global/local sharp）**：
  \[
  \langle a,b\rangle=(x-y)(x^3-y^3)
  =(x-y)^2(x^2+xy+y^2)>0\quad(x\ne y).
  \]
  F strictly/maximally monotone，但 strong modulus 0。不存在 positive global cocoercivity，因为
  \(\langle a,b\rangle/|b|^2=1/(x^2+xy+y^2)\to0\) at large scale。限制 \(x,y\in[-r,r]\) 时 sharp local cocoercivity为 \(1/(3r^2)\)（下确界由 \(x,y\to r\) 达到）。
- **Cayley**：给定 Minty input \(s\)，令 x 是 \(s=x+\lambda x^3\) 的唯一实根，则
  \[
  J_{\lambda F}(s)=x,\qquad R_{\lambda F}(s)=x-\lambda x^3.
  \]
  参数 derivative为
  \[
  \frac{dR}{ds}=\frac{1-3\lambda x^2}{1+3\lambda x^2}\in(-1,1],
  \]
  且绝对值 supremum为 1。
- **RL side**：global RL\(_1\) sharp \(L=1\)。as \(|s|\to\infty\)，\(R(s)=-s+2J(s)\sim-s\)，故所有 global \(\gamma<1\) 失败。任意 bounded Minty window上按 diameter继承 subunit RL。
- **Regularity side**：exact residual law
  \[
  d(x,S)=|x|=d(0,F(x))^{1/3}.
  \]
  ordinary MSR/SMSR失败；inverse不 Lipschitz，故 MR/SMR失败。largest residual exponent为 \(q_*=1/3\)，q-MSR=q-SMSR exact modulus 1；two-variable q-MR exact modulus \(2^{2/3}\)，即 odd power map的 sharp Hölder constant。\(q>1/3\) 失败。
- **验证 / phase**：factorization与 implicit derivative各自独立核验 graph/RL；exact residual law无需数值。坐标：strict/maximal monotonicity + nonexpansive Cayley，但 only Hölder inverse stability。

---

## 22. 逻辑覆盖索引（不是 synthesis）

下表只检查 gap cells 是否有显式对象；“是/否”均指条目中指定的 local/global convention。

| Gap cell | 至少两个独立 witness |
|---|---|
| global RL\(_\gamma\) + ordinary MR/SMSR | LC-02（tuned scalar，线性退化 \(R=0\)）；LC-15（genuine Hölder Cayley，local SMR） |
| global RL\(_\gamma\) + MSR but not MR/SMSR | LC-20（nontrivial global EB）；LC-14（trivial/domain-vacuous，用作警告而非替代 LC-20） |
| global RL\(_\gamma\) + not ordinary MSR | LC-16（tanh）；LC-17（rational） |
| not global RL\(_\gamma\) + MR/SMSR | LC-03（negative scalar）；LC-04（skew rotation）；LC-08（indefinite diagonal） |
| not global RL\(_\gamma\) + not MSR | LC-18（indeed no global RL\(_1\) either）；LC-21（RL\(_1\) only）；LC-09（infinite-dimensional linear） |
| strong + cocoercive | LC-02, LC-05 |
| strong + not cocoercive | LC-10 |
| not strong + cocoercive | LC-06, LC-11, LC-20 |
| neither strong nor cocoercive | LC-04（skew）, LC-07（nilpotent）, LC-08（indefinite） |
| maximal + strong | LC-02, LC-05, LC-10 |
| maximal + not strong | LC-01, LC-04, LC-06, LC-09, LC-11, LC-12, LC-20, LC-21 |
| nonmaximal + strong | LC-13 |
| nonmaximal + not strong | LC-14, LC-19 |
| \(J\) contraction but neither \(F\) nor \(F^{-1}\) strong | LC-04；LC-08 for \(\lambda c>2\)（后者甚至 nonmonotone） |
| \(F\) strong, \(F^{-1}\) not strong, \(J\) contraction, \(R\) not | LC-10 |
| \(F^{-1}\) strong, \(F\) not strong, \(J\) not contraction | LC-11 |
| \(F,F^{-1}\) both strong and \(R\) contraction | LC-02（non-tuned also）, LC-05 |

## 23. B-stage validation record

1. **Symbolic audit**：所有 finite-dimensional linear entries 使用 matrix singular values；LC-07 shear norm、LC-04/05 scaled-rotation norm、LC-15--20 的 secant-slope/Cayley identities均显示在条目中。
2. **Executed numerical grid check（仅作自检，不代替证明）**：double precision 下 LC-07 的 \(\|J\|,\|R\|\) closed forms 在 \(\lambda=0.1,1,3\) 的误差 \(\le4.5\times10^{-16}\)；LC-15 取 \(\alpha=0.4\) 的 grid 达到 \(2^{0.6}\)；LC-16 的 fixed-gap maxima（\(d=0.1,1,4\)）均在 \(-d/2\) 达到；LC-17 的 sampled derivative minimum为 \(-0.125\) at \(|s|\approx1.73205\)；LC-18 sampled comonotone ratio保持 \(\ge-1\)，而 hypomonotone ratio已降至 \(-3.08\times10^4\)。这些结果与 symbolic bounds一致。
3. **Scale audit**：每次 \(\gamma<1\) 的失败都给出 small-或large-ray量词；每次 bounded inheritance 都打印 domain/range diameter，未把 local/bounded Hölder 当 genuine exponent。
4. **Regularity audit**：trivial MSR（LC-01/12/14）显式标记；nonclosed range（LC-09）、missing output side（LC-13）、nonisolated zero（LC-06/11/20）分别使用不同失败机制。
5. **Maximality audit**：只在 full-domain continuous monotone、normal cone/sum或显示 monotone transform可直接验证处写 maximal；partial graphs LC-13/14/19 均给出真扩张。
6. **待 C 独立复算**：尤其 LC-15 的 global inverse folds、LC-16/17/18 的 two-variable \(q\)-MR exact asymptotic constants，以及 LC-20 在 boundary reference 的 MR 反证应由 C 不依赖本标签重做。

本文没有据这些点判断任何 monotonicity–regularity “跷跷板”；这里只提交 phase cloud 的可复算坐标。
