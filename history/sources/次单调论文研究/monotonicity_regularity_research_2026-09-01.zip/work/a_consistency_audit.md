# Subagent A 独立一致性审计

> 审计日期：2026-09-01。审计对象：`a_monotonicity.md`、`a_regularity.md`、`a_rl_position.md`、`a_relation_audit.md`、`a_terminology_sources.md`、`a_algorithm_evidence.md`、`root_math_audit.md`。  
> 本文件只检查定义、量词、空间、代数、见证与引文承载范围；不重写 atlas，也不作任何 seesaw 结论。  
> 分级：**BLOCKER**＝在修复前不能作为事实边/算法数据使用；**MAJOR**＝会改变节点、假设或结论范围；**MINOR**＝不改变数学内容但会损坏渲染、检索或可追溯性；**PASS**＝已独立复算或交叉核对通过。

## BLOCKER

### B-01 — PPA-03 的增长步长 rate 按原文照抄后仍是无效命题

**位置**：`a_algorithm_evidence.md`，PPA-03 的 Theorem 7.3(ii)–(iii) 记录及总览中的 `V3`。

**问题**：Li–Mordukhovich 原文确实印成

\[
\lambda_k=O(k^s),
\]

但该上界不能推出文中所需的和式下界。原证明紧接着使用

\[
\sum_{i<k}\min\{\lambda_i^2,\lambda_i^{2(1-q)}\}
\ge C\sum_{i<k} i^{2s(1-q)},
\]

这需要 eventual lower growth \(\lambda_i\ge c i^s\)，即 \(\Omega(k^s)\)（或更安全的 \(\Theta(k^s)\)），而不是 \(O(k^s)\)。常值步长本身对每个 \(s>0\) 都是 \(O(k^s)\)，已足以显示现有量词不可能支撑随 \(s\) 任意提高的 rate。这个问题来自 primary source 的 statement/proof 内部，而不是本文件的转录错误。[原文 Theorem 7.3 及证明，pp. 25–26](https://optimization-online.org/wp-content/uploads/2012/02/3340.pdf)。

**影响**：Theorem 7.3(ii)–(iii) 不能按当前文字标 `V3`，也不能进入 algorithm phase diagram。Theorem 7.3(i)、(iv)、(v) 不受此问题影响。

**可直接补丁句**：

> **SOURCE-TYPO / PENDING REPAIR.** 原文 (ii)–(iii) 印作 \(\lambda_k=O(k^s)\)，但其证明实际使用 eventual lower bound \(\lambda_k\ge c k^s\)。在找到正式勘误或补出独立证明前，本表不把 (ii)–(iii) 记为 `V3`；若采用修正版假设，应写 \(\lambda_k=\Omega(k^s)\)（或 \(\Theta(k^s)\)）并标明这是 proof-audited correction，而非原 theorem 的逐字陈述。

## MAJOR

### M-01 — Spingarn 的 anchored / two-point 两个定义被合并，且 1981/1982 来源承担不同任务

**位置**：`a_monotonicity.md` §2.3(b)、§10–12；对照 `a_terminology_sources.md` §2.1–2.2。

**冲突**：

- `a_terminology_sources.md` 正确拆出 Spingarn 1981 的一端点固定 `(S-pw)` 与两端点移动 `(S-strict)`，并指出后者在原文叫 **strictly submonotone**；
- `a_monotonicity.md` 却把两端点式 `(SP)` 直接命名为 “Spingarn submonotonicity”，并以只读到摘要的 Spingarn 1982 PPA 论文加 later-source 公式承载历史命名；
- 1981 的 *Submonotone Subdifferentials of Lipschitz Functions* 与 1981/82 的 *Submonotone Mappings and the Proximal Point Algorithm* 是两篇不同文献。未读到 1982 全文前，不能用其摘要消解 1981 的 bare/strict 命名差异。

这不是纯术语问题：anchored 条件与 all-pairs 条件的逻辑强度不同，会改变 atlas 边和后续例子所属区域。

**可直接补丁句**：

> 历史节点必须拆成：(i) Spingarn-1981 pointwise submonotone `(S-pw)`；(ii) Spingarn-1981 strictly submonotone `(S-strict)`；(iii) Spingarn-1981/82 PPA 论文采用的 mapping/maximality convention（在取得全文前标 `PENDING_VERIFICATION`）。后期作者常把 `(S-strict)` 简称为 submonotone；因此不得把 `(SP)` 无限定地写成 bare “Spingarn submonotone”。

### M-02 — prox-regularity 的有限维 iff 被默认 Hilbert 化，且 converse 漏了 proximal-subgradient 条件

**位置**：`a_monotonicity.md` §6 与关系矩阵最后一行；对照 `a_relation_audit.md` §4。

**冲突**：`a_relation_audit.md` 把所引 Poliquin–Rockafellar 精确 iff 限定在 \(\mathbb R^n\)，并明确要求 \(\bar v\) 是 proximal subgradient、\(f\)-attentive localization 和值域截断；`a_monotonicity.md` 在全篇默认 Hilbert 空间下写成了结构性 “prox-regular \(\Leftrightarrow_{\rm local}\) localized hypomonotone subgradient”，只以“proper/lsc、prox-bounded 等”笼统代替关键条件。

交换两点相加所得的

\[
\text{prox-regular support inequalities}\Longrightarrow
\langle x_1-x_2,v_1-v_2\rangle\ge-r\|x_1-x_2\|^2
\]

是 Hilbert 代数；反向 characterization 不能据此自动升级到无限维。

**可直接补丁句**：

> 在实 Hilbert 空间中，prox-regular 支持式推出相应 attentive、值域截断图的局部 \(r\)-hypomonotonicity。本文引用的 converse/iff 只按 Poliquin–Rockafellar 的有限维 limiting-subdifferential 定理使用，并须另保留：\(\bar v\) 为 proximal subgradient、\(f\)-attentive localization 及所需 proper/lsc/prox-bounded 假设。任何无限维 converse 必须另引明确 theorem。

### M-03 — gauge contraction 常数只对 \(0<\gamma<1\) 正确，当前文字误含 \(\gamma=1\)

**位置**：`a_rl_position.md` (5.5) 及其后一句；`root_math_audit.md` “Draft theorem checks to preserve” 第一项。

**复算**：

\[
\Phi(r)=\psi\!\left(\frac{r+Lr^\gamma}{2\lambda}\right).
\]

- 若 \(0<\gamma<1\)，则输入渐近于 \((L/(2\lambda))r^\gamma\)，所以现有阈值
  \[
  \limsup_{t\downarrow0}\frac{\psi(t)}{t^{1/\gamma}}
  <\left(\frac{2\lambda}{L}\right)^{1/\gamma}
  \]
  正确；
- 若 \(\gamma=1\)，输入是 \(((1+L)/(2\lambda))r\)，正确阈值是
  \[
  \limsup_{t\downarrow0}\frac{\psi(t)}t<\frac{2\lambda}{1+L},
  \]
  不是 \(2\lambda/L\)。

**可直接补丁句**：

> 条件 (5.5) 仅在 \(0<\gamma<1\) 下成立。若 \(\gamma=1\)，应改用 \(\limsup_{t\downarrow0}\psi(t)/t<2\lambda/(1+L)\)。

### M-04 — 无限维 Asplund 的 PSNC 条件没有标明应施加在 inverse 上

**位置**：`a_regularity.md` §8.1 和 §10 的 “Asplund coderivative iff Aubin/MR” 行。

**问题**：Mordukhovich–Nguyen Theorem 2.1 是对某个映射 \(G\) 的 **Aubin/Lipschitz-like** 性给出

\[
G\text{ PSNC},\qquad D_M^*G(\bar p,\bar x)(0)=\{0\}.
\]

要刻画 \(F\) 的 metric regularity，必须取 \(G=F^{-1}\)。当前文字只写 “PSNC + mixed coderivative”，容易被读成 PSNC\((F)\)，这不是同一假设。[Theorem 2.1 原文](https://arxiv.org/pdf/2410.11362)。

**可直接补丁句**：

> 在 Asplund 空间中，Aubin\((G)\) 的 iff 使用 closed graph、PSNC\((G)\) 与 \(D_M^*G(\bar p,\bar x)(0)=\{0\}\)。对 MR\((F)\) 应明确令 \(G=F^{-1}\)，故所需的是 PSNC\((F^{-1})\) 及对应 inverse mixed-coderivative kernel；不得无定理地替换成 PSNC\((F)\)。

### M-05 — “\(q>1\) metric regularity 退化”与全文的 arbitrary metric-space scope 不相容

**位置**：`a_regularity.md` §0、§3.2、§10；`a_relation_audit.md` §8 的对应概述。

**反例**：在一般度量空间中结论不成立。取

\[
X=(\mathbb R,|\cdot|),\qquad
Y=(\mathbb R,|\cdot|^{1/q}),\qquad q>1,
\]

并令 \(F:X\to Y\) 为恒等映射，则

\[
d_X(x,F^{-1}(y))=|x-y|
=d_Y(y,F(x))^q.
\]

故 \(F\) 是非局部常值的 exact \(q\)-MR 映射。退化结论依赖输出空间的线性/路径几何以及对 inverse Hölder map 的 chaining argument，不能在 arbitrary metric spaces 下无条件陈述。

**可直接补丁句**：

> 对 \(q>1\) 的 MR 退化结论只在具有适当线段/路径结构的 normed-space setting 下使用：inverse 的 pairwise \(q\)-Hölder estimate 沿线段细分后迫使 localization 局部常值。任意 metric spaces 中该结论为假；snowflake metric 给出反例。

### M-06 — Luke–Tam 原定理的 Euclidean scope 在默认 Hilbert atlas 中未持续保留

**位置**：`a_monotonicity.md` §2.3(a)、§7.1、关系矩阵；对照 `a_terminology_sources.md` §2.5、§8.1 与 `a_rl_position.md` §2.2。

**问题**：Luke–Tam 2025 的定义、restricted operator、maximality与算法命题在 finite-dimensional Euclidean setting。内积展开

\[
\text{LT}_\tau\iff \operatorname{Lip}R\le\sqrt{1+4\tau}
\]

可作为 Hilbert 空间中的透明代数延伸，但这不自动延伸其 published maximal-extension、outer-semicontinuity 或 PPA theorem。当前 `a_monotonicity.md` 的默认 Hilbert scope 容易使读者误以为全部均为原文 Hilbert 定理。

**可直接补丁句**：

> Luke–Tam 原文设置为有限维 Euclidean 空间。本文在任意实 Hilbert 空间使用的仅是同一图不等式及 Cayley 恒等式的代数延伸；其 maximality、restricted-resolvent existence 和算法结论仍按原文有限维假设引用。

### M-07 — directional regularity 条目仍是 schematic，不能承载 iff/implication 边

**位置**：`a_regularity.md` §5.1。

**问题**：`(DMR-gph)` 中“测试点距图不超过 \(O(t)\)”没有给出常数、集合、锥邻域和量词；output-residual 版本也只打印一个 cone membership。此时 (5.1)–(5.2) 的 “iff in zero direction” 无法从该文件中的定义机械核查，且非切向 vacuity 的边界取决于精确 convention。

**可直接补丁句**：

> 本段公式目前仅为 schematic，不作为 atlas 定义或关系边。合并前须逐字补入 S3 Definition 7 / S10 的方向锥、\(t\)、扰动方向、distance-to-graph cutoff 与所有邻域量词；随后分别在各自 convention 下陈述 (5.1)–(5.2)。

### M-08 — hypomonotone \(\Rightarrow_s\) Luke–Tam strictness 的 witness 尚未达到可复核标准

**位置**：`a_monotonicity.md` §2.3(a)、§8、§9 的 `M-07`；`a_rl_position.md` `RL-G5`。

**问题**：`F(x)=-\sqrt x` 只写“指定小区间”“某个 \(\tau\)”；没有给 restricted graph、区间、\(\tau\) 或证明。`a_rl_position.md` 自己又把这些数据列为 B/C 待抄清。因而它目前不能支撑关系矩阵中的 strict arrow；最多支撑文献指向。

**可直接补丁句**：

> 在从 Luke–Tam Example 2 抄清相同 restricted graph 上的区间、有限 \(\tau\) 及“无任何有限 hypomonotonicity 常数”的证明前，将该边写为 `hypomonotone ⇒ LT-submonotone`；strictness 标 `PENDING_EXPLICIT_WITNESS`。完成数据核对后再恢复 \(\Rightarrow_s\)。

### M-09 — PPA-04 的 evidence depth 不足以让精细 theorem 量词进入 `V2`

**位置**：`a_algorithm_evidence.md` PPA-04 与 bibliography item 3。

**问题**：唯一给出的 locator 是 publisher abstract page，但条目承载 Theorems 3.1/4.2 的精确阈值 \(1/(2\operatorname{reg}T)\)、存在选择序列、tail/invariance 和 superlinear 分支。文件又注明出版社 PDF 在当前环境不可全文解析。若没有另存的 theorem text/page image，这属于“摘要/元数据 locator 支撑全文命题”的可追溯性缺口；至少不符合本文件对 `V2` 的自定义要求。

**可直接补丁句**：

> PPA-04 暂降为 `V1/PENDING_SOURCE_CAPTURE`。恢复 `V2` 前应提供可复核的 primary theorem statement（PDF 页码或稳定全文 locator），逐项核对 Theorems 3.1 与 4.2 的阈值、existence-vs-all-selections 量词及 neighborhood hypotheses。

## MINOR

### m-01 — LaTeX / typography corruption

本地七文件均通过 UTF-8 解码；未发现 NUL、C0 control character、DEL、BOM 或 replacement character。发现以下可直接修复的渲染问题：

1. `a_rl_position.md` (AFNE identity) 两处
   `+|(I-J)x-(I-J)y\|^2` 应为
   `+\|(I-J)x-(I-J)y\|^2`。
2. `a_rl_position.md` §5.1：
   `d(u,S)\le\rho,d(0,F(u))^q` 应为
   `d(u,S)\le\rho\,d(0,F(u))^q`。
3. `root_math_audit.md` 有系统性的 plain-parenthesis math corruption，例如 `(H)`、`(L=1)`、`(t\downarrow0)`、`(p,q\)`、`(F(x)\asymp...)`、`(q_*=1/\alpha)`。应统一改为 `\(...\)`；其中 `(p,q\)` 还含不匹配的反斜线/括号。

### m-02 — bibliographic year 与名称

Otero–Iusem 在 `a_monotonicity.md` 写 2010、在 `a_terminology_sources.md` 标 2011。建议统一写“2010 report / 2011 publication”，避免误认为两篇文献。

### m-03 — symbol collision

`a_rl_position.md` §2.1 临时设 \(q=\rho/\lambda\)，随后 §5 又用 \(q\) 表 regularity exponent。数学上未错，但极易污染 \(\gamma q\) 讨论。建议在 semimonotonicity 计算中改成 \(m=\lambda\mu,s=\rho/\lambda\)，与 `a_monotonicity.md` (2.4) 一致。

### m-04 — “localization modulus equals reg”应写成 exact-infimum 语言

`a_relation_audit.md` §7 的“localization 的 Lipschitz modulus 等于 \(\operatorname{reg}F\)”容易被理解为某个固定 neighborhood 上最小值必然达到。更安全的句子是：

> 取所有充分小 inverse localizations 的局部 Lipschitz constants 的下确界，得到 \(\operatorname{reg}F(\bar x\mid\bar y)\)；对每个 \(\ell>\operatorname{reg}F\) 可缩小邻域取得 \(\ell\)-Lipschitz localization。

### m-05 — metric-space scope 的引用应补 Ioffe

`a_regularity.md` §1.1 以 S1 支撑 “metric spaces” 三联等价，但 S1 的 preliminaries 明确采用 Banach spaces。关系审计已经列出 Ioffe 的 metric-space source；总 atlas 应把该引用并入此句，或把仅由 S1 承载的版本限于 Banach spaces。

## PASS

以下高风险项目已独立复算/交叉核对通过，可保留：

1. **Minty/Cayley 字典**：\(d=a+\lambda b\)、\(r=a-\lambda b\)、\(4\lambda\langle a,b\rangle=\|d\|^2-\|r\|^2\)；RL 确实强迫 resolvent 在自身 range 上单值，但不推出 full domain。
2. **RL \(\gamma=1\) tied curve**：
   \[
   \mu_L=\frac{1-L^2}{2\lambda(1+L^2)},\qquad
   \rho_L=\lambda^2\mu_L,
   \]
   以及缩放算子 \(\lambda F\) 的 equal-parameter semimonotonicity重写均正确。
3. **RL inverse/scaling**：
   \[
   F\in RL(\lambda,L,\gamma)
   \iff F^{-1}\in RL(\lambda^{-1},L\lambda^{\gamma-1},\gamma),
   \]
   且 \(F\mapsto cF\) 对应 \(\lambda\mapsto\lambda/c\)。
4. **一般 \((\mu,\rho)\)-semimonotone 到 RL 的 class bound**：令 \(p=\lambda\mu,s=\rho/\lambda\)，在 \(1+p+s>0\)、\(ps<1/4\) 下，
   \[
   L_{\mu,\rho}(\lambda)
   =\frac{|p-s|+\sqrt{1-4ps}}{1+p+s}
   \]
   的二次方程推导正确；tied case 精确退化为 \(L\)。
5. **强单调 / resolvent 关系**：strong monotonicity只推出 scaled-FNE 和 \(J\) contraction；单纯 \(J\) contraction 不反推 strong monotonicity。九十度旋转 witness 正确。
6. **comonotonicity / conical averagedness 参数**：\(\alpha=\lambda/[2(\lambda+\rho)]\) 与 reflected inequality 的 \(\rho/\lambda\) scaling 正确；\(R=2I\) 的 Cayley pullback确为 \(F(u)=-u/(3\lambda)\)，且 \(J=3I/2\) 不 conically averaged。
7. **core regularity witnesses**：\(F=|x|\)、\(F(x_1,x_2)=x_1\)、\(F(x)=\{x,-x\}\)、\(F\equiv0\) 分别正确填充 MR/SMSR/SMR 的 strict 与 incomparability 区域；\(F=\{x,0\}\) 也正确见证 MSR+HREG 不推出 MR。
8. **sharp exponent witness**：\(F_p(x)=\operatorname{sgn}(x)|x|^p\) 的最大 residual exponent 为 \(q_*=1/p\)，等号 modulus 为 1，较小 exponent 的 exact local upper modulus可为 0。
9. **finite-dimensional coderivative/derivative 边界**：MR 的 limiting-coderivative kernel iff、SMSR 的 graphical-derivative kernel iff，以及 \(F(x)=\{x,-x\}\) 和离散图的 coderivative non-sharpness均与所引 primary theorem 一致；只需按 M-04 修正 Asplund inverse orientation。
10. **编码检查**：七个输入文件均为有效 UTF-8，未检出非法 control chars；现存问题属于手工 LaTeX 标记损坏，而不是底层编码损坏。

## 审计结论（仅就一致性）

- `BLOCKER`: 1
- `MAJOR`: 9
- `MINOR`: 5
- 已复算通过的高风险项目：10 组

在合并 atlas 前，至少必须处理 B-01、M-01、M-02、M-03、M-04、M-05；否则算法 evidence、历史节点、空间范围或 RL contraction threshold 会被错误传播。

## SCI-Skills expert return contract

```yaml
contract_version: "1.0"
expert_skill: sci-skills-literature-search
project_id: null
paper_family: null
stage_id: null
task_id: null
task_status: COMPLETE
inputs_reviewed:
  - work/a_monotonicity.md
  - work/a_regularity.md
  - work/a_rl_position.md
  - work/a_relation_audit.md
  - work/a_terminology_sources.md
  - work/a_algorithm_evidence.md
  - work/root_math_audit.md
outputs:
  - work/a_consistency_audit.md
evidence_status:
  - VERIFIED_USER_MATERIAL: seven local research files inspected
  - VERIFIED_SOURCE: targeted primary-source checks for Li--Mordukhovich, Cibulka--Dontchev--Kruger, Durea--Strugariu, Mordukhovich--Nguyen
  - EXECUTED_LOCAL: UTF-8/control-character and formula-pattern scans
  - AI_INFERENCE: algebraic recomputations and counterexamples explicitly identified above
assumptions:
  - The audit does not certify literature-search completeness or novelty.
author_input_needed: []
manual_actions: []
quality_checks:
  - definition/convention cross-file comparison
  - local/global and anchored/all-pairs quantifier audit
  - finite/infinite-dimensional scope audit
  - inverse/resolvent scaling recomputation
  - strict-witness region check
  - citation-depth spot check
  - UTF-8/control/LaTeX scan
conflicts:
  - conflict_id: C-PPA-03-Omega
    conflict_type: primary theorem statement versus proof
    claim: lambda_k=O(k^s) yields the displayed accelerated PPA rates
    competing_values_or_interpretations:
      - printed statement uses O(k^s)
      - proof requires an eventual lower bound Omega(k^s)
    recommended_resolution: downgrade pending erratum or restate under an independently justified Omega/Theta assumption
  - conflict_id: C-SPINGARN-NAMING
    conflict_type: definition/convention collision
    claim: the two-point liminf formula is bare Spingarn submonotonicity
    competing_values_or_interpretations:
      - 1981 pointwise anchored submonotone
      - 1981 two-point strictly submonotone
      - unresolved 1981/82 PPA mapping convention
    recommended_resolution: split nodes and mark the 1981/82 convention pending full-text verification
conflict_resolution_status: UNRESOLVED
merge_permission: orchestrator_only
recommended_next_action: repair B-01 and the five mandatory MAJOR items before merging theory_atlas.md
stage_acceptance_recommendation: REPAIR
```

