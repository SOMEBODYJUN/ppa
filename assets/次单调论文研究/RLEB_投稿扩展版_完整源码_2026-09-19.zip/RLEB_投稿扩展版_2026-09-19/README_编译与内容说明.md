# RLEB 论文源码

题目：*Nonlinear Generalized Monotonicity and Error Bounds for Proximal Point Convergence at Multivalued Graph Junctions*

作者：菠萝

## 文件结构

- `main.tex`：论文入口与排版设置。
- `sections/frontmatter.tex`：题目、摘要、引言和贡献概述。
- `sections/theorem_spine.tex`：RL 图几何、一般 gauge 误差界、直接收敛定理、能量证书、幂律与线性特例。
- `sections/extensions_moduli_structure.tex`：一般 RL 模、Dini 有限长度门槛、对数二值接缝、连续极限回缩、Hadamard/双曲转移、四元数实化和随机不变域推论。
- `sections/native_schur_verifier.tex`：完整双侧接缝的 signed-Schur 导数判别器及 matched-jet 精化。
- `sections/verification_example.tex`：残差判别、平方根多值接缝、最佳指数、精确轨道和理论分离。
- `sections/related_work.tex`：与 semimonotonicity、Luke--Tam、Luke--Thao--Tam、Leventhal、逆正则性及广义次正则性的比较。
- `sections/conclusion.tex`：结论和后续数学问题。
- `sections/appendix_signed_schur.tex`：signed-Schur 判别器的完整假设、证明和边界反例。
- `references.bib`：参考文献。
- `投稿前审计与剩余问题.md`：数学复核、文献定位和仍待处理的投稿风险。

## 数学主线

正文恢复了最直接的证明顺序：

1. all-pairs RL 给出能量不等式和步长上界；
2. PPA 包含式把步长转化为输出残差；
3. 一般 gauge 误差界把输出残差转化为下一步到解集的距离；
4. 标量兼容条件给出距离收缩；
5. 步长上界给出有限长度、局部化和整轨道点收敛。

新增的一般模版本把 $Lr^\gamma$ 替换为 $\omega(r)$。距离收缩仍由同一标量复合给出，但点收敛需要几何采样级数
$\sum_k\omega(\kappa^k r)$ 可和；对非减模这等价于局部 Dini 条件。对数二值接缝给出该门槛两侧的完整显式轨道。

能量证书作为补充结果单列。临界残差增长阶 (a=\gamma) 时，直接证书的阈值是
\(\lambda m>L/2\)，能量证书的阈值是 \(\lambda m>L/\sqrt2\)。

## 标准编译

在完整 TeX Live 环境中运行：

```bash
xelatex main.tex
bibtex main
xelatex main.tex
xelatex main.tex
```

作者名由 `figures/author_u83e0.pdf` 和 `figures/author_u841d.pdf` 两个矢量字形组成，因此不依赖 CJK 字体。

最终检查稿为 30 页。已完成 BibTeX 重建、交叉引用检查、溢出检查和逐页渲染检查。

## 本轮清洗原则

- 保留公式、量词、假设和结论范围；不通过语言润色强化 claim。
- 删除重复的贡献声明、模板化转折和过量的防御性措辞。
- 区分 RL 单射性、Minty 输入覆盖和残差误差界。
- 将文献已有机制表述为输入接口，将本文定理的实际新增部分限定在可证明范围内。
- 编译后检查交叉引用、文献引用、溢出版面和逐页渲染。
