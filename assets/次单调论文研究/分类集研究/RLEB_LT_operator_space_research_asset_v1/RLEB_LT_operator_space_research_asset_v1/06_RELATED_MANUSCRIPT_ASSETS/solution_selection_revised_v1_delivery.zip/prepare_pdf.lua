-- Rendering only: keep the Markdown manuscript as the authoritative source.
-- Remove its top title (the template prints it), promote remaining headings,
-- and normalize typographic dashes without altering formulas.
local removed_title = false
function Header(h)
  if h.level == 1 and not removed_title then
    removed_title = true
    return {}
  end
  h.level = math.max(1, h.level - 1)
  if pandoc.utils.stringify(h.content):match('^8%.') then
    return {h, pandoc.RawBlock('latex', '\\small')}
  end
  return h
end
function Str(s)
  s.text = s.text:gsub('–', '-'):gsub('—', '-'):gsub('‑', '-')
  return s
end
