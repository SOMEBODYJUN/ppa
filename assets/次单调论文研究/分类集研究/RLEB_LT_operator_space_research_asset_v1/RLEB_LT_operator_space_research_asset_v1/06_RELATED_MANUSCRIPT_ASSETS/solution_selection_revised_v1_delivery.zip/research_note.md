# RLEB-PPA 中解选择映射的最优稳定性

**审计后修订研究稿 v1｜2026-09-19**

起点：用户提供的论文 *Nonlinear Generalized Monotonicity and Error Bounds for Proximal Point Convergence at Multivalued Graph Junctions* 的完整 TeX 源码，特别是正文 RL 条件、一步估计、局部收敛定理及平方根接缝例子。

**摘要。** 在已建立的局部 RLEB 框架上，本文研究算法初值到极限解的映射。借助经典有限步比较与一致尾界的截断思路，对仅局部 Hölder 的单步映射导出显式几何及超几何极限模，并给出匹配下界：几何情形在固定实际参数 $(\gamma,q)$ 下达到 $(\log\log/\log)^\beta$ 量级，超几何情形的 stretched-log 指数 $\alpha$ 不能提高。实现使用完整单值 resolvent 的闭图至多二值算子；有理幂指数时为半代数，并满足整个多值算子的最小残差误差界与严格 RLEB 兼容。一个显式模型使敏感参考轨道自身仍 Q-二次收敛，而极限选择在原点任意完整邻域上没有正阶两点 Hölder 模，且不是半代数映射。

**状态与范围。** 本稿以 2026-09-18 研究推导稿为基础，落实数学与优先权审计的接口及表述修订；原 RLEB 论文仅作为已建立的接口，不在此重审其无关部分。相对该原稿，新增对象是初值到最终解的映射；这一对象、截断方法、一般 resolvent 逆图编码，以及快速半代数迭代的坏极限现象均有先例，见 §6。本文不把数值测试当作证明，也不宣称全球首次。精确联合结果目前仅有列明范围内的 `NO-EXACT-PRIOR-FOUND` 结论；未取得的原页与版本差异仍明确保留。

## 0. 结果概览和精确边界

一般部分记 $T=J_{\mathcal G}$，其中 $\mathcal G\subset\operatorname{gph}F$ 是原 RLEB 的局部图块，

$$J_{\mathcal G}(x)=\{u:(u,(x-u)/\lambda)\in\mathcal G\},\qquad
\Pi(x)=\lim_{k\to\infty}T^k x.$$

原局部条件只保证图块内 resolvent 在工作域上单值。只有在 §1 由长度预算预先确定的共同轨道区 $W$ 上另有 $J_{\lambda F}=J_{\mathcal G}$，一般推论才适用于完整 PPA。§2-§4 的显式模型均直接反演全部纤维，其 $T$ 确实是全空间上的完整 $J_F$（$\lambda=1$），不是选择一个分支。这里的 proximal 一律指算子 inclusion $x-u\in\lambda F(u)$；不主张已实现某势函数的 $\operatorname{prox}_f$。

本稿证明：

1. 在原稿的 all-pairs Hölder RL 与统一几何距离收敛下，$\Pi$ 有统一的对数型连续模
   $$\|\Pi(x)-\Pi(y)\|\le C\left(\frac{\log\log(1/\delta)}{\log(1/\delta)}\right)^\beta,
   \qquad \beta=\frac{\gamma\log(1/q)}{\log(1/\gamma)},\quad\delta=\|x-y\|\downarrow0.$$
2. 对每一对固定实数 $0<\gamma,q<1$，存在满足原稿严格 RLEB 兼容条件的闭图至多二值算子，具有精确距离因子 $q$，并达到这个连续模的量级；有理 $\gamma$ 时该实现半代数。因而在原点任意完整邻域上，一般不能推出任何正阶的两点 Hölder 初值稳定性。
3. 若统一距离递推是 $d_{k+1}\le Kd_k^\nu$，$\nu>1$，则连续模改进为
   $$C\exp\{-c[\log(1/\delta)]^\alpha\},\qquad
   \alpha=\frac{\log\nu}{\log(\nu/\gamma)}.$$
   对固定 $(\gamma,\nu)$，指数 $\alpha$ 也不能提高，不涉及指数前最佳常数。一个显式半代数至多二值算子使每条非平凡局部轨道的**点误差**都 Q-二次收敛，包括产生坏稳定性的参考轨道，但其极限解选择在原点任意完整邻域上仍不是任何正阶的两点 Hölder 映射。一般超几何族在 $\gamma,\nu$ 都有理时保证半代数。

这里 $q$ 是已经证明的统一距离因子，可以取原稿的 $\kappa$；若可独立证明更精确的距离因子，则可使用后者。例子中的精确 $q=1/4$ 不等于保守 RLEB 标量证书的极限因子 $\kappa_*=1/2$。几何量级最优性是在给定实际统一 $q$ 与 $\gamma$ 的类别中陈述的，不是在预先固定保守 $\kappa$ 或所有其他常数的类别中陈述。

本稿不声称新例子满足原稿附录的强切向反演假设；例子特意允许另一个切向退化方向。它们满足正文的 all-pairs RL、完整 proximal coverage、输出误差界和严格兼容条件。

## 1. 从有限步正则性向极限映射传递

### 定理 1：统一尾界与 Hölder 迭代的稳定性传递

设 $T$ 的一族轨道都存在并留在同一工作区域 $V$。对某个 $H,R>0$、$0<\gamma<1$，假设

$$\|Tx-Ty\|\le H\|x-y\|^\gamma\quad
(x,y\in V,\ \|x-y\|\le R).\tag{1.1}$$

设初值集合 $B\subset V$ 上每条轨道都收敛，记极限为 $\Pi(x)$。

**(a) 几何尾界。** 若存在 $M>0$、$0<\sigma<1$，使得

$$\|T^k x-\Pi(x)\|\le M\sigma^k\quad(x\in B,k\ge0),\tag{1.2}$$

则存在 $C,\delta_0>0$，使对 $x,y\in B$、$0<\delta=\|x-y\|<\delta_0$，

$$\|\Pi(x)-\Pi(y)\|\le
C\left(\frac{\log\log(1/\delta)}{\log(1/\delta)}\right)^\beta,
\qquad \beta=\frac{\log(1/\sigma)}{\log(1/\gamma)}.\tag{1.3}$$

**(b) 超几何尾界。** 若存在 $M,c_0>0$、$\nu>1$，使得

$$\|T^k x-\Pi(x)\|\le M\exp(-c_0\nu^k)\quad(x\in B,k\ge0),\tag{1.4}$$

则存在 $C,c,\delta_0>0$，使

$$\|\Pi(x)-\Pi(y)\|\le
C\exp\{-c[\log(1/\delta)]^\alpha\},
\qquad\alpha=\frac{\log\nu}{\log(\nu/\gamma)}.\tag{1.5}$$

#### 证明

取 $A\ge\max\{1,H^{1/(1-\gamma)}\}$，令 $t=\log(1/\delta)$。只要迭代比较始终处于距离 $R$ 内，由归纳

$$\|T^j x-T^j y\|\le A\delta^{\gamma^j}=Ae^{-t\gamma^j}.\tag{1.6}$$

(a) 记 $a=\log(1/\sigma)$、$b=\log(1/\gamma)$、$\beta=a/b$，取 $D=\beta+1$，并令

$$n=\left\lfloor\frac{\log[t/(D\log t)]}{b}\right\rfloor.$$

当 $t$ 足够大时 $n\ge0$，且

$$t\gamma^n\ge D\log t,\qquad
\sigma^n\le e^a\left(\frac{D\log t}{t}\right)^\beta.$$

对 $0\le j\le n$，式 (1.6) 的候选上界不超过 $At^{-D}$。当 $t$ 足够大时它小于 $R$，所以可由归纳闭合局部适用性，而不是未经检查地使用局部 Hölder 估计。于是

$$\|\Pi(x)-\Pi(y)\|
\le Ae^{-t\gamma^n}+2M\sigma^n
\le At^{-D}+2Me^aD^\beta(\log t/t)^\beta.$$

这给出 (1.3)。

(b) 取

$$n=\left\lfloor\frac{\log t}{\log(\nu/\gamma)}\right\rfloor.$$

则存在只依赖 $\gamma,\nu$ 的正数 $c_1,c_2$，使

$$t\gamma^n\ge c_1t^\alpha,\qquad\nu^n\ge c_2t^\alpha.$$

式 (1.6) 的候选上界在 $j\le n$ 时统一趋于零，同样可以闭合距离 $R$ 的局部限制。故

$$\|\Pi(x)-\Pi(y)\|
\le Ae^{-t\gamma^n}+2Me^{-c_0\nu^n}
\le Ce^{-ct^\alpha}.$$

证毕。

### 推论 1：原稿局部 RLEB 接口与完整 PPA 的条件版本

令 $S=\operatorname{zer}F$，$r_F(u)=\inf\{\|u^*\|:u^*\in F(u)\}$（空集的下确界为 $+\infty$），$U_R=\{x\in U:d(x,S)\le R\}$。假设原稿局部定理的 A1-A4、gauge 定义域及严格兼容条件成立，参数为 $0<\gamma<1$、$L\ge0$、$0<\kappa<1$。这里只调用其以下结论：$J_{\mathcal G}$ 在 $U_R$ 单值；all-pairs RL 与解点比较成立；距离每步缩小至多 $\kappa$；严格长度预算保证留在图块。令 $T=J_{\mathcal G}$。

原稿的 all-pairs RL 等价于

$$\|2(Tx-Ty)-(x-y)\|\le L\|x-y\|^\gamma.$$

因此在 $\delta\le R$ 时，

$$\|Tx-Ty\|\le\tfrac12(\delta+L\delta^\gamma)
\le H\delta^\gamma,\quad H=\tfrac12(R^{1-\gamma}+L).\tag{1.7}$$

同一个常数控制步长：$\|Tx-x\|\le H d(x,S)^\gamma$。若统一有

$$d(T^k x,S)\le q^kD,$$

则

$$\|T^k x-\Pi(x)\|\le\frac{HD^\gamma}{1-q^\gamma}q^{\gamma k}.\tag{1.8}$$

在定理 1(a) 中取 $\sigma=q^\gamma$ 即得概览中的 $\beta$。

具体地，原稿的严格局部化预算为

$$\mathcal L(d)=\frac12\left(\frac d{1-\kappa}
+\frac{Ld^\gamma}{1-\kappa^\gamma}\right).\tag{1.9}$$

固定 $\bar x\in S\cap U$，取 $\rho>0$ 使 $B_\rho(\bar x)\subset U$，再选 $0<\varepsilon\le R$ 使 $\varepsilon+\mathcal L(\varepsilon)<\rho$。预先定义共同轨道输入区

$$W=U_R\cap\overline B_{\varepsilon+\mathcal L(\varepsilon)}(\bar x).\tag{1.10}$$

对每个 $x\in B_\varepsilon(\bar x)$，有 $d(x,S)\le\varepsilon$，且

$$\operatorname{dist}(x,U^c)>\rho-\varepsilon>
\mathcal L(\varepsilon)\ge\mathcal L(d(x,S)).$$

原局部定理因而同时适用于整球；部分轨道长度界及距离收缩保证所有迭代点在 $W$ 中。在 (1.8) 中取 $D=\varepsilon,q=\kappa$，得到整球共同点尾

$$\|T^kx-\Pi(x)\|\le
\frac{H\varepsilon^\gamma}{1-\kappa^\gamma}\kappa^{\gamma k}
\quad(x\in B_\varepsilon(\bar x),\ k\ge0).\tag{1.11}$$

这证明了共同区域和统一尾常数，不是另行假定未知共同吸引域。若另证整球统一的实际距离界 $d(T^kx,S)\le Dq^k$，则使用 (1.8) 的较精确参数；逐初值的常数不能代替该统一常数。

若要将本推论称为完整 PPA 的结论，须另核查

$$J_{\lambda F}(x)=J_{\mathcal G}(x)\qquad(x\in W).\tag{1.12}$$

等式保证完整轨道逐步等于局部轨道。仅在初值球上核查不够，因为切向漂移可能离开初值球。接口必要性可由最小反例看出：$F(u)=\{u,-u\}$、$\mathcal G=\{(u,u):u\in\mathbb R\}$、$\lambda=1$ 时，局部条件可取 $U=\mathbb R,R=1,\gamma=1/2,L=0,\psi(t)=t,\kappa=1/2$，但

$$J_{\mathcal G}(x)=x/2,\qquad
J_F(x)=\begin{cases}\{x/2\},&x\ne0,\\\mathbb R,&x=0.\end{cases}$$

两个显式模型及参数族已直接证明完整反演，不受此接口区别影响。

若整球上有 $d_{k+1}\le Kd_k^\nu$、$K>0,\nu>1$，令 $z_k=K^{1/(\nu-1)}d_k$，并将初值球缩小到 $z_0\le\vartheta<1$，则 $z_k\le\vartheta^{\nu^k}$。置 $C_K=K^{-1/(\nu-1)}$、$a=-\gamma\log\vartheta>0$。结合步长界和 $\nu^{k+j}\ge\nu^k+j(\nu-1)$，得到共同尾

$$\|T^kx-\Pi(x)\|\le
\frac{H C_K^\gamma}{1-e^{-a(\nu-1)}}e^{-a\nu^k}.\tag{1.13}$$

若 $K=0$，则一步到解并随后驻定，是另行处理的退化情形。

特别地，原稿 residual growth 接口 $r_F(u)\ge m d(u,S)^a$，其中 $m>0$、$0<a<\gamma<1$，给出 $\nu=\gamma/a>1$，故

$$\alpha=\frac{\log(\gamma/a)}{\log(1/a)}.$$

### 锚定连续性与两点连续性不同

固定 $s\in S\cap U$，按 (1.9)-(1.11) 以 $s$ 为中心选取共同初值球 $B_\varepsilon(s)$ 及预算工作区 $W_s$。则 $\Pi(s)=s$。以下比较的 $x$ 限于该初值球，全部比较轨道留在 $W_s$ 内；由轨道尾界在初始步的估计，

$$\|\Pi(x)-s\|\le\|x-s\|+C d(x,S)^\gamma
\le C'\|x-s\|^\gamma.$$

这是固定解点处的局部 Hölder calmness。§2-§4 的显式模型具有完整全空间 resolvent，在其已证收敛域内直接使用这一结论，不另受一般图块 $U$ 的限制。calmness 不推出某个完整邻域上对任意两点的 Hölder 连续性；下文反例正是在距离解集任意近的非解点处破坏后者。

## 2. 原 RLEB 框架内的新增显式半代数反例

原稿二维平方根接缝是本节基础；新增的 cap 切向坐标产生解选择的劣化。完整 resolvent 的一般逆图编码本身是标准事实 [BMW]，这里需另外验证全部分支的常数、最小残差和严格兼容。

对 $y\ge0$，定义

$$D_y(\eta)=\min\left\{2\sqrt y,\frac{\sqrt{1+4\eta_+}-1}{2}\right\},
\qquad\eta_+=\max\{\eta,0\}.$$

定义 $F:\mathbb R^3\rightrightarrows\mathbb R^3$：

$$F(\xi,\eta,y)=
\begin{cases}
\{(-2\sqrt y,-D_y(\eta),3y),\ (-2\sqrt y,-D_y(\eta),-5y)\},&y\ge0,\\
\varnothing,&y<0.
\end{cases}\tag{2.1}$$

### 定理 2：完整 proximal 公式、RL、误差界和精确速率

算子 (2.1) 的图闭且半代数，在 $y>0$ 时恰有两个值，在 $y=0$ 时仅一个值，在 $y<0$ 时为空；零集为

$$S=\mathbb R^2\times\{0\}.$$

其完整单位参数 proximal 映射全局单值且为

$$T(z,p,r)=\left(z+\sqrt{|r|},\ p+\sqrt{\min\{p_+,|r|\}},\ \frac{|r|}{4}\right).\tag{2.2}$$

对任意尺度 $R>0$，完整图满足 $\mathrm{RL}(1,1/2,L_R)$，其中

$$L_R=2\sqrt2+\tfrac32\sqrt R.\tag{2.3}$$

$1/2$ 是原点附近最大 RL 指数，且 $\lim_{R\downarrow0}L_R=2\sqrt2$ 是最优渐近常数。全局输出误差界为

$$d(u,S)\le\tfrac14r_F(u)^2.\tag{2.4}$$

原稿直接兼容因子可以取

$$\kappa_R=\frac{(\sqrt R+L_R)^2}{16}
=\frac{(2\sqrt2+\frac52\sqrt R)^2}{16}\longrightarrow\frac12<1.\tag{2.5}$$

严格兼容恰要求

$$0<R<\left[\frac{2(4-2\sqrt2)}5\right]^2.\tag{2.5a}$$

任意尺度成立的是 RL 和合成上界，而不是 $\kappa_R<1$。例如 $R=0.01$ 时 $\kappa_R\approx0.5922946$。实际距离因子则是精确的 $q=1/4$。有限 $R>0$ 时 $\kappa_R>1/2$，且

$$\beta_{\rm actual}=1,\qquad
\beta_{\rm cert}(R)=\frac{\log(1/\kappa_R)}{2\log2}\longrightarrow\frac12.$$

本文不把实际速率的下界当成固定保守证书类别的锐性证明；也不声称 (2.3) 是每个有限 $R$ 下最小的 RL 常数。

#### 完整 proximal 公式的证明

给定 proximal 输入 $(z,p,r)$，正、负分支的第三坐标方程分别是 $r=4y$ 和 $r=-4y$，因此 $y=|r|/4$，且 $r\ne0$ 时恰好一个分支允许。第一坐标给出 $\xi=z+\sqrt{|r|}$。

令 $a=|r|$。第二坐标方程是 $p=\eta-D_{a/4}(\eta)$。该函数连续、严格递增且满射，其分段表达是

- $\eta\le0$：$p=\eta$；
- $0\le\eta\le a+\sqrt a$：令 $v=(\sqrt{1+4\eta}-1)/2$，则 $\eta=v^2+v$，$p=v^2$；
- $\eta\ge a+\sqrt a$：$p=\eta-\sqrt a$。

所以唯一的逆是 $\eta=p+\sqrt{\min\{p_+,a\}}$。在 $r=0$ 时两分支合并为同一零图点。没有遗漏任何 proximal fiber。

闭图性来自两支在闭半空间上的连续性；半代数性也由显式有限运算与非负平方根给出。第一分量非零当且仅当 $y>0$，故零集如上。

#### all-pairs RL 的证明

令 $x=(z,p,r)$、$x'=(z',p',r')$、$\delta=\|x-x'\|$，并记

$$h_1=\sqrt{|r|}-\sqrt{|r'|},\qquad
h_2=\sqrt{\min\{p_+,|r|\}}-\sqrt{\min\{p'_+,|r'|\}}.$$

因为 $\min$ 对无穷范数是 1-Lipschitz，正部与绝对值也是 1-Lipschitz，故 $|h_1|,|h_2|\le\sqrt\delta$。写 $\mathcal R=2T-I$，有

$$\mathcal R x-\mathcal R x'
=(\Delta z,\Delta p,\tfrac12\Delta|r|-\Delta r)+2(h_1,h_2,0).$$

第一个向量范数不超过 $\tfrac32\delta$，第二个不超过 $2\sqrt2\sqrt\delta$。因此

$$\|\mathcal R x-\mathcal R x'\|
\le\tfrac32\delta+2\sqrt2\sqrt\delta
\le L_R\sqrt\delta\quad(\delta\le R).$$

这包含异号 $r,r'$ 的跨分支比较。等价关系立即给出原稿内积形式的 RL。

为验证最优指数与渐近常数，取 $x_t=(0,t,t)$、$x_t'=(0,t,0)$。此时

$$\|x_t-x_t'\|=t,\qquad
\|\mathcal R x_t-\mathcal R x_t'\|^2=8t+t^2/4.$$

所以任何指数大于 $1/2$ 的局部 RL 都失败，且在指数 $1/2$ 时渐近常数至少 $2\sqrt2$。

#### 输出误差界和兼容性的证明

整个多值算子的两支范数平方分别为 $4y+D_y(\eta)^2+9y^2$ 与 $4y+D_y(\eta)^2+25y^2$。因此真正的最小残差为

$$r_F(\xi,\eta,y)^2=4y+D_y(\eta)^2+9y^2\ge4y.$$

负 proximal 输入选中的是较大残差支，不改变上述取最小值的 EB。这证明 (2.4)。在 $\eta\le0$、$y\downarrow0$ 时比值 $y/r_F^2\to1/4$，故系数渐近最优。代入原稿的 $\psi(t)=t^2/4$ 及步长界得到 (2.5)。取满足 (2.5a) 的固定 $R$、$\mathcal G=\operatorname{gph}F$、$U=\mathbb R^3$，并取 $\bar t\ge(R+L_R\sqrt R)/2$，则完整纤维覆盖、零点比较、gauge 定义域及严格兼容同时成立，且局部化预算不存在出界障碍。

#### 精确法向速率与统一尾界

对初值 $(z_0,p_0,r_0)$，令 $a_0=|r_0|$。则

$$a_k=4^{-k}a_0,\qquad
z_k=z_0+2\sqrt{a_0}(1-2^{-k}),$$

且 $p_k$ 单调不减，每步增量位于 $[0,\sqrt{a_k}]$。于是 $p_k$ 收敛，并且在 $k\ge1$ 时

$$\|T^k x-\Pi(x)\|\le2\sqrt2\sqrt{a_0}\,2^{-k}+a_0\,4^{-k}.\tag{2.6}$$

对 $r_0\ge0$，(2.6) 从 $k=0$ 起成立；对 $r_0<0$，初始点的总长度可用 $2\sqrt2\sqrt{a_0}+\tfrac32a_0$ 控制。证明是把切向增量范数界 $\sqrt2\sqrt{a_k}$ 求和，再把单调法向变化求和。

## 3. 初值到极限解的精确劣化

固定任意 $0<r_0<1$，比较

$$x_0=(0,0,r_0),\qquad x_\varepsilon=(0,\varepsilon,r_0),\quad\varepsilon>0.$$

两条轨道的第一、第三坐标完全相同。第一条轨道第二坐标恒为零；第二条满足

$$p_{k+1}=p_k+\sqrt{\min\{p_k,r_k\}},\quad
p_0=\varepsilon,\quad r_k=4^{-k}r_0.\tag{3.1}$$

### 定理 3：最优的对数–对数连续模

存在依赖 $r_0$ 的 $c,C,\varepsilon_0>0$，使

$$c\frac{\log\log(1/\varepsilon)}{\log(1/\varepsilon)}
\le\|\Pi(x_\varepsilon)-\Pi(x_0)\|
\le C\frac{\log\log(1/\varepsilon)}{\log(1/\varepsilon)}
\quad(0<\varepsilon<\varepsilon_0).\tag{3.2}$$

特别地，对所有 $\theta>0$，

$$\frac{\|\Pi(x_\varepsilon)-\Pi(x_0)\|}{\|x_\varepsilon-x_0\|^\theta}\longrightarrow+\infty.$$

#### 证明：首次切换时刻

令 $t=\log(1/\varepsilon)$，定义

$$N=\min\{k:p_k\ge r_k\}.$$

这个时刻有限：若永不发生，则 $p_k\ge\varepsilon>0$，而 $r_k\to0$，矛盾。并且 $N\to\infty$ 当 $\varepsilon\downarrow0$，由每个有限次迭代对初值的连续性可知。

在 $k<N$ 时，$p_k<r_k\le r_0<1$，因此

$$\sqrt{p_k}\le p_{k+1}\le2\sqrt{p_k}.$$

迭代取对数，得到对所有 $0\le k\le N$ 一致成立的

$$e^{-t2^{-k}}\le p_k\le4e^{-t2^{-k}}.\tag{3.3}$$

注意上界常数不随 $k,N,\varepsilon$ 增长。

由 $p_N\ge r_N$ 及 $p_{N-1}<r_{N-1}$，结合 (3.3)，得到

$$t2^{-N}\le N\log4+O(1),\qquad
t2^{-(N-1)}\ge(N-1)\log4+O(1).$$

因此 $t2^{-N}=\Theta(N)$，继而

$$N=\frac{\log t-\log\log t}{\log2}+O(1),\qquad
2^{-N}=\Theta(\log t/t).\tag{3.4}$$

从 $N$ 起一直处于饱和段，因为 $p_k$ 不减而 $r_k$ 递减。于是有**精确公式**

$$p_\infty=p_N+\sum_{k=N}^\infty\sqrt{r_k}
=p_N+2\sqrt{r_0}\,2^{-N}.\tag{3.5}$$

另外

$$p_N\le r_{N-1}+\sqrt{r_{N-1}}\le C_0\sqrt{r_N}.$$

式 (3.5) 同时给出下界 $p_\infty\ge2\sqrt{r_N}$ 和同阶上界，所以 $p_\infty=\Theta(2^{-N})$。再用 (3.4) 即得 (3.2)。两条轨道的其余极限坐标相同，故极限差的欧氏范数就是 $p_\infty$。

由 $\gamma=1/2,q=1/4$，定理 1 的 $\beta=1$，上、下界完全匹配。尤其不能删除分子中的 $\log\log$，得到统一的 $O(1/\log)$ 界。这里的 $\Theta$ 不主张存在归一化比值极限；离散切换时刻允许有界振荡。

### 任意 $\gamma,q$ 的 RLEB 内部最优性

取 $A,B>0$，定义

$$T(z,p,r)=\left(z+A|r|^\gamma,\ p+B\min\{p_+,|r|\}^\gamma,\ q|r|\right).\tag{3.6}$$

令 $h(s)=s+Bs^\gamma$，并设 $\tau_a$ 是严格递增满射

$$p\mapsto p+B\min\{p_+,a\}^\gamma$$

的逆，即

$$\tau_a(\eta)=
\begin{cases}
\eta,&\eta\le0,\\
h^{-1}(\eta),&0<\eta<h(a),\\
\eta-Ba^\gamma,&\eta\ge h(a).
\end{cases}$$

对 $y\ge0$、$a=y/q$，定义两值

$$F(\xi,\eta,y)=\{(-Aa^\gamma,\tau_a(\eta)-\eta,a-y),
(-Aa^\gamma,\tau_a(\eta)-\eta,-a-y)\},\tag{3.7}$$

并在 $y<0$ 令其为空。它是闭图至多二值算子（$y>0$ 恰二值、$y=0$ 一值、$y<0$ 空），完整 resolvent 就是 (3.6)，零集仍为平面。标量输入映射在三段上连续严格递增，像覆盖 $\mathbb R$，且 $|\tau_a(\eta)-\eta|\le Ba^\gamma$ 保证 $a\downarrow0$ 时连续接合。法向输入为 $r=\pm a$，由其符号和唯一标量逆恢复全部纤维。若 $\gamma$ 为有理数，则它是半代数算子；系数 $q,A,B$ 无须有理。

同样的 all-pairs 估计给出

$$L_R=2\sqrt{A^2+B^2}+(1+2q)R^{1-\gamma},$$

整个算子的最小残差精确为

$$r_F(u)^2=A^2a^{2\gamma}+(\tau_a(\eta)-\eta)^2+(1-q)^2a^2,$$

因此

$$r_F(u)\ge A(y/q)^\gamma,\qquad
\psi(t)=q(t/A)^{1/\gamma}.$$

原稿兼容商的极限是

$$\kappa_*=q\left(1+(B/A)^2\right)^{1/(2\gamma)}.$$

对任何给定 $\gamma,q$，都可选

$$0<B/A<\sqrt{q^{-2\gamma}-1}$$

使 $\kappa_*<1$。更明确地，有限尺度兼容商可用

$$\kappa_R=q\left(\frac{\sqrt{A^2+B^2}+(1+q)R^{1-\gamma}}A\right)^{1/\gamma}$$

控制，再固定

$$R^{1-\gamma}<\frac{Aq^{-\gamma}-\sqrt{A^2+B^2}}{1+q}$$

即可使 $\kappa_R<1$。模型参数和半径先固定，再令敏感初值趋零；因此该族真正位于严格兼容区域内部。由于 $B>0$ 时 $\kappa_*>q$，这不证明固定保守证书 $\kappa=q$ 的更窄类别中也尖锐。

对 $p_0=\varepsilon$ 的首次切换时刻 $N$，取 $t=\log(1/\varepsilon)$。未饱和时

$$\log p_{k+1}=\gamma\log p_k+\log(B+p_k^{1-\gamma}).$$

最后一项在固定有界区间内。具体令

$$C_0=\frac{\max\{|\log B|,|\log(B+r_0^{1-\gamma})|\}}{1-\gamma},$$

则误差不超过 $C_0$，故

$$\log p_k=-\gamma^k t+O(1)\quad(0\le k\le N).\tag{3.8}$$

该估计包含 $k=N$，因为生成 $p_N$ 的前一步仍未饱和。记 $a=\log(1/q)$；在 $N$ 使用 $p_N$ 的上界、在 $N-1$ 使用 $p_{N-1}$ 的下界，得到

$$t\gamma^N\le aN+C_0-\log r_0,\qquad
t\gamma^{N-1}>a(N-1)-C_0-\log r_0.$$

所以 $t\gamma^N=\Theta(N)$，全部常数与 $\varepsilon,N$ 无关，继而

$$N=\frac{\log t-\log\log t}{\log(1/\gamma)}+O(1).$$

饱和后

$$p_\infty=p_N+\frac{B r_N^\gamma}{1-q^\gamma},\qquad
p_N\le r_{N-1}+B r_{N-1}^\gamma=O(r_N^\gamma).$$

从而

$$p_\infty=\Theta(r_N^\gamma)
=\Theta\left((\log t/t)^{\gamma\log(1/q)/\log(1/\gamma)}\right).$$

这证明定理 1(a) 在每个给定实际 $(\gamma,q)$ 的 RLEB 类中的量级最优性。它不预先固定所有有效 RL、EB、尾界常数，也不将实际 $q$ 与证书 $\kappa_R$ 混用。

## 4. Q-二次点收敛仍不能保证 Hölder 解选择

令

$$\widetilde D_y(\eta)=\min\left\{y^{1/4},\frac{\sqrt{1+4\eta_+}-1}{2}\right\},$$

并定义闭图半代数至多二值算子

$$\widetilde F(\xi,\eta,y)=
\begin{cases}
\{(-y^{1/4},-\widetilde D_y(\eta),\sqrt y-y),
(-y^{1/4},-\widetilde D_y(\eta),-\sqrt y-y)\},&y\ge0,\\
\varnothing,&y<0.
\end{cases}\tag{4.1}$$

### 定理 4：二次收敛与根对数指数稳定性

其完整 resolvent 是

$$\widetilde T(z,p,r)=\left(z+\sqrt{|r|},\ p+\sqrt{\min\{p_+,|r|\}},\ r^2\right).\tag{4.2}$$

固定 $0<R_0<1$。在输入 collar $|r|,|r'|\le R_0$ 上，对任意给定有限比较尺度 $D>0$，限于 $\delta=\|x-x'\|\le D$ 的输入对，它满足 $\gamma=1/2$ 的 all-pairs RL，有效常数为

$$L_{R_0,D}=2\sqrt2+(1+4R_0)\sqrt D.$$

全局输出误差界为

$$d(u,S)\le r_{\widetilde F}(u)^4.\tag{4.3}$$

原稿的直接兼容 map 为 $O(d^2)$；下证给出固定 collar、共同覆盖及有限尺度下的统一严格兼容半径。对 $0<|r_0|<1$，每条轨道的点误差 $e_k=\|\widetilde T^k x-\widetilde\Pi(x)\|$ 均具有确切的 Q-二次量级：存在正数 $c,C$，使

$$ce_k^2\le e_{k+1}\le Ce_k^2\quad(k\ \text{充分大}).\tag{4.4}$$

然而对固定 $0<r_0<1$、$x_\varepsilon=(0,\varepsilon,r_0)$、$x_0=(0,0,r_0)$，存在 $c,C>0$，使

$$\exp(-C\sqrt{\log(1/\varepsilon)})
\le\|\widetilde\Pi(x_\varepsilon)-\widetilde\Pi(x_0)\|
\le\exp(-c\sqrt{\log(1/\varepsilon)}).\tag{4.5}$$

所以这个二次点收敛的半代数 PPA，在原点任意完整邻域上仍不具有任何正阶的两点 Hölder 初值到最终解稳定性。完整 resolvent 虽然全空间定义，轨道收敛结论仅用于 $|r_0|<1$；$r_0=0$ 是驻点，不讨论 $0/0$ 的 Q 比值。

#### 证明

第三坐标方程是 $r=\pm\sqrt y$，故 $y=r^2$；第二坐标反演与定理 2 相同，cap 的输入量现在是 $|r|$。这证明完整公式。

在 $|r|\le R_0$ 时，$r\mapsto2r^2-r$ 的 Lipschitz 常数不超过 $1+4R_0$，故对距离不超过 $D$ 的输入对，

$$\| (2\widetilde T-I)x-(2\widetilde T-I)x'\|
\le[2\sqrt2+(1+4R_0)\sqrt D]\sqrt{\|x-x'\|}.$$

两支范数平方分别为

$$\sqrt y+\widetilde D_y(\eta)^2+(\sqrt y-y)^2,
\qquad \sqrt y+\widetilde D_y(\eta)^2+(\sqrt y+y)^2.$$

整个多值算子的最小值为前者，故 $r_{\widetilde F}(u)\ge y^{1/4}$，即 (4.3)；不是用选中残差替代最小残差。取 $\psi(t)=t^4$ 时，原稿直接 map

$$\psi((d+L\sqrt d)/2)=(d+L\sqrt d)^4/16=O(d^2).$$

为将它变成统一的局部证书，取完整图块

$$\mathcal G_{R_0}=\operatorname{gph}\widetilde F\cap\{0\le y\le R_0^2\}.$$

其输入像恰为 $\mathbb R^2\times[-R_0,R_0]$，且该 collar 前向不变。选 $0<R\le R_0$、$U=\mathbb R^3$，则每个 $U_R$ 输入的完整纤维均在图块内。以比较尺度 $D=R$ 和 $L_R=2\sqrt2+(1+4R_0)\sqrt R$，有

$$\sup_{0<d\le R}\frac{\psi((d+L_R\sqrt d)/2)}d
\le\frac{R[2\sqrt2+(2+4R_0)\sqrt R]^4}{16}\longrightarrow0.$$

先取足够小的固定 $R$ 使右端小于 $1$，再取 $\bar t\ge(R+L_R\sqrt R)/2$，即可同时满足完整覆盖、all-pairs 有限比较尺度、gauge 定义域和严格兼容。不存在从 $O(d^2)$ 无量词跳到统一证书的问题。

令 $a_0=|r_0|\in(0,1)$，则从第 1 步起法向坐标为 $r_k=a_0^{2^k}>0$。第一切向坐标的尾部至少为 $\sqrt{r_k}$；两切向增量范数至多为 $\sqrt2\sqrt{r_k}$，且法向变化总和为 $r_k$。用

$$\sum_{j=0}^\infty r_k^{2^j/2}\le
\frac{\sqrt{r_k}}{1-\sqrt{a_0}}$$

可得 $e_k\asymp\sqrt{r_k}$，继而 $e_{k+1}\asymp r_k\asymp e_k^2$。

更精确地，对 $k\ge1$ 令 $b_k=\sqrt{r_k}\in(0,1)$，则 $b_{k+1}=b_k^2$。对 $0<b<1$ 定义

$$S(b)=\sum_{j\ge0}b^{2^j},\qquad
0\le S(b)-b\le\frac{b^2}{1-b}.$$

第一切向尾精确为 $S(b_k)$。当 $p_0\le0$ 时第二切向坐标恒定；当 $p_0>0$ 时最终进入并留在饱和段，第二切向尾也为 $S(b_k)$。因此充分大 $k$ 的完整欧氏点误差满足

$$e_k^2=mS(b_k)^2+b_k^4,\qquad
m=\begin{cases}1,&p_0\le0,\\2,&p_0>0.\end{cases}$$

从而

$$\lim_{k\to\infty}\frac{e_{k+1}}{e_k^2}
=m^{-1/2}=\begin{cases}1,&p_0\le0,\\1/\sqrt2,&p_0>0.\end{cases}$$

逐轨道的最终饱和起点可依赖初值，不意味着所有初值共用一个二次渐近起点。另一方面，若 $|r_0|\le R_0<1$，上述尾级数有统一上界，给出整 collar 的共同超几何尾；二者是不同的量词。

现在考虑初值差 $\varepsilon$。未饱和时仍有

$$\log p_k=-2^{-k}t+O(1),\quad t=\log(1/\varepsilon).$$

在上述正初值比较中，令 $A_0=-\log r_0>0$，阈值变成 $r_k=\exp(-A_0 2^k)$。由 $p_N\ge r_N$、$p_{N-1}<r_{N-1}$，

$$N=\frac{\log t}{\log4}+O(1).$$

所以 $t2^{-N}=\Theta(\sqrt t)$、$2^N=\Theta(\sqrt t)$。由于

$$p_\infty=p_N+\sum_{k=N}^\infty\sqrt{r_k},$$

第一项和尾部的对数都为 $-\Theta(\sqrt t)$，即 (4.5)。注意这里不能错误地套用几何法向情形的 $p_N=O(r_N^{1/2})$；超几何下降时这一般不成立。本证明分别控制 overshoot 项与饱和尾项。

### 任意超线性阶数的最优指数

更一般地，把 (3.6) 的最后一个坐标换成 $|r|^\nu$，$\nu>1$。完整算子由 (3.7) 把 $a=y/q$ 换成 $a=y^{1/\nu}$ 得到。误差界变成

$$d(u,S)\le(r_F(u)/A)^{\nu/\gamma}.$$

在固定 $|r|,|r'|\le R_0<1$ 上，对于每个有限输入对尺度 $D>0$，all-pairs RL 指数仍是 $\gamma$。法向反射 $2|r|^\nu-r$ 的 Lipschitz 常数不超过 $1+2\nu R_0^{\nu-1}$，所以可用常数 $2\sqrt{A^2+B^2}+(1+2\nu R_0^{\nu-1})D^{1-\gamma}$。取输出图块 $0\le y\le R_0^\nu$，其输入像恰为完整 collar；在足够小的统一尺度上，兼容商为 $O(d^{\nu-1})\to0$。对每条 $0<|r_0|<1$ 的轨道，点误差满足 $e_k\asymp r_k^\gamma$，因而具有确切的 Q-$\nu$ 量级。

对敏感初值，首次切换满足

$$\gamma^N t\asymp\nu^N,\qquad
N=\frac{\log t}{\log(\nu/\gamma)}+O(1).$$

未饱和对数式 (3.8) 在 $k=N$ 仍成立，因此 overshoot 项本身为 $p_N=\exp[-\Theta(t^\alpha)]$。若 $r_k=e^{-a\nu^k}$，$a=-\log r_0>0$，则饱和尾独立满足

$$B e^{-a\gamma\nu^N}\le
B\sum_{j\ge0}e^{-a\gamma\nu^{N+j}}
\le\frac{B}{1-e^{-a\gamma(\nu-1)}}e^{-a\gamma\nu^N}.$$

两项相加，才得到

$$p_\infty=\exp[-\Theta(t^\alpha)],\qquad
\alpha=\frac{\log\nu}{\log(\nu/\gamma)}.$$

这与定理 1(b) 匹配：不能统一替换为任何更大的根对数指数 $\alpha'>\alpha$。这里的最优性是指数层面的，不主张指数前常数最优。若 $\gamma,\nu$ 为有理数，则该族也是半代数的。

## 5. 两个结构性推论

### 5.1 半代数有限步映射的极限不必半代数

定理 2、4 中的 $F,T$ 均为半代数，每个有限次迭代 $T^k$ 也半代数。然而极限映射在原点的任何完整邻域内都不是半代数。

证明：若该极限映射在某个完整邻域内半代数，取充分小的固定 $r_0>0$，对两个模型分别取标量切片

$$f(\varepsilon)=\pi_2\Pi(0,\varepsilon,r_0)
=\|\Pi(0,\varepsilon,r_0)-\Pi(0,0,r_0)\|.$$

二次模型将 $\Pi$ 换为 $\widetilde\Pi$。不是把整个极限向量称为趋零标量：几何模型的第一极限坐标恒为 $2\sqrt{r_0}>0$。有限步第二坐标对 $\varepsilon$ 连续，且

$$0\le f(\varepsilon)-p_k(\varepsilon)
\le\sum_{j\ge k}\sqrt{r_j}\longrightarrow0$$

的尾界与 $\varepsilon$ 无关，故 $f$ 连续、$f(0)=0$、$f(\varepsilon)>0$（$\varepsilon>0$）。半代数性在直线限制和坐标投影下保持；增长二分引理 [LP22, Lemma 2.2] 遂给

$$f(\varepsilon)=c\varepsilon^a+o(\varepsilon^a),\qquad
c>0,\quad a\in\mathbb Q_{>0}.$$

这与 (3.2) 或 (4.5) 对每个正幂都更慢的衰减矛盾。结论仅为非半代数，不是“在任何 o-minimal 结构都不可定义”。

因此不能把“每一步是半代数”偷换成“迭代无穷次后的算法解选择也是半代数”。

### 5.2 一项真正恢复 Hölder 稳定性的切向条件

以下命题的证明是标准离散 Gronwall 估计；不把这一证明技巧主张为创新。它用于识别上述反例中确实缺少的结构。

设

$$T(a,r)=(a+B(a,r),qr),\quad
(a,r)\in\mathbb R^m\times[0,R],\quad0<q<1,$$

其中 $B:\mathbb R^m\times[0,R]\to\mathbb R^m$、$B(a,0)=0$，并且对所有 $a,b\in\mathbb R^m$、$r,s\in[0,R]$ 及某些统一的 $C,H,\eta>0$、$0<\gamma\le1$，

$$\|B(a,r)-B(b,r)\|\le Cr^\eta\|a-b\|,$$

$$\|B(a,r)-B(a,s)\|\le H|r-s|^\gamma.$$

则轨道有限长，其极限第一坐标 $\Pi_a$ 满足

$$\|\Pi_a(a,r)-\Pi_a(b,s)\|
\le \exp\!\left(\frac{CR^\eta}{1-q^\eta}\right)
\left[\|a-b\|+\frac{H}{1-q^\gamma}|r-s|^\gamma\right].\tag{5.1}$$

证明：$\|B(a,r)\|\le Hr^\gamma$ 保证轨道收敛。两轨道第一坐标差 $u_k$ 满足

$$u_{k+1}\le(1+CR^\eta q^{\eta k})u_k+Hq^{\gamma k}|r-s|^\gamma.$$

将乘积界

$$\prod_{k\ge0}(1+CR^\eta q^{\eta k})
\le\exp(CR^\eta/(1-q^\eta))$$

与几何级数结合，再取极限即得 (5.1)。反例的 $p\mapsto\sqrt{p_+}$ 切向尖点明显不满足第一项 Lipschitz 条件。

若只在切向子域给定条件，还须另证全部比较轨道留在该域；上述全切向域版本没有这一额外留域问题。此命题只针对明确写出的三角结构，不声称是必要条件，也不声称已证明一般曲面、耦合法向动力学或原稿所有 signed-Schur 图块的 Hölder 稳定性。新模型的自然输出坐标反演满足 $dp/d\eta=1-1/\sqrt{1+4\eta}\downarrow0$，不提供原附录强切向反演所需的统一下界；本文不调用那些强假设，也不额外宣称排除一切重新参数化。

## 6. 文献位置与尚未确认的优先权

本节依据截至 2026-09-19 的定理级独立审计更新。以下区分数学工具、宽泛现象和本稿精确联合结果；没有把“搜索未命中”作为首创证明。方括号标签对应 §8 的完整书目及版本。

### 6.1 截断方法已有，精确非幂模分别判断

Wiśnicki [W14, Lemma 1] 对完备有界度量空间上的单步 $k$-Lipschitz 迭代，在共同增量 $c\rho^n$ 下使用

$$d(Rx,Ry)\le k^n d(x,y)+\frac{2c\rho^n}{1-\rho}$$

推出 Hölder 极限回缩。更早的 Pérez García 和 Fetter Nathansky [PGF10, Lemma 2.1(c)] 在完备有界度量空间 $X$ 上，设 $T:X\to X$ 连续，辅助映射 $u:X\to X$ 为 $p$-Lipschitz（$p>1$），且对全部 $x\in X$ 满足

$$d(Tu(x),u(x))\le a\,d(Tx,x),\qquad
d(u(x),x)\le B\,d(Tx,x),\qquad 0<a<1,\quad B>0.$$

该引理得到 $\lim_n u^n$ 的 Hölder 指数 $\log(1/a)/(\log p+\log(1/a))$。收敛的是辅助迭代，不是说周期映射 $T$ 自身按此结论收敛。

因此，有限前缀加两尾再平衡步数不是本文的新方法。本文需另算的包络是

$$Ae^{-t\gamma^n}+2M\sigma^n
\quad\hbox{或}\quad Ae^{-t\gamma^n}+2Me^{-c_0\nu^n},\qquad
t=\log(1/\delta),$$

并须闭合局部尺度。已读上述引理没有陈述这里的 $(\log t/t)^\beta$ 和 $e^{-ct^\alpha}$ 两个指定量级；但 U1 中更早的一般命题原页尚待核验。即使抽象上界最终只是某旧一般命题的显式特化，§3-§4 的匹配算法下界仍须独立判同。

### 6.2 AGM 已有坏极限现象，不具有本稿全部量词

经典算术-几何平均迭代为

$$G(a,b)=((a+b)/2,\sqrt{ab}),\qquad
\Pi_G(a,b)=(M(a,b),M(a,b)).$$

对 $0\le b\le a\le R$，置 $d_n=a_n-b_n$。原点轨道驻定；统一使用不含零分母的恒等式，直接有

$$d_{n+1}=\frac12(\sqrt{a_n}-\sqrt{b_n})^2\le d_n/2,
\qquad \|G^n(a,b)-\Pi_G(a,b)\|\le d_n\le R2^{-n}.$$

该单步映射在有界域上半代数且 $1/2$-Hölder。Brent [B76, (4.16)-(4.18)] 与 Cox [C84, Theorem 1.1] 的经典积分关系及端点渐近给

$$M(1,\varepsilon)=\frac{\pi}{2K(\sqrt{1-\varepsilon^2})}
\sim\frac{\pi}{2\log(1/\varepsilon)},\qquad M(1,0)=0.$$

因此半代数快迭代、非任意 Hölder 及非半代数极限选择并存的宽泛现象已有。这里的稳定性对应由经典公式直接推导，不冒称原文使用本文术语；绝对值延拓也可将该宽泛现象放到全欧氏输入域。

区别有三项：AGM 给 $1/t$ 而不是本稿的匹配 $\log t/t$；坏参考轨道 $G^n(c,0)=(c2^{-n},0)$ 只有几何尾，不能属于包含该点的共同超几何尾域；AGM 正初值点误差虽 Q-二次，不能与轴上的坏选择拼成“坏参考轨道自身 Q-二次”。本稿二次模型则在 $p_0=0,r_0>0$ 的坏参考轨道上仍有比值 $1$。

### 6.3 逆图 resolvent 编码是标准事实，严格兼容不是自动继承

Bauschke、Moursi 和 Wang [BMW, Fact 2.1] 给出 $F=T^{-1}-I\Rightarrow J_F=T$。图的线性变换保持闭图和半代数性，且纤维值数对应 $\#F(u)=\#T^{-1}(u)$。本稿不把编码本身作为新构造原理；需要新做的是指定全对模、真实 min-residual、严格 RLEB 数值匹配及坏选择的同时实现。

AGM 的直接编码已经是至多二值的。对 $s\ge t\ge0$，令 $d=\sqrt{s^2-t^2}$，则

$$F_{\rm AGM}(s,t)=\{(d,s-t-d),(-d,s-t+d)\}.$$

其完整 resolvent 在 $\mathbb R_+^2$ 为 $G$。然而在 $(h,0)$，最小残差为 $h$，到零集的距离为 $h/\sqrt2$，故有效输出 gauge 必须满足 $\psi(h)\ge h/\sqrt2$。固定小 $c>0$，输入对 $(c,t),(c,0)$ 又迫使 all-pairs 反射模满足 $\omega(t)\ge\sqrt{ct}$（$0<t\le c$）。于是

$$\frac{\psi((t+\omega(t))/2)}t
\ge\frac{\sqrt c}{2\sqrt2\sqrt t}\longrightarrow\infty.$$

这排除该直接编码在坏边界附近的严格兼容，不排除所有有限维 lift、换变量或其他 AGM 改造。原 RLEB 二维基例的性质同样是继承基础，新增项是 cap 切向放大、匹配选择下界及超几何变体。

### 6.4 收敛框架和好极限映射的结构性先例

Luke 和 Tam [LT, Lemma 2, Theorem 2] 的局部 PPA 收敛及点尾是相关基础，不提供本文两初值极限差的两个指定模。Luke、Thao 和 Tam [LTTQ, arXiv v2 Theorems 2.15, 2.18, Corollary 2.19] 的 almost-averaged 与次正则框架给收敛率，但其点态比较不能替代本文整个工作域的 all-pairs 条件。[LTTP, Theorems 1-4] 已在审计阶段取得全文：Theorems 1-2 的非扩张/averaged 迭代，其极限继承非扩张；Theorem 4 本身不要求非扩张，不能据前两条的假设一并排除，但它也没有本文的坏选择结论。

Li、Mordukhovich 和 Zhu [LMZ, arXiv v1 Theorems 4.3-4.4, Example 4.6] 已有高阶实际点收敛，例 4.6 的 PPA 已 Q-二次，但唯一极限为 $0$，选择映射恒定。因此纯高阶收敛不是本文独立新颖性。Lee 和 Phạm [LP22, Lemma 2.2, Proposition 3.1, Theorem 3.1] 提供一元半代数增长及有限图正则性工具，不保证无限迭代极限半代数，也不自动提供本文指定 EB 系数与严格兼容。

Beyn [B93, Theorems 2.1-2.2, 3.1] 在满秩光滑零流形上研究 Gauss-Newton 的共同二次点尾与 $C^k$ 初值-极限映射，是同一研究对象的真实前身。Pasteczka [P16, Theorems 1-3, §3.2] 对正则拟算术均值迭代给共同双指数尾；其生成元满足导数不退化与 $|f_i''/f_i'|\le K$，AGM 应用中的 $K=1/x_{\min}$ 在坏边界不统一。该文任意连续 $\varphi$ 出现在复合不变函数 $\varphi\circ M$ 中，不等于极限均值 $M$ 可任意粗糙。

Chen、He 和 Huang [CHH, Assumptions 1-3, Theorems 2-3] 的光滑 clean intersection 与切法向导数控制给光滑极限回缩；二阶回缩不是点误差 Q-二次的同义词。Kvalheim 和 Revzen [KR, Proposition 1, §3.2.2, Proposition 8, Theorem 2] 的一般 NHIM 结论先给连续相位，逆向构造则预设光滑相位并以法向支配保持正则性；仅保证连续不是一个非任意 Hölder 的存在反例。这些结构对照解释 §5.2 的动机，不将其范围扩张为所有 signed-Schur 图块。

### 6.5 可保留的贡献和未关闭入口

本文的最小贡献包限定为：局部 Hölder 单步与共同点尾的两个显式非幂模；固定实际 $(\gamma,q)$ 下的几何量级匹配；固定 $(\gamma,\nu)$ 下的超几何指数匹配；以及满足真实最小残差、all-pairs RL、完整 resolvent 和严格 RLEB 的有限分支实现。任意实参数给闭图至多二值实现，有理幂参数另给半代数实现。所有“最优”均按这些类别解释。

在列明文献、版本和截止日内，未定位覆盖精确联合包的同一定理或构造。

这一有限结论记为 `NO-EXACT-PRIOR-FOUND`，不等于证明全球首创。以下入口仍未解决，不从修订稿中删除：

- **U1：** Benyamini 和 Lindenstrauss [BL00, Proposition 1.10] 的命题及证明原页尚未取得。须检查是否允许任意有限步模及尾函数、是否已明确算出本文量级；不能由 Wiśnicki 只用 Lipschitz 版本推断原命题也仅限于此。
- **U2：** [LMZ] 的实质对应基于 arXiv:2406.13207v1。正式 DOI 版本的增改和编号差异尚未闭合；本稿不把 v1 定理号冒称为已核正式刊本编号。
- **U3：** Chicone-Liu 的 *Asymptotic phase revisited*（J. Differential Equations 204 (2004), 227-246）及 Battelli-Palmer 的 *Smoothness of Asymptotic Phase Revisited* 全文尚未完整取得，未核定理号、DOI/arXiv 或覆盖范围。它们是未排除入口，不是已证同一先例。Kvalheim-Revzen 的全文缺口已关闭，不再列入此项。
- **范围外问题：** 固定保守 $\kappa$ 的同量级锐性、有限尺度最小 $L_R$、超几何指数前最佳常数、一般 signed-Schur 极限稳定性，以及 AGM 的所有增强实现均未解决，也不是现有主结果的必要假设。

优先权结论与投稿等级、录用判断不同；本稿不从阴性检索给出后两者的保证。

## 7. 数值核查与复现

`verify_research.py` 使用确定种子，对两个显式模型各作 100000 组检查，覆盖异号 proximal 输入、切向尖点和接缝：完整 graph identity、两个分支分别反演回输出、输出 EB、随机 all-pairs RL，以及直接迭代与切换后的精确几何尾和交叉核对。连续域的结论仍由以上证明保证。

初次运行的最大 graph identity 绝对误差约为 $1.91\times10^{-17}$，两个分支逆向检查的最大绝对误差约为 $1.53\times10^{-16}$；抽样没有发现 EB 或 RL 违反。完整数值保存在 JSON 和 CSV 中。

几何模型固定 $r_0=0.01$，$\varepsilon=e^{-t}$：

| $t$ | 切换时刻 $N$ | 极限解差 | 极限解差 $\times t/\log t$ |
|---:|---:|---:|---:|
| $10^2$ | 4 | 0.0144341844 | 0.313434 |
| $10^4$ | 10 | 0.000252706683 | 0.274373 |
| $10^6$ | 16 | 0.00000328791013 | 0.237987 |
| $10^{12}$ | 35 | $6.05004654\times10^{-12}$ | 0.218958 |

代码在切换前使用 $\log p$，因此无需把 $e^{-10^6}$ 存成普通浮点数。超线性模型同时报告对数极限差和遗漏正尾项的几何级数上界；这些是浮点计算，不是区间算术或形式化证书。

## 8. 参考文献与核验版本

原 RLEB 基础稿：用户提供，*Nonlinear Generalized Monotonicity and Error Bounds for Proximal Point Convergence at Multivalued Graph Junctions*，2026-09-18 投稿资产包；本稿仅调用局部 resolvent、all-pairs RL、长度预算与 residual-growth 接口，不补造作者名或正式出版标识。

- **[W14]** Andrzej Wiśnicki. *Hölder continuous retractions and amenable semigroups of uniformly Lipschitzian mappings in Hilbert spaces*. Topological Methods in Nonlinear Analysis 43 (2014), 89-96. [DOI: 10.12775/TMNA.2014.006](https://doi.org/10.12775/TMNA.2014.006); [arXiv:1204.6464v2](https://arxiv.org/abs/1204.6464v2), Lemma 1.
- **[PGF10]** Víctor Pérez García and Helga Fetter Nathansky. *Fixed points of periodic mappings in Hilbert spaces*. Annales UMCS, Sectio A 64(2) (2010), 37-48. [原刊 DOI: 10.2478/v10062-010-0013-y](https://doi.org/10.2478/v10062-010-0013-y); 现期刊网页另列 [10.17951/a.2010.64.2.37-48](https://doi.org/10.17951/a.2010.64.2.37-48). Lemma 2.1(c).
- **[B76]** Richard P. Brent. *Fast Multiple-Precision Evaluation of Elementary Functions*. Journal of the ACM 23 (1976), 242-251. [DOI: 10.1145/321941.321944](https://doi.org/10.1145/321941.321944). §4, (4.16)-(4.18), §5.
- **[C84]** David A. Cox. *The Arithmetic-Geometric Mean of Gauss*. L'Enseignement Mathématique 30 (1984), 275-330. [DOI: 10.5169/seals-53831](https://doi.org/10.5169/seals-53831). Theorem 1.1 and §1; 此为原刊标识，不与后期重印混用。
- **[BMW]** Heinz H. Bauschke, Walaa M. Moursi and Xianfu Wang. *Generalized monotone operators and their averaged resolvents*. [DOI: 10.1007/s10107-020-01500-6](https://doi.org/10.1007/s10107-020-01500-6); [arXiv:1902.09827v1](https://arxiv.org/abs/1902.09827v1), Fact 2.1.
- **[LP22]** Jae Hyoung Lee and Tiến-Sơn Phạm. *Openness, Hölder Metric Regularity, and Hölder Continuity Properties of Semialgebraic Set-Valued Maps*. SIAM Journal on Optimization 32(1) (2022), 56-74. [DOI: 10.1137/20M1331901](https://doi.org/10.1137/20M1331901); [arXiv:2004.02188v2](https://arxiv.org/abs/2004.02188v2), Lemma 2.2, Proposition 3.1, Theorem 3.1, Corollary 3.1.
- **[LT]** D. Russell Luke and Matthew K. Tam. *Generalized Monotonicity and the Proximal Point Algorithm*. [DOI: 10.1287/moor.2025.0863](https://doi.org/10.1287/moor.2025.0863). 已核正式全文 Proposition 1, Proposition 4, Lemma 2, Assumption 2, Theorem 2, Example 2.
- **[LTTQ]** D. Russell Luke, Nguyen H. Thao and Matthew K. Tam. *Quantitative Convergence Analysis of Iterated Expansive, Set-Valued Mappings*. [DOI: 10.1287/moor.2017.0898](https://doi.org/10.1287/moor.2017.0898); [arXiv:1605.05725v2](https://arxiv.org/abs/1605.05725v2). v2 Theorems 2.15, 2.18, Corollary 2.19；正式版对应 Theorems 2.1-2.2, Corollary 2.3。
- **[LTTP]** D. Russell Luke, Nguyen H. Thao and Matthew K. Tam. *Implicit Error Bounds for Picard Iterations on Hilbert Spaces*. Vietnam Journal of Mathematics 46 (2018), 243-258. [DOI: 10.1007/s10013-018-0279-x](https://doi.org/10.1007/s10013-018-0279-x). Theorems 1-4, Remark 1；本次审计已核全文，不再停留于原研究阶段的摘要阅读。
- **[LMZ]** Guoyin Li, Boris S. Mordukhovich and Jiangxing Zhu. *Generalized Metric Subregularity with Applications to High-Order Regularized Newton Methods*. [DOI: 10.1287/moor.2024.0570](https://doi.org/10.1287/moor.2024.0570); [arXiv:2406.13207v1](https://arxiv.org/abs/2406.13207v1). 本稿对应 Theorems 4.3-4.4, Remark 4.5, Example 4.6 均按 v1；正式版差异未关闭。
- **[B93]** Wolf-Jürgen Beyn. *On Smoothness and Invariance Properties of the Gauss-Newton Method*. Numerical Functional Analysis and Optimization 14(5-6) (1993), 503-514. [DOI: 10.1080/01630569308816536](https://doi.org/10.1080/01630569308816536). Theorems 2.1-2.2, 3.1, equation (2.1).
- **[P16]** Paweł Pasteczka. *Iterated Quasi-Arithmetic Mean-Type Mappings*. Colloquium Mathematicum 144 (2016), 215-228. [DOI: 10.4064/cm6479-2-2016](https://doi.org/10.4064/cm6479-2-2016); [arXiv:1412.2997v1](https://arxiv.org/abs/1412.2997v1), Theorems 1-3, Lemma 4.3, §3.2.
- **[CHH]** Shixiang Chen, Yixiao He and Wen Huang. *Retractions by Alternating Projections*. [arXiv:2605.17384v2](https://arxiv.org/abs/2605.17384v2). Assumptions 1-3, Proposition 2, Theorems 2-3, Lemma 4.9；未据标题把二阶回缩认作 Q-二次率。
- **[KR]** Matthew Kvalheim and Shai Revzen. *Reverse-engineering invariant manifolds with asymptotic phase*. [arXiv:1608.08442v1](https://arxiv.org/abs/1608.08442v1). Proposition 1, §3.2.2, Propositions 6, 8, Theorem 2.
- **[BL00]** Yoav Benyamini and Joram Lindenstrauss. *Geometric Nonlinear Functional Analysis, Volume 1*. AMS Colloquium Publications 48 (2000). [AMS 书目](https://www.ams.org/books/coll/048/). Proposition 1.10 的原页未取得，故本稿只列待核入口，不给未经核验的定理内容。
