# 构建与作者视觉 QA 记录

日期：2026-09-19。对象：`research_note.md` 经同源转换生成的修订 LaTeX/PDF。

## 构建结果

`BUILD_PASS`：Pandoc 3.1.3 与 XeLaTeX（TeX Live 2023/Debian）三遍编译成功，得到 20 页 A4 中文 PDF：

`output/pdf/solution_selection_revised.pdf`

构建命令：`bash build.sh`。本工作区使用既有本地 ctex/xeCJK/Fandol 工具链；没有安装新依赖、提升权限或修改系统。每次构建将 TeX 与辅助文件放入 `mktemp` 创建的独立 `build/latex.*` 目录，成功后才复制正式 TeX/PDF/日志，避免共享辅助文件碰撞。PDF 技能要求的作者操作标记在第一次副本创建/编辑前已成功执行一次。

关闭小修后的首次共用目录编译曾遇到截断 `.aux` 的 `Runaway argument`，没有据失败产物放行；迁移到独立目录后，从干净辅助文件三遍构建成功，最终日志无此错误。

最终日志 `build/solution_selection_revised.log`：

- 0 个 Overfull box；
- 0 个缺字（Missing character）；
- 0 个 Undefined control sequence 或未定义引用；
- 仍有 Fandol 的 `Script CJK` 字体元数据警告，以及参考文献两处 underfull 行间伸展提示；实际字形完整，未出现黑方块、裁切或重叠。没有将这些警告隐瞒成“零警告”。

## 逐页视觉检查

先以 Poppler 85 dpi 将全 PDF 渲染为 PNG，逐一查看全部页面，检查正文、数学公式、编号、页眉、分支数组、数值表与参考文献。首轮发现一处长审计标签溢出及参考文献末页孤行；分别通过源段落断开与参考文献统一小一号排版修正，并完整重编译、重渲染。

三项独立审核小修后，再次完整渲染并逐页查看 20 页；随后仅在模板中增加段首/段末孤行控制。最终渲染在 `tmp/pdfs/release/page-01.png` 至 `page-20.png`：与刚完成的全页检查相比，仅第 18-19 页发生版面变化，已重新逐页查看；其他 18 页 PNG 逐字节相同。末页不再只有一行，跨页段落不再留下孤行，参考文献字号可读，全部页面未见裁切、遮挡、公式溢出、缺字或错误的空白页。

本记录是作者侧构建/版面 QA，不替代独立数学和文献关闭审核。

## 内容保真及原件保护

`node verify_package.mjs` 产生 `build/package_integrity.json`。结果：

- 原稿 28 条带编号公式均在修订稿中保留，去除空白后逐式相同；
- 回复文件包含 C01-C24 全部 24 项，无缺失；
- 四个上传原件哈希均与本轮记录一致；
- 验证脚本与原归档脚本逐字节一致；
- 核心公式没有因 Markdown 到 LaTeX 转换另建手写分叉。

机械保真检查不能代替数学审查；它只验证没有意外改掉原有编号公式和原件。

## 数值复现

运行：`python3 verify_research.py --out build/reproduction`。

固定种子 `20260918`；每个显式模型 100000 组。最大 graph identity 误差约 `1.9082e-17`，两支反演最大误差约 `1.5266e-16`；EB 抽样违反数值为 0，direct iteration cross-check 通过。`diff -ru results build/reproduction` 无差异。

这些仅证明本包数值程序可重复运行，不能据有限抽样提高数学或全球优先权结论。

## 当前内容哈希

| 文件 | SHA-256 |
| --- | --- |
| `research_note.md` | `91ad4b0948a21443fc557b5ea579e692650399504e735223d72347ba86bea1b8` |
| `solution_selection_revised.tex` | `b0c750a8235ecfe2c1959f5b6da37bc2b539afe0f7ace618c26243ea33ee2a56` |
| `output/pdf/solution_selection_revised.pdf` | `0bd11b6c3e8c246842151a0190928b0bc02c3f1662405d0d0771c4687d418c03` |

这些哈希对应三项关闭小修及最终排版完成版；若独立审核要求进一步修改，必须重建、重查并更新本表。PDF 的构建时间元数据会随重建变化；独立构建应在副本中完成，不应无记录地替换本次冻结交付 PDF。
