# Solution-selection 修订包：源文件对应

修订日期：2026-09-19。修订者只修改新目录副本；未改动四个上传原件，也未改动原 RLEB 投稿资产。

## 正式主稿

- `research_note.md`：本修订包唯一权威内容源，完整中文研究稿。
- `solution_selection_revised.tex`：从该 Markdown 机械生成的完整 LaTeX 源，可独立用安装了 ctex/Fandol 的 XeLaTeX 编译；不要另行编辑此生成文件再遗漏 Markdown。
- `output/pdf/solution_selection_revised.pdf`：同源编译 PDF。
- `manuscript_template.tex`、`prepare_pdf.lua`、`build.sh`：构建模板、仅排版过滤器与可重复构建命令。

原压缩包 `03-RLEB_solution_selection_2026-09-18.zip` 只有 Markdown 主稿、README、审计任务和 Python/JSON/CSV 数值复现资产，没有另一个正式 TeX 主稿或原有 PDF 构建流程。本次增加 LaTeX/PDF 输出，不把原 RLEB 的 TeX 误认作本研究稿。

`source_archive/RLEB_solution_selection_2026-09-18/` 保存原压缩包的完整解包快照；它是只读来源记录，不是待阅读的最新版。压缩包内 `research_note.md` 与单独上传的 `02-research_note.md` 一致，SHA-256：

`42cd0a2a7bbf91e105f37f450b239d1b839fa67159a079f5b880acf2710934b7`。

## 修订凭据

- `response_to_audit.md`：R1-R6、C01-C24 和未解决文献的逐项回复。
- `change_log.md`：本轮修改范围及不变的核心结果。
- `build_report.md`：编译、渲染、视觉检查与数值复现记录。

已落实不等于独立放行；最终关闭状态以监督者组织的针对性独立审核为准。U1-U3 文献缺口仍未解决，不能写成全球优先权已关闭。

## 构建和数值复现

```bash
bash build.sh
python3 verify_research.py --out build/reproduction
```

PDF 构建需要 Pandoc 3、XeLaTeX、ctex/xeCJK/Fandol 和常规数学宏包。在本工作区，脚本优先使用已存在的 `../papers/toolchain/run-xelatex.sh`；脱离本工作区时回退到标准 `xelatex`。Python 脚本需 NumPy，只作为数值复现，不是数学证明。

`verify_research.py` 与 `results/` 是原研究包的未改动副本；本轮重跑结果在 `build/reproduction/`，不覆盖原结果。

## 上传原件核对值

| 原件 | SHA-256 |
| --- | --- |
| `01-Codex_independent_audit.md` | `33414e95e98cd446221b3daeb9684d2592408cdfacef0ac5f520c4d431065705` |
| `02-research_note.md` | `42cd0a2a7bbf91e105f37f450b239d1b839fa67159a079f5b880acf2710934b7` |
| `03-RLEB_solution_selection_2026-09-18.zip` | `54350c47dd90e352afdb08123fd689a3737ef3441806f2a7a930c12eb9eaf1f4` |
| `04-RLEB_PPA_-_2026-09-18.zip` | `a377f9dd6a66f9281b1b98089c311b81923e908e541093768bfa9e9d1fe03871` |
