# Solution-selection 修订稿：独立文献与主张范围审核

日期：2026-09-19。审核对象：`solution_selection_revised_v1/research_note.md`，758 行。

本轮所读修订稿 SHA-256：`6147db97517f13b2cc1f73629e9c594dde07cd212e4de15cc9983aabaec53e0e`。

**终判：`MINOR_REPAIR`。优先权主张的实质范围已通过；只余两处可直接关闭的表述小修，不要求改动主定理、重做优先权全检索或增加新成果。**

本文行号仅对应上述快照。未修改研究稿或原 RLEB 文件；仅写本报告。对读原稿和修订稿，并读取 D1–D4、`D_claim_scope_audit.md`、`D_adversarial_priorart_stress.md`、`solution_selection_final_audit.md`。本轮直接复读新增主要先例的原始相关定理或公式；没有把上一轮审计的全篇阅读记录冒称为本轮逐页重读所有论文。

## 一、致命错误／重大主张越界

没有发现。

以下旧风险已实质关闭：

- 第 7、9、646–660 行明确把有限步比较加共同尾的截断方法归于已有框架。
- 第 662–681 行正面承认 AGM 已有快速半代数迭代与坏极限选择的宽泛现象，且没有把经典论文没有使用的现代术语冒称为原文定理。
- 第 183、683–696 行明确承认标准逆图编码及原 RLEB 二维基例是基础，不重复计作新成果。
- 第 704–706 行把 Beyn、Pasteczka、Chen–He–Huang、Kvalheim–Revzen 定位为结构性先例，而非硬说成同一反例。
- 第 9、644、712–721 行限制阴性检索的证据范围；没有用 `NO-EXACT-PRIOR-FOUND` 代替世界首创证明或录用判断。

“首次切换／饱和时刻”是数学定义，不是历史优先权声明，不构成问题。

## 二、两项小修及安全替换

### P1．Pérez 引理的简述应补上有界性及 \(p>1\)

位置：第 652 行。现句给出了正确指数，但压缩为“\(p\)-Lipschitz 辅助迭代及残差缩小率 \(a<1\)”后，没有提到 Lemma 2.1(c) 明写的 \(p>1\)、\(\operatorname{diam}X<\infty\) 和此前的步长条件。它不影响本稿定理，却不宜作为完整的先例假设对应被引用。

原文是：在完备度量空间中，连续 \(T\) 及辅助映射 \(u\) 满足

\[
d(Tu(x),u(x))\le a\,d(Tx,x),\qquad
d(u(x),x)\le B\,d(Tx,x),\qquad 0<a<1,
\]

并且 \(u\) 是 \(p\)-Lipschitz；(c) 再要求 \(p>1\)、域有界。其证明得到

\[
\theta=\frac{\log(1/a)}{\log p+\log(1/a)}.
\]

这与稿中指数一致，迭代对象确实是 \(u\)，不是周期映射 \(T\) 自身。[原刊 Lemma 2.1，pp. 38–40](https://journals.umcs.pl/a/article/download/3985/2887)

安全替换：

> 更早的 Pérez García 和 Fetter Nathansky [PGF10, Lemma 2.1(c)] 在完备有界度量空间中，对满足其残差收缩与步长控制条件的 \(p\)-Lipschitz 辅助迭代 \(u\)（\(p>1\)），得到指数 \(\log(1/a)/(\log p+\log(1/a))\)。收敛的是该辅助迭代，而非周期映射自身。

此项是引用摘要的假设补齐，不是发现该公式或本稿主结果为假。

### P2．AGM 商式须单独处理原点，避免 \(0/0\)

位置：第 669–672 行。声明范围包含 \((a,b)=(0,0)\)，而所写商式

\[
d_{n+1}=\frac{d_n^2}{2(\sqrt{a_n}+\sqrt{b_n})^2}
\]

在该点为 \(0/0\)。最小反例只是代入 \(a=b=0\)，并不反驳 AGM 的几何尾结论。

安全补句：

> 当 \(a_n+b_n>0\) 时使用下列商式；在原点轨道驻定，\(d_{n+1}\le d_n/2\) 及点尾界均直接成立。

点尾常数 \(\|G^n(a,b)-(M,M)\|_2\le d_n\) 本身正确：两坐标误差非负、和为 \(d_n\)，故欧氏范数不超过其和。无需将常数改大，也不需要撤回 AGM 对照。

## 三、新增文献的题录、定理定位与实际对应

下表区分“本轮复读原文”与“沿用上一轮已核版本”。没有根据摘要判定某篇论文不存在结果。

| 稿中标签／位置 | 题录和原始定位核验 | 对应裁定 |
| --- | --- | --- |
| [W14]，648–650、744 行 | Andrzej Wiśnicki，*Hölder continuous retractions and amenable semigroups of uniformly Lipschitzian mappings in Hilbert spaces*，TMNA 43(1) (2014), 89–96；DOI 10.12775/TMNA.2014.006；arXiv:1204.6464v2，Lemma 1。[原文](https://arxiv.org/html/1204.6464v2)、[期刊记录](https://apcz.umk.pl/TMNA/article/view/TMNA.2014.006) | 本轮核准。原文确有单步 Lipschitz、共同几何增量和 \(k^n\delta+2c\rho^n/(1-\rho)\) 截断估计；不是本稿 \(\delta^{\gamma^n}\) 的同量级定理。卷期年份采用 2014，不能被网页迁移时间 2016 替换。 |
| [PGF10]，652、745 行 | Víctor Pérez García、Helga Fetter Nathansky，*Fixed points of periodic mappings in Hilbert spaces*，Annales UMCS A 64(2) (2010), 37–48；原 PDF DOI 10.2478/v10062-010-0013-y；网页 DOI 10.17951/a.2010.64.2.37-48；Lemma 2.1(c)。[原刊全文](https://journals.umcs.pl/a/article/download/3985/2887)、[期刊记录](https://journals.umcs.pl/a/article/view/3985) | 两种 DOI 的来源说明正确，辅助迭代与指数对应正确；补 P1 即关闭假设压缩。 |
| [B76]，674、746 行 | Richard P. Brent，*Fast Multiple-Precision Evaluation of Elementary Functions*，JACM 23 (1976), 242–251；DOI 10.1145/321941.321944；§4 (4.16)–(4.18)、§5。[作者原刊 PDF](https://maths-people.anu.edu.au/~brent/pd/rpb034.pdf)、[作者题录](https://maths-people.anu.edu.au/~brent/pub/pub034.html) | 本轮核到原刊 AGM 递推和积分式；二次计算位于 §5。正文将“非 Hölder／非半代数”说成由经典公式推导的对应，而非原文同名定理，准确。DOI 沿用上一轮 ACM 题录核验；本轮 DOI 页面未返回正文。 |
| [C84]，674、747 行 | David A. Cox，*The Arithmetic-Geometric Mean of Gauss*，L'Enseignement Mathématique 30 (1984), 275–330；原刊标识 10.5169/seals-53831；Theorem 1.1、§1。[作者上传的原刊扫描／OCR](https://www.researchgate.net/publication/248675540_The_Arithmetic-Geometric_Mean_of_Gauss) | 本轮核准原刊封面标识和 Theorem 1.1 所在论证；OCR 漏掉若干公式，积分式另以 Brent 可读原刊核准。稿件正确排除了网页顶部后期重印 DOI，不混作 1984 原刊。 |
| [BMW]，183、685、748 行 | Heinz H. Bauschke、Walaa M. Moursi、Xianfu Wang，*Generalized monotone operators and their averaged resolvents*；DOI 10.1007/s10107-020-01500-6；arXiv:1902.09827v1，Fact 2.1。[原文](https://arxiv.org/html/1902.09827v1)、[出版社题录](https://link.springer.com/article/10.1007/s10107-020-01500-6) | 本轮直接核准任意 \(T:D\to X\)、\(A=T^{-1}-I\Rightarrow J_A=T\)，无须先假设单调。闭图、半代数与值数的传递是图线性同构推论；严格 RL–EB 兼容不自动继承。文中区分准确。 |
| [B93]，704、754 行 | Wolf-Jürgen Beyn，*On Smoothness and Invariance Properties of the Gauss-Newton Method*，NFAO 14(5–6) (1993), 503–514；DOI 10.1080/01630569308816536；Theorems 2.1–2.2、3.1，(2.1)。[原刊扫描](https://noah.nrw/ubbihs/download/pdf/5114560)、[机构题录](https://noah.nrw/ubbihs/content/titleinfo/5114560) | 本轮直接查看刊本 p. 505：共同初值域上的 \(C\alpha^{2^n}\) 点尾及 \(C^k\) 极限映射均确实出现。满秩、\(C^{k+1}\) 假设不能移到本稿弱 Hölder 模型上；稿件作为同对象的好结构前身引用，准确。Theorem 3.1 对应沿用 D4 的逐页核验。 |
| [P16]，704、755 行 | Paweł Pasteczka，*Iterated Quasi-Arithmetic Mean-Type Mappings*，Colloquium Mathematicum 144 (2016), 215–228；DOI 10.4064/cm6479-2-2016；arXiv:1412.2997v1，Theorems 1–3、§3.2。[原文](https://arxiv.org/html/1412.2997v1)、[作者提交题录](https://arxiv.org/abs/1412.2997v1) | 本轮核准。生成元属于 \(\mathcal S_K\)，尤其 \(C^2\)、\(f_i'\ne0\)、\(f_i''\) 局部有界变差、\(|f_i''/f_i'|\le K\)；该文给双指数尾。AGM 的 \(K=1/\min x\) 不在坏边界统一；任意连续 \(\varphi\) 只属于 \(\varphi\circ M\)，不是任意粗糙极限均值。稿件未错误扩张。 |
| [CHH]，706、756 行 | Shixiang Chen、Yixiao He、Wen Huang，*Retractions by Alternating Projections*，arXiv:2605.17384v2；Assumptions 1–3、Theorems 2–3。[v2 原文](https://arxiv.org/html/2605.17384v2) | 本轮核准 Theorem 2 的 \(C^1\) 极限回缩和 Theorem 3 的 \(C^2\)／二阶回缩；后者确实是回缩的几何阶数，不是点误差 Q-二次的同义词。 |
| [KR]，706、757 行 | Matthew Kvalheim、Shai Revzen，*Reverse-engineering invariant manifolds with asymptotic phase*，arXiv:1608.08442v1；Proposition 1、§3.2.2、Proposition 8、Theorem 2。[v1 原文](https://arxiv.org/html/1608.08442v1) | 本轮核准一般 NHIM 命题先给连续相位；逆向构造明确预设 \(C^r\) 相位，法向支配后的 Theorem 2 给扰动相位 \(C^{r-2}\)。稿件没有把“只证明连续”偷换为“存在非任意 Hölder 反例”。 |
| [LP22]，599、702、749 行 | Jae Hyoung Lee、Tiến-Sơn Phạm，*Openness, Hölder Metric Regularity, and Hölder Continuity Properties of Semialgebraic Set-Valued Maps*；DOI 10.1137/20M1331901；arXiv:2004.02188v2，Lemma 2.2、Proposition 3.1、Theorem 3.1。[v2 原文](https://arxiv.org/html/2004.02188v2) | 本轮复核增长二分的有理幂首项以及闭图半代数的 Hölder 次正则性；它们不把无穷迭代极限变成半代数。非半代数切片论证的引用正确。 |

原五篇起点中 [LT]、[LTTQ]、[LTTP]、[LMZ] 的新稿定位与 D1–D4／最终审计逐项一致。尤其第 700 行不再把 LTTP Theorem 4 说成也假设非扩张；第 702、717、753 行全部明确 LMZ 编号采用 v1。本轮没有重新取得 LMZ 正式版，不签发正式刊本无增改的证明。

## 四、关键优先权比较的独立公式核查

### 1．AGM 宽泛覆盖与精确未覆盖并存

经典积分式给

\[
M(1,\varepsilon)=\frac{\pi}{2K(\sqrt{1-\varepsilon^2})}
\sim\frac{\pi}{2\log(1/\varepsilon)}.
\]

故其选择并非任何正阶 Hölder，且不能半代数。但它的坏参考轨道恰为 \(G^n(c,0)=(c2^{-n},0)\)，因此不满足共同超几何尾，参考轨道也不 Q-二次。稿第 681 行没有将 AGM 正内部的二次率与边界的坏选择错误拼接。

同时，\(1/t\) 与 \(\log t/t\) 相差无界因子。AGM 不提供本稿几何匹配下界，不等于截断证明框架无先例。这两个方向均已在稿中正确分开。

### 2．AGM 标准逆图的兼容性反证没有扩大作用域

对稿第 689 行的直接编码，\((h,0)\) 的整个多值残差最小范数为 \(h\)，到非负对角零集的距离为 \(h/\sqrt2\)。而对输入 \((c,t),(c,0)\)，

\[
(2G-I)(c,t)-(2G-I)(c,0)=(t,2\sqrt{ct}-t),
\]

在 \(0<t\le c\) 时范数至少 \(\sqrt{ct}\)。因此有效 gauge 与 all-pairs 模必使

\[
\frac{\psi((t+\omega(t))/2)}{t}\ge
\frac{\sqrt c}{2\sqrt2\sqrt t}\longrightarrow\infty.
\]

这只是直接编码的反证，不排除所有 lift。稿第 696 行明确保留了这个边界，正确。

### 3．最优性与半代数性没有换量词

第 31、225–230、400–447、581、710、719 行共同保证：

\[
q_{\rm actual}=1/4,\qquad\kappa_R>1/2,\qquad\kappa_R\downarrow1/2,
\]

且一般族有 \(\kappa_*=q(1+(B/A)^2)^{1/(2\gamma)}>q\)（\(B>0\)）。因此“固定实际参数的锐性”没有被改写成“固定保守证书的锐性”。超几何主张只排除 \(\alpha'>\alpha\)，不宣称最佳前常数。

第 7、25、29、383、581、710 行把实参数闭图实现与有理幂半代数实现分开；实系数 \(q,A,B\) 不必有理。标题中的“最优”受上述精确类别约束，不要求删除。

## 五、U1–U3 与其他边界

| 项目 | 修订稿位置 | 核验结果 |
| --- | --- | --- |
| U1：Benyamini–Lindenstrauss Proposition 1.10 原页 | 660、716、758 行 | 保留；没有凭 Wiśnicki 的 Lipschitz 特例断言书中也只含该特例。没有虚称本轮已取得原页。 |
| U2：LMZ 正式版与 arXiv v1 | 702、717、753 行 | 保留；编号和覆盖结论锁定 v1，没有把期刊 DOI 当作版本一致性证明。 |
| U3：Chicone–Liu、Battelli–Palmer 相位全文 | 718 行 | 保留为未排除入口，没有编造定理号／DOI或明确排除结论；Kvalheim–Revzen 则正确移出全文缺口。 |
| 超出当前成果的更强主张 | 719 行 | 固定保守 \(\kappa\)、有限尺度最小 RL 常数、最佳指数前常数、一般 signed-Schur 及所有 AGM 增强实现均没有冒领解决。 |

本轮没有关闭 U1–U3，也没有把“尚未关闭”变成“已有同一先例”。这些入口限制无保留首创性声明，不妨碍将已修补的正文作为具有明确贡献边界的研究稿交回作者继续推进。

## 六、关闭要求

只需落实 P1、P2 两处有限文本补齐，并保持上述版本和量词限制。届时本项可升级为 `REVISION_CLAIMS_PASS`；不要求对原 RLEB 无关内容重审，不要求撤回已经通过数学审计的主结果，也不新增“必须再造一个反例”的门槛。

本项的 PASS 只意味着修订稿的引用及贡献口径与本轮证据相符，不等于世界首创认证或期刊录用许可。
