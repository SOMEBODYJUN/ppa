#!/usr/bin/env bash
# Build only; never modifies the uploaded research assets.
set -euo pipefail
paper_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$paper_dir"
mkdir -p build output/pdf tmp/pdfs
paper_build_dir="$(mktemp -d "$paper_dir/build/latex.XXXXXXXX")"
pandoc research_note.md --from=markdown+tex_math_dollars+raw_tex \
  --to=latex --standalone --template=manuscript_template.tex \
  --lua-filter=prepare_pdf.lua --output="$paper_build_dir/solution_selection_revised.tex"
local_launcher="$paper_dir/../papers/toolchain/run-xelatex.sh"
if [[ -f "$local_launcher" ]]; then
  for build_pass in 1 2 3; do
    bash "$local_launcher" -output-directory="$paper_build_dir" "$paper_build_dir/solution_selection_revised.tex"
  done
else
  for build_pass in 1 2 3; do
    xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error \
      -file-line-error -output-directory="$paper_build_dir" "$paper_build_dir/solution_selection_revised.tex"
  done
fi
cp "$paper_build_dir/solution_selection_revised.tex" solution_selection_revised.tex
cp "$paper_build_dir/solution_selection_revised.pdf" build/solution_selection_revised.pdf
cp "$paper_build_dir/solution_selection_revised.log" build/solution_selection_revised.log
cp "$paper_build_dir/solution_selection_revised.pdf" output/pdf/solution_selection_revised.pdf
pdfinfo output/pdf/solution_selection_revised.pdf
