# C^{1,1}/composite generalized-subregularity attack

Date: 2026-09-09. Task: c11_subregularity_attack.

Status: **PARTIAL for the public direction; PROVED for the quantitative composite module below; KILL as a stand-alone flagship claim in its present form.**

We obtain an explicit, same-target, nonisolated composite verifier, a specified RL–PPA interface, and a nonpower example showing why a general gauge should be retained. Most mechanisms of the current module are classical. The potentially high-value remaining part is rank-deficient, active-changing, second-subderivative-target verification.

## 1. Verified public direction and target

Li–Mordukhovich–Zhu's paper was published online in Mathematics of Operations Research on 7 April 2026, DOI [10.1287/moor.2024.0570](https://pubsonline.informs.org/doi/abs/10.1287/moor.2024.0570). The accessible [arXiv v1](https://arxiv.org/html/2406.13207v1) is dated 19 June 2024. Its §8 explicitly names extension of second-order results to C^{1,1} and composite functions as future work. Publication metadata are verified; theorem-level reading here uses that arXiv version, not an assumed identical final PDF.

Source map: Definition 3.1 defines subregularity relative to a target inside the stationary set. Proposition 6.3 transfers distances between stationary, second-order-stationary, and local-minimum sets using weak separation. Theorem 6.4 and Corollary 6.5 connect this to generalized and KL-derived error bounds. The source puts its gauge on the distance side; our gauge below is on the residual side, requiring inversion.

The extension contains three jobs: define the nonsmooth second-order target; verify local target consistency; produce a usable modulus and radius from native information. Only the first intrinsically needs a replacement for the Hessian. A formal C²→C¹,¹ target-transfer statement alone is not a substantial new theory.

## 2. Hessian-free target transfer

For proper lower-semicontinuous f, define
\[
\Gamma=\{x:0\in\partial f(x)\},\qquad
\Theta_2=\{x\in\Gamma:d^2f(x\mid0)(w)\ge0\quad\forall w\},
\]
\[
d^2f(x\mid0)(w)=\liminf_{t\downarrow0,\,w'\to w}
\frac{f(x+tw')-f(x)}{t^2/2}.
\]
Every local minimizer belongs to \(\Theta_2\subset\Gamma\). For C² f this is the PSD-Hessian target. The second-subderivative target is not new; see [Bodard–Ahookhosh–Patrinos, Definition 2.2](https://arxiv.org/html/2506.22332v1).

### Theorem A — target transfer, PROJECT_PROOF

Let \(\bar x\in\operatorname{dom}f\) be a local minimizer on \(B_\alpha(\bar x)\). Assume weak separation:
\[
y\in\Gamma\cap B_\varsigma(\bar x)\Longrightarrow f(y)\le f(\bar x).
\]
Choose \(0<R<\min\{\alpha,\varsigma\}\). For any set
\[
\{\text{local minimizers of }f\}\subset S\subset\Gamma
\]
and every \(x\in B_{R/4}(\bar x)\),
\[
\boxed{d(x,S)=d(x,\Gamma)=d(x,[f\le f(\bar x)]).}
\tag{A.1}
\]
In particular this holds for \(S=\Theta_2\): an EB for \(\Gamma\) transfers with the same modulus and constants.

Proof. Inside \(B_R(\bar x)\), stationarity plus weak separation and local minimality imply \(f=f(\bar x)\). Such points are local minimizers. Conversely every lower-level point in this ball has that value, is a local minimizer, and is stationary by Fermat's rule. The three sets agree there and contain \(\bar x\). For \(x\in B_{R/4}\), any point outside \(B_R\) is over \(3R/4\) away, while \(\bar x\) is less than \(R/4\) away. Thus distance infima use the common local part. ∎

If only \(\bar x\in\Theta_2\) is known, local minimality still requires a generalized strict-saddle assumption or another certificate: \(-x^4\) has zero second subderivative at zero but no local minimum there. Theorem A extends the source's local-set argument, not a new major mechanism.

## 3. Quantitative C^{1,1} composite verifier

Let \(f=\phi\circ c\), \(F=\partial f\), with:

- \(c:\mathbb R^n\to\mathbb R^m\) C^{1,1} near \(B_R[\bar x]\).
- \(A=Dc(\bar x)\) full row rank, \(\sigma_0=\sigma_{\min}(A)>0\).
- \(Dc\) is \(\beta\)-Lipschitz there, \(\beta R<\sigma_0\).
- \(\phi:\mathbb R^m\to\mathbb R\) finite convex, \(C=\arg\min\phi\ne\varnothing\), \(c(\bar x)\in C\).
- A native outer error-bound gauge, nondecreasing and tending to zero at zero, is known on the relevant image:
  \[
  d(z,C)\le\Psi_\phi(d(0,\partial\phi(z))).
  \tag{B.1}
  \]

Define
\[
\theta=\beta R/\sigma_0<1,\quad
\sigma=\sigma_0-\beta R,\quad J=\|A\|+\beta R,\quad
\boxed{r=\frac{R}{2(1+J/\sigma)}>0.}
\tag{B.2}
\]
Let \(S=c^{-1}(C)\), with global c continuous. A localized target may instead be used only if it is closed, is a subset of the zero set, and has exactly the same intersection with \(B_R(\bar x)\) as this preimage; mere containment of the local preimage is insufficient.

### Theorem B — explicit modulus transfer, PROJECT_PROOF

For \(x\in B_r(\bar x)\),
\[
\boxed{d(x,S)\le\Psi_F(r_F(x)),\qquad
\Psi_F(t)=\sigma^{-1}\Psi_\phi(t/\sigma),\qquad
r_F(x)=d(0,F(x)).}
\tag{B.3}
\]
Inside \(B_R(\bar x)\),
\[
\boxed{\Gamma=\Theta_2=S.}
\tag{B.4}
\]
If native outer data give \(r_{\partial\phi}(z)\ge m\,d(z,C)^a\), then
\[
\boxed{q=1/a,\quad K=\sigma^{-1-1/a}m^{-1/a},\quad
d(x,S)\le K r_F(x)^q}
\tag{B.5}
\]
on the explicit radius (B.2).

Proof. Let \(B=A^\dagger\), so \(\|B\|=1/\sigma_0\), and \(BA\) projects onto \(\operatorname{ran}A^T\). For \(x\in B_r\), select \(\hat z\in P_C(c(x))\). On \(x+\operatorname{ran}A^T\), iterate
\[
\mathcal T_x(y)=y-B(c(y)-\hat z).
\]
The derivative remainder makes this map \(\theta\)-Lipschitz between points of the slice in \(B_R\). Its first displacement is at most \(d(c(x),C)/\sigma_0\); its geometric-series displacement is at most \(d(c(x),C)/\sigma\). Moreover \(d(c(x),C)\le J\|x-\bar x\|\), and
\[
\|x-\bar x\|+d(c(x),C)/\sigma\le (1+J/\sigma)r=R/2.
\]
Thus all iterates remain inside the ball and converge to y with \(B(c(y)-\hat z)=0\). Since B is injective, \(c(y)=\hat z\), so
\[
d(x,S)\le \sigma^{-1}d(c(x),C).
\tag{B.6}
\]
The finite-convex composite chain rule gives
\[
F(x)=Dc(x)^T\partial\phi(c(x)).
\]
Singular-value perturbation gives \(\|Dc(x)^Tv\|\ge\sigma\|v\|\), hence
\[
r_F(x)\ge\sigma r_{\partial\phi}(c(x)).
\tag{B.7}
\]
Equations (B.1), (B.6), and (B.7) prove the modulus; specialization proves (B.5). The same adjoint injectivity says \(0\in F(x)\) iff \(c(x)\in C\). Those points globally minimize f and hence belong to \(\Theta_2\), proving (B.4). ∎

Inputs are \(A,\beta,R\), the outer residual-growth data, and a subgradient bound used next—not a complete graph or solved inverse. Full row rank is a real restriction: multiplier cancellation and rank-changing geometry are not handled.

Novelty boundary: this combines standard submersion/metric-regularity, chain-rule, and convex-growth machinery. Source Lemma 3.6 already uses the full-row-rank composite stationarity mechanism. This checked quantitative plug-in is useful but not a new global mechanism.

## 4. Independent RL, actual coverage, and localization

Suppose all outer subgradients on \(c(B_R)\) have norm at most a known M. Put \(h=\beta M\).

### Theorem C — all-pairs RL and covered localized resolvent, PROJECT_PROOF

For all graph pairs based in \(B_R(\bar x)\),
\[
\langle u-v,x-y\rangle\ge-h\|x-y\|^2.
\tag{C.1}
\]
For a fixed positive \(\lambda\) with \(\lambda h<1\), this supplies
\[
\boxed{\gamma=1,\qquad L=\frac{1+\lambda h}{1-\lambda h}.}
\tag{C.2}
\]
Every input \(x\in B_{R/2}(\bar x)\) has a unique output inside \(B_R\) minimizing
\[
f(y)+(2\lambda)^{-1}\|y-x\|^2
\]
over the closed ball. It is the unique localized proximal solution. For \(x\in B_{r/2}\), the output lies in \(B_r\), where Theorem B applies.

Proof. Convexity of \(\phi\) and the C¹,¹ remainder give, for every \(u=Dc(x)^Tw\in F(x)\),
\[
f(y)\ge f(x)+\langle u,y-x\rangle-\tfrac12M\beta\|y-x\|^2.
\]
Add the reversed inequality to obtain (C.1). For differences a,b, it follows that \(\|a+\lambda b\|\ge(1-\lambda h)\|a\|\). Use the squared identity
\[
\|a-\lambda b\|^2=\|a+\lambda b\|^2-4\lambda\langle a,b\rangle
\le\left(1+\frac{4\lambda h}{(1-\lambda h)^2}\right)\|a+\lambda b\|^2.
\]
The parenthesis is \((1+\lambda h)^2/(1-\lambda h)^2\), proving (C.2). The proximal objective is strongly convex on the ball, with modulus \(1/\lambda-h\); compactness gives its unique minimizer. At a boundary point its value exceeds that at \(\bar x\) because \(f\ge f(\bar x)\) and \(R-\|x-\bar x\|>\|x-\bar x\|\). The minimizer is interior and satisfies the proximal inclusion. Its value comparison gives \(\|y-x\|\le\|x-\bar x\|\), so \(\|y-\bar x\|\le2\|x-\bar x\|\). ∎

No claim is made about remote graph branches. On actual covered transitions, T5 gives
\[
\boxed{d(x^+,S)\le\Psi_F\left(
\frac{d(x,S)}{\lambda(1-\lambda h)}\right).}
\tag{C.3}
\]
For \(\Psi_F(t)=Kt^q\), \(q>1\), set \(A_q=K[\lambda(1-\lambda h)]^{-q}\). Any desired \(\kappa\in(0,1)\) is certified for
\[
d\le(\kappa/A_q)^{1/(q-1)}.
\tag{C.4}
\]
The explicit whole-orbit localization budget is
\[
\|x^0-\bar x\|+
\frac{d(x^0,S)}{(1-\lambda h)(1-\kappa)}<r/2.
\tag{C.5}
\]
When the initial distance satisfies (C.4) and the initial position satisfies (C.5), the geometric-series step bound preserves coverage, proves finite length and point convergence. Also \(d_{k+1}\le A_qd_k^q\).

This is a legal independent-certificate application. Its small-step prox-regular/hypomonotone geometry has gamma=1, not genuine non-Lipschitz RL.

## 5. Curved non-C² model: powers and genuinely useful nonpower gauge

Take
\[
c(s,t)=t-(s_+)^2,\quad Dc=(-2s_+,1),\quad \beta=2,\quad
S=\{(s,(s_+)^2):s\in\mathbb R\}.
\]
This c is C¹,¹ but not C². S is curved and nonisolated, without appending a free direct-product coordinate.

Let eta be continuous, strictly increasing and unbounded on the nonnegative half-line, with eta(0)=0, and set
\[
\phi(z)=\int_0^{|z|}\eta(u)\,du,\quad f=\phi\circ c.
\]
Then
\[
F=\eta(|c|)\operatorname{sign}(c)(-2s_+,1),\qquad
\Gamma=\Theta_2=S,\qquad
r_F=\eta(|c|)\sqrt{1+4s_+^2}.
\]
Vertical repair gives the sharper model-specific estimate
\[
\boxed{d((s,t),S)\le\eta^{-1}(r_F(s,t)).}
\tag{D.1}
\]
On a ball \(B_R(0)\), let \(d_0=R+R^2\). Then
\[
h=2\eta(d_0),\qquad
L=(1+\lambda h)/(1-\lambda h),\quad\gamma=1,\quad\lambda h<1.
\tag{D.2}
\]

### 5.1 Power case

For \(\eta(u)=u^a\), \(0<a<1\), the exact best EB power at zero is \(q=1/a\), with valid K=1.

To prove optimality, take \((s,t)=(0,t)\), \(0<t<1/2\). The nearest point of S is zero: for the curved half, writing \(v=s^2\ge0\), squared distance is \(v+(t-v)^2\), increasing in v; the flat half also projects to zero. Thus d=t and \(r_F=t^a\), excluding every larger exponent. Theorem C now gives a fully explicit local superlinear PPA certificate.

### 5.2 Nonpower case

For \(0<u\le1\), take
\[
\eta(u)=u\log(e/u),\qquad\eta(0)=0,
\]
extended by \(\eta(u)=u\) for \(u\ge1\), so its global inverse is well-defined. On \(|z|\le1\),
\[
\phi(z)=\tfrac34z^2-\tfrac12z^2\log|z|,\qquad\phi(0)=0.
\]
The valid gauge is
\[
\boxed{\Psi_F(r)=\eta^{-1}(r)\sim r/\log(1/r)=o(r).}
\tag{D.3}
\]
No power EB with q>1 holds: along the same vertical ray,
\[
\frac d{r_F^q}=\frac{t^{1-q}}{[\log(e/t)]^q}\longrightarrow\infty.
\]
Put \(b=[\lambda(1-\lambda h)]^{-1}\). The actual PPA estimate is
\[
d_{k+1}\le\eta^{-1}(bd_k),\qquad d_{k+1}/d_k\to0
\quad\text{unless finite termination occurs}.
\tag{D.4}
\]
For \(\kappa\in(0,1)\), a positive scalar contraction radius is
\[
\boxed{r_\kappa=
\min\{1/\kappa,\ (e/\kappa)\exp(-b/\kappa)\}.}
\tag{D.5}
\]
Indeed \(bd\le\eta(\kappa d)\) iff \(b\le\kappa\log(e/(\kappa d))\). Impose both \(d(x^0,S)\le r_\kappa\) and the positional budget (C.5).

On the invariant vertical ray, the scalar inclusion is exactly
\[
t_k=t_{k+1}+\lambda t_{k+1}\log(e/t_{k+1}),
\]
whose positive solution is the unique localized proximal output by Theorem C. Therefore
\[
t_{k+1}\sim t_k/[\lambda\log(1/t_k)].
\]
It is superlinear but has no uniform Q-order greater than one along this orbit. General gauges retain rate information that no power q>1 encodes. This does not contradict power-envelope restrictions for fixed Q-linear compatibility.

### 5.3 Genuine multivalued variant

Use \(\phi(z)=\nu|z|+\int_0^{|z|}\eta(u)\,du\), \(\nu>0\). At c=0,
\[
F(s,t)=Dc(s,t)^T[-\nu,\nu].
\]
Off S its residual is at least nu. Consequently any actual proximal transition with step residual below nu must land in S. This is exact-penalty/identification behavior, already closely related to classical identifiable-manifold theory—not a new nonlinear RL mechanism.

## 6. Obstructions

### 6.1 C¹,¹ gradients do not create q>1 EB

If single-valued F is ell-Lipschitz near its closed zero set S, then \(\|F(x)\|\le\ell d(x,S)\). If nonzero distances approach zero, an EB \(d\le K\|F\|^q\), q>1, would imply \(1\le K\ell^q d^{q-1}\to0\), impossible. Thus extending only to C¹,¹ gradients cannot supply the q>1 needed for genuine gamma<1 fixed-Q-linear matching. A non-Lipschitz outer component or a different rate mechanism is needed.

### 6.2 Missing weak separation destroys target-correct EB

Let \(f(0)=0\) and \(f(x)=e^{-1/x^2}(2+\sin(1/x^4))\) for x nonzero. It is C-infinity, positive away from zero, with a global minimum at zero. It has strict local maxima \(x_k\to0\): with \(u=1/x^4\), the derivative sign is that of
\[
\cos u-\frac{2+\sin u}{2\sqrt u},
\]
which crosses from positive to negative near \(2\pi k+\pi/2\), with negative derivative there. At the corresponding x, the Hessian is negative. Hence \(x_k\in\Gamma\setminus\Theta_2\), residual zero but \(d(x_k,\Theta_2)>0\). No admissible EB toward \(\Theta_2\) holds on a full neighborhood. WSP fails because \(f(x_k)>f(0)\).

### 6.3 WSP does not permit an arbitrary smaller target

For \(f(x,y)=x^2\), WSP holds and \(\Gamma=\{0\}\times\mathbb R\). Choosing \(S=\{(0,0)\}\) makes the residual zero at \((0,t)\) but the target distance positive. One cannot silently turn nonisolated ordinary subregularity into a point-target estimate.

### 6.4 Clarke-Hessian substitution can be wrong

Let \(a=11/10\), \(g(0)=0\), and
\[
g(x)=x^2(a+\sin\log|x|)\quad(x\ne0).
\]
Then g is C¹,¹ and \(g(x)\ge(a-1)x^2\), so zero is a strong local minimum. For x nonzero,
\[
g''(x)=2a+\sin\log|x|+3\cos\log|x|.
\]
Its Clarke generalized Hessian at zero is
\[
[2a-\sqrt{10},\,2a+\sqrt{10}],
\]
which contains negative values. Requiring every generalized Hessian to be PSD excludes this minimizer. For minus g, zero is a strict local maximum while its Clarke interval contains positive values; requiring some PSD generalized Hessian admits that maximum. The correct necessary quantity is
\[
d^2g(0\mid0)(w)=2(a-1)w^2\ge0.
\]

## 7. Legitimate roles of existing tools

| Tool | Role | Missing automatic conclusion |
|---|---|---|
| Clarke generalized Hessian | Neighborhood curvature bounds; hypomonotonicity; inverse sufficient tests | Canonical pointwise PSD characterization of the second-subderivative target |
| Second subderivative/epi-derivative | Correct quadratic necessary condition; composite critical-cone calculus | Residual EB, explicit constants, or target consistency |
| Limiting/directional coderivative of the actual residual | Metric regularity/subregularity under qualified no-abnormal-multiplier conditions | All-pairs RL or high-order growth from only first-order homogeneous data |
| KL/Łojasiewicz/slope tools | Gauge or power EB to lower-level/minimizer sets; growth conversion | Identity with the intended second-order target or optimal native constants |

## 8. Closest-literature collision audit

Targeted primary-source reconnaissance on 2026-09-09; not a systematic review. Independent dynamic-agent audit checked the theorem locations except the abstract-only item.

| Source | Verified overlap | Consequence |
|---|---|---|
| [Bodard–Ahookhosh–Patrinos 2025](https://arxiv.org/html/2506.22332v1), Def. 2.2, Thm. 3.6 | Uses the actual second-subderivative SOS target; FBE-Hessian equivalence restores a continuously existing Hessian for the smooth part | Correct target is existing; non-C² data-level verification may distinguish a stronger theorem |
| [Wu–Xie 2026](https://arxiv.org/html/2605.02754v1), Thms. 3.1, 5.1 | Identifiable-manifold EB transfer; C¹,¹ plus ell1 composite under relative-interior stationarity; nonisolated minimizers | Active-manifold transfer alone is not a flagship. Some PDF extracts number HTML Thm. 5.1 as Thm. 7 |
| [Liu–Pan–Qian 2025](https://arxiv.org/html/2311.06871v4), Eq. (4), Thm. 12; [SIAM DOI](https://epubs.siam.org/doi/10.1137/23M1618697) | Composite proximal-Newton rate under assumed Hölder EB to a special second-order set, allowing nonisolated solutions | Smooth part remains C²; its target differs from the second-subderivative target; EB still needs verification |
| [Liao–Ding–Zheng](https://arxiv.org/html/2312.16775v2), Thm. 3.1, Table 1; [2026 journal](https://link.springer.com/article/10.1007/s10898-025-01585-3) | Weakly-convex growth/EB/PL conversions with explicit constants, nonisolated minimizers | Explicit weak-convex EB conversion is already existing |
| [Wang–Li–Hu–Li–Li](https://arxiv.org/html/2308.08735v1), Thm. 3.1 | Uniformized KL, level-set EB and Hölder growth for prox-regular functions, exponents and constants | Generic KL/growth conversion is supporting machinery |
| [Ma–Ouyang–Ye–Zhang 2025](https://arxiv.org/html/2507.12682v1), Thm. 4.4, Cor. 4.5 | Second-order sufficient conditions for growth relative to nonisolated solution sets | Reviewed data remain C²; residual bridge remains separate |
| [Gao–Ouyang–Zhang–Zhu 2025](https://link.springer.com/article/10.1007/s11228-025-00753-7) | Abstract verifies generalized/Hölder subregularity for generalized-subsmooth multifunctions | Full theorem unavailable here; unresolved novelty gate for general graph verifiers |
| [Liu–Pan 2024](https://link.springer.com/article/10.1007/s10589-024-00560-0), Lemma 2 | KL 1/2 plus growth gives linear EB to a special composite second-order set | Generic KL+growth→SOS EB is not new |

An additional nearby [Lee–Wright 2026 preprint](https://optimization-online.org/wp-content/uploads/2026/02/degeneratePN_new.pdf) treats proximal Newton-like generalized equations and Hölder EB with weak Jacobian smoothness; reviewed at abstract/excerpt level here. Again a convergence theorem assuming EB differs from a verifier.

Recorded searches:

- “Generalized Metric Subregularity” “C^{1,1}” composite 2025 2026
- “Generalized Metric Subregularity with Applications” “Mathematics of Operations Research” 2026
- C1,1 composite second-order stationary error bound generalized subregularity 2026
- site:pubsonline.informs.org “Generalized Metric Subregularity” “Li”

No reliable total hit counts were exposed. DOI/arXiv identity and titles were used for deduplication; versions are grouped. These searches do not prove a universal literature absence.

## 9. Contribution and flagship decision

PROVED here:

1. Hessian-free same-target transfer with a positive explicit radius.
2. C¹,¹ full-row-rank convex-composite verifier producing a general gauge or (q,K,r) for the correct nonisolated target.
3. Independent all-pairs gamma=1 RL, input coverage, and T5 orbit localization.
4. Curved non-C² power example with optimal exponent.
5. Curved nonpower example with superlinear PPA but no q>1 power EB, including exact invariant-orbit asymptotic.
6. WSP, target, and Clarke-Hessian counterexamples.

NOT PROVED:

- The whole published C¹,¹/composite second-order convergence extension.
- Rank-deficient or active-changing native second-order verification with general computable gauges.
- A genuine nonlinear RL separation or superiority over prox-regular/partial/KL/PPA frameworks.
- Global priority or top-journal readiness.

Keep the module in the RL manuscript: it answers the native-data verification question and supports retaining general gauges. Do not promote the current module alone as a SIOPT/Mathematical Programming flagship. Its mechanism is too close to classical submersion/chain-rule/weak-convexity tools; recent collisions are substantial. This is a research-value assessment, not an acceptance prediction.

## 10. Smallest next theorem worth a flagship attack

For \(f=g+\phi\circ c\), with c,g C¹,¹ and phi convex PLQ or prox-regular twice epi-differentiable, permit rank loss in Dc and active-face changes. Keep the exact target
\[
\Theta_2=\{x:0\in\partial f(x),\ d^2f(x\mid0)\ge0\}.
\]
From finite active-face data, neighborhood generalized-derivative enclosures, target-consistency radius, and quantitative no-cancellation for all relevant multipliers, derive
\[
d(x,\Theta_2)\le\Psi(d(0,\partial f(x)))
\]
with computable gauge and radius, allowing nonisolated solutions. Do not assume an equivalent residual-growth condition as input. Include a genuinely non-C², rank-deficient, active-changing model and compare directly with Wu–Xie identification and generalized-subsmooth criteria.

If completed broadly and with an algorithmic consequence inaccessible to the closest assumptions, this could support a serious SIOPT/MOOR/MP submission. That is not the result currently proved.

## 11. Execution check

The standard-library script [verify_c11_composite.py](verify_c11_composite.py) was executed successfully. For inputs \(10^{-k}\), k=10,30,100,300,1000,10000, it solves the exactly scaled logarithmic PPA equation without underflow. The ratio of its output to \(t/[\lambda\log(1/t)]\) was respectively 0.81159, 0.91614, 0.96857, 0.98777, 0.99579, 0.99948. It also checks the RL squared-constant identity and the sign-changing Clarke-Hessian interval. This supports arithmetic, not the theorems' proofs. Symbolic/multiprecision packages were unavailable; no packages were installed.

## 12. Evidence / execution contract

~~~yaml
contract_version: "1.0"
expert_skill: [sci-skills-paper-deep-reading, sci-skills-literature-search]
project_id: null
paper_family: theoretical
stage_id: null
task_id: c11_subregularity_attack
task_status: PARTIAL
inputs_reviewed:
  - Uploaded T5 definitions and certificate scope
  - Li–Mordukhovich–Zhu arXiv v1 Sections 3, 6, 8
  - MOOR official publication record
  - Primary collision literature in Section 8
outputs: [ATTACK_C11_COMPOSITE_GENERALIZED_SUBREGULARITY.md, verify_c11_composite.py]
evidence_status:
  - VERIFIED_USER_MATERIAL: T5 interface
  - VERIFIED_SOURCE: public direction and theorem-level collision statements
  - PROJECT_PROOF: Theorems A–C, models and counterexamples
  - EXECUTED_LOCAL: standard-library scalar-equation and constant checks
  - PENDING_VERIFICATION: global novelty and final-publisher theorem identity
  - PENDING_VERIFICATION: Gao et al. full-theorem novelty gate
assumptions:
  - Finite-dimensional Euclidean setting
  - Full-row-rank and finite-convex restrictions are not waived
  - Targeted reconnaissance, not systematic literature coverage
author_input_needed: []
manual_actions: []
quality_checks:
  - Separated residual-side and distance-side gauges
  - Proved local target equality
  - Supplied explicit radii and proximal coverage
  - Proved lower-bound obstructions on actual sequences
  - Separated mathematical proof from novelty
  - Independent dynamic-agent collision audit performed
  - Independent math audit passed Theorems A–C and logarithmic model after stated target/inverse/domain repairs
conflicts: []
conflict_resolution_status: NOT_REQUIRED
merge_permission: orchestrator_only
recommended_next_action: Attack the rank-deficient active-changing target-correct verifier in Section 10.
stage_acceptance_recommendation: REPAIR
~~~

Primary next action: attack Section 10's rank-deficient, active-changing, target-correct verifier; retain Theorems A–C as the checked baseline that a stronger result must surpass.
