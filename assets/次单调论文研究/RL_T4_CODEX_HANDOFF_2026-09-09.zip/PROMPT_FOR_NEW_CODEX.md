# RL–PPA 论文 T4 修复任务（交给新的 Codex 对话）

你正在处理一篇有限维 Euclidean 空间中的理论论文。核心对象是集合值算子

\[
F:\mathbb R^n\rightrightarrows\mathbb R^n,
\qquad J_{\lambda F}=(I+\lambda F)^{-1},
\]

以及 all-pairs RL 条件

\[
\|a-\lambda b\|\le L\|a+\lambda b\|^\gamma,
\qquad 0<\gamma\le1,
\]

和独立的 generalized metric subregularity

\[
d(y,S)\le\psi(d(0,F(y))).
\]

论文希望用二者控制实际 PPA 转移、覆盖、有限长度以及到非孤立零集中的一个点的收敛。请注意：all-pairs RL、解比较证书、允许转移证书是不同量词；resolvent 单值性与输入覆盖也是不同问题。

## 输入文件

1. `RL_PPA_generalized_subregularity_Boluo.tex`：当前 38 页主稿，也是唯一应当被视为最新版的正文。
2. `RL_PPA_generalized_subregularity_Boluo.pdf`：当前编译效果，仅供核对。
3. `RL_FLAGSHIP_UPGRADE_ARCHITECTURE.md`：已有但未完成验收的 T4 架构材料。
4. `ATTACK_C11_COMPOSITE_GENERALIZED_SUBREGULARITY.md`：包含一个尚未并入主稿的非幂 gauge、真实 PPA 轨道候选。
5. `verify_c11_composite.py`：该模块的计算校核脚本。

不要把其他历史稿当作最新版，也不要假定输入文件中的 novelty 判断已经成立。

## 已知审稿诊断（必须独立复核）

1. 当前结构实例中，Corollary 5.3 的算法结论被 Proposition 5.4 以更弱条件、全局范围和严格更优速率支配。
2. 主稿只给出抽象的 logarithmic gauge，没有展示一个超越幂律的真实算子与实际 PPA 轨道。
3. 尚无证据表明全文被既有理论完全覆盖，但必须进行定理级比较：
   - Li–Mordukhovich–Zhu, *Generalized Metric Subregularity with Applications to High-Order Regularized Newton Methods*, Theorems 4.3–4.4；
   - Luke–Thao–Tam, *Quantitative Convergence Analysis of Iterated Expansive, Set-Valued Mappings*, 2018；
   - Leventhal, *Metric Subregularity and the Proximal Point Method*, 2009。
4. 当主稿 (3.25) 中 `L=1` 时，应明确核对其是否精确恢复
   \[
   K/\sqrt{K^2+\lambda^2}
   \]
   的经典单调 PPA 因子。
5. 当前最值得保留的候选主成果是 Proposition 3.5、Theorem 5.1、Proposition 5.2，以及完整逆的 genuine non-Lipschitz 性和跨活跃面分析。

## 本轮任务边界：先修复 T4，不要立即重写 LaTeX

本轮目标是形成可验收的“论证框架与章节结构”，并解决主稿究竟应该以什么为主线。不要先润色句子，不要先生成新 PDF，也不要直接覆盖原始 `.tex`。

### 任务 A：重建贡献等级

逐项审计主稿所有 Lemma/Theorem/Proposition/Corollary，给出：

- 数学作用；
- 是否被本文后续结果支配；
- 与既有文献的重合范围；
- 应保留为主定理、降级为诊断/例证、移入附录，还是删除；
- 支撑它的准确文件位置和公式。

必须专门处理 Corollary 5.3 与 Proposition 5.4 的关系。不得把“通用证书成功应用”与“该结构类最强收敛定理”混为一谈。

### 任务 B：一般 gauge 的真实例子

先独立核验 `ATTACK_C11_COMPOSITE_GENERALIZED_SUBREGULARITY.md` 中的非幂例子，包括：

- 算子、零集、residual、gauge、PPA 转移是否属于同一问题；
- \(\psi(r)\sim r/\log(1/r)\) 的推导；
- 为什么不存在能表达该精确超线性轨道的统一 \(q>1\) 幂律误差界；
- 实际轨道
  \[
  t_k=t_{k+1}+\lambda t_{k+1}\log(e/t_{k+1})
  \]
  及其渐近式是否正确；
- 是否存在一个更直接的已知证明完全支配 RL–gauge 论证。

运行并审查校核脚本，但数值脚本不能代替数学证明。

然后检索或构造额外候选，目标是判断能否得到一个更强的实例：实际 PPA、一般非幂 gauge，最好同时具有 genuine \(\gamma<1\)、集合值结构或非孤立零集。不得为了满足目标而伪造例子；如果做不到，明确证明或说明卡在哪里。每个候选都必须排查直接法、KL、almost-averaged、已有 Hölder/generalized-subregularity PPA 理论是否已经给出同等或更强结论。

### 任务 C：三组定理级文献比较

只使用原始论文或官方版本。逐一定理比较：对象、几何假设、正则性假设、是否允许一般 gauge、是否处理多值迭代、是否给有限长度/点收敛、速率类型和显式常数。

特别回答：

1. Li–Mordukhovich–Zhu Theorems 4.3–4.4 已经覆盖主稿哪些抽象比较序列与一般 gauge 结论？没有覆盖哪些 RL 图几何、尖锐常数或完整逆验证？
2. Luke–Thao–Tam 2018 的 almost-averaged/expansive set-valued mapping + metric subregularity 框架与本稿在哪个精确切片重合？
3. (3.25), `L=1` 与 Leventhal 2009 的因子是否完全相同？如果相同，给出可直接放进正文的恢复声明。

“没有检索到”不得写成“首次”。

### 任务 D：形成可执行的 T4 论文结构

输出一个新的详细提纲。每节必须写明：

- 本节唯一论证任务；
- 输入假设和依赖的前置结果；
- 主要定理/反例；
- 回应哪个潜在审稿反驳；
- 对总贡献的作用；
- 是否需要正文、附录或删除。

结构必须把最强贡献放在前台，不能按研究发生时间堆放。必须明确一般 gauge 例子应放在哪里，以及 Corollary 5.3 应如何降级、改名、移位或删除。

## 交付文件

请在不修改原始输入文件的前提下生成：

1. `RL_T4_REPAIR_DOSSIER.md`：完整 T4 诊断、贡献等级和定理级文献比较。
2. `RL_GENERAL_GAUGE_EXAMPLE_AUDIT.md`：现有例子的逐步核验、额外候选及最终选择。
3. `RL_V2_REVISION_MAP.md`：新版详细提纲，精确到旧稿中哪些段落/命题保留、移动、改写、删除。
4. 如有符号或数值校核，保存可复现脚本及运行结果；不得用脚本代替证明。

## 验收标准

- 贡献主线不再依赖被 Proposition 5.4 支配的 Corollary 5.3。
- 至少有一个同算子、同零集、同残差、同实际 PPA 的非幂 gauge 轨道通过证明核验；若未通过，必须明确拒绝写入。
- 三组关键文献完成定理级而非摘要级比较。
- 明确区分：项目证明、原始文献已知、待核实、推断。
- 不把 \(\gamma=1\) 的非幂例子误写成 genuine nonlinear RL。
- 不把 transition-level 结论误写成 all-pairs RL，也不从单值性偷换覆盖性。
- 给出的新提纲可以直接作为下一轮 LaTeX 重写的施工图。

完成后先简要报告最重要的三项判断，再提供全部交付文件链接。不要声称论文已经完成或可以投稿。
