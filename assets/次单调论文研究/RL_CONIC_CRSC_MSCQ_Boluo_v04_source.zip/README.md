# Frozen minimal-face constant rank and metric subregularity over amenable cones

Author: 菠萝. Version: v0.4, September 9, 2026.

This source package contains the English LaTeX manuscript and its verified-reference bibliography. No affiliation, email, funding, or coauthor information has been inferred.

Version 0.4 corrects only the visible author name and PDF author metadata to 菠萝 and updates the version identifier. The document body, mathematical content, bibliography, and layout commands remain identical to version 0.3. Earlier version 0.3 applies the bounded final-review repairs recorded in the ledger.

## Files

- `main.tex`: mathematical manuscript.
- `references.bib`: 12 verified core works, plus a separate citation record for the reviewed author version of the closest paper (13 entries total).
- `main.bbl`: bibliography produced by the successful BibTeX run.
- `build.sh`: build/render script for the Linux environment in which this package was produced.
- `DRAFT_LEDGER.md`: internal evidence, scope, and unresolved release gates; not a submission appendix.
- `BUILD_REPORT.md`: actual compilation and visual-QA record.
- `expert-result.yaml`: SCI expert return contract; not manuscript content.
- `author-cjk.ttf`, `author-cjk.enc`, `author-cjk.tfm`: bundled native pdfLaTeX resources for the exact author name.
- `build_author_font.py`, `FONT_SOURCE.md`: optional font-resource regeneration and provenance.

## Ordinary TeX Live build

From the extracted directory, use a normally configured TeX Live installation:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

Or run pdfLaTeX once, BibTeX on `main`, then pdfLaTeX repeatedly until references stabilize. Packages are standard TeX Live packages; the body uses Latin Modern and AMS mathematical fonts. Keep the three bundled `author-cjk` resources beside `main.tex`: they render the Chinese author name directly, without a separate CJK package or system-font installation.

The supplied `build.sh` has a workspace-local workaround for missing generated TeX databases/formats in the producing environment and calls system Poppler for page QA. It does not install software or change system files. That workaround is not needed in an ordinarily configured TeX installation.

## Mathematical and evidence scope

The manuscript retains the frozen finite-dimensional proper-cone scope. Nice cones give nearby facial stability and a common-manifold normal correction; the linear original-residual bound additionally uses amenability of the reference face in the original cone. The universal characterization allows constants and neighborhoods to vary across maps and faces.

The two positive models are coupled SOC and PSD examples. General local constants do not identify a numerical validity radius; the separately proved direct bounds are explicitly valid on the radius-one-quarter ball. The LRS counterexample's actual residual is positive and O(t^5), not proved Theta(t^5). Numerical lower-bound-ratio checks are not certified cone-distance computations or replacements for the analytic proof.

## Remaining release gate

The final published theorem text of DOI `10.1007/s10107-025-02237-w` has not been compared with the March 20, 2025 author manuscript. The bibliography distinguishes the verified final publication record from the separately reviewed author version. The paper's comparison is version-qualified and asserts no worldwide-first result. The internal ledger preserves this unresolved final-version/priority gate. No submission or external coordination has been performed.
