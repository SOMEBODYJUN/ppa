# Build report: RL-CONIC-2026 / MW-MASTER-V04

## v0.4 exact-author-name outcome (current)

The PDF-visible author and PDF author metadata are both exactly **菠萝**. The final deliverable is `output/conic_paper/RL_CONIC_CRSC_MSCQ_菠萝_v04.pdf`, identical to the current `latex_v01/main.pdf`. It has **20 A4 pages**, 433,772 bytes, and subject `Theoretical manuscript v0.4`.

Only the author-name implementation, metadata, and version identifiers changed in the LaTeX preamble. The entire document body and `references.bib` are byte-for-byte identical to the preserved v0.3 source archive. Both the extracted PDF text and the 90-dpi JPEG renders of pages 2-20 are byte-for-byte identical to v0.3. No mathematical text, citation, theorem numbering, layout command, or page-placement logic was changed.

### Existing-font route and compilation

The installed PyMuPDF/MuPDF runtime contains a Droid Sans Fallback CJK font exposed by `fitz.Font("china-s")`. Both required code points are present. A 1,300-byte subset plus a two-character encoding and TeX metrics now supply the author line through native pdfLaTeX font embedding. Unicode mappings make the name searchable and extractable. The final PDF contains 22 font instances, all embedded, subsetted, and Unicode-mapped, including the new TrueType author font.

The optional `build_author_font.py` regenerates the three bundled font resources using installed fontTools and `ttf2tfm`; ordinary compilation needs only the supplied resources. An initial font-metric probe required explicit PostScript glyph names; this was corrected before the final build. No font download, installation, system-file edit, privilege escalation, or post-build PDF overlay was used. The PDF skill's edit-operation marker ran exactly once before the first v0.4 authoring patch.

`bash build.sh` completed four pdfLaTeX passes and one BibTeX pass with exit status 0. The final LaTeX and BibTeX logs contain no warnings, errors, undefined references/citations, overfull/underfull boxes, or missing-character messages. The 13-entry bibliography and generated `main.bbl` retain their v0.3 hashes.

### Verification and visual QA

| Check | Final result |
|---|---|
| Visible author | 菠萝, centered on the title page |
| Author metadata | 菠萝 |
| First-page extracted text | Contains 菠萝; does not contain Boluo |
| Page count | 20 |
| Font embedding | 22 of 22 instances embedded/subsetted/Unicode-mapped |
| Full-page visual QA | All final pages `qa/v04-01.jpg` through `qa/v04-20.jpg` individually inspected |
| Additional first-page check | Independent reviewer confirms exact readable 菠萝 and no visible layout anomaly |
| Body and bibliography source comparison | Byte-for-byte unchanged from v0.3 |
| PDF pages 2-20 text comparison | Identical to v0.3 |
| PDF pages 2-20 JPEG render comparison | All 19 images byte-for-byte identical to v0.3 |
| Clipping, overlap, missing glyphs, broken tables | None observed |

The final JPEG render command was `/usr/bin/pdftoppm -r 90 -jpeg main.pdf qa/v04`. No mathematical verification script or external literature search was rerun for this author-only repair.

### Final fingerprints and package

```text
4da7f81e1907a866f656eb2ab4da98e1efc2f156c5370c89016f2cba3c7a9af3  main.tex
14cf0474d90a34fa9c3aa4b89bf409446aca78975d31925823861fd1d4533ef5  references.bib
75cc4d3dd2cbc30c58722f5929c16e4edaf19c47773162ea533ff4e3d6a9ca18  main.bbl
273086ca09fbc68cbb0ee2eb59313994dc86b434281dcc8ff777618edc52b6c3  main.pdf / RL_CONIC_CRSC_MSCQ_菠萝_v04.pdf
```

`RL_CONIC_CRSC_MSCQ_Boluo_v04_source.zip` contains 13 files: the eight manuscript/build/ledger files in v0.3, the three `author-cjk` font resources, `build_author_font.py`, and `FONT_SOURCE.md`. It excludes the separately delivered PDF, caches, logs, and QA renders. Its members are checked by ZIP integrity test and compared byte-for-byte with the final files.

The previous files are preserved: `RL_CONIC_CRSC_MSCQ_Boluo_v03.pdf` retains SHA-256 `2b3fb0f8aa4c987bd3d3e8916bed1f7884df82bc5b4f5aeec8ccf49d68ba3306`, and `RL_CONIC_CRSC_MSCQ_Boluo_v03_source.zip` retains `83b218e42dbbb10f241bd565e77f87baa6eb84bb306ace7b20dd4f2d4b0c2d84`.

No author-name, compile, or layout blocker remains. The prior M01 final-version/priority reservation is unchanged. The orchestrator retains final saving and stage authority.

Primary next action: deliver the author-corrected v0.4 PDF and complete source package.

---

## Historical v0.3 build record (author display superseded above)

### v0.3 outcome (historical)

Date: 2026-09-09. The bounded red-team repair is complete. The current `main.pdf` has **20 A4 pages**, 432,856 bytes, author metadata `Boluo`, and subject `Theoretical manuscript v0.3`. The source has 1,476 lines. All 20 final pages were rendered and individually inspected; no clipping, overlapping content, unreadable equation, missing glyph, or broken table was observed.

The four `FINAL_*_REDTEAM_V02.md` reports were read completely. The bibliography is unchanged: 13 cited records for 12 works, with the reviewed M01 author version separate from its published metadata record. No new theory, citation, example, experiment, or algorithmic claim was introduced.

### Repair and bounded regression

| Requested repair | Final location | Result |
|---|---|---|
| Restore relative-correction hypotheses | Lemma 4.1, page 8 | Explicit Section 3 standing hypotheses, proper nice C, frozen CRSC, and the common M of Lemma 3.5 |
| Correct input/output antecedent | Lemma 4.1 proof, page 8 | d0 is explicitly in ker(P_H A) |
| Limit global A1/A2 by niceness | Proposition 4.5, page 9 | Same niceness assumption stated in the sentence |
| Front-load the three main results | Numbered list at the start of page 2 | Theorems 3.3, 4.2, 4.6 and supporting corollary/proposition links resolve |
| Neutralize the external-project interface | Section 7, page 18 | Generic operator, local zero-set agreement, independently supplied residual comparison, displayed local bound and gauge |
| Small clarity changes | Abstract; organization; Section 5 projection; Section 6.3 introduction; Table 2 | No stronger result or radius claim |

The original mathematical reviewer performed one bounded read-only regression of `lem:relative`, its d0 sentence, and `prop:inclusion` after repair. The returned verdict was **PASS**, with no residual blocker, major, or minor issue for FM-M01, FM-m01, and FM-m02. The reviewer sent the result directly to both the editor and the orchestrator. The subsequent source change only placed the introductory result block at the start of a page; it did not alter these mathematical statements.

### Actual compilation and visual QA

The PDF skill's edit-operation marker ran successfully exactly once before the first v0.3 authoring patch. `bash build.sh` reused the existing workspace-local TeX format and installed font maps, ran four pdfLaTeX passes and one BibTeX pass, and generated PNG pages and extracted text with system Poppler. No installation, system-file change, escalation, or external API was used.

The first build had 19 pages, but its main-results lead-in was separated from the numbered list. A local page-placement correction brought the lead-in and all three entries together at the start of page 2. The final complete build then produced 20 pages. The latest PDF was rendered with `/usr/bin/pdftoppm -r 90 -jpeg main.pdf qa/v03` and pages `qa/v03-01.jpg` through `qa/v03-20.jpg` were each visually inspected. The bibliography continues normally onto page 20; the final page contains three complete entries.

| Final check | Result |
|---|---|
| Build exit status | 0 |
| LaTeX/BibTeX warnings and errors | None |
| Undefined references or citations | None |
| Overfull/underfull boxes or missing characters | None |
| Bibliography keys versus used keys | 13 versus 13; zero missing, zero unused |
| Changed bibliography metadata | None; references.bib and main.bbl retain their v0.2 hashes |
| Public RL-PPA / separately verified / production placeholders | None |
| Font embedding | All 21 listed font instances embedded, subsetted, and Unicode-mapped |
| Full-page visual QA | 20 of 20 final pages individually inspected |
| Source archive integrity | Eight intended files; ZIP integrity and byte-for-byte source matching checked |

The mathematical numerical scripts were not rerun or modified. Their evidence remains described only as numerical lower-bound-ratio checks, not certified true-residual calculations. The final repair does not provide a fresh full proof audit or global-priority certification.

### Final fingerprints

```text
29ff1346b9114290fa63adeec2f751a8fb7cbdf328e12d5c10b9fd393af722c0  main.tex
14cf0474d90a34fa9c3aa4b89bf409446aca78975d31925823861fd1d4533ef5  references.bib
75cc4d3dd2cbc30c58722f5929c16e4edaf19c47773162ea533ff4e3d6a9ca18  main.bbl
2b3fb0f8aa4c987bd3d3e8916bed1f7884df82bc5b4f5aeec8ccf49d68ba3306  main.pdf
```

### Source package and residual gate

`output/conic_paper/RL_CONIC_CRSC_MSCQ_Boluo_v03_source.zip` contains exactly `main.tex`, `references.bib`, `main.bbl`, `build.sh`, `README.md`, `DRAFT_LEDGER.md`, `BUILD_REPORT.md`, and `expert-result.yaml`. The separately delivered PDF, TeX cache, logs, and QA images are excluded. The archive is checked with `unzip -t`, and its eight uncompressed members are compared byte-for-byte with the final files.

No requested repair, compile, or layout blocker remains. The M01 version-of-record theorem comparison remains `PENDING_VERIFICATION`; the source and public prose retain the March 20, 2025 author-version limitation. Broader priority remains unverified. Scott's accurately cited v3 is retained; the existence of v5 and the Lourenco pinpoint provenance are recorded as nonblocking maintenance notes in `DRAFT_LEDGER.md`.

The orchestrator remains responsible for final saving and stage acceptance. This subtask performs no submission, external coordination, or SCI-stage transition.

Primary next action: the orchestrator reviews and accepts the bounded v0.3 repair package while preserving the final-version/priority gate.

---

## Historical v0.2 build report (superseded by the current record above)

### v0.2 outcome (historical snapshot)

The directed integration is complete. The current `main.pdf` has **19 A4 pages**, 430,874 bytes, author metadata `Boluo`, and 21 embedded/subsetted/Unicode-mapped font instances. The current `main.tex` has 1,453 lines. All 19 pages were rendered and individually visually inspected. No clipping, overlap, missing glyph, unreadable equation, or broken table was observed.

All five v0.2 reports were read completely before integration. The full-facial-CRCQ definition was additionally confirmed by the original boundary reviewer: Definition 3.1 in the reviewed author manuscript tests all faces of the reduced cone on one common neighborhood and separately requires reference adjoint-polar-image closedness. The apex identity reduction used here makes that closedness equivalent to the positive-dual formulation.

### Applied integration map

| Requirement | Current manuscript location | Result |
|---|---|---|
| NR-1: face amenability in C | Theorem 4.2, displayed face-residual hypothesis; Corollary 4.3 | Integrated, no independent-cone ambiguity |
| NR-2 and B3: complete universal quantifiers | Theorem 4.6 | Four equivalent properties; constants/radii may depend on system and face |
| NR-3: output-local reduction | Lemma 6.1 | Xi output neighborhood, local equivalence, positive Lipschitz bound, projection containment |
| NR-4: common neighborhood | End of Theorem 4.2 proof; Remark 4.4 | Nested charts, finite simultaneous restrictions, no numerical-radius inference |
| NR-5: degenerate cases | Theorem 3.3 proof, Lemma 4.1 proof, Remark 4.4 table | Full-face bounded lifts, identity chart, zero movement, zero-dimensional branch |
| B1 | Proposition 4.5 | Exact face inclusion, homogeneity, closed projection image, all-face common ranks |
| B2 | Proposition 5.1 | Properness, exposed face, entire feasible set, positive-part projection and epsilon-kappa contradiction |
| Counterexample evidence strength | Proposition 5.1 and final paragraph of Section 5 | True residual is positive O(t^5); only constructed upper bound has Theta(t^5) |
| E-SOC | Section 6.3 | Explicit adjoint image; normal closure; sigma/eta/tau; local theorem constant; independent ball repair |
| E-PSD | Section 6.4 | k>=3, fixed C0/D0, Frobenius norms, exact image/closure/constants; independent ball repair |
| Constant/radius distinction | Equations 6.6-6.7, 6.13-6.14 and Table 2 | General constants versus direct B_1/4 bounds kept separate |
| Verified references | Introduction, Table 1, tool attributions and 13 bibliography entries | All 12 core works M01-M12, plus the separately cited M01 author version |
| Short RL interface | Section 7 | Conditional gauge transfer only, no RL parameter or convergence theorem |

No new theory, cone class, algorithm, experiment, or source claim was introduced. The optional general-gauge paragraph from v0.1 was removed to keep the RL interface short. Internal portfolio/journal assessments and production placeholders are absent from the paper.

### Current compilation and QA

Execution command: `bash build.sh` from `output/conic_paper/latex_v01`.

The already generated workspace-local format and installed font maps were reused. Four pdfLaTeX passes and one BibTeX pass completed successfully, followed by system Poppler rendering/text extraction. One initial table underfull-box warning was repaired by ragged-right table columns; the complete final build was then rerun.

| Final check | Result |
|---|---|
| Build exit status | 0 |
| LaTeX or BibTeX warnings/errors | None |
| Undefined references/citations | None |
| Overfull/underfull boxes | None |
| Missing characters | None |
| Bibliography entries | 13, all cited; 12 works plus one separately preserved source version |
| Visible PENDING_CITATION / AUTHOR_INPUT_NEEDED markers | None; release gates moved to internal ledger |
| Visual QA | All pages 1-19 inspected individually using `qa/v02-01.jpg` through `qa/v02-19.jpg` |
| Page QA render command | `/usr/bin/pdftoppm -r 90 -jpeg main.pdf qa/v02` |
| Source archive | `output/conic_paper/RL_CONIC_CRSC_MSCQ_Boluo_v02_source.zip` |

The mathematical verification scripts were not rerun in this editorial task. Their prior reported evidence is described only as numerical lower-bound-ratio checks or deterministic sanity checks, not as certified true-residual calculations. Formal/general claims are supported by the explicit proofs and cited source findings.

### Current fingerprints

```text
0be99274c1d01c615e59578dd20c0f647dcbd65ef6145632ca4159aacc39385a  main.tex
14cf0474d90a34fa9c3aa4b89bf409446aca78975d31925823861fd1d4533ef5  references.bib
75cc4d3dd2cbc30c58722f5929c16e4edaf19c47773162ea533ff4e3d6a9ca18  main.bbl
18a8384e4c3e4addbea8abdb4c684823aaa0e5338d84a66dc47677b8b7bc4ccb  main.pdf
```

### Source package and residual gates

The source archive contains eight files: `main.tex`, `references.bib`, `main.bbl`, `build.sh`, `README.md`, `DRAFT_LEDGER.md`, `BUILD_REPORT.md`, and `expert-result.yaml`. It excludes generated format caches, page images, and the separately delivered PDF. `README.md` explains an ordinary TeX Live build and the current environment's local workaround. Archive integrity is checked with `unzip -t` after packaging.

There is **no remaining compile or identified mathematical integration blocker**. The final published M01 theorem text remains unavailable for comparison with the March 20, 2025 author manuscript. This is an unresolved final-version/priority release gate, not a reason to pretend the version comparison has been completed. The public prose is explicitly version-qualified and makes no first-result claim. Broader priority and previous exact CQ naming of the LRS adaptation remain unverified. Optional author metadata and any future RL convergence source are not needed for this bounded draft, which asserts neither.

Root coordination remains responsible for final deliverable saving and the SCI stage decision. No external upload, submission, author/editor contact, or stage mutation was performed by this editing subtask.

Primary next action: root review and accept the v0.2 handoff while preserving the unresolved final-version release gate.

---

## Historical v0.1 build report (superseded by the current record above)

Date: 2026-09-09. Draft state: v0.1, provisional. Stage authority remains with the SCI-Skills orchestrator.

## Outcome

`main.pdf` was compiled successfully from `main.tex` and `references.bib` and visually inspected on all 14 pages. The PDF is A4, 383,885 bytes, with author metadata `Boluo`. The supplied native spelling 菠萝 is retained in the LaTeX source comment; no unverified affiliation, email, funding, or coauthor was added.

Requested outputs:

- `main.tex`: complete English proof manuscript, 1,116 lines after a codomain clarification.
- `references.bib`: two deliberately sparse records containing only bibliographic fields explicitly supported by the four supplied source/audit files.
- `main.pdf`: successfully compiled 14-page draft.
- `BUILD_REPORT.md`: this report.

Supporting files:

- `DRAFT_LEDGER.md`: pre-drafting claim ledger, section contracts, missing items, terminology, and optional unrendered figure proposal.
- `build.sh`: reproducible workspace-local build and render command.
- `expert-result.yaml`: exact SCI expert return contract.
- `main.log`, `compile-pass-1.log` through `compile-pass-4.log`, `bibliography-build.log`: actual build evidence.
- `qa/page-01.png` through `qa/page-14.png`, `qa/last-page-14.jpg`, and `qa/main-layout.txt`: rendering/text QA evidence.
- `tex-cache/pdflatex.fmt`: local generated format cache, not a manuscript dependency to ship to an ordinary TeX installation.

## Evidence and execution status

`VERIFIED_USER_MATERIAL`: the four assigned inputs were read completely; no later-created agent audit or bibliography file was read or integrated into v0.1.

`AI_INFERENCE`: prose and complete proof reconstruction from the frozen, audited theorem package. This is not formal proof certification or a new independent priority search.

`EXECUTED_LOCAL`: PDF compilation, BibTeX processing, page rendering, layout text extraction, embedded-font inspection, warning checks, and SHA-256 calculation.

`PENDING_VERIFICATION`: final-version priority comparison, complete bibliographic fields for the nearest CRSC and Pataki papers, full facial CRCQ definition alignment, and exact external RL-PPA source.

## Build route and incidental runtime repairs

The PDF skill's artifact-start marker completed successfully exactly once before the first authoring patch.

Installed TeX executables were available, but this image lacked the generated TeX filename database, `pdflatex.fmt`, and aggregate `pdftex.map`. Default `kpsewhich` therefore did not find installed style files. The safe local workaround was:

1. Set the process-local `TEXMF` search roots to the already installed `/usr/share/texlive/texmf-dist`, `/usr/share/texmf`, and `/etc/texmf`, without database-only markers.
2. Generate `pdflatex.fmt` inside this task's `tex-cache` directory using the installed `pdflatex.ini`.
3. Load the installed Latin Modern, Computer Modern, and AMS symbol map files explicitly for the compilation process.
4. Run four pdfLaTeX passes with one BibTeX pass after the first TeX pass.

An initial unconfigured compile failed at font expansion because the aggregate font map was absent. That failure was repaired by the explicit map setup; the final compile succeeded.

The runtime's first Poppler wrapper could not locate its bundled `libpoppler.so.160`. Already installed `/usr/bin/pdfinfo`, `/usr/bin/pdftoppm`, `/usr/bin/pdftotext`, and `/usr/bin/pdffonts` worked and were used. No package installation, system-file edit, privilege escalation, network download, or external API was performed.

Reproduce in this environment:

```bash
bash /workspace/scratch/01cfe9a021bd/output/conic_paper/latex_v01/build.sh
```

In a normally configured TeX Live environment, the source is portable and may instead be built with the usual pdfLaTeX / BibTeX / pdfLaTeX sequence; the local cache workaround is environmental, not part of the mathematics.

## Quality checks

| Check | Result |
|---|---|
| Final pdfLaTeX exit status | PASS, 0 |
| Final LaTeX warnings | None |
| Undefined labels/citations | None |
| Overfull/underfull box warnings | None |
| Missing glyph warnings | None |
| Font embedding | All 20 listed font instances embedded, subsetted, and Unicode-mapped |
| Page count and size | 14 pages, A4 |
| Visual inspection | Pages 1-13 inspected as PNG; page 14 inspected as a fresh JPEG render after the image viewer rejected its valid PNG |
| Clipping/overlap/layout defects | None observed |
| Figure gate | No scientific figure rendered; only PDF QA page images |
| Source scope | Nice stability separated from amenable-face MSCQ; universal quantifiers explicit |
| Edge branches | F=0, F=C, rank=0, zero-dimensional reduction all explicit |
| Residuals | Original and reduced cone residuals kept distinct; LRS cone residual stated as upper bound |
| Joint inputs | SOC and PSD proofs use one common normal map and manifold |
| RL claims | Only conditional gauge transfer; no operator construction, RL parameters, Minty coverage, or rate claimed |

BibTeX reports one expected metadata warning: `empty year in lourencoAmenable`. The four assigned files did not supply a verified publication year for that entry. It was intentionally left unset instead of invented. Surname-only author fields are likewise deliberate sparse verified metadata awaiting the orchestrator's independently verified bibliography.

Visible provisional markers in the PDF: four `PENDING_CITATION` items and two `AUTHOR_INPUT_NEEDED` items. These are requested content markers, not unresolved LaTeX citations. They prevent treating this proof draft as submission-ready.

## v0.1 fingerprints

```text
ab4e315a4ff42b088f7bc6486dc26e8382c51ac4dd8fbc9b2267429a389e3ec7  main.tex
307b3c2017015847772c6fb40915cbfd38aa781ea4d201f948bcc4c287e4b5d7  references.bib
3e611a6b5759efad6553eef5b9786107b712e1217dfcc64c76ef3705dc9850db  main.pdf
```

## Limitations and handoff

The supplied source audits, not a fresh literature search in this subtask, support the bibliographic attributions. The missing final publication comparison remains a release gate. Internal portfolio rankings and journal acceptance judgments were not imported into the paper as scientific claims.

The main editor has not integrated messages or later files from the parallel proof/example/bibliography agents. The orchestrator must authorize that separate integration step. This subtask does not advance T4/T5 or initiate any submission. Final deliverable persistence and packaging are coordinated by the root task after integration, avoiding duplicate provisional exports.

## One next action

Await the orchestrator's controlled integration request for v0.1.
