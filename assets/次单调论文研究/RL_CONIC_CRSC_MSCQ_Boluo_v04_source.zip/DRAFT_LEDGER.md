# RL-CONIC-2026 / MW-MASTER-V04: author-name correction ledger

## v0.4 exact author-name correction (current)

Date: 2026-09-09. The author explicitly requires the PDF-visible name to be exactly **菠萝**. This instruction supersedes the earlier choice of Boluo for the visible author line. Both the visible name and PDF author metadata are now 菠萝; no affiliation, email, funding, or coauthor is added.

The repair uses the existing pdfLaTeX engine and a small subset of the runtime's built-in CJK font. The subset, encoding, and metrics are bundled with the source, along with an optional regeneration script and provenance note. No system font is installed and no mathematical source is changed. The entire document body and the bibliography are byte-for-byte identical to the v0.3 source archive. Version identifiers in the preamble now read v0.4.

The deliverable is `output/conic_paper/RL_CONIC_CRSC_MSCQ_菠萝_v04.pdf`; the portable source archive retains the authorized ASCII filename `RL_CONIC_CRSC_MSCQ_Boluo_v04_source.zip`. The v0.3 PDF and source ZIP remain intact under their original names.

Verification includes PDF metadata, Unicode text extraction, native font embedding, full 20-page visual QA, and a separate reviewer's confirmation of the visible name. The existing M01 final-version and priority reservations are unchanged and do not block this author-name correction. Current execution details are in `BUILD_REPORT.md`.

Primary next action: return the author-corrected v0.4 files to the orchestrator for delivery.

---

## Historical v0.3 repair ledger (author display superseded above)

### v0.3 authorized scope and repair map (historical)

Date: 2026-09-09. This is a bounded manuscript repair under the existing T4-to-T5 provisional drafting authority. The four final v0.2 red-team reports were read completely: `FINAL_MATH_REDTEAM_V02.md`, `FINAL_COMMUNICATION_REDTEAM_V02.md`, `FINAL_BOUNDARY_REDTEAM_V02.md`, and `FINAL_CITATION_REDTEAM_V02.md`. No new theory, example, numerical experiment, source, or stage transition is authorized or introduced.

| Finding | v0.3 disposition | Scope preserved |
|---|---|---|
| FM-M01 | Lemma 4.1 explicitly inherits the standing hypotheses of Section 3, names proper nice C and frozen minimal-face CRSC, and points to the common manifold of Lemma 3.5 | Restores the approved lemma's hypothesis scope; does not change its proof or constant |
| FM-m01 / MINOR-COMM-01 | The tangent-space sentence now names d0, not an ambiguous output-vector antecedent | Input/output spaces kept distinct |
| FM-m02 | Proposition 4.5 expressly limits global A1/A2 to the same niceness assumption | General closed-cone metric equivalence remains general |
| MAJOR-COMM-01 | Three numbered main results precede the closest-results discussion and point to the relevant theorems/corollaries | Universal statements remain over all admissible apex systems for one fixed proper nice cone |
| MAJOR-COMM-02 | Section 7 is a neutral regularity and residual-transfer interface; undefined RL-PPA and the unlocated verified-analysis assertion are removed | Same local zero set plus an independently supplied residual comparison gives the displayed local error bound and composite gauge; no convergence conclusion |
| Optional local clarity | Shortened abstract ending; shorter organization paragraph; one-sentence purpose for the examples; unscaled-output projection wording; precise final error-bound row in Table 2; flexible Table 1 placement | No new result, radius, or numerical claim |
| Final boundary review | No mandatory repair; retains actual positive residual O(t^5), full feasible-set projection, and epsilon-kappa failure | No true-residual Theta(t^5) or certified-distance claim |
| Final citation review | references.bib remains byte-for-byte unchanged, with 13 version-specific records for 12 works | No new citation or version substitution |

### Current evidence and remaining gates

- `VERIFIED_USER_MATERIAL`: the four final reports and the exact v0.2 source state. Their external source-verification findings are attributed to those reports; this editing task performs no fresh literature search.
- `AI_INFERENCE`: the local wording changes implement the authorized repairs without extending theorem scope.
- `PENDING_VERIFICATION / PRIORITY-VOR-ACCESS`: the M01 final published theorem text is still unavailable for comparison with the March 20, 2025 author manuscript. Version-limited comparison remains in the public prose; no global-priority claim is made.
- `PENDING_VERIFICATION`: broader priority and prior use of the exact full-facial-CRCQ formulation for the LRS adaptation remain unverified.
- Nonblocking citation maintenance: the final citation report verifies that Scott v5 exists with a changed title. The correctly cited v3 is intentionally retained under the no-new-citation/no-version-change scope of this repair.
- Nonblocking pinpoint provenance: Lourenco Proposition 12 is supported by its accessible author text and the cross-reference in the LRS published-format text; the editor does not claim to have read Lourenco's own final publisher text.
- The neutral residual-transfer section remains mathematically available to future RL work if that work supplies the operator, zero-set equivalence, residual comparison, and independent algorithmic assumptions. It asserts no completed or separately verified RL application.
- Boluo / 菠萝 remains the directly authorized author identity. No affiliation, email, funding, or coauthor is inferred.
- Build execution, the full-page visual inspection, targeted regression, and source-package integrity are recorded in the current section of `BUILD_REPORT.md`.

Primary next action: return the v0.3 repair package to the orchestrator for bounded acceptance while preserving the unresolved final-version/priority gate.

---

## v0.2 historical directed integration ledger (superseded where repaired above)

## v0.2 pre-edit integration contract

Date: 2026-09-09. The orchestrator authorized integration of exactly these five complete reports, all now read by the editor:

1. `output/conic_paper/T4_argument_architecture.md`
2. `output/conic_paper/CORE_PROOF_AUDIT.md`
3. `output/conic_paper/BOUNDARY_COUNTEREXAMPLE_AUDIT.md`
4. `output/conic_paper/PRIORITY_EVIDENCE_MATRIX.md`
5. `output/conic_paper/EXAMPLES_AND_CONSTANTS_AUDIT.md`

These reports are `VERIFIED_USER_MATERIAL` in this editing task. Their source owners' direct verification is preserved as attributed audit evidence, not represented as fresh browsing by the editor. The changes below integrate already audited results and add no theory.

| ID | Authorized change | Acceptance condition |
|---|---|---|
| NR-1 | Leading face-level MSCQ theorem with F amenable **in C** | Display the face-residual inequality; whole-cone version remains a corollary |
| NR-2 / B3 | All spaces/maps/reference points; map-dependent constants and radii; equivalent full-CRCQ property | No uniform modulus, common radius across systems, or fixed input dimension |
| NR-3 | Formal output-local residual-transfer lemma | Xi on output neighborhood; Xi(ybar)=0; output-set equivalence; local Lipschitz bound; nearest-point containment |
| NR-4 | Uniform nested charts and local-constant qualification | An explicit constant formula is not an explicit validity radius |
| NR-5 | Full-face bounded dual lifts and degeneracy summary | Identity chart for rank zero; no movement for zero face residual |
| B1 | General isometric face-inclusion proposition | All-face ranks plus closed adjoint image, not constant derivative alone |
| B2 | Properness, exposed face, entire feasible set, positive-part projection, epsilon-kappa failure | Actual residual is positive O(t^5); only the constructed upper bound is Theta(t^5) |
| E-SOC | Joint model and full audited constants | General kappa=4+26sqrt(2), unspecified smaller radius; direct 5/(4sqrt(2)) on B_1/4 |
| E-PSD | k>=3, C0=[e1,e2], D0=[e2,e3], Frobenius products | General kappa=4+56sqrt(k), unspecified smaller radius; direct 5/4 on B_1/4 |
| LIT | All 12 verified core works and separate M01 author-version citation | Exact verified fields only; no invented volume/page/DOI information |
| RL | Short conditional gauge-transfer section | No rates, operator construction, or RL parameters |

### Internal gates and conflict dispositions

- `PENDING_VERIFICATION / PRIORITY-VOR-ACCESS`: M01 final published theorem text was not obtained. The March 20, 2025 author manuscript retains A1/A2; the VOR may differ. Public comparison is version-qualified, with no first-result claim.
- `PENDING_VERIFICATION`: worldwide priority and prior use of the exact facial-CRCQ naming for the LRS adaptation remain unverified.
- `CF-A1`: proof audit, drafting completion, and final-source priority are separate gates. No stage is changed.
- `CF-A2`: the root authorized face-level MSCQ followed by whole-cone corollary.
- `CF-A3`: portfolio ratings and journal tiers stay outside the paper.
- `CF-A4`: resolved by BOUNDARY/PRIORITY: LRS Proposition 5.1 gives niceness, Proposition 5.2 nonamenability, Theorem 5.3 existence.
- Author-name discrepancy: the direct task supplies `Boluo / 菠萝`, which governs over the architecture's no-romanization assumption. Printed author remains Boluo; native spelling remains in source; no additional metadata.
- Hyperbolicity discrepancy: no extra hyperbolic example or corollary is inserted; the two audited positive models suffice for the frozen task.
- Scripts: floating-point values are only **numerical lower-bound-ratio checks**, with denominator the constructed residual upper bound, not the true cone residual. No interval certification. Original scripts are neither changed nor rerun in this editing task.
- `AUTHOR_INPUT_NEEDED` before unconditional priority release: lawful M01 final theorem pages and a version-difference check. Optional real author metadata remains optional, not fabricated.

### Updated section contracts

Retain the v0.1 section order. Add version-qualified grouped related work and a compact nearest-hypothesis table; define full facial CRCQ in the apex setup; integrate B1/B3 with explicit quantifiers; expand uniform-neighborhood and degeneracy explanations; adopt B2; include exact closed images, projection closures, fixed norms/parameters, general constants, and separate B_1/4 direct repairs in the two examples; formalize reduction transfer; shorten RL; remove internal production instructions from the mathematical narrative. All unresolved gates remain in this ledger. No figure is rendered; page images are QA-only.

---

## v0.1 historical ledger (preserved)

Date: 2026-09-09. Author supplied as Boluo / 菠萝. This is T4-to-T5 provisional drafting, not a stage acceptance or submission decision.

## Scope and inputs

Only these four project inputs were read for v0.1:

1. `output/ATTACK_PRODUCT_CONE_CRSC_MSCQ.md`, complete.
2. `output/AUDIT_GENERAL_NICE_CONE_CRSC_MSCQ_RANK_SANDWICH.md`, complete.
3. `output/JOURNAL_PRIORITY_AUDIT_GENERAL_AMENABLE_CRSC_MSCQ.md`, complete.
4. `output/PORTFOLIO_FINAL_UPDATE_AFTER_AMENABLE_THEOREM.md`, complete.

The manuscript is a theoretical paper for conic-optimization and variational-analysis readers. The research question is when a frozen minimal-face constant-rank condition controls nearby geometry and the original cone residual. No datasets, numerical results, new cone constructions, algorithm rates, or journal acceptance claims are authorized.

## Claim ledger created before result-bearing prose

| ID | Allowed claim | Evidence and boundary |
|---|---|---|
| C1 | Nice + frozen minimal-face CRSC gives a fixed-subspace rank sandwich | ATTACK §§2-3; AUDIT §§2-3; C1 data only; reference adjoint image must be closed |
| C2 | Same assumptions give full-neighborhood closed images and minimal-face stability | ATTACK §4; AUDIT §4 and §6A; fixed reference face, not a moving rank hypothesis |
| C3 | Same assumptions give quantitative correction to the common face manifold and local facial reduction | ATTACK Lemmas 4.2-4.3 and Cor. 4.4; AUDIT §6A; closure of projected cone retained |
| C4 | Nice + amenability of the reference face gives MSCQ and the stated local upper bound | ATTACK §5; AUDIT §§6/6A; entire-cone amenability is sufficient, not necessary for one map |
| C5 | Within proper nice cones, amenability is equivalent to universal apex CRSC-to-MSCQ | ATTACK §7; AUDIT §6A; quantified over all maps, not pointwise CQ equivalence |
| C6 | Published LRS cone gives a linear full-facial-rank/CRCQ counterexample | ATTACK §7.2; AUDIT §5; cone and original tangency are attributed, not claimed new |
| C7 | Product and PSD examples satisfy joint CRSC and have the displayed feasible sets | ATTACK §6; AUDIT §6A; no blockwise input error-bound inference |
| C8 | A fixed valid local reduction transfers the residual in the one needed direction | ATTACK §§2/5; AUDIT §7; no automatic nonapex reduction for every amenable cone |
| C9 | RL receives only a regularity gauge after independent residual comparison | ATTACK §10; PORTFOLIO §6; no RL parameters, PPA operator, Minty coverage, or rate follows |

Status: supplied mathematical audit supports C1-C9 as `VERIFIED_USER_MATERIAL` plus mathematical reasoning (`AI_INFERENCE`), not formal proof certification. Bibliographic and final-version verification are separate gates.

## Section contracts

| Section | Purpose and sequence | Completion check / prohibited claim |
|---|---|---|
| Title/abstract | State fixed-face condition, geometric result, metric result, universal boundary | No first-ever or all-nice MSCQ wording |
| Introduction | Problem; nearest facial-reduction work; amenability distinction; coherent contribution | Imported tools and LRS geometry attributed; final-version gate visible |
| Preliminaries | Euclidean setup, proper cone, dual, fixed face, CRSC, imported criterion | All symbols frozen; positive-dual signs; MSCQ defined |
| Nice-cone chain | Rank sandwich; kernel continuity; A1/A2; angle; normal correction; reduction | F=0, F=C, rank=0 handled |
| Metric chain | Relative correction; minimal-face amenability; constants; universal characterization | Same input manifold throughout; constants local and nonoptimal |
| Boundary | Linear face inclusion; attributed four-dimensional witness | Exact distance and upper-bound residual distinguished |
| Scope/examples | Output product calculus; PSD face constant; coupled SOC/PSD examples; fixed reductions | No new cone-class theorem or automatic nonapex reducibility claim |
| RL interface | Constraint relation; independently supplied comparison; general gauge | No unproved algorithm theorem |
| Limitations/conclusion | State verified scope and release gates; answer original question | No new result introduced in conclusion |

## Unresolved placeholders

- `PENDING_CITATION`: full final bibliographic record and version-of-record theorem comparison for the nearest minimal-face CRSC paper.
- `PENDING_CITATION`: complete Pataki record and exact formal reference for the imported closed-image theorem (the theorem content is reproduced from the supplied audited materials).
- `PENDING_CITATION`: supplement the sparse verified bibliography with the separately verified source ledger at orchestrator integration.
- `AUTHOR_INPUT_NEEDED`: publication name choice/romanization, affiliation/contact only if the author elects to supply them; none invented.
- `AUTHOR_INPUT_NEEDED`: final-version PDF or lawful theorem-level comparison before unconditional priority wording.
- `AUTHOR_INPUT_NEEDED`: exact RL-PPA source and its independent operator hypotheses before any external RL citation or convergence claim.

## Terminology and figure proposals

Use “frozen minimal-face CRSC,” “amenability of the reference face,” “full-neighborhood stability,” and “local upper bound.” Reserve “universal” for the quantifier over every admissible input map. Use a different calligraphic operator symbol for RL to avoid confusing it with the minimal face F.

No figure is rendered. Optional exact location: after the normal-correction lemma, a two-panel explanatory figure could show the common manifold and the within-face correction. It would require author approval and a clearly schematic construction; the proof and a short equation chain already carry the needed information. No scientific-result plot is needed.

## One next action

Return v0.1 to the orchestrator for controlled integration of separately verified citations and review findings; do not advance the SCI stage.
